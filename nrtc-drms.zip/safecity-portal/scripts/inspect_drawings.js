const fs = require('fs');
const path = require('path');

// 1. Workbook sheets
const wbXml = fs.readFileSync('temp_emp_unzip/xl/workbook.xml', 'utf8');
console.log('--- Workbook sheets ---');
const sheetRegex = /<sheet\s+name="([^"]+)"\s+sheetId="(\d+)"\s+r:id="([^"]+)"/g;
let m;
const sheetList = [];
while ((m = sheetRegex.exec(wbXml)) !== null) {
  console.log(`  Name: "${m[1]}" | sheetId: ${m[2]} | rId: ${m[3]}`);
  sheetList.push({ name: m[1], sheetId: m[2], rId: m[3] });
}

// 2. Workbook rels
const wbRels = fs.readFileSync('temp_emp_unzip/xl/_rels/workbook.xml.rels', 'utf8');
console.log('\n--- Workbook rels ---');
const relRegex = /Id="([^"]+)"\s+Type="([^"]+)"\s+Target="([^"]+)"/g;
const rIdToTarget = {};
while ((m = relRegex.exec(wbRels)) !== null) {
  rIdToTarget[m[1]] = m[3];
  console.log(`  ${m[1]} -> ${m[3]}`);
}

// Map each sheet name to its file
sheetList.forEach(s => {
  s.target = rIdToTarget[s.rId];
  console.log(`Sheet "${s.name}" is at xl/${s.target}`);
});

// Check worksheets _rels
const wsDir = 'temp_emp_unzip/xl/worksheets/_rels';
if (fs.existsSync(wsDir)) {
  fs.readdirSync(wsDir).forEach(f => {
    console.log(`\n--- Worksheet rels: ${f} ---`);
    const c = fs.readFileSync(path.join(wsDir, f), 'utf8');
    console.log(c);
  });
}
