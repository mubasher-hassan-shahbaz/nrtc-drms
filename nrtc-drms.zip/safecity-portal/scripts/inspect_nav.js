const fs = require('fs');

fs.readdirSync('.').filter(f => f.endsWith('.html')).forEach(f => {
  const content = fs.readFileSync(f, 'utf8');
  const m = content.match(/<nav class="sidebar-nav"[\s\S]*?<\/nav>/i);
  if (m) {
    const items = m[0].split('<a ').slice(1).map(x => {
      const h = (x.match(/href="([^"]*)"/) || [])[1];
      const text = x.replace(/<[^>]*>/g, '').trim().split('\n')[0].trim();
      const isActive = x.includes('class="active"') || x.includes("class='active'");
      return `${h} (${text})${isActive ? ' [ACTIVE]' : ''}`;
    });
    console.log(`=== ${f} (${items.length} items) ===`);
    console.log(items.join('\n'));
    console.log('');
  } else {
    console.log(`=== ${f} (NO NAV) ===\n`);
  }
});
