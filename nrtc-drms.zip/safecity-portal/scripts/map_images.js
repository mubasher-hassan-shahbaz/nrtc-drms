const fs = require('fs');
const path = require('path');
const xlsx = require('xlsx');

const xml = fs.readFileSync('temp_emp_unzip/xl/drawings/drawing1.xml', 'utf8');
const rels = fs.readFileSync('temp_emp_unzip/xl/drawings/_rels/drawing1.xml.rels', 'utf8');

// Parse rels: rId -> target (../media/image1.jpeg)
const relMap = {};
const relRegex = /Id="(rId\d+)"\s+Type=".*?"\s+Target="(.*?)"/g;
let m;
while ((m = relRegex.exec(rels)) !== null) {
  relMap[m[1]] = m[2].replace('../media/', '');
}
console.log('Total rels mapped:', Object.keys(relMap).length);

// In drawing1.xml, each twoCellAnchor has <xdr:from><xdr:row>ROW</xdr:row>... and <a:blip r:embed="rId..."
const anchorRegex = /<xdr:from>[\s\S]*?<xdr:row>(\d+)<\/xdr:row>[\s\S]*?<a:blip\s+[^>]*?r:embed="(rId\d+)"/g;
const rowToImg = {};
let count = 0;
while ((m = anchorRegex.exec(xml)) !== null) {
  const rowIdx = parseInt(m[1], 10); // 0-indexed row in sheet
  const rId = m[2];
  const imgFile = relMap[rId];
  rowToImg[rowIdx] = imgFile;
  count++;
}

console.log('Total row anchors matched:', count);
console.log('Sample rowToImg mappings (first 10):', Object.entries(rowToImg).slice(0, 10));

// Create assets/employees directory and copy images
const targetImgDir = path.join(__dirname, '../assets/employees');
if (!fs.existsSync(targetImgDir)) {
  fs.mkdirSync(targetImgDir, { recursive: true });
}

// Copy all images
const mediaDir = 'temp_emp_unzip/xl/media';
const mediaFiles = fs.readdirSync(mediaDir);
mediaFiles.forEach(f => {
  fs.copyFileSync(path.join(mediaDir, f), path.join(targetImgDir, f));
});
console.log(`Copied ${mediaFiles.length} employee images to assets/employees/`);

// Save mapping
fs.writeFileSync(path.join(__dirname, '../data/row_to_image_map.json'), JSON.stringify(rowToImg, null, 2));
