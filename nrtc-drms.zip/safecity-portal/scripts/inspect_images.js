const fs = require('fs');
const XLSX = require('xlsx');

const xml = fs.readFileSync('./temp_emp_unzip/xl/drawings/drawing1.xml', 'utf8');
const rels = fs.readFileSync('./temp_emp_unzip/xl/drawings/_rels/drawing1.xml.rels', 'utf8');

const relMap = {};
const relRegex = /Id="([^"]+)"[^>]*Target="([^"]+)"/g;
let m;
while ((m = relRegex.exec(rels)) !== null) {
  relMap[m[1]] = m[2].replace('../media/', '');
}

const wb = XLSX.readFile('C:/Users/mubas/.gemini/antigravity/brain/786d803e-4a56-4256-8e0f-49f9457a89ad/.user_uploaded/media_1790697626668.xlsx');
const ws = wb.Sheets['Personal details'];
const data = XLSX.utils.sheet_to_json(ws, { header: 1 });

const anchorRegex = /<xdr:(twoCellAnchor|oneCellAnchor)[^>]*>([\s\S]*?)<\/xdr:\1>/g;
const anchors = [];
while ((m = anchorRegex.exec(xml)) !== null) {
  const content = m[2];
  const fromRow = content.match(/<xdr:from>[\s\S]*?<xdr:row>(\d+)<\/xdr:row>/);
  const fromCol = content.match(/<xdr:from>[\s\S]*?<xdr:col>(\d+)<\/xdr:col>/);
  const toRow = content.match(/<xdr:to>[\s\S]*?<xdr:row>(\d+)<\/xdr:row>/);
  const toCol = content.match(/<xdr:to>[\s\S]*?<xdr:col>(\d+)<\/xdr:col>/);
  const blip = content.match(/r:embed="([^"]+)"/);
  if (fromRow && blip) {
    const fR = parseInt(fromRow[1]);
    const fC = fromCol ? parseInt(fromCol[1]) : 0;
    const tR = toRow ? parseInt(toRow[1]) : fR;
    const tC = toCol ? parseInt(toCol[1]) : fC;
    const img = relMap[blip[1]];
    anchors.push({ fromRow: fR, toRow: tR, fromCol: fC, toCol: tC, img });
  }
}

console.log('Total anchors found:', anchors.length);

anchors.sort((a, b) => a.fromRow - b.fromRow);

anchors.slice(0, 20).forEach(a => {
  const rowData = data[a.fromRow] || [];
  console.log(`FromRow: ${a.fromRow}, ToRow: ${a.toRow}, Img: ${a.img}, Person at row ${a.fromRow}: [${rowData[1]}] ${rowData[2]} (${rowData[3]})`);
});
