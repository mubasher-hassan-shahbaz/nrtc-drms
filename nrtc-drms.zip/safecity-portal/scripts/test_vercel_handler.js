const handler = require('../api/index.js');
const { EventEmitter } = require('events');

function createMockReq(url, method, body, headers = {}) {
  const req = new EventEmitter();
  req.url = url;
  req.method = method;
  req.headers = { 'content-type': 'application/json', ...headers };
  req.body = body;
  req.query = {};
  if (url.includes('?')) {
    const qs = url.split('?')[1];
    const sp = new URLSearchParams(qs);
    for (const [k, v] of sp.entries()) {
      req.query[k] = v;
    }
  }
  return req;
}

function createMockRes() {
  const res = {
    statusCode: 200,
    headers: {},
    body: '',
    setHeader(k, v) { this.headers[k] = v; },
    getHeader(k) { return this.headers[k]; },
    status(code) { this.statusCode = code; return this; },
    json(data) {
      this.body = JSON.stringify(data);
      if (this.onEnd) this.onEnd(this.statusCode, data);
    },
    send(data) {
      this.body = data;
      if (this.onEnd) this.onEnd(this.statusCode, data);
    },
    end(data) {
      if (data) this.body = data;
      if (this.onEnd) this.onEnd(this.statusCode, this.body);
    }
  };
  return res;
}

function testRequest(url, method, body, headers = {}) {
  return new Promise((resolve) => {
    const req = createMockReq(url, method, body, headers);
    const res = createMockRes();
    res.onEnd = (status, data) => resolve({ status, data });
    handler(req, res);
  });
}

async function run() {
  console.log('--- TESTING VERCEL SERVERLESS HANDLER SIMULATION ---');

  // Test 1: Vercel rewrite with __route=auth/login
  const res1 = await testRequest('/api/index.js?__route=auth/login', 'POST', { username: 'admin', password: 'password123' });
  console.log('Test 1 (Vercel __route rewrite):', res1.status, res1.data.success ? `✓ Login successful for: ${res1.data.user.name}` : res1.data);

  // Test 2: Direct /api/auth/login
  const res2 = await testRequest('/api/auth/login', 'POST', { username: 'finance_admin', password: 'password123' });
  console.log('Test 2 (Direct /api/auth/login):', res2.status, res2.data.success ? `✓ Login successful for: ${res2.data.user.name}` : res2.data);

  // Test 3: Vercel rewrite with __route=districts
  const res3 = await testRequest('/api/index.js?__route=districts', 'GET', null);
  console.log('Test 3 (Districts via __route rewrite):', res3.status, Array.isArray(res3.data) ? `✓ Districts count: ${res3.data.length}` : res3.data);

  // Test 4: Vercel with x-matched-path header
  const res4 = await testRequest('/api/index.js', 'GET', null, { 'x-matched-path': '/api/employees' });
  console.log('Test 4 (Employees via x-matched-path):', res4.status, Array.isArray(res4.data) ? `✓ Employees count: ${res4.data.length}` : res4.data);

  console.log('--- ALL SIMULATION TESTS PASSED ---');
  process.exit(0);
}

run().catch(e => {
  console.error(e);
  process.exit(1);
});
