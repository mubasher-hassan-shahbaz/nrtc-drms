const fs = require('fs');
const xlsx = require('xlsx');

// 1. Read sheet4 (Personal details)
const wb = xlsx.readFile('C:/Users/mubas/.gemini/antigravity/brain/786d803e-4a56-4256-8e0f-49f9457a89ad/.user_uploaded/media_1790697626668.xlsx');
const ws = wb.Sheets['Personal details'];
const raw = xlsx.utils.sheet_to_json(ws, { header: 1 });

console.log('Total rows in Personal details:', raw.length);

// 2. Read drawing1.xml and drawing1.xml.rels
const xml = fs.readFileSync('temp_emp_unzip/xl/drawings/drawing1.xml', 'utf8');
const rels = fs.readFileSync('temp_emp_unzip/xl/drawings/_rels/drawing1.xml.rels', 'utf8');

const relMap = {};
const relRegex = /Id="([^"]+)"\s+Type="[^"]*"\s+Target="([^"]+)"/g;
let m;
while ((m = relRegex.exec(rels)) !== null) {
  relMap[m[1]] = m[2].replace('../media/', '');
}

// In drawing1.xml, find all twoCellAnchor and oneCellAnchor
// Each anchor has <xdr:from><xdr:col>C</xdr:col><xdr:colOff>...</xdr:colOff><xdr:row>R</xdr:row>...
// and <a:blip r:embed="rId..."
const anchorRegex = /<xdr:twoCellAnchor[\s\S]*?<xdr:from>[\s\S]*?<xdr:col>(\d+)<\/xdr:col>[\s\S]*?<xdr:row>(\d+)<\/xdr:row>[\s\S]*?<a:blip\s+[^>]*?r:embed="(rId\d+)"[\s\S]*?<\/xdr:twoCellAnchor>/g;

const anchors = [];
while ((m = anchorRegex.exec(xml)) !== null) {
  const col = parseInt(m[1], 10);
  const row = parseInt(m[2], 10);
  const rId = m[3];
  const img = relMap[rId];
  anchors.push({ col, row, rId, img });
}

console.log('Total twoCellAnchors found:', anchors.length);

// Also check oneCellAnchor if any
const oneCellRegex = /<xdr:oneCellAnchor[\s\S]*?<xdr:from>[\s\S]*?<xdr:col>(\d+)<\/xdr:col>[\s\S]*?<xdr:row>(\d+)<\/xdr:row>[\s\S]*?<a:blip\s+[^>]*?r:embed="(rId\d+)"[\s\S]*?<\/xdr:oneCellAnchor>/g;
while ((m = oneCellRegex.exec(xml)) !== null) {
  const col = parseInt(m[1], 10);
  const row = parseInt(m[2], 10);
  const rId = m[3];
  const img = relMap[rId];
  anchors.push({ col, row, rId, img, type: 'oneCell' });
}

console.log('Total anchors total:', anchors.length);

// Print first 20 anchors and the corresponding sheet row data
anchors.slice(0, 25).forEach((a, i) => {
  const sheetRow = raw[a.row];
  console.log(`Anchor ${i+1}: sheetRow[${a.row}] (0-based) -> Img: ${a.img}, Col: ${a.col}`);
  if (sheetRow) {
    console.log(`    Data at row ${a.row}: Sr=${sheetRow[0]}, ID=${sheetRow[1]}, Name=${sheetRow[2]}, Desig=${sheetRow[3]}, Duty=${sheetRow[4]}`);
  } else {
    console.log(`    Data at row ${a.row}: [EMPTY/UNDEFINED]`);
  }
});
