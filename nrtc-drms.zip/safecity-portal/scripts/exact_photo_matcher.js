const fs = require('fs');
const xlsx = require('xlsx');

// 1. Read sheet4 row heights
const sheetXml = fs.readFileSync('temp_emp_unzip/xl/worksheets/sheet4.xml', 'utf8');
let defaultHt = 65.1;
const defMatch = sheetXml.match(/defaultRowHeight="([\d.]+)"/);
if (defMatch) defaultHt = parseFloat(defMatch[1]);

const rowHtRegex = /<row\s+[^>]*?r="(\d+)"(?:[^>]*?ht="([\d.]+)")?[^>]*?>/g;
let m;
const rowHeights = {};
let maxRow = 152;
while ((m = rowHtRegex.exec(sheetXml)) !== null) {
  const r = parseInt(m[1], 10);
  const ht = m[2] ? parseFloat(m[2]) : defaultHt;
  rowHeights[r] = ht;
  if (r > maxRow) maxRow = r;
}

// Calculate rowTopEmu (1-based row index in Excel)
// In OpenXML drawing, xdr:row is 0-indexed! So xdr:row = 0 means row 1 in Excel.
const rowTopEmu = {};
let cumulativeEmu = 0;
for (let r = 0; r <= maxRow + 5; r++) {
  rowTopEmu[r] = cumulativeEmu;
  const ht = rowHeights[r + 1] !== undefined ? rowHeights[r + 1] : defaultHt;
  cumulativeEmu += Math.round(ht * 12700);
}

// 2. Read drawings & rels
const xml = fs.readFileSync('temp_emp_unzip/xl/drawings/drawing1.xml', 'utf8');
const rels = fs.readFileSync('temp_emp_unzip/xl/drawings/_rels/drawing1.xml.rels', 'utf8');

const relMap = {};
const relRegex = /Id="([^"]+)"\s+Type="[^"]*"\s+Target="([^"]+)"/g;
while ((m = relRegex.exec(rels)) !== null) {
  relMap[m[1]] = m[2].replace('../media/', '');
}

const twoCellRegex = /<xdr:twoCellAnchor[\s\S]*?<xdr:from>[\s\S]*?<xdr:col>(\d+)<\/xdr:col>[\s\S]*?<xdr:colOff>(\d+)<\/xdr:colOff>[\s\S]*?<xdr:row>(\d+)<\/xdr:row>[\s\S]*?<xdr:rowOff>(\d+)<\/xdr:rowOff>[\s\S]*?<a:blip\s+[^>]*?r:embed="(rId\d+)"[\s\S]*?<\/xdr:twoCellAnchor>/g;

const anchors = [];
while ((m = twoCellRegex.exec(xml)) !== null) {
  const fromCol = parseInt(m[1], 10);
  const fromColOff = parseInt(m[2], 10);
  const fromRow = parseInt(m[3], 10);
  const fromRowOff = parseInt(m[4], 10);
  const rId = m[5];
  const img = relMap[rId];
  
  const absY = (rowTopEmu[fromRow] || 0) + fromRowOff;
  anchors.push({ fromRow, fromRowOff, absY, img, rId });
}

// Find matching row for each anchor
// We want to find the Excel 0-based row where absY falls:
// rowTopEmu[r] <= absY < rowTopEmu[r+1]
const wb = xlsx.readFile('C:/Users/mubas/.gemini/antigravity/brain/786d803e-4a56-4256-8e0f-49f9457a89ad/.user_uploaded/media_1790697626668.xlsx');
const raw = xlsx.utils.sheet_to_json(wb.Sheets['Personal details'], { header: 1 });

const rowToExactImage = {};
anchors.forEach(a => {
  // Find which row's vertical bounds contain absY + center offset
  // A photo has height, its top is absY. Let's find r such that absY is closest to rowTopEmu[r]
  let bestRow = 0;
  let minDiff = Infinity;
  for (let r = 0; r <= maxRow; r++) {
    // Check if absY is within this row
    const rTop = rowTopEmu[r];
    const rBottom = rowTopEmu[r + 1];
    if (a.absY >= rTop - 50000 && a.absY < rBottom) {
      bestRow = r;
      break;
    }
  }
  
  rowToExactImage[bestRow] = a.img;
  const sheetData = raw[bestRow];
  console.log(`Anchor (absY=${a.absY}) -> Row ${bestRow}: ${a.img} | Name: "${sheetData ? sheetData[2] : 'N/A'}" | Desig: "${sheetData ? sheetData[3] : 'N/A'}"`);
});

console.log('\nTotal mapped rows:', Object.keys(rowToExactImage).length);
