const fs = require('fs');
const path = require('path');

const dir = path.join(__dirname, '..');
const htmlFiles = fs.readdirSync(dir).filter(f => f.endsWith('.html'));

let updatedCount = 0;

htmlFiles.forEach(file => {
  const filePath = path.join(dir, file);
  let content = fs.readFileSync(filePath, 'utf8');
  const orig = content;

  // Pattern for nav-fin-tab-expenses
  content = content.replace(/<a\s+[^>]*id="nav-fin-tab-expenses"[^>]*>/gi, () => {
    return `<a href="finance.html?tab=expenses" id="nav-fin-tab-expenses" onclick="if(window.location.pathname.toLowerCase().endsWith('finance.html') && window.switchFinanceTab){ switchFinanceTab('expenses'); return false; }">`;
  });

  // Pattern for nav-fin-tab-queries
  content = content.replace(/<a\s+[^>]*id="nav-fin-tab-queries"[^>]*>/gi, () => {
    return `<a href="finance.html?tab=queries" id="nav-fin-tab-queries" onclick="if(window.location.pathname.toLowerCase().endsWith('finance.html') && window.switchFinanceTab){ switchFinanceTab('queries'); return false; }">`;
  });

  if (content !== orig) {
    fs.writeFileSync(filePath, content, 'utf8');
    updatedCount++;
    console.log(`Updated navigation in ${file}`);
  }
});

console.log(`Successfully updated ${updatedCount} files.`);
