const xlsx = require('xlsx');
const path = require('path');
const fs = require('fs');

const fPath = 'C:/Users/mubas/.gemini/antigravity/brain/786d803e-4a56-4256-8e0f-49f9457a89ad/.user_uploaded/media_1790697626668.xlsx';
const wb = xlsx.readFile(fPath);

console.log('Sheets:', wb.SheetNames);
wb.SheetNames.forEach(name => {
  const ws = wb.Sheets[name];
  const json = xlsx.utils.sheet_to_json(ws, { header: 1 });
  console.log('\n--- Sheet [' + name + '] (' + json.length + ' rows) ---');
  for (let i = 0; i < Math.min(10, json.length); i++) {
    console.log('Row ' + i + ':', JSON.stringify(json[i]));
  }
});
