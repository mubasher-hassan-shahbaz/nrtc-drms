const fs = require('fs');
const xlsx = require('xlsx');

const wb = xlsx.readFile('C:/Users/mubas/.gemini/antigravity/brain/786d803e-4a56-4256-8e0f-49f9457a89ad/.user_uploaded/media_1790697626668.xlsx');
const ws = wb.Sheets['Personal details'];
const raw = xlsx.utils.sheet_to_json(ws, { header: 1 });

const xml = fs.readFileSync('temp_emp_unzip/xl/drawings/drawing1.xml', 'utf8');
const rels = fs.readFileSync('temp_emp_unzip/xl/drawings/_rels/drawing1.xml.rels', 'utf8');

const relMap = {};
const relRegex = /Id="([^"]+)"\s+Type="[^"]*"\s+Target="([^"]+)"/g;
let m;
while ((m = relRegex.exec(rels)) !== null) {
  relMap[m[1]] = m[2].replace('../media/', '');
}

// Extract all twoCellAnchor and oneCellAnchor
// Let's capture from.row, from.rowOff, from.col, from.colOff, to.row, rId
const twoCellRegex = /<xdr:twoCellAnchor[\s\S]*?<xdr:from>[\s\S]*?<xdr:col>(\d+)<\/xdr:col>[\s\S]*?<xdr:colOff>(\d+)<\/xdr:colOff>[\s\S]*?<xdr:row>(\d+)<\/xdr:row>[\s\S]*?<xdr:rowOff>(\d+)<\/xdr:rowOff>[\s\S]*?<a:blip\s+[^>]*?r:embed="(rId\d+)"[\s\S]*?<\/xdr:twoCellAnchor>/g;

const anchorList = [];
while ((m = twoCellRegex.exec(xml)) !== null) {
  const col = parseInt(m[1], 10);
  const colOff = parseInt(m[2], 10);
  const row = parseInt(m[3], 10);
  const rowOff = parseInt(m[4], 10);
  const rId = m[5];
  const img = relMap[rId];
  anchorList.push({ row, col, rowOff, colOff, rId, img });
}

console.log('Total twoCellAnchors parsed:', anchorList.length);

// Sort anchorList by row
anchorList.sort((a, b) => a.row - b.row);

// Let's see all anchor rows and compare to raw sheet rows
console.log('\n--- Sorted Anchors vs Sheet Rows ---');
anchorList.forEach((a, i) => {
  const r = raw[a.row];
  console.log(`[Anchor ${i+1}] Row ${a.row} -> ${a.img} (Col ${a.col}, rowOff ${a.rowOff})`);
  if (r) {
    console.log(`    -> Sheet data: Sr=${r[0]} | ID=${r[1]} | Name="${r[2]}" | Desig="${r[3]}"`);
  } else {
    console.log(`    -> NO DATA at row ${a.row}`);
  }
});
