const fs = require('fs');
const path = require('path');

const dir = path.join(__dirname, '..');
const htmlFiles = fs.readdirSync(dir).filter(f => f.endsWith('.html'));

let updated = 0;
htmlFiles.forEach(file => {
  const filePath = path.join(dir, file);
  let content = fs.readFileSync(filePath, 'utf8');
  if (content.includes('js/data/store.js') && !content.includes('employees-data.js')) {
    content = content.replace('<script src="js/data/store.js"></script>', '<script src="js/data/employees-data.js"></script>\n<script src="js/data/store.js"></script>');
    fs.writeFileSync(filePath, content, 'utf8');
    updated++;
    console.log(`Added employees-data.js to ${file}`);
  }
});
console.log(`Finished adding to ${updated} files.`);
