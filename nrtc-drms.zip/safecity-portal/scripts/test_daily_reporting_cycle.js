const assert = require('assert');
const { SafeCityStore } = require('../js/data/store.js');
const http = require('http');
const app = require('../server.js');

// Mock localStorage and sessionStorage for Node.js environment test
global.localStorage = {
  _store: {},
  getItem(k) { return this._store[k] || null; },
  setItem(k, v) { this._store[k] = String(v); },
  removeItem(k) { delete this._store[k]; },
  clear() { this._store = {}; }
};
global.sessionStorage = {
  _store: {},
  getItem(k) { return this._store[k] || null; },
  setItem(k, v) { this._store[k] = String(v); },
  removeItem(k) { delete this._store[k]; },
  clear() { this._store = {}; }
};

async function runTests() {
  console.log('====================================================');
  console.log('RUNNING DAILY REPORTING CYCLE & STATUS TESTS');
  console.log('====================================================');

  // Test setup data
  const baseUsers = [
    { id: 'usr_attock', name: 'Attock Engineer', role: 'DISTRICT_USER', districtId: 'attock', districtName: 'Attock', active: true },
    { id: 'usr_chakwal', name: 'Chakwal Engineer', role: 'DISTRICT_USER', districtId: 'chakwal', districtName: 'Chakwal', active: true },
    { id: 'usr_jhelum', name: 'Jhelum Engineer', role: 'DISTRICT_USER', districtId: 'jhelum', districtName: 'Jhelum', active: true },
    { id: 'usr_murree', name: 'Murree Engineer', role: 'DISTRICT_USER', districtId: 'murree', districtName: 'Murree', active: true },
    { id: 'usr_disabled', name: 'Disabled Engineer', role: 'DISTRICT_USER', districtId: 'layyah', districtName: 'Layyah', active: false },
    { id: 'usr_deleted', name: 'Deleted Engineer', role: 'DISTRICT_USER', districtId: 'bhakkar', districtName: 'Bhakkar', active: true, deleted: true },
    { id: 'usr_admin', name: 'NRTC Admin', role: 'ADMIN', districtId: 'all', active: true }
  ];

  // Test 1: Report submitted during the 24-hour window -> Received
  console.log('\n--- Test 1: Report submitted during 24h window -> Received ---');
  {
    const store = new SafeCityStore();
    store.users = JSON.parse(JSON.stringify(baseUsers));
    store.reports = [
      {
        id: 'rep_attock_01',
        user_id: 'usr_attock',
        district_id: 'attock',
        district_name: 'Attock',
        report_date: '2026-10-01',
        submitted_at: '2026-10-01 14:30:00'
      }
    ];

    const res = store.getDailyReportingStatus({ date: '2026-10-01' });
    const attockStatus = res.users.find(u => u.userId === 'usr_attock');
    assert.strictEqual(attockStatus.status, 'RECEIVED', 'Attock should be RECEIVED');
    assert.strictEqual(attockStatus.reportId, 'rep_attock_01');
    console.log('✓ Attock submitted during window is correctly marked RECEIVED.');
  }

  // Test 2: No report submitted -> Pending
  console.log('\n--- Test 2: No report submitted -> Pending ---');
  {
    const store = new SafeCityStore();
    store.users = JSON.parse(JSON.stringify(baseUsers));
    store.reports = [];

    const res = store.getDailyReportingStatus({ date: '2026-10-01' });
    const chakwalStatus = res.users.find(u => u.userId === 'usr_chakwal');
    assert.strictEqual(chakwalStatus.status, 'PENDING', 'Chakwal should be PENDING');
    assert.strictEqual(chakwalStatus.reportId, null);
    console.log('✓ District with no submission is correctly marked PENDING.');
  }

  // Test 3: Report submitted near midnight -> assigned to correct reporting cycle
  console.log('\n--- Test 3: Report submitted near midnight -> correct cycle ---');
  {
    const store = new SafeCityStore();
    store.users = JSON.parse(JSON.stringify(baseUsers));
    store.reports = [
      // Submitted at 11:58 PM on 01 Oct (inside 01 Oct 12:00 AM -> 02 Oct 12:00 AM)
      {
        id: 'rep_jhelum_midnight',
        user_id: 'usr_jhelum',
        district_id: 'jhelum',
        district_name: 'Jhelum',
        report_date: '2026-10-01',
        submitted_at: '2026-10-01 23:58:30'
      },
      // Submitted at 12:05 AM on 02 Oct with report_date 2026-10-01 (grace near midnight)
      {
        id: 'rep_murree_grace',
        user_id: 'usr_murree',
        district_id: 'murree',
        district_name: 'Murree',
        report_date: '2026-10-01',
        submitted_at: '2026-10-02 00:05:10'
      }
    ];

    const resOct1 = store.getDailyReportingStatus({ date: '2026-10-01' });
    const jhelumOct1 = resOct1.users.find(u => u.userId === 'usr_jhelum');
    const murreeOct1 = resOct1.users.find(u => u.userId === 'usr_murree');
    assert.strictEqual(jhelumOct1.status, 'RECEIVED', 'Jhelum 11:58 PM should be RECEIVED in Oct 01 cycle');
    assert.strictEqual(murreeOct1.status, 'RECEIVED', 'Murree 12:05 AM grace should be RECEIVED in Oct 01 cycle');
    console.log('✓ Near-midnight submissions are properly assigned to the correct reporting cycle.');
  }

  // Test 4: Multiple reports by same user -> 1 report per cycle, no duplicate counting
  console.log('\n--- Test 4: Multiple reports by same user -> Deduplicated ---');
  {
    const store = new SafeCityStore();
    store.users = JSON.parse(JSON.stringify(baseUsers));
    store.reports = [
      {
        id: 'rep_attock_early',
        user_id: 'usr_attock',
        district_id: 'attock',
        report_date: '2026-10-01',
        submitted_at: '2026-10-01 09:00:00'
      },
      {
        id: 'rep_attock_late',
        user_id: 'usr_attock',
        district_id: 'attock',
        report_date: '2026-10-01',
        submitted_at: '2026-10-01 17:00:00'
      }
    ];

    const res = store.getDailyReportingStatus({ date: '2026-10-01' });
    assert.strictEqual(res.summary.received, 1, 'Should count exactly 1 report received for Attock');
    assert.strictEqual(res.receivedReports.length, 1, 'receivedReports array should be deduplicated to 1');
    assert.strictEqual(res.receivedReports[0].id, 'rep_attock_late', 'Should select the latest report submitted in cycle');
    console.log('✓ Multiple submissions by the same user are deduplicated (latest selected).');
  }

  // Test 5: Disabled / deleted user -> not included in expected count
  console.log('\n--- Test 5: Disabled/deleted users not counted in expected ---');
  {
    const store = new SafeCityStore();
    store.users = JSON.parse(JSON.stringify(baseUsers));
    store.reports = [];

    const res = store.getDailyReportingStatus({ date: '2026-10-01' });
    // baseUsers has: attock, chakwal, jhelum, murree (4 active district users), disabled (inactive), deleted (deleted), admin (out of district scope)
    assert.strictEqual(res.summary.totalExpected, 4, 'Expected active users must be exactly 4');
    assert(!res.users.some(u => u.userId === 'usr_disabled'), 'usr_disabled must NOT be in expected list');
    assert(!res.users.some(u => u.userId === 'usr_deleted'), 'usr_deleted must NOT be in expected list');
    assert(!res.users.some(u => u.userId === 'usr_admin'), 'usr_admin must NOT be in expected list');
    console.log('✓ Disabled, deleted, and non-district accounts are excluded from expected count.');
  }

  // Test 6: Invariant verification: Received + Pending === Total Expected
  console.log('\n--- Test 6: Strict Invariant: Received + Pending === Total Expected ---');
  {
    const fs = require('fs');
    const path = require('path');
    const dbUsers = JSON.parse(fs.readFileSync(path.join(__dirname, '../data/users.json'), 'utf8'));
    const dbReports = JSON.parse(fs.readFileSync(path.join(__dirname, '../data/reports.json'), 'utf8'));

    const store = new SafeCityStore();
    // Test with actual database users & reports
    const dbRes = store.getDailyReportingStatus({ date: '2026-10-01', users: dbUsers, reports: dbReports });
    console.log(`Database Oct 01 Cycle Summary: Expected=${dbRes.summary.totalExpected}, Received=${dbRes.summary.received}, Pending=${dbRes.summary.pending}`);
    assert.strictEqual(
      dbRes.summary.received + dbRes.summary.pending,
      dbRes.summary.totalExpected,
      'Received + Pending MUST EQUAL Total Expected'
    );
    assert.strictEqual(dbRes.summary.totalExpected, 37, 'Total expected for full Punjab must be exactly 37');

    const dbResOct2 = store.getDailyReportingStatus({ date: '2026-10-02', users: dbUsers, reports: dbReports });
    console.log(`Database Oct 02 Cycle Summary: Expected=${dbResOct2.summary.totalExpected}, Received=${dbResOct2.summary.received}, Pending=${dbResOct2.summary.pending}`);
    assert.strictEqual(
      dbResOct2.summary.received + dbResOct2.summary.pending,
      dbResOct2.summary.totalExpected,
      'Received + Pending MUST EQUAL Total Expected on Oct 02'
    );
    console.log('✓ Invariant holds true: Received + Pending === Total Expected.');
  }

  // Test 7: HTTP API Endpoint GET /api/reports/daily-status
  console.log('\n--- Test 7: Backend API Verification (GET /api/reports/daily-status) ---');
  const server = http.createServer(app);
  await new Promise((resolve) => server.listen(0, resolve));
  const port = server.address().port;

  try {
    const apiData = await new Promise((resolve, reject) => {
      http.get(`http://localhost:${port}/api/reports/daily-status?date=2026-10-01`, (res) => {
        let raw = '';
        res.on('data', chunk => raw += chunk);
        res.on('end', () => {
          try {
            resolve(JSON.parse(raw));
          } catch (e) {
            reject(e);
          }
        });
      }).on('error', reject);
    });

    assert.strictEqual(apiData.success, true, 'API should return success: true');
    assert.strictEqual(apiData.summary.totalExpected, 37, 'API totalExpected should be 37');
    assert.strictEqual(apiData.summary.received + apiData.summary.pending, apiData.summary.totalExpected, 'API Received + Pending === Total Expected');
    assert.strictEqual(apiData.cycle.deadline, '12:00 AM (Midnight)', 'Deadline should be 12:00 AM (Midnight)');
    console.log('✓ Backend API /api/reports/daily-status responded accurately with expected=37, received=' + apiData.summary.received + ', pending=' + apiData.summary.pending);
  } finally {
    server.close();
  }

  console.log('\n====================================================');
  console.log('ALL 7 DAILY REPORTING CYCLE TESTS PASSED PERFECTLY!');
  console.log('====================================================\n');
}

runTests().catch(err => {
  console.error('TEST FAILED:', err);
  process.exit(1);
});
