const fs = require('fs');
const XLSX = require('xlsx');

const currentEmps = require('../data/employees.json');
const rowMap = require('./effective_row_to_image.json');

const wb = XLSX.readFile('C:/Users/mubas/.gemini/antigravity/brain/786d803e-4a56-4256-8e0f-49f9457a89ad/.user_uploaded/media_1790697626668.xlsx');
const ws = wb.Sheets['Personal details'];
const excelRows = XLSX.utils.sheet_to_json(ws, { header: 1 });

console.log('Auditing all 142 employees against exact Excel rows and drawing image map...');
let mismatches = 0;
let matchedCount = 0;

currentEmps.forEach(emp => {
  const parts = emp.id.split('_');
  const r = parseInt(parts[parts.length - 1], 10);
  const excelRow = excelRows[r];
  const expectedImg = rowMap[r] ? 'assets/employees/' + rowMap[r] : null;

  if (emp.photo !== expectedImg) {
    mismatches++;
    console.log(`Mismatch on row ${r} [${emp.empId}] ${emp.name}: Current=${emp.photo} vs Expected=${expectedImg}`);
  } else if (emp.photo) {
    matchedCount++;
  }
});

console.log(`Total exact verified photos matched: ${matchedCount} / ${Object.keys(rowMap).length}`);
console.log(`Total mismatches: ${mismatches}`);
if (mismatches === 0) {
  console.log('SUCCESS: All employee photos are 100% verified and match the source Excel file!');
}
