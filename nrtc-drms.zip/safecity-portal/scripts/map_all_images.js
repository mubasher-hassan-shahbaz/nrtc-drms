const fs = require('fs');
const XLSX = require('xlsx');

const xml = fs.readFileSync('./temp_emp_unzip/xl/drawings/drawing1.xml', 'utf8');
const rels = fs.readFileSync('./temp_emp_unzip/xl/drawings/_rels/drawing1.xml.rels', 'utf8');

const relMap = {};
const relRegex = /Id="([^"]+)"[^>]*Target="([^"]+)"/g;
let m;
while ((m = relRegex.exec(rels)) !== null) {
  relMap[m[1]] = m[2].replace('../media/', '');
}

const wb = XLSX.readFile('C:/Users/mubas/.gemini/antigravity/brain/786d803e-4a56-4256-8e0f-49f9457a89ad/.user_uploaded/media_1790697626668.xlsx');
const ws = wb.Sheets['Personal details'];
const data = XLSX.utils.sheet_to_json(ws, { header: 1 });

const anchorRegex = /<xdr:(twoCellAnchor|oneCellAnchor)[^>]*>([\s\S]*?)<\/xdr:\1>/g;
const anchors = [];
while ((m = anchorRegex.exec(xml)) !== null) {
  const content = m[2];
  const fromRow = content.match(/<xdr:from>[\s\S]*?<xdr:row>(\d+)<\/xdr:row>/);
  const fromRowOff = content.match(/<xdr:from>[\s\S]*?<xdr:rowOff>(\d+)<\/xdr:rowOff>/);
  const blip = content.match(/r:embed="([^"]+)"/);
  if (fromRow && blip) {
    const fR = parseInt(fromRow[1]);
    const fOff = fromRowOff ? parseInt(fromRowOff[1]) : 0;
    const img = relMap[blip[1]];
    // If fOff > 500,000, it means it's pushed down into the next row (or next rows)
    const effectiveRow = fOff > 500000 ? fR + Math.round(fOff / 800000) : fR;
    anchors.push({ fromRow: fR, rowOff: fOff, effectiveRow, img });
  }
}

anchors.sort((a, b) => a.effectiveRow - b.effectiveRow);

console.log('Effective rows mapped:');
const mapping = {};
anchors.forEach(a => {
  const r = data[a.effectiveRow] || [];
  console.log(`Row ${a.effectiveRow} (orig fromRow=${a.fromRow}, off=${a.rowOff}): Img=${a.img} -> [${r[1]}] ${r[2]}`);
  mapping[a.effectiveRow] = a.img;
});

fs.writeFileSync('./scripts/effective_row_to_image.json', JSON.stringify(mapping, null, 2));
