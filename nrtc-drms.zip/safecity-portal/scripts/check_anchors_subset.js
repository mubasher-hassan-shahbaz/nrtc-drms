const fs = require('fs');

const xml = fs.readFileSync('temp_emp_unzip/xl/drawings/drawing1.xml', 'utf8');
const rels = fs.readFileSync('temp_emp_unzip/xl/drawings/_rels/drawing1.xml.rels', 'utf8');
const relMap = {};
let m;
const relRegex = /Id="([^"]+)"\s+Type="[^"]*"\s+Target="([^"]+)"/g;
while ((m = relRegex.exec(rels)) !== null) relMap[m[1]] = m[2].replace('../media/', '');

const twoCellRegex = /<xdr:twoCellAnchor[\s\S]*?<xdr:from>[\s\S]*?<xdr:col>(\d+)<\/xdr:col>[\s\S]*?<xdr:colOff>(\d+)<\/xdr:colOff>[\s\S]*?<xdr:row>(\d+)<\/xdr:row>[\s\S]*?<xdr:rowOff>(\d+)<\/xdr:rowOff>[\s\S]*?<a:blip\s+[^>]*?r:embed="(rId\d+)"[\s\S]*?<\/xdr:twoCellAnchor>/g;
const list = [];
while ((m = twoCellRegex.exec(xml)) !== null) {
  list.push({ col: parseInt(m[1]), row: parseInt(m[3]), rowOff: parseInt(m[4]), img: relMap[m[5]] });
}
list.sort((a,b) => a.row - b.row || a.rowOff - b.rowOff);
list.filter(x => x.row <= 30).forEach(x => console.log('Anchor row:', x.row, 'rowOff:', x.rowOff, 'col:', x.col, '->', x.img));
