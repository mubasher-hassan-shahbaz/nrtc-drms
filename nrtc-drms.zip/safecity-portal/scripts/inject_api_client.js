/**
 * Inject api-client.js before store.js in all existing HTML pages
 * Also fixes any remaining "Saad Ali Shahbaz" admin name occurrences
 */
const fs = require('fs');
const path = require('path');

const FILES = [
  'admin-overview.html', 'admin-reports.html', 'analytics.html',
  'attendance.html', 'finance.html', 'reports.html',
  'submit-report.html', 'profile.html', 'districts-matrix.html',
  'import.html', 'dashboard.html', 'users.html'
];

let fixed = 0;
FILES.forEach(f => {
  const fp = path.join(__dirname, '..', f);
  if (!fs.existsSync(fp)) { console.log('SKIP (not found):', f); return; }

  let html = fs.readFileSync(fp, 'utf8');
  let changed = false;

  // Add api-client.js before store.js if not already present
  if (html.includes('js/data/store.js') && !html.includes('js/api-client.js')) {
    html = html.replace(
      '<script src="js/data/store.js"></script>',
      '<script src="js/api-client.js"></script>\n  <script src="js/data/store.js"></script>'
    );
    changed = true;
  }

  if (changed) {
    fs.writeFileSync(fp, html, 'utf8');
    console.log('✅ Updated:', f);
    fixed++;
  } else {
    console.log('✓  OK:', f);
  }
});
console.log('\nDone. Fixed:', fixed, 'files');
