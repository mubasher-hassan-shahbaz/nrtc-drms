const fs = require('fs');
const path = require('path');
const assert = require('assert');

console.log('--- RUNNING USER FIXES VERIFICATION ---');

// TEST 1: Employees and Attendance Dropdown
const employeesJson = JSON.parse(fs.readFileSync(path.join(__dirname, '../data/employees.json'), 'utf8'));
console.log(`Loaded ${employeesJson.length} employees from data/employees.json`);
const chakwalEmps = employeesJson.filter(e => (e.district_id === 'chakwal' || (e.location && e.location.includes('Chakwal'))));
console.log(`Found ${chakwalEmps.length} Chakwal employees:`, chakwalEmps.map(e => `${e.name} (${e.empId})`));
assert(chakwalEmps.length > 0, 'Chakwal employees must exist');

// Mock localStorage and window for store.js testing
global.localStorage = {
  data: {},
  getItem(k) { return this.data[k] || null; },
  setItem(k, v) { this.data[k] = String(v); },
  removeItem(k) { delete this.data[k]; }
};
global.window = {
  localStorage: global.localStorage,
  PUNJAB_DISTRICTS: require('../js/data/districts.js').PUNJAB_DISTRICTS || []
};
global.PUNJAB_DISTRICTS = global.window.PUNJAB_DISTRICTS;

// Load store
const { SafeCityStore } = require('../js/data/store.js');
const store = new SafeCityStore();

// Test store with real employees sync
store.syncEmployees(employeesJson);
const distEmps = store.getEmployeesByDistrict('chakwal');
console.log(`store.getEmployeesByDistrict('chakwal') returned ${distEmps.length} employees`);
assert(distEmps.length > 0, 'getEmployeesByDistrict must find Chakwal employees');

const mubasher = store.getEmployeeById('12-55');
assert(mubasher && mubasher.name.includes('Mubasher'), 'getEmployeeById by empId 12-55 must find Mubasher');
const mubasherById = store.getEmployeeById(mubasher.id);
assert(mubasherById && mubasherById.name.includes('Mubasher'), 'getEmployeeById by id must find Mubasher');

const bioResult = store.verifyFaceBiometric('12-55', null, false);
console.log('Biometric verification result for 12-55:', bioResult.verified, bioResult.matchScore);
assert(bioResult.verified === true, 'Biometric verification must succeed');
console.log('✓ TEST 1 PASSED: Attendance employee dropdown & biometric verification verified.');

// TEST 2: Availability strictly from report form (100% Chakwal)
const reportsJson = JSON.parse(fs.readFileSync(path.join(__dirname, '../data/reports.json'), 'utf8'));
const chakwalReports = reportsJson.filter(r => r.district_id === 'chakwal').sort((a,b) => new Date(b.report_date) - new Date(a.report_date));
const latestChakwal = chakwalReports[0];
console.log('Latest Chakwal report date:', latestChakwal.report_date, 'uptime_percent:', latestChakwal.uptime_percent);
assert.strictEqual(latestChakwal.uptime_percent, '100.0', 'Latest Chakwal report must be 100.0%');

const calculatedUptime = SafeCityStore.getDistrictOverallUptime(latestChakwal);
console.log('SafeCityStore.getDistrictOverallUptime(latestChakwal):', calculatedUptime);
assert.strictEqual(calculatedUptime, 100.0, 'Calculated uptime must be 100.0%');
console.log('✓ TEST 2 PASSED: 100% availability matches between district report and admin calculation.');

// TEST 3: Sidebar Glitch Check
const htmlFiles = fs.readdirSync(path.join(__dirname, '..')).filter(f => f.endsWith('.html'));
let glitchCount = 0;
htmlFiles.forEach(f => {
  const content = fs.readFileSync(path.join(__dirname, '..', f), 'utf8');
  // Check if SLA Analytics is inside Field Workforce
  const fwMatch = content.match(/Field Workforce[\s\S]*?<\/nav>/i);
  if (fwMatch && fwMatch[0].includes('analytics.html')) {
    console.error(`GLITCH FOUND in ${f}: analytics.html is inside Field Workforce!`);
    glitchCount++;
  }
});
assert.strictEqual(glitchCount, 0, 'No HTML file should have analytics.html in Field Workforce');
console.log(`✓ TEST 3 PASSED: All ${htmlFiles.length} HTML pages have clean, glitch-free sidebar navigation.`);

// TEST 4: Vercel Config and API Entrypoint
const vercelJson = JSON.parse(fs.readFileSync(path.join(__dirname, '../vercel.json'), 'utf8'));
assert(vercelJson.version === 2, 'vercel.json must have version 2');
assert(fs.existsSync(path.join(__dirname, '../api/index.js')), 'api/index.js must exist');
const apiHandler = require('../api/index.js');
assert(typeof apiHandler === 'function', 'api/index.js must export Express app');
console.log('✓ TEST 4 PASSED: Vercel configuration and serverless handler verified.');

console.log('\n========================================');
console.log('  ALL USER REQUEST VERIFICATIONS PASSED! ');
console.log('========================================');
