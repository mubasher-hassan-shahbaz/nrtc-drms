const fs = require('fs');
const http = require('http');

async function runAudit() {
  console.log('=== STARTING FULL DRMS SYSTEM AUDIT ===\n');

  let passed = 0;
  let failed = 0;

  function assert(condition, message) {
    if (condition) {
      console.log(`[PASS] ${message}`);
      passed++;
    } else {
      console.error(`[FAIL] ${message}`);
      failed++;
    }
  }

  // 1. Employee & Photo Verification
  const emps = JSON.parse(fs.readFileSync('./data/employees.json', 'utf8'));
  assert(emps.length === 142, `All 142 employees present (found ${emps.length})`);
  
  const masooma = emps.find(e => e.name.toLowerCase().includes('masooma'));
  assert(masooma && masooma.photo === 'assets/employees/image5.jpeg', `Masooma Ijaz has correct photo image5.jpeg (actual: ${masooma?.photo})`);
  assert(masooma && masooma.empId === '4-919', `Masooma Ijaz has correct Emp ID 4-919 (actual: ${masooma?.empId})`);

  const adnan = emps.find(e => e.name.toLowerCase().includes('adnan') && (e.designation.includes('Site') || e.email.includes('chandia')));
  assert(adnan && adnan.photo === 'assets/employees/image54.jpeg', `Adnan Ahmed Chandia has correct photo image54.jpeg (actual: ${adnan?.photo})`);
  assert(adnan && adnan.empId === '12-53', `Adnan Ahmed Chandia has correct Emp ID 12-53 (actual: ${adnan?.empId})`);

  const photosCount = emps.filter(e => e.photo).length;
  assert(photosCount === 91, `Exact 91 photos matched to authentic employees (found ${photosCount})`);

  // 2. Dummy Email Removal Verification
  const users = JSON.parse(fs.readFileSync('./data/users.json', 'utf8'));
  const fakeNrtcEmails = users.filter(u => u.role === 'DISTRICT_USER' && u.email && u.email.trim() !== '');
  assert(fakeNrtcEmails.length === 0, `All fake district @nrtc.com.pk emails removed from users.json (found ${fakeNrtcEmails.length})`);

  const storeJs = fs.readFileSync('./js/data/store.js', 'utf8');
  assert(!storeJs.includes('chakwal@nrtc.com.pk'), 'store.js has no fake chakwal@nrtc.com.pk email');
  assert(!storeJs.includes('${dist.id}@nrtc.com.pk'), 'store.js has no dynamic fake district email generator');

  // 3. Site Coordinates Verification
  const sites = JSON.parse(fs.readFileSync('./data/sites.json', 'utf8'));
  assert(sites.length === 1721, `All 1,721 sites present in sites.json (found ${sites.length})`);
  
  const mbd13 = sites.find(s => s.spotId === 'MBD-13');
  assert(mbd13 && Math.abs(mbd13.lng - 73.504898) < 0.0001, `MBD-13 coordinates corrected to 73.504898 (actual: ${mbd13?.lng})`);

  const outOfBounds = sites.filter(s => s.lat < 27 || s.lat > 36 || s.lng < 68 || s.lng > 76);
  assert(outOfBounds.length === 0, `Zero coordinate anomalies across all 1,721 sites (found ${outOfBounds.length})`);

  // 4. Map Marker Colors Verification
  const appJs = fs.readFileSync('./js/app.js', 'utf8');
  assert(appJs.includes('window.getSiteMarkerColor = function'), 'window.getSiteMarkerColor defined in app.js');

  const sitesHtml = fs.readFileSync('./sites.html', 'utf8');
  assert(sitesHtml.includes('#dc2626') && sitesHtml.includes('MCR') && sitesHtml.includes('DR'), 'sites.html assigns Red to MCR & DR');
  assert(sitesHtml.includes('#8b5cf6') && sitesHtml.includes('PS') && sitesHtml.includes('DC'), 'sites.html assigns Purple to PS & DC');

  const distDetailHtml = fs.readFileSync('./district-detail.html', 'utf8');
  assert(distDetailHtml.includes('#dc2626') && distDetailHtml.includes('MCR') && distDetailHtml.includes('DR'), 'district-detail.html assigns Red to MCR & DR');
  assert(distDetailHtml.includes('#8b5cf6') && distDetailHtml.includes('PS') && distDetailHtml.includes('DC'), 'district-detail.html assigns Purple to PS & DC');

  // 5. Clean Database Verification (Zero Demo Data)
  const finances = JSON.parse(fs.readFileSync('./data/finances.json', 'utf8'));
  assert(finances.length === 0, `finances.json is clean with 0 demo expenses (found ${finances.length})`);

  const queries = JSON.parse(fs.readFileSync('./data/finance_queries.json', 'utf8'));
  assert(queries.length === 0, `finance_queries.json is clean with 0 demo queries (found ${queries.length})`);

  const ptclTickets = JSON.parse(fs.readFileSync('./data/ptcl_tickets.json', 'utf8'));
  assert(ptclTickets.length === 0, `ptcl_tickets.json is clean with 0 demo tickets (found ${ptclTickets.length})`);

  // 6. Live API Health & Authentication
  function get(url) {
    return new Promise((resolve, reject) => {
      http.get(url, res => {
        let d = '';
        res.on('data', chunk => d += chunk);
        res.on('end', () => resolve({ status: res.statusCode, body: JSON.parse(d) }));
      }).on('error', reject);
    });
  }

  function post(url, payload) {
    return new Promise((resolve, reject) => {
      const data = JSON.stringify(payload);
      const req = http.request(url, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json', 'Content-Length': Buffer.byteLength(data) }
      }, res => {
        let d = '';
        res.on('data', chunk => d += chunk);
        res.on('end', () => resolve({ status: res.statusCode, body: JSON.parse(d) }));
      });
      req.on('error', reject);
      req.write(data);
      req.end();
    });
  }

  try {
    const adminLogin = await post('http://localhost:3000/api/auth/login', { username: 'admin', password: 'password123' });
    assert(adminLogin.body.success && adminLogin.body.user.role === 'ADMIN', 'Admin login successful');

    const distLogin = await post('http://localhost:3000/api/auth/login', { username: 'wazirabad', password: 'password123' });
    assert(distLogin.body.success && distLogin.body.user.role === 'DISTRICT_USER', 'District user login successful (Wazirabad)');

    const ptclLogin = await post('http://localhost:3000/api/auth/login', { username: 'ptcl_admin', password: 'password123' });
    assert(ptclLogin.body.success && ptclLogin.body.user.role === 'PTCL_ADMIN', 'PTCL Admin login successful');

    const financeLogin = await post('http://localhost:3000/api/auth/login', { username: 'finance_admin', password: 'password123' });
    assert(financeLogin.body.success && financeLogin.body.user.role === 'FINANCE_ADMIN', 'Finance Admin login successful');

    const distRes = await get('http://localhost:3000/api/districts');
    assert(distRes.status === 200 && distRes.body.length === 37, `API returns 37 authentic districts (received ${distRes.body.length})`);

    const sitesRes = await get('http://localhost:3000/api/sites');
    assert(sitesRes.status === 200 && sitesRes.body.length === 1721, `API returns 1,721 authentic sites (received ${sitesRes.body.length})`);

    const empsRes = await get('http://localhost:3000/api/employees');
    assert(empsRes.status === 200 && empsRes.body.length === 142, `API returns 142 authentic employees (received ${empsRes.body.length})`);
  } catch (err) {
    assert(false, `API Error: ${err.message}`);
  }

  console.log(`\n=== AUDIT COMPLETE ===`);
  console.log(`PASSED: ${passed}`);
  console.log(`FAILED: ${failed}`);
  if (failed === 0) {
    console.log('ALL AUDIT CHECKS PASSED PERFECTLY!\n');
  }
}

runAudit();
