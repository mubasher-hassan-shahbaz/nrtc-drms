const xlsx = require('xlsx');

const wb = xlsx.readFile('C:/Users/mubas/.gemini/antigravity/brain/786d803e-4a56-4256-8e0f-49f9457a89ad/.user_uploaded/media_1790697626668.xlsx');
const sheet1 = xlsx.utils.sheet_to_json(wb.Sheets['Sheet1'], { header: 1 });
const pRaw = xlsx.utils.sheet_to_json(wb.Sheets['Personal details'], { header: 1 });

const s1Map = {};
for (let i = 2; i < sheet1.length; i++) {
  const r = sheet1[i];
  if (!r || !r[2]) continue;
  const cleanName = String(r[2]).trim().toLowerCase().replace(/[^a-z0-9]/g, '');
  const empId = r[1] ? String(r[1]).trim() : '';
  s1Map[cleanName] = {
    empId: empId,
    name: r[2],
    fatherName: r[3] ? String(r[3]).trim() : '',
    joiningDate: r[4],
    designation: r[5] ? String(r[5]).trim() : '',
    dob: r[6],
    cnic: r[7] ? String(r[7]).trim() : ''
  };
  if (empId) {
    s1Map['id_' + empId.toLowerCase().replace(/[^a-z0-9]/g, '')] = s1Map[cleanName];
  }
}

console.log('Sheet1 mapped entries:', Object.keys(s1Map).length);

// Count how many Personal details rows match
let matched = 0;
let total = 0;
for (let i = 3; i < pRaw.length; i++) {
  const r = pRaw[i];
  if (!r || !r[2] || String(r[0]).includes('PSC') || String(r[0]).includes('Sr')) continue;
  total++;
  const cleanName = String(r[2]).trim().toLowerCase().replace(/[^a-z0-9]/g, '');
  const empId = r[1] ? String(r[1]).trim().toLowerCase().replace(/[^a-z0-9]/g, '') : '';
  if (s1Map[cleanName] || (empId && s1Map['id_' + empId])) {
    matched++;
  }
}

console.log(`Matched ${matched} out of ${total} employees in Personal details with Sheet1 personal records!`);
