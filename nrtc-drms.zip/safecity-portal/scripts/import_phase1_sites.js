const fs = require('fs');
const path = require('path');
const xlsx = require('xlsx');

const excelPath = 'C:/Users/mubas/.gemini/antigravity/brain/786d803e-4a56-4256-8e0f-49f9457a89ad/.user_uploaded/media_1790755975727.xlsx';
const sitesJsonPath = path.join(__dirname, '../data/sites.json');

console.log('Loading Excel workbook from:', excelPath);
const wb = xlsx.readFile(excelPath);
const ws = wb.Sheets['All Cities'];
if (!ws) {
  console.error('Sheet "All Cities" not found!');
  process.exit(1);
}

const rows = xlsx.utils.sheet_to_json(ws, { header: 1 });
console.log(`Read ${rows.length} rows from "All Cities" sheet.`);

// District reference coordinates & names
const districtRefs = {
  'sheikhupura': { name: 'Sheikhupura', division: 'Lahore', lat: 31.7131, lng: 73.9783 },
  'sialkot': { name: 'Sialkot', division: 'Gujranwala', lat: 32.4945, lng: 74.5229 },
  'gujrat': { name: 'Gujrat', division: 'Gujrat', lat: 32.5742, lng: 74.0754 },
  'jhelum': { name: 'Jhelum', division: 'Rawalpindi', lat: 32.9405, lng: 73.7276 },
  'attock': { name: 'Attock', division: 'Rawalpindi', lat: 33.7660, lng: 72.3609 },
  'murree': { name: 'Murree', division: 'Rawalpindi', lat: 33.9070, lng: 73.3943 },
  'okara': { name: 'Okara', division: 'Sahiwal', lat: 30.8081, lng: 73.4506 },
  'sahiwal': { name: 'Sahiwal', division: 'Sahiwal', lat: 30.6682, lng: 73.1114 },
  'jhang': { name: 'Jhang', division: 'Faisalabad', lat: 31.2781, lng: 72.3188 },
  'muzaffargarh': { name: 'Muzaffargarh', division: 'D.G. Khan', lat: 30.0750, lng: 71.1921 },
  'dg_khan': { name: 'Dera Ghazi Khan', division: 'D.G. Khan', lat: 30.0561, lng: 70.6403 },
  'rahim_yar_khan': { name: 'Rahim Yar Khan', division: 'Bahawalpur', lat: 28.4212, lng: 70.2989 },
  'hasanabdal': { name: 'Hasanabdal', division: 'Rawalpindi', lat: 33.8200, lng: 72.6900 },
  'taxila': { name: 'Taxila', division: 'Rawalpindi', lat: 33.7460, lng: 72.8090 },
  'mianwali': { name: 'Mianwali', division: 'Sargodha', lat: 32.5853, lng: 71.5436 },
  'sargodha': { name: 'Sargodha', division: 'Sargodha', lat: 32.0836, lng: 72.6711 },
  'bahawalpur': { name: 'Bahawalpur', division: 'Bahawalpur', lat: 29.3956, lng: 71.6836 },
  'multan': { name: 'Multan', division: 'Multan', lat: 30.1575, lng: 71.5249 }
};

function normalizeDistrict(rawCity) {
  if (!rawCity) return null;
  const c = String(rawCity).toLowerCase().trim().replace(/[^a-z0-9]/g, '');
  if (c.includes('sheikhupura')) return 'sheikhupura';
  if (c.includes('sialkot')) return 'sialkot';
  if (c.includes('gujrat')) return 'gujrat';
  if (c.includes('jhelum') || c.includes('jehlum')) return 'jhelum';
  if (c.includes('attock')) return 'attock';
  if (c.includes('murree')) return 'murree';
  if (c.includes('okara')) return 'okara';
  if (c.includes('sahiwal')) return 'sahiwal';
  if (c.includes('jhang')) return 'jhang';
  if (c.includes('muzaffargarh')) return 'muzaffargarh';
  if (c.includes('rahim') || c.includes('ryk')) return 'rahim_yar_khan';
  if (c.includes('dg') || c.includes('deraghazi')) return 'dg_khan';
  if (c.includes('hasan') || c.includes('hassan')) return 'hasanabdal';
  if (c.includes('taxila')) return 'taxila';
  if (c.includes('mianwali')) return 'mianwali';
  if (c.includes('sargodha')) return 'sargodha';
  if (c.includes('bahawalpur') || c.includes('bhawalpur')) return 'bahawalpur';
  if (c.includes('multan')) return 'multan';
  return null;
}

function cleanCoord(val) {
  if (val === undefined || val === null) return NaN;
  const str = String(val).replace(/,/g, '').replace(/°/g, '').trim();
  const num = parseFloat(str);
  return isNaN(num) ? NaN : num;
}

const phase1Sites = [];
const cityStats = {};

let lastCity = '';

for (let i = 2; i < rows.length; i++) {
  const r = rows[i];
  if (!r || r.length === 0) continue;
  if (r[2]) lastCity = r[2];
  const rawCity = r[2] || lastCity;
  const distKey = normalizeDistrict(rawCity);
  if (!distKey) continue;
  if (!r[3] && !r[4]) continue;

  const info = districtRefs[distKey];
  let lat = cleanCoord(r[5]);
  let lng = cleanCoord(r[6]);
  let isApprox = false;

  if (isNaN(lat) || isNaN(lng)) {
    // If exact GPS coordinate not in sheet (e.g. MDC / BS / DC offices), place near center
    const offsetIdx = (phase1Sites.length % 25);
    lat = info.lat + (offsetIdx * 0.0012 - 0.012);
    lng = info.lng + (offsetIdx * 0.0015 - 0.015);
    isApprox = true;
  }

  const fixCam = parseInt(r[13]) || 0;
  const ptzCam = parseInt(r[14]) || 0;
  const frCam = parseInt(r[15]) || 0;
  const psCam = parseInt(r[16]) || 0;
  const anprCam = parseInt(r[17]) || 0;
  const strobeLight = parseInt(r[18]) || 0;
  const radarCam = parseInt(r[19]) || 0;
  const boxCam = parseInt(r[20]) || 0;
  const totalCams = fixCam + ptzCam + frCam + psCam + anprCam + boxCam;

  const spotId = String(r[3] || '').trim();
  const siteName = String(r[4] || spotId || `${info.name} Site ${i - 1}`).trim();
  
  let rawType = String(r[7] || '').trim().toUpperCase();
  if (!rawType) {
    if (spotId.includes('-C-') || spotId.includes('CEE')) rawType = 'CEE';
    else if (spotId.includes('-D-') || spotId.includes('DEE')) rawType = 'DEE';
    else if (spotId.includes('-P') || spotId.includes('PS')) rawType = 'PS';
    else if (spotId.includes('MDC')) rawType = 'MDC';
    else if (spotId.includes('BS')) rawType = 'BS';
    else if (spotId.includes('DC')) rawType = 'DC';
    else rawType = 'IPNV';
  }

  // Parse pole height & arm
  const poleHeight = parseFloat(String(r[8] || r[9] || 6.8).replace(/[^0-9.]/g, '')) || 6.8;
  const poleArm = String(r[10] || '1.5').trim();

  // Cabinets and meters
  const cabinet = (parseInt(r[11]) || 0) + (parseInt(r[12]) || 0) || (parseInt(r[37]) || 0) || (parseInt(r[38]) || 0) || 1;
  const electricMeter = parseInt(r[42]) || 1;
  const wifiAps = parseInt(r[23]) || 0;
  const panicButtons = parseInt(r[22]) || 0;

  let cleanSpotId = spotId;
  if (spotId === 'MDC') cleanSpotId = `${info.name.substring(0, 3).toUpperCase()}-MDC`;
  else if (spotId === 'DC') cleanSpotId = `${info.name.substring(0, 3).toUpperCase()}-DC`;
  else if (spotId === 'BS') cleanSpotId = `${info.name.substring(0, 3).toUpperCase()}-BS`;
  else if (!spotId) cleanSpotId = `${info.name.substring(0, 3).toUpperCase()}-${String(phase1Sites.length + 1).padStart(3, '0')}`;

  let cleanSiteName = siteName;
  if (!cleanSiteName || cleanSiteName === 'MDC') {
    if (rawType === 'MDC' || cleanSpotId.includes('MDC')) cleanSiteName = 'DPO Office / Control Room';
    else if (rawType === 'DC') cleanSiteName = 'DC Office';
    else cleanSiteName = `${info.name} Site`;
  }

  const siteId = `site_p1_${distKey}_${cleanSpotId.toLowerCase().replace(/[^a-z0-9]/g, '_')}_${i}`;

  const siteObj = {
    id: siteId,
    srNo: parseInt(r[0]) || (phase1Sites.length + 1),
    cluster: 1,
    phase: 'Phase 1',
    city: info.name,
    district_id: distKey,
    spotId: cleanSpotId,
    siteName: cleanSiteName,
    lat: Math.round(lat * 1000000) / 1000000,
    lng: Math.round(lng * 1000000) / 1000000,
    siteType: rawType,
    poleHeight: poleHeight,
    poleType: poleHeight >= 6.8 ? 'L' : 'Straight',
    poleArm: poleArm,
    cabinet: cabinet,
    electricMeter: electricMeter,
    fixCam: fixCam,
    ptzCam: ptzCam,
    frCam: frCam,
    psCam: psCam,
    anprCam: anprCam,
    strobeLight: strobeLight,
    radarCam: radarCam,
    boxCam: boxCam,
    totalCameras: totalCams,
    wifiAps: wifiAps,
    panicButtons: panicButtons,
    status: 'ONLINE',
    isCoordinatesApproximate: isApprox
  };

  phase1Sites.push(siteObj);
  cityStats[info.name] = (cityStats[info.name] || 0) + 1;
}

console.log(`Successfully parsed ${phase1Sites.length} Phase-1 sites across 18 districts:`);
console.table(cityStats);

// Load existing sites.json (Phase 2)
let existingSites = [];
if (fs.existsSync(sitesJsonPath)) {
  existingSites = JSON.parse(fs.readFileSync(sitesJsonPath, 'utf8'));
  console.log(`Loaded ${existingSites.length} existing Phase-2 sites from sites.json.`);
}

// Remove any prior duplicate phase-1 entries if any
const existingPhase2Only = existingSites.filter(s => s.phase !== 'Phase 1');
console.log(`Keeping ${existingPhase2Only.length} Phase-2 sites.`);

// Merge Phase 2 and Phase 1 sites
const combinedSites = [...existingPhase2Only, ...phase1Sites];
console.log(`Total combined sites for all 37 districts: ${combinedSites.length}`);

// Write to data/sites.json
fs.writeFileSync(sitesJsonPath, JSON.stringify(combinedSites, null, 2), 'utf8');
console.log(`Successfully wrote ${combinedSites.length} sites to data/sites.json.`);

// Verify totals by city
const allCities = {};
combinedSites.forEach(s => {
  allCities[s.city] = (allCities[s.city] || 0) + 1;
});
console.log(`Total unique cities now in sites.json: ${Object.keys(allCities).length}`);
