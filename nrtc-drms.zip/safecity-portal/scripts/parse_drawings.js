const fs = require('fs');
const xml = fs.readFileSync('./temp_emp_unzip/xl/drawings/drawing1.xml', 'utf8');
const rels = fs.readFileSync('./temp_emp_unzip/xl/drawings/_rels/drawing1.xml.rels', 'utf8');

// Parse rels
const relMap = {};
const relRegex = /Id="([^"]+)"[^>]*Target="([^"]+)"/g;
let m;
while ((m = relRegex.exec(rels)) !== null) {
  relMap[m[1]] = m[2].replace('../media/', '');
}

// Parse drawing1.xml for twoCellAnchor / oneCellAnchor
const anchorRegex = /<xdr:(twoCellAnchor|oneCellAnchor)[^>]*>([\s\S]*?)<\/xdr:\1>/g;
const rowToImg = {};
while ((m = anchorRegex.exec(xml)) !== null) {
  const content = m[2];
  const rowMatch = content.match(/<xdr:from>[\s\S]*?<xdr:row>(\d+)<\/xdr:row>/);
  const colMatch = content.match(/<xdr:from>[\s\S]*?<xdr:col>(\d+)<\/xdr:col>/);
  const blipMatch = content.match(/r:embed="([^"]+)"/);
  if (rowMatch && blipMatch) {
    const row = parseInt(rowMatch[1]);
    const col = colMatch ? parseInt(colMatch[1]) : -1;
    const rId = blipMatch[1];
    const img = relMap[rId];
    rowToImg[row] = { img, col };
  }
}

console.log('Extracted exact row to image map count:', Object.keys(rowToImg).length);
console.log('Sample rows:');
[3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14].forEach(r => {
  console.log(`Row ${r}:`, rowToImg[r]);
});

fs.writeFileSync('./scripts/exact_drawing_row_map.json', JSON.stringify(rowToImg, null, 2));
