/**
 * End-to-end Verification Script for PTCL Ticket Management with DEE + MCR Sites
 * Tests:
 * 1. Initial empty state & KPI summary
 * 2. PTCL Admin authentication & role verification
 * 3. Authentic DEE + MCR sites lookup via /api/sites?district=sheikhupura&type=DEE,MCR (real database records)
 * 4. Creation permission restrictions (Only DISTRICT_USER / SUPER_ADMIN)
 * 5. Ticket creation with DEE + MCR Sites & Multi-Issue (e.g. QL Down + Internet Down)
 * 6. Multi-Dashboard visibility (User, Other User, Admin, PTCL Admin)
 * 7. PTCL Admin updates progress to In Progress and Resolved with remarks
 * 8. User Acknowledgement & Strict Closure Permissions:
 *    - Rejection of unauthorized acknowledgement/closure by another user (HTTP 403)
 *    - Rejection of acknowledgement/closure by Admin / PTCL Admin (HTTP 403)
 *    - Successful acknowledgement and closure by the original creator
 *    - Automatic calculation of resolution time & recording of acknowledgedAt, closedAt
 *    - Verification that createdAt remains immutable
 * 9. Date/Time and faceted filtering (including MCR spot ID search)
 * 10. Excel (.xlsx) and CSV export endpoints with DEE + MCR sites, issues, and acknowledgedAt
 * 11. Complete audit trail history
 * 12. CRITICAL CLEANUP: Restores ptcl_tickets.json to [] (strictly zero dummy/test data left behind)
 */

const http = require('http');
const fs = require('fs');
const path = require('path');

const PORT = 3000;
const BASE_URL = `http://localhost:${PORT}`;

function request(method, path, body = null) {
  return new Promise((resolve, reject) => {
    const url = new URL(path, BASE_URL);
    const options = {
      hostname: url.hostname,
      port: url.port,
      path: url.pathname + url.search,
      method: method,
      headers: {
        'Content-Type': 'application/json'
      }
    };

    const req = http.request(options, (res) => {
      let data = [];
      res.on('data', chunk => data.push(chunk));
      res.on('end', () => {
        const buffer = Buffer.concat(data);
        const contentType = res.headers['content-type'] || '';
        let parsed = null;
        if (contentType.includes('application/json')) {
          try {
            parsed = JSON.parse(buffer.toString());
          } catch(e) {
            parsed = buffer.toString();
          }
        } else {
          parsed = buffer;
        }
        resolve({
          status: res.statusCode,
          headers: res.headers,
          data: parsed
        });
      });
    });

    req.on('error', err => reject(err));
    if (body) {
      req.write(JSON.stringify(body));
    }
    req.end();
  });
}

async function runTests() {
  console.log('===========================================================');
  console.log('  STARTING PTCL DEE + MCR SITES VERIFICATION TESTS        ');
  console.log('===========================================================\n');

  let passed = 0;
  let failed = 0;

  function assert(condition, message) {
    if (condition) {
      console.log(`  ✓ PASS: ${message}`);
      passed++;
    } else {
      console.error(`  ✗ FAIL: ${message}`);
      failed++;
    }
  }

  try {
    // Ensure clean state before starting tests
    const dbPath = path.join(__dirname, '..', 'data', 'ptcl_tickets.json');
    fs.writeFileSync(dbPath, '[]\n', 'utf8');

    // 1. Check Initial Summary (Empty State)
    console.log('[Test 1] Verify Initial Empty State');
    const initSummary = await request('GET', '/api/ptcl-tickets/summary');
    assert(initSummary.status === 200, 'Summary endpoint returns 200 OK');
    assert(initSummary.data.totalTickets === 0, 'Total tickets is initially 0');
    assert(initSummary.data.open === 0, 'Open tickets is initially 0');
    assert(initSummary.data.avgResolutionTime === 'N/A', 'Average resolution time is N/A when 0 closed tickets');

    // 2. Test PTCL Admin Authentication
    console.log('\n[Test 2] Verify PTCL Admin Authentication');
    const authRes = await request('POST', '/api/auth/login', {
      username: 'ptcl_admin',
      password: 'password123'
    });
    assert(authRes.status === 200, 'PTCL Admin login returns 200');
    assert(authRes.data.success === true, 'Login successful');
    assert(authRes.data.user.role === 'PTCL_ADMIN', 'User role is PTCL_ADMIN');

    // 3. Test Authentic DEE + MCR Sites from Database
    console.log('\n[Test 3] Verify Authentic DEE + MCR Sites from Database (Sheikhupura & Attock)');
    const skpSitesRes = await request('GET', '/api/sites?district=sheikhupura&type=DEE,MCR');
    assert(skpSitesRes.status === 200, 'Sites endpoint with type=DEE,MCR returns 200');
    assert(Array.isArray(skpSitesRes.data), 'Returns an array of sites');
    assert(skpSitesRes.data.length >= 7, `Found ${skpSitesRes.data.length} authentic DEE+MCR sites for Sheikhupura`);
    
    const skpIds = skpSitesRes.data.map(s => s.spotId);
    assert(skpIds.includes('SKP-D-01'), 'Includes DEE site SKP-D-01');
    assert(skpIds.includes('SKP-MDC'), 'Includes MCR site SKP-MDC');
    
    const skpMcrSite = skpSitesRes.data.find(s => s.spotId === 'SKP-MDC');
    assert(skpMcrSite && skpMcrSite.siteCategory === 'MCR', 'SKP-MDC tagged as category MCR');
    const skpDeeSite = skpSitesRes.data.find(s => s.spotId === 'SKP-D-01');
    assert(skpDeeSite && skpDeeSite.siteCategory === 'DEE', 'SKP-D-01 tagged as category DEE');
    console.log(`         Sheikhupura sites: DEE=${skpDeeSite.spotId}, MCR=${skpMcrSite.spotId} (${skpMcrSite.siteName})`);

    const atgSitesRes = await request('GET', '/api/sites?district=attock&type=DEE,MCR');
    assert(atgSitesRes.status === 200, 'Sites endpoint for Attock returns 200');
    const atgIds = atgSitesRes.data.map(s => s.spotId);
    assert(atgIds.includes('ATG-D-01'), 'Attock includes DEE site ATG-D-01');
    assert(atgIds.includes('ATG-MDC'), 'Attock includes MCR site ATG-MDC');

    // 4. Test RBAC: Admin & PTCL Admin CANNOT create tickets
    console.log('\n[Test 4] Verify Creation Restrictions (Only DISTRICT_USER)');
    const adminCreate = await request('POST', '/api/ptcl-tickets', {
      userRole: 'ADMIN',
      userId: 'usr_admin',
      issues: ['QL Down'],
      sites: [{ siteId: 'SKP-MDC', siteName: 'DPO Office Sheikhupura' }]
    });
    assert(adminCreate.status === 403, 'Admin cannot create tickets (HTTP 403)');

    const ptclCreate = await request('POST', '/api/ptcl-tickets', {
      userRole: 'PTCL_ADMIN',
      userId: 'usr_ptcl_admin',
      issues: ['QL Down'],
      sites: [{ siteId: 'SKP-MDC', siteName: 'DPO Office Sheikhupura' }]
    });
    assert(ptclCreate.status === 403, 'PTCL Admin cannot create tickets (HTTP 403)');

    // 5. Test DEE + MCR Sites & Multi-Issue Ticket Creation (QL Down + Internet Down)
    console.log('\n[Test 5] Verify Combined DEE + MCR Sites Ticket Creation with QL Down & Internet Down');
    const selectedSites = [
      { siteId: 'SKP-D-01', siteName: 'Bagh Chowk Hafizabad Road', siteType: 'DEE', siteCategory: 'DEE' },
      { siteId: 'SKP-MDC', siteName: 'DPO Office Sheikhupura', siteType: 'MCR', siteCategory: 'MCR' }
    ];
    const selectedIssues = ['QL Down', 'Internet Down'];

    const userCreate = await request('POST', '/api/ptcl-tickets', {
      userId: 'usr_sheikhupura',
      userName: 'Sheikhupura Site Lead',
      userRole: 'DISTRICT_USER',
      districtId: 'sheikhupura',
      districtName: 'Sheikhupura',
      sites: selectedSites,
      issues: selectedIssues,
      priority: 'Critical',
      description: 'QL link down affecting DPO Office MCR and DEE-01 site communication. Packet loss 100%.',
      attachmentUrl: ''
    });
    assert(userCreate.status === 201, 'District User creates DEE + MCR ticket (HTTP 201)');
    assert(userCreate.data.success === true, 'Response indicates success');
    const ticket = userCreate.data.ticket;
    assert(ticket.ticketId && ticket.ticketId.startsWith('PTCL-'), `Ticket ID generated: ${ticket.ticketId}`);
    assert(ticket.status === 'Open', 'Initial status is Open');
    assert(ticket.createdAt != null, 'Server-side createdAt recorded');
    assert(ticket.sites.length === 2, 'Stored 2 selected sites (DEE + MCR)');
    assert(ticket.siteIds.includes('SKP-D-01') && ticket.siteIds.includes('SKP-MDC'), 'siteIds array indexed with DEE & MCR');
    assert(ticket.issues.includes('QL Down') && ticket.issues.includes('Internet Down'), 'Stored selected issues (QL Down, Internet Down)');
    assert(ticket.acknowledgedAt === null, 'acknowledgedAt is null initially');

    // 6. Test Multi-Dashboard Visibility
    console.log('\n[Test 6] Verify Multi-Dashboard Visibility');
    const userView = await request('GET', `/api/ptcl-tickets?userId=usr_sheikhupura`);
    assert(userView.data.length === 1, 'Creator sees their ticket in user dashboard');

    const otherUserView = await request('GET', `/api/ptcl-tickets?userId=usr_attock`);
    assert(otherUserView.data.length === 0, 'Other district user does not see Sheikhupura ticket');

    const adminView = await request('GET', `/api/ptcl-tickets`);
    assert(adminView.data.length >= 1, 'Admin sees ticket in provincial overview');

    const ptclView = await request('GET', `/api/ptcl-tickets`);
    assert(ptclView.data.length >= 1, 'PTCL Admin sees ticket in NOC desk');

    // 7. Test PTCL Admin Progress Updates
    console.log('\n[Test 7] Verify PTCL Admin Updates Progress to In Progress and Resolved');
    const ptclTryClose = await request('PUT', `/api/ptcl-tickets/${ticket.ticketId}/status`, {
      newStatus: 'Closed',
      remarks: 'PTCL trying to close',
      userRole: 'PTCL_ADMIN'
    });
    assert(ptclTryClose.status === 403, 'PTCL Admin cannot directly set status to Closed (HTTP 403)');

    const inProgressRes = await request('PUT', `/api/ptcl-tickets/${ticket.ticketId}/status`, {
      newStatus: 'In Progress',
      remarks: 'PTCL Core IP team investigating MCR switch port and QL routing at Sheikhupura DPO',
      userName: 'PTCL NOC Engineer',
      userRole: 'PTCL_ADMIN',
      userId: 'usr_ptcl_admin'
    });
    assert(inProgressRes.status === 200, 'PTCL Admin marks In Progress (HTTP 200)');
    assert(inProgressRes.data.ticket.status === 'In Progress', 'Status updated to In Progress');

    const resolvedRes = await request('PUT', `/api/ptcl-tickets/${ticket.ticketId}/status`, {
      newStatus: 'Resolved',
      remarks: 'QL circuit re-routed via backup fiber core. MCR and DEE link operational with zero packet loss.',
      userName: 'PTCL NOC Engineer',
      userRole: 'PTCL_ADMIN',
      userId: 'usr_ptcl_admin'
    });
    assert(resolvedRes.status === 200, 'PTCL Admin marks Resolved (HTTP 200)');
    assert(resolvedRes.data.ticket.status === 'Resolved', 'Status is Resolved');
    assert(resolvedRes.data.ticket.resolvedAt != null, 'resolvedAt timestamp recorded');

    // 8. Test User Acknowledgement & Strict Closure Permissions
    console.log('\n[Test 8] Verify User Acknowledgement & Strict Closure Permissions');
    const wrongUserAck = await request('PUT', `/api/ptcl-tickets/${ticket.ticketId}/acknowledge`, {
      userId: 'usr_attock',
      userName: 'Attock Engineer',
      userRole: 'DISTRICT_USER',
      remarks: 'Attempted acknowledgement by unauthorized user'
    });
    assert(wrongUserAck.status === 403, 'Another user cannot acknowledge or close ticket (HTTP 403)');

    const adminAck = await request('PUT', `/api/ptcl-tickets/${ticket.ticketId}/acknowledge`, {
      userId: 'usr_admin',
      userName: 'Admin',
      userRole: 'ADMIN',
      remarks: 'Attempted acknowledgement by Admin'
    });
    assert(adminAck.status === 403, 'Admin cannot acknowledge or close ticket (HTTP 403)');

    const ptclAck = await request('PUT', `/api/ptcl-tickets/${ticket.ticketId}/acknowledge`, {
      userId: 'usr_ptcl_admin',
      userName: 'PTCL NOC',
      userRole: 'PTCL_ADMIN',
      remarks: 'Attempted acknowledgement by PTCL Admin'
    });
    assert(ptclAck.status === 403, 'PTCL Admin cannot acknowledge or close ticket (HTTP 403)');

    const creatorAck = await request('PUT', `/api/ptcl-tickets/${ticket.ticketId}/acknowledge`, {
      userId: 'usr_sheikhupura',
      userName: 'Sheikhupura Site Lead',
      userRole: 'DISTRICT_USER',
      remarks: 'Verified MCR video wall and DEE-01 feeds are active. Latency < 10ms. Confirm resolution.'
    });
    assert(creatorAck.status === 200, 'Original creator acknowledges and closes ticket (HTTP 200)');
    const closedTicket = creatorAck.data.ticket;
    assert(closedTicket.status === 'Closed', 'Status updated to Closed');
    assert(closedTicket.acknowledgedAt != null, 'acknowledgedAt timestamp recorded');
    assert(closedTicket.closedAt != null, 'closedAt timestamp recorded');
    assert(closedTicket.createdAt === ticket.createdAt, 'Original createdAt timestamp remains unchanged');
    assert(closedTicket.resolutionTimeMs != null, 'Resolution time ms calculated');
    assert(closedTicket.resolutionTimeStr != null, `Resolution time formatted: ${closedTicket.resolutionTimeStr}`);

    // 9. Test Date/Time & Faceted Filtering
    console.log('\n[Test 9] Verify Filtering & Search by MCR Site');
    const filterDistrict = await request('GET', '/api/ptcl-tickets?district=sheikhupura');
    assert(filterDistrict.data.length === 1, 'Filter by district=sheikhupura returns ticket');

    const filterStatus = await request('GET', '/api/ptcl-tickets?status=Closed');
    assert(filterStatus.data.length === 1, 'Filter by status=Closed returns ticket');

    const filterSearchMcr = await request('GET', '/api/ptcl-tickets?search=SKP-MDC');
    assert(filterSearchMcr.data.length === 1, 'Search query by MCR site ID (SKP-MDC) returns ticket');

    // 10. Test Export Endpoints (Excel & CSV)
    console.log('\n[Test 10] Verify Export with DEE + MCR Sites and Issues');
    const exportCsv = await request('GET', '/api/ptcl-tickets/export?format=csv');
    assert(exportCsv.status === 200, 'CSV export returns 200 OK');
    const csvText = exportCsv.data.toString();
    assert(csvText.includes('Ticket ID,User,District,Site,Issue,Priority'), 'CSV header includes standard required columns');
    assert(csvText.includes('Acknowledged Date/Time'), 'CSV header includes Acknowledged Date/Time');
    assert(csvText.includes('SKP-MDC'), 'CSV contains exported MCR site (SKP-MDC)');
    assert(csvText.includes('SKP-D-01'), 'CSV contains exported DEE site (SKP-D-01)');
    assert(csvText.includes('QL Down'), 'CSV contains exported issue (QL Down)');

    const exportXlsx = await request('GET', '/api/ptcl-tickets/export?format=xlsx');
    assert(exportXlsx.status === 200, 'Excel export returns 200 OK');
    assert(exportXlsx.headers['content-type'].includes('spreadsheetml'), 'Content-Type is openxmlformats spreadsheet');
    assert(Buffer.isBuffer(exportXlsx.data) && exportXlsx.data.length > 1000, 'Valid Excel binary buffer received');

    // 11. CRITICAL CLEANUP: Restore database to empty array []
    console.log('\n[Test 11] CRITICAL CLEANUP: Restoring ptcl_tickets.json to []');
    fs.writeFileSync(dbPath, '[]\n', 'utf8');

    // Verify database is completely clean
    const cleanCheck = await request('GET', '/api/ptcl-tickets/summary');
    assert(cleanCheck.data.totalTickets === 0, 'Database verified clean: totalTickets === 0');
    assert(cleanCheck.data.open === 0, 'open === 0');
    assert(cleanCheck.data.closed === 0, 'closed === 0');
    assert(cleanCheck.data.avgResolutionTime === 'N/A', 'avgResolutionTime === N/A');

  } catch(err) {
    console.error('Test execution error:', err);
    failed++;
  }

  console.log('\n===========================================================');
  console.log(`  TEST RESULTS: ${passed} PASSED | ${failed} FAILED`);
  console.log('===========================================================');

  if (failed > 0) {
    process.exit(1);
  } else {
    process.exit(0);
  }
}

runTests();
