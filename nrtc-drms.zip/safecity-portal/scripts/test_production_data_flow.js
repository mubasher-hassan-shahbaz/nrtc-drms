const http = require('http');
const handler = require('../api/index.js');
const { PUNJAB_DISTRICTS } = require('../js/data/districts.js');
const storeModule = require('../js/data/store.js');

async function runTests() {
  console.log('====================================================');
  console.log('VERIFYING VERCEL PRODUCTION ENVIRONMENT & API ENGINE');
  console.log('====================================================\n');

  let passed = 0;
  let failed = 0;

  function assert(condition, message) {
    if (condition) {
      console.log(`  ✅ PASS: ${message}`);
      passed++;
    } else {
      console.error(`  ❌ FAIL: ${message}`);
      failed++;
    }
  }

  // 1. Start Serverless Simulated Server
  const server = http.createServer(handler);
  await new Promise(resolve => server.listen(0, resolve));
  const port = server.address().port;
  const baseUrl = `http://localhost:${port}`;

  try {
    // Test 1: API /api/districts returns all 37 districts
    console.log('--- 1. Testing /api/districts on Vercel Handler ---');
    const distRes = await fetch(`${baseUrl}/api/districts`, {
      headers: { 'x-forwarded-uri': '/api/districts', 'x-matched-path': '/api/index.js' }
    });
    assert(distRes.status === 200, `/api/districts returned status 200 (was ${distRes.status})`);
    const distCache = distRes.headers.get('cache-control');
    assert(distCache && distCache.includes('no-store'), `Cache-Control includes no-store (was "${distCache}")`);
    const districts = await distRes.json();
    assert(Array.isArray(districts) && districts.length === 37, `Returns exactly 37 districts (got ${districts.length})`);

    // Test 2: API /api/reports without limit returns all 3,121 reports
    console.log('\n--- 2. Testing /api/reports (Full Production Database) ---');
    const repRes = await fetch(`${baseUrl}/api/reports`, {
      headers: { 'x-forwarded-uri': '/api/reports' }
    });
    assert(repRes.status === 200, `/api/reports returned status 200`);
    const reports = await repRes.json();
    assert(Array.isArray(reports) && reports.length >= 3000, `Returns full database dataset (got ${reports.length} reports)`);

    // Test 3: Check every one of the 37 DRMS districts has reports in the response
    console.log('\n--- 3. Verifying Reports for all 37 Districts ---');
    const distNamesInReports = new Set(reports.map(r => (r.district_name || r.city || '').toLowerCase().replace(/[^a-z0-9]/g, '')));
    let allCovered = true;
    const norm = s => {
      let x = (s || '').toLowerCase().replace(/[^a-z0-9]/g, '');
      if (x === 'hasanabdal' || x === 'hassanabdal') return 'hassanabdal';
      if (x === 'deraghazikhan' || x === 'dgkhan') return 'deraghazikhan';
      if (x === 'tobateksingh' || x === 'ttsingh') return 'tobateksingh';
      if (x === 'rahimyarkhan' || x === 'ryk') return 'rahimyarkhan';
      return x;
    };
    PUNJAB_DISTRICTS.forEach(d => {
      const dTarget = norm(d.id || d.name);
      const hasReports = reports.some(r => norm(r.district_id) === dTarget || norm(r.district_name) === dTarget || norm(r.city) === dTarget);
      if (!hasReports) {
        console.error(`Missing reports for: ${d.name} (${d.id})`);
        allCovered = false;
      }
    });
    assert(allCovered, `All 37 Punjab DRMS districts have authentic database reports`);

    // Test 4: Hasanabdal / Hassan Abdal normalization
    console.log('\n--- 4. Testing Hassan Abdal / Hasanabdal Alias Querying ---');
    const hasan1 = await (await fetch(`${baseUrl}/api/reports?district=hasanabdal`)).json();
    const hasan2 = await (await fetch(`${baseUrl}/api/reports?district=hassan_abdal`)).json();
    assert(hasan1.length > 0 && hasan1.length === hasan2.length, `Both 'hasanabdal' and 'hassan_abdal' return ${hasan1.length} reports`);

    // Test 5: Vercel URL rewrite with __route & query string preservation
    console.log('\n--- 5. Testing Vercel Rewrite URL Normalizer ---');
    const rwRes = await fetch(`${baseUrl}/api/index.js?__route=reports&limit=15&district=attock`);
    const rwData = await rwRes.json();
    assert(rwRes.status === 200, `Rewrite URL returned 200`);
    assert(rwData.length === 15, `Preserved limit=15 query param (got ${rwData.length})`);
    assert(rwData.every(r => norm(r.district_id) === 'attock' || norm(r.district_name) === 'attock'), `Preserved district=attock filter`);

    // Test 6: Static middleware does not intercept /api or loop redirects
    console.log('\n--- 6. Verifying No 301 Redirect Loop on /api ---');
    const loopRes = await fetch(`${baseUrl}/api/districts`, { redirect: 'manual' });
    assert(loopRes.status === 200, `Manual redirect test returned 200 (not 301/302)`);

    // Test 7: Excluded non-DRMS districts are strictly absent
    console.log('\n--- 7. Verifying Absence of Excluded Districts ---');
    const excluded = ['lahore', 'rawalpindi', 'faisalabad', 'kasur', 'gujranwala', 'nankana', 'nankana_sahib'];
    const hasExcluded = reports.some(r => excluded.includes((r.district_id || '').toLowerCase()));
    assert(!hasExcluded, `Zero excluded districts present in API reports`);

    // Test 8: Store seed reports cover all 37 districts
    console.log('\n--- 8. Verifying Store Seed Baseline Coverage ---');
    const storeSeed = storeModule.generateSeedReports ? storeModule.generateSeedReports() : [];
    if (storeSeed.length > 0) {
      const seedDistIds = new Set(storeSeed.map(r => norm(r.district_id || r.district_name)));
      let seedAllCovered = true;
      PUNJAB_DISTRICTS.forEach(d => {
        if (!seedDistIds.has(norm(d.id || d.name))) seedAllCovered = false;
      });
      assert(seedAllCovered, `store.js generateSeedReports covers all 37 districts baseline`);
    }

  } finally {
    server.close();
  }

  console.log('\n====================================================');
  console.log(`TEST SUMMARY: ${passed} PASSED, ${failed} FAILED`);
  console.log('====================================================');

  if (failed > 0) process.exit(1);
}

runTests().catch(err => {
  console.error('Test execution failed:', err);
  process.exit(1);
});
