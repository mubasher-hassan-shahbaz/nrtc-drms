const fs = require('fs');
const targets = ['lahore', 'rawalpindi', 'faisalabad', 'gujranwala', 'kasur', 'nankana'];

fs.readdirSync('.').forEach(f => {
  if (f.endsWith('.html')) {
    const c = fs.readFileSync(f, 'utf8');
    targets.forEach(t => {
      const regex = new RegExp(`value=['"]${t}['"]`, 'i');
      if (regex.test(c)) {
        console.log(`Found option value="${t}" in ${f}`);
      }
    });
  }
});
console.log('Option scan complete.');
