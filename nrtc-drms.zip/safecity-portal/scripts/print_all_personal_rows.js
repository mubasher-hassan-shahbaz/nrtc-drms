const xlsx = require('xlsx');

const wb = xlsx.readFile('C:/Users/mubas/.gemini/antigravity/brain/786d803e-4a56-4256-8e0f-49f9457a89ad/.user_uploaded/media_1790697626668.xlsx');
const ws = wb.Sheets['Personal details'];
const raw = xlsx.utils.sheet_to_json(ws, { header: 1 });

console.log('--- All Rows in Personal details ---');
raw.forEach((r, idx) => {
  if (r && r.length > 0) {
    console.log(`Row ${idx}: Sr=${r[0]} | ID=${r[1]} | Name="${r[2]}" | Desig="${r[3]}" | Loc="${r[4]}" | Phone="${r[5]}" | Email="${r[6]}"`);
  } else {
    console.log(`Row ${idx}: [EMPTY]`);
  }
});
