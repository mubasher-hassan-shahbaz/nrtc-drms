const fs = require('fs');

const sheetXml = fs.readFileSync('temp_emp_unzip/xl/worksheets/sheet4.xml', 'utf8');

// Parse row heights: <row r="1" ... ht="15" ...>
// Default row height in Excel is usually around 15 pt (or sheetFormatPr defaultRowHeight)
let defaultHt = 15;
const defMatch = sheetXml.match(/defaultRowHeight="([\d.]+)"/);
if (defMatch) defaultHt = parseFloat(defMatch[1]);
console.log('defaultRowHeight:', defaultHt);

const rowHtRegex = /<row\s+[^>]*?r="(\d+)"(?:[^>]*?ht="([\d.]+)")?[^>]*?>/g;
let m;
const rowHeights = {};
let maxRow = 0;
while ((m = rowHtRegex.exec(sheetXml)) !== null) {
  const r = parseInt(m[1], 10);
  const ht = m[2] ? parseFloat(m[2]) : defaultHt;
  rowHeights[r] = ht;
  if (r > maxRow) maxRow = r;
}

console.log('Max row found in sheet4:', maxRow);
console.log('Sample row heights:');
for (let r = 1; r <= 35; r++) {
  console.log(`Row ${r}: ht = ${rowHeights[r] !== undefined ? rowHeights[r] : defaultHt} pt`);
}
