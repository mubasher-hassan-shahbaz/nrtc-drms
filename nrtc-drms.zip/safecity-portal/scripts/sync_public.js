const fs = require('fs');
const path = require('path');

const rootDir = path.resolve(__dirname, '..');
const publicDir = path.join(rootDir, 'public');

function copyRecursiveSync(src, dest) {
  const exists = fs.existsSync(src);
  const stats = exists && fs.statSync(src);
  const isDirectory = exists && stats.isDirectory();
  if (isDirectory) {
    if (!fs.existsSync(dest)) {
      fs.mkdirSync(dest, { recursive: true });
    }
    fs.readdirSync(src).forEach((childItemName) => {
      copyRecursiveSync(path.join(src, childItemName), path.join(dest, childItemName));
    });
  } else {
    fs.copyFileSync(src, dest);
  }
}

console.log('Syncing files to public/ folder...');

// 1. Copy all .html files
const htmlFiles = fs.readdirSync(rootDir).filter(f => f.endsWith('.html') || f.endsWith('.ico') || f.endsWith('.png'));
htmlFiles.forEach(f => {
  fs.copyFileSync(path.join(rootDir, f), path.join(publicDir, f));
  console.log(`Copied ${f} -> public/${f}`);
});

// 2. Copy css/, js/, data/, assets/
const dirs = ['css', 'js', 'data', 'assets'];
dirs.forEach(d => {
  const srcPath = path.join(rootDir, d);
  const destPath = path.join(publicDir, d);
  if (fs.existsSync(srcPath)) {
    copyRecursiveSync(srcPath, destPath);
    console.log(`Synchronized ${d}/ -> public/${d}/`);
  }
});

console.log('Public directory synchronization complete!');
