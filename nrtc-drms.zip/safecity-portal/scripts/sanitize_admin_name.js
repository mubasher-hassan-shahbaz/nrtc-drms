const fs = require('path');
const fsPromises = require('fs');

function sanitizeFile(relPath) {
  const filePath = require('path').join(__dirname, '..', relPath);
  let content = fsPromises.readFileSync(filePath, 'utf8');
  let original = content;
  content = content.replace(/Engr\.\s*Saad\s*Ali\s*Shahbaz\s*\([^)]*\)/g, 'NRTC PMU Admin');
  content = content.replace(/Engr\.\s*Saad\s*Ali\s*Shahbaz/g, 'Admin');
  content = content.replace(/'Saad Ali Shahbaz'/g, "'Admin'");
  content = content.replace(/"Saad Ali Shahbaz"/g, '"Admin"');
  if (content !== original) {
    fsPromises.writeFileSync(filePath, content, 'utf8');
    console.log('Sanitized:', relPath);
  } else {
    console.log('No change:', relPath);
  }
}

sanitizeFile('js/data/store.js');
sanitizeFile('js/app.js');
console.log('Sanitization complete.');
