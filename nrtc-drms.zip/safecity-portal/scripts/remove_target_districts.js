const fs = require('fs');
const path = require('path');
const XLSX = require('xlsx');

console.log('=== REMOVING 6 TARGET DISTRICTS COMPLETELY ===\n');

const targets = ['nankana_sahib', 'nankana', 'lahore', 'faisalabad', 'kasur', 'rawalpindi', 'gujranwala'];

// 1. Clean data/users.json
const usersPath = './data/users.json';
let users = JSON.parse(fs.readFileSync(usersPath, 'utf8'));
const initialUserCount = users.length;

users = users.filter(u => {
  const uname = (u.username || '').toLowerCase();
  const udist = (u.districtId || '').toLowerCase();
  return !targets.includes(uname) && !targets.includes(udist);
});

// Update any remaining PMU admins to remove (Lahore)
users.forEach(u => {
  if (u.districtName) {
    u.districtName = u.districtName.replace(/\s*\(Lahore\)/gi, '').replace(/\s*\(Headquarters\)/gi, '').trim();
  }
});

fs.writeFileSync(usersPath, JSON.stringify(users, null, 2), 'utf8');
console.log(`1. Users cleaned: ${initialUserCount} -> ${users.length} (removed ${initialUserCount - users.length} users)`);

// 2. Clean data/employees.json
const empsPath = './data/employees.json';
let emps = JSON.parse(fs.readFileSync(empsPath, 'utf8'));
const initialEmpCount = emps.length;

// First preserve Warizabad -> wazirabad, and Haripur / NCI -> central
emps.forEach(e => {
  const loc = (e.location || '').trim();
  if (loc.toLowerCase() === 'warizabad') {
    e.location = 'Wazirabad';
    e.district_id = 'wazirabad';
    e.districtName = 'Wazirabad';
  } else if (loc.toLowerCase() === 'haripur') {
    e.district_id = 'central';
    e.districtName = 'NRTC Complex (Haripur)';
  } else if (loc.toLowerCase() === 'nci') {
    e.district_id = 'central';
    e.districtName = 'NRTC Center (NCI)';
  }
});

// Remove employees belonging to target districts or whose location is in target districts
emps = emps.filter(e => {
  const loc = (e.location || '').toLowerCase();
  const dist = (e.district_id || '').toLowerCase();
  const distName = (e.districtName || '').toLowerCase();

  const isTargetLoc = targets.some(t => loc.includes(t) || loc === 'rwp' || loc === 'bo lahore' || loc === 'psca hq' || loc === 'pd house');
  const isTargetDist = targets.includes(dist);
  const isTargetDistName = targets.some(t => distName.includes(t));

  return !isTargetLoc && !isTargetDist && !isTargetDistName;
});

fs.writeFileSync(empsPath, JSON.stringify(emps, null, 2), 'utf8');
console.log(`2. Employees cleaned: ${initialEmpCount} -> ${emps.length} (removed ${initialEmpCount - emps.length} employees)`);

// 3. Update data/portal-credentials.csv & portal-credentials.xlsx
const csvRows = ['#,Username (Login ID),Display Name,Role,District,Password,Email,Designation'];
const xlsxRows = [
  ['#', 'Username (Login ID)', 'Display Name', 'Role', 'District', 'Password', 'Email', 'Designation']
];

let uIdx = 1;
users.forEach(u => {
  csvRows.push([
    uIdx,
    u.username,
    `"${u.name}"`,
    u.role,
    `"${u.districtName || u.districtId}"`,
    u.password,
    `"${u.email || ''}"`,
    `"${u.designation || ''}"`
  ].join(','));

  xlsxRows.push([
    uIdx,
    u.username,
    u.name,
    u.role,
    u.districtName || u.districtId,
    u.password,
    u.email || '',
    u.designation || ''
  ]);
  uIdx++;
});

fs.writeFileSync('./data/portal-credentials.csv', csvRows.join('\n'), 'utf8');

const ws = XLSX.utils.aoa_to_sheet(xlsxRows);
const wb = XLSX.utils.book_new();
XLSX.utils.book_append_sheet(wb, ws, 'Portal Credentials');
XLSX.writeFile(wb, './data/portal-credentials.xlsx');
console.log(`3. Portal credentials files regenerated with ${users.length} active users.`);

// 4. Clean js/data/districts.js
const districtsJsPath = './js/data/districts.js';
let distContent = fs.readFileSync(districtsJsPath, 'utf8');

// Replace divisions mentioning the 6 target districts with regional zones
distContent = distContent
  .replace(/division:\s*'Rawalpindi'/g, "division: 'Northern Region'")
  .replace(/division:\s*'Faisalabad'/g, "division: 'Central Region'")
  .replace(/division:\s*'Gujranwala'/g, "division: 'Gujrat Region'")
  .replace(/division:\s*'Lahore'/g, "division: 'Sheikhupura Region'");

// Filter PUNJAB_DISTRICTS in the file
const distRegex = /const PUNJAB_DISTRICTS = (\[[\s\S]*?\]);/;
const match = distContent.match(distRegex);
if (match) {
  let list = eval(match[1]);
  const initialDistCount = list.length;
  list = list.filter(d => !targets.includes(d.id.toLowerCase()));
  
  // Format cleanly
  const formattedList = 'const PUNJAB_DISTRICTS = ' + JSON.stringify(list, null, 2) + ';';
  distContent = distContent.replace(distRegex, formattedList);
  fs.writeFileSync(districtsJsPath, distContent, 'utf8');
  console.log(`4. PUNJAB_DISTRICTS cleaned: ${initialDistCount} -> ${list.length} (removed ${initialDistCount - list.length} districts)`);
}

// 5. Clean js/data/store.js of target district references
const storePath = './js/data/store.js';
let storeContent = fs.readFileSync(storePath, 'utf8');
storeContent = storeContent
  .replace(/division:\s*'Rawalpindi'/g, "division: 'Northern Region'")
  .replace(/division:\s*'Faisalabad'/g, "division: 'Central Region'")
  .replace(/division:\s*'Gujranwala'/g, "division: 'Gujrat Region'")
  .replace(/division:\s*'Lahore'/g, "division: 'Sheikhupura Region'")
  .replace(/NRTC PMU Command \(Lahore\)/g, 'NRTC PMU Command');

fs.writeFileSync(storePath, storeContent, 'utf8');
console.log('5. store.js cleaned of target district references.');

// 6. Clean placeholder in sites.html
const sitesHtmlPath = './sites.html';
let sitesContent = fs.readFileSync(sitesHtmlPath, 'utf8');
sitesContent = sitesContent.replace(
  'placeholder="🔍 Search any Punjab District (e.g. Lahore, Chakwal, Rawalpindi, Multan, Attock, Faisalabad...)"',
  'placeholder="🔍 Search any Punjab District (e.g. Chakwal, Multan, Attock, Wazirabad, Sialkot...)"'
);
fs.writeFileSync(sitesHtmlPath, sitesContent, 'utf8');
console.log('6. sites.html search placeholder updated.');

console.log('\n=== REMOVAL COMPLETED SUCCESSFULLY ===');
