const fs = require('fs');
const path = require('path');

const rootDir = path.resolve(__dirname, '..');
const files = fs.readdirSync(rootDir).filter(f => f.endsWith('.html'));
let count = 0;

files.forEach(f => {
  const filePath = path.join(rootDir, f);
  let content = fs.readFileSync(filePath, 'utf8');
  const target = /if\s*\(\s*window\.location\.pathname\.toLowerCase\(\)\.endsWith\('finance\.html'\)\s*&&\s*window\.switchFinanceTab\s*\)/g;
  if (target.test(content)) {
    content = content.replace(target, 'if(window.switchFinanceTab && document.getElementById("tabContentExpenses"))');
    fs.writeFileSync(filePath, content, 'utf8');
    count++;
    console.log('Updated ' + f);
  }
});

console.log('Total files updated: ' + count);
