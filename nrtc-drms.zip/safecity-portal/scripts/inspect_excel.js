const fs = require('fs');
const path = require('path');
const xlsx = require('xlsx');

const dir = 'C:\\Users\\mubas\\.gemini\\antigravity\\brain\\786d803e-4a56-4256-8e0f-49f9457a89ad\\.user_uploaded';
const files = fs.readdirSync(dir).filter(f => f.endsWith('.xlsx'));

console.log('Found xlsx files:', files);

files.forEach(f => {
  const filePath = path.join(dir, f);
  console.log(`\n========================================`);
  console.log(`FILE: ${f} (${(fs.statSync(filePath).size / 1024).toFixed(1)} KB)`);
  try {
    const wb = xlsx.readFile(filePath);
    console.log('Sheets:', wb.SheetNames);
    wb.SheetNames.forEach(sheetName => {
      const sheet = wb.Sheets[sheetName];
      const data = xlsx.utils.sheet_to_json(sheet, { header: 1 });
      console.log(`  Sheet [${sheetName}]: ${data.length} rows`);
      if (data.length > 0) {
        // print first 3 non-empty rows
        const sample = data.filter(r => r && r.length > 0).slice(0, 3);
        console.log('    Sample rows:');
        sample.forEach((r, idx) => console.log(`      [Row ${idx+1}]:`, r.slice(0, 8)));
      }
    });
  } catch (err) {
    console.error(`  Error reading ${f}:`, err.message);
  }
});
