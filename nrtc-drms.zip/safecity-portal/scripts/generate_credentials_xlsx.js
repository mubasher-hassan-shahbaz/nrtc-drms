/**
 * Generate Excel (.xlsx) credentials file using the xlsx library
 */
const fs = require('fs');
const path = require('path');
const XLSX = require('xlsx');

const users = JSON.parse(fs.readFileSync(path.join(__dirname, '../data/users.json'), 'utf8'));

// Build worksheet data
const wsData = [
  // Header row
  ['#', 'Login Username', 'Display Name', 'Role', 'District / Location', 'Division', 'Password', 'Email Address', 'Designation', 'Notes']
];

users.forEach((u, idx) => {
  wsData.push([
    idx + 1,
    u.username,
    u.name,
    u.role === 'ADMIN' ? '🛡️ PMU Admin' : '🏛️ District User',
    u.districtName || 'All Punjab',
    u.division || 'PMU Lahore',
    u.password || 'password123',
    u.email || '',
    u.designation || '',
    u.role === 'ADMIN' ? 'Full access to all pages' : 'District-only access'
  ]);
});

// Create workbook
const wb = XLSX.utils.book_new();
const ws = XLSX.utils.aoa_to_sheet(wsData);

// Column widths
ws['!cols'] = [
  { wch: 4 },   // #
  { wch: 20 },  // Username
  { wch: 35 },  // Display Name
  { wch: 16 },  // Role
  { wch: 22 },  // District
  { wch: 18 },  // Division
  { wch: 14 },  // Password
  { wch: 35 },  // Email
  { wch: 35 },  // Designation
  { wch: 30 },  // Notes
];

XLSX.utils.book_append_sheet(wb, ws, 'Portal Credentials');

// Also add a summary sheet
const summaryData = [
  ['Punjab Safe City O&M Portal — Login Credentials'],
  ['Generated:', new Date().toLocaleString('en-PK', { timeZone: 'Asia/Karachi' })],
  [''],
  ['IMPORTANT SECURITY NOTICE'],
  ['• All passwords should be changed after first login'],
  ['• Admin logins: admin, lahore'],
  ['• District logins: use the district name as username'],
  ['• Universal password: password123'],
  [''],
  ['Total Users:', users.length],
  ['PMU Admin Accounts:', users.filter(u => u.role === 'ADMIN').length],
  ['District User Accounts:', users.filter(u => u.role === 'DISTRICT_USER').length],
];

const summaryWs = XLSX.utils.aoa_to_sheet(summaryData);
summaryWs['!cols'] = [{ wch: 35 }, { wch: 50 }];
XLSX.utils.book_append_sheet(wb, summaryWs, 'README');

const outPath = path.join(__dirname, '../data/portal-credentials.xlsx');
XLSX.writeFile(wb, outPath);
console.log(`✅ Excel credentials written: ${outPath}`);
console.log(`   ${users.length} users exported`);
