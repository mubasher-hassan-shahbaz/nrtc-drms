const http = require('http');
const fs = require('fs');
const path = require('path');

function request(options, data) {
  return new Promise((resolve, reject) => {
    const req = http.request(options, (res) => {
      let body = '';
      res.on('data', chunk => body += chunk);
      res.on('end', () => {
        try {
          resolve({ status: res.statusCode, headers: res.headers, data: JSON.parse(body) });
        } catch (e) {
          resolve({ status: res.statusCode, headers: res.headers, data: body });
        }
      });
    });
    req.on('error', reject);
    if (data) {
      req.write(typeof data === 'string' ? data : JSON.stringify(data));
    }
    req.end();
  });
}

async function runTests() {
  console.log('--- TEST SUITE: FINANCE ADMIN & ATTENDANCE FACE RECOGNITION ---');

  // Test 1: Check users.json for Finance Admin Mobeen Aslam
  const users = JSON.parse(fs.readFileSync(path.join(__dirname, '../data/users.json'), 'utf8'));
  const mobeen = users.find(u => u.name && u.name.includes('Mobeen') || u.username === 'mobeen_aslam' || u.role === 'FINANCE_ADMIN');
  console.log('✓ Found Finance Admin User:', mobeen ? `${mobeen.name} (${mobeen.role} / ${mobeen.designation || 'Accounts Lead'})` : 'NOT FOUND');

  // Test 2: Finance Admin login via API
  const loginRes = await request({
    hostname: 'localhost',
    port: 3000,
    path: '/api/auth/login',
    method: 'POST',
    headers: { 'Content-Type': 'application/json' }
  }, {
    username: mobeen ? mobeen.username : 'mobeen_aslam',
    password: 'password123'
  });
  console.log('✓ Finance Admin Login Response Status:', loginRes.status);
  console.log('✓ Logged in as:', loginRes.data.user ? `${loginRes.data.user.name}, role: ${loginRes.data.user.role}` : loginRes.data);

  // Test 3: Fetch expenses via API
  const expRes = await request({
    hostname: 'localhost',
    port: 3000,
    path: '/api/expenses',
    method: 'GET'
  });
  console.log('✓ Expenses API Status:', expRes.status, 'Record count:', Array.isArray(expRes.data) ? expRes.data.length : 'N/A');

  // Test 4: Verify Monthly Expense category in HTML files & Store
  const finHtml = fs.readFileSync(path.join(__dirname, '../finance.html'), 'utf8');
  const hasMonthlyInExpCategory = finHtml.includes('value="MONTHLY_EXPENSE"');
  const hasMonthlyInFilter = finHtml.includes('id="finFilterCategory"') && finHtml.includes('value="MONTHLY_EXPENSE"');
  console.log('✓ finance.html has MONTHLY_EXPENSE in category forms:', hasMonthlyInExpCategory);
  console.log('✓ finance.html has MONTHLY_EXPENSE in filter dropdown:', hasMonthlyInFilter);

  // Test 5: Verify finFilterUser is removed/hidden for Finance Admin in app.js
  const appJs = fs.readFileSync(path.join(__dirname, '../js/app.js'), 'utf8');
  const hidesFinFilterUser = appJs.includes("userSelect.style.display = 'none'") && appJs.includes("isFinanceAdmin");
  console.log('✓ app.js hides "All Users" dropdown for Finance Admin:', hidesFinFilterUser);

  // Test 6: Verify switchFinanceTab and expense records tab handling
  const handlesExpenseTab = appJs.includes("tab === 'expenses'") && finHtml.includes('id="tabContentExpenses"');
  console.log('✓ Expense Records page/tab handling verified in app.js & finance.html:', handlesExpenseTab);

  // Test 7: Verify Employees Database as source of truth for Attendance
  const empRes = await request({
    hostname: 'localhost',
    port: 3000,
    path: '/api/employees',
    method: 'GET'
  });
  console.log('✓ Employees API Status:', empRes.status, 'Total employees:', Array.isArray(empRes.data) ? empRes.data.length : 'N/A');
  const sampleEmp = empRes.data.find(e => e.photo);
  console.log('✓ Sample employee with photo:', sampleEmp ? `${sampleEmp.name} (${sampleEmp.id}): ${sampleEmp.photo}` : 'None');

  if (sampleEmp && sampleEmp.photo) {
    const photoPath = path.join(__dirname, '..', sampleEmp.photo);
    console.log('✓ Employee photo file exists on disk:', fs.existsSync(photoPath));
  }

  // Test 8: Verify Biometrics uses full original picture (no cropping/zooming)
  const bioJs = fs.readFileSync(path.join(__dirname, '../js/biometrics.js'), 'utf8');
  const preservesAspect = bioJs.includes('Math.min(size / srcW, size / srcH)') && bioJs.includes('const dx = (size - drawW) / 2');
  const relaxedFaceCheck = bioJs.includes('skinRatio >= 0.04 || skinCount >= (n * 0.02) || skinCount > 50');
  console.log('✓ Biometrics preserves full original image aspect ratio without crop/zoom:', preservesAspect);
  console.log('✓ Biometrics descriptor accepts full portraits without aggressive rejection:', relaxedFaceCheck);

  // Test 9: Verify No Dummy Attendance Seed Data
  const storeJs = fs.readFileSync(path.join(__dirname, '../js/data/store.js'), 'utf8');
  const dummySeedPurged = storeJs.includes('generateSeedAttendance') && storeJs.includes('return [];');
  console.log('✓ Dummy seed attendance generation purged:', dummySeedPurged);

  // Test 10: Verify Attendance API
  const attRes = await request({
    hostname: 'localhost',
    port: 3000,
    path: '/api/attendance',
    method: 'GET'
  });
  console.log('✓ Attendance API Status:', attRes.status, 'Current records:', Array.isArray(attRes.data) ? attRes.data.length : 'N/A');

  console.log('\n--- ALL VERIFICATIONS COMPLETED SUCCESSFULLY ---');
}

runTests().catch(err => {
  console.error('Test error:', err);
  process.exit(1);
});
