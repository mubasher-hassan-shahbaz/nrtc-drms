const http = require('http');
const fs = require('fs');
const path = require('path');
const app = require('../server.js');

let server;
const PORT = 3099;

function runTests() {
  server = app.listen(PORT, async () => {
    console.log(`Test server running on port ${PORT}...`);
    let passed = 0;
    let failed = 0;

    const assert = (condition, desc) => {
      if (condition) {
        console.log(`  ✅ PASS: ${desc}`);
        passed++;
      } else {
        console.error(`  ❌ FAIL: ${desc}`);
        failed++;
      }
    };

    try {
      // TEST 1: Check /api/auth/me endpoint with Admin credentials
      console.log('\n--- 1. Testing /api/auth/me Endpoint ---');
      const resAdmin = await fetch(`http://localhost:${PORT}/api/auth/me`, {
        headers: {
          'x-user-id': 'usr_admin',
          'x-user-role': 'ADMIN'
        }
      });
      const dataAdmin = await resAdmin.json();
      assert(dataAdmin.success === true, 'Admin auth/me returns success');
      assert(dataAdmin.user && dataAdmin.user.name === 'Admin', `Admin user.name is correct ("${dataAdmin.user?.name}")`);
      assert(dataAdmin.user && !dataAdmin.user.password, 'Password field is stripped from safeUser');
      assert(dataAdmin.user && dataAdmin.user.role === 'ADMIN', 'Role is ADMIN');

      // TEST 2: Check /api/auth/me endpoint with Finance Admin credentials
      console.log('\n--- 2. Testing Finance Admin /api/auth/me ---');
      const resFin = await fetch(`http://localhost:${PORT}/api/auth/me`, {
        headers: {
          'x-user-id': 'usr_finance_admin',
          'x-user-role': 'FINANCE_ADMIN'
        }
      });
      const dataFin = await resFin.json();
      assert(dataFin.success === true, 'Finance Admin auth/me returns success');
      assert(dataFin.user && dataFin.user.name === 'Finance Admin', `Finance Admin name is correct ("${dataFin.user?.name}")`);
      assert(dataFin.user && dataFin.user.role === 'FINANCE_ADMIN', 'Role is FINANCE_ADMIN');

      // TEST 3: Verify finance tab switching doesn't have infinite reload logic
      console.log('\n--- 3. Verifying Finance Switch Logic in js/app.js ---');
      const appJs = fs.readFileSync(path.join(__dirname, '../js/app.js'), 'utf8');
      assert(!appJs.includes("window.location.pathname.toLowerCase().endsWith('finance.html')"), 'Removed bad endsWith finance.html redirect loop in switchFinanceTab');
      assert(appJs.includes('if (!contentExpenses || !contentQueries)'), 'switchFinanceTab checks for DOM presence instead of path collision');
      assert(appJs.includes('window.history.replaceState({}, \'\', url)'), 'switchFinanceTab updates URL history query cleanly without reload');

      // TEST 4: Verify mobile sidebar toggle and overlay in ticket pages
      console.log('\n--- 4. Verifying Mobile Sidebar in Ticket Pages ---');
      const ticketsHtml = fs.readFileSync(path.join(__dirname, '../tickets.html'), 'utf8');
      const ptclHtml = fs.readFileSync(path.join(__dirname, '../ptcl-tickets.html'), 'utf8');
      assert(ticketsHtml.includes('sidebar-close-btn'), 'tickets.html has sidebar-close-btn');
      assert(ptclHtml.includes('sidebar-close-btn'), 'ptcl-tickets.html has sidebar-close-btn');
      assert(ptclHtml.includes("sb.classList.toggle('open'"), 'ptcl-tickets.html toggles .open instead of .active');
      assert(ptclHtml.includes("sidebarOverlay"), 'ptcl-tickets.html manages sidebarOverlay');

      // TEST 5: Verify Responsive CSS down to 200px
      console.log('\n--- 5. Verifying Responsive CSS (<300px down to 200px) ---');
      const stylesCss = fs.readFileSync(path.join(__dirname, '../css/styles.css'), 'utf8');
      assert(stylesCss.includes('@media (max-width: 300px)'), 'styles.css has media query for max-width: 300px');
      assert(stylesCss.includes('z-index: 10000 !important;'), 'styles.css elevates mobile sidebar to z-index: 10000');
      assert(stylesCss.includes('z-index: 9999 !important;'), 'styles.css elevates mobile overlay to z-index: 9999');
      assert(stylesCss.includes('overflow-x: hidden !important;'), 'styles.css locks body and container overflow-x on ultra-narrow viewports');

      // TEST 6: Verify Profile Name dynamic binding & sanitize
      console.log('\n--- 6. Verifying Profile Sanitization ---');
      const storeJs = fs.readFileSync(path.join(__dirname, '../js/data/store.js'), 'utf8');
      assert(storeJs.includes('/saad|shahbaz/i'), 'store.js has active sanitization against stale legacy names');
      assert(appJs.includes('/saad|shahbaz/i'), 'app.js has active sanitization against stale legacy names');

      console.log(`\n========================================`);
      console.log(`TEST RESULTS: ${passed} PASSED, ${failed} FAILED`);
      console.log(`========================================\n`);

      server.close(() => {
        process.exit(failed > 0 ? 1 : 0);
      });
    } catch (err) {
      console.error('Test execution failed with error:', err);
      if (server) server.close();
      process.exit(1);
    }
  });
}

runTests();
