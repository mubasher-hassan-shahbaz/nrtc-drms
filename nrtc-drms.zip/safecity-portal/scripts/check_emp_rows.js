const XLSX = require('xlsx');
const wb = XLSX.readFile('C:/Users/mubas/.gemini/antigravity/brain/786d803e-4a56-4256-8e0f-49f9457a89ad/.user_uploaded/media_1790697626668.xlsx');
const ws = wb.Sheets['Personal details'];
const data = XLSX.utils.sheet_to_json(ws, { header: 1 });

for (let i = 2; i < 28; i++) {
  const r = data[i] || [];
  console.log(`Excel Row ${i}: Sr=${r[0]}, EmpID=${r[1]}, Name=${r[2]}, Desig=${r[3]}, Loc=${r[4]}, Email=${r[6]}`);
}
