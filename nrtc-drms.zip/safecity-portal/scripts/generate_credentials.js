/**
 * Generate credentials Excel/CSV file for all 44 portal users
 */
const fs = require('fs');
const path = require('path');

const users = JSON.parse(fs.readFileSync(path.join(__dirname, '../data/users.json'), 'utf8'));

// Build CSV
const csvLines = [
  // Header
  ['#', 'Username (Login ID)', 'Display Name', 'Role', 'District', 'Division', 'Password', 'Email', 'Designation'].join(',')
];

users.forEach((u, idx) => {
  const row = [
    idx + 1,
    u.username,
    `"${u.name}"`,
    u.role === 'ADMIN' ? 'Admin (PMU)' : 'District User',
    `"${u.districtName || 'All Punjab'}"`,
    `"${u.division || 'PMU'}"`,
    u.password || 'password123',
    `"${u.email || ''}"`,
    `"${u.designation || ''}"`
  ];
  csvLines.push(row.join(','));
});

const csvContent = csvLines.join('\n');
const csvPath = path.join(__dirname, '../data/portal-credentials.csv');
fs.writeFileSync(csvPath, csvContent, 'utf8');
console.log(`✅ Credentials CSV written: ${csvPath}`);
console.log(`   Total users: ${users.length}`);
console.log(`   Admins: ${users.filter(u => u.role === 'ADMIN').length}`);
console.log(`   District users: ${users.filter(u => u.role === 'DISTRICT_USER').length}`);
console.log('\nSample credentials:');
users.slice(0, 5).forEach(u => {
  console.log(`  ${u.username} / ${u.password || 'password123'} (${u.role})`);
});
