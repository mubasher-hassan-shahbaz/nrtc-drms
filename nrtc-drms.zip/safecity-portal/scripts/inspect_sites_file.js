const xlsx = require('xlsx');

const wb = xlsx.readFile('C:/Users/mubas/.gemini/antigravity/brain/786d803e-4a56-4256-8e0f-49f9457a89ad/.user_uploaded/media_1790697626387.xlsx');
console.log('Sheets in media_1790697626387.xlsx:', wb.SheetNames);
wb.SheetNames.forEach(name => {
  const ws = wb.Sheets[name];
  const json = xlsx.utils.sheet_to_json(ws, { header: 1 });
  console.log(`Sheet [${name}]: ${json.length} rows`);
  if (json.length > 0) {
    console.log('  Row 0:', JSON.stringify(json[0]?.slice(0, 8)));
    console.log('  Row 1:', JSON.stringify(json[1]?.slice(0, 8)));
    console.log('  Row 2:', JSON.stringify(json[2]?.slice(0, 8)));
  }
});
