const fs = require('fs');
const path = require('path');

const districts = [
  { id: 'attock', name: 'Attock', division: 'Rawalpindi' },
  { id: 'bahawalnagar', name: 'Bahawalnagar', division: 'Bahawalpur' },
  { id: 'bahawalpur', name: 'Bahawalpur', division: 'Bahawalpur' },
  { id: 'bhakkar', name: 'Bhakkar', division: 'Sargodha' },
  { id: 'chakwal', name: 'Chakwal', division: 'Rawalpindi' },
  { id: 'chiniot', name: 'Chiniot', division: 'Faisalabad' },
  { id: 'dg_khan', name: 'Dera Ghazi Khan', division: 'D.G. Khan' },
  { id: 'faisalabad', name: 'Faisalabad', division: 'Faisalabad' },
  { id: 'gujranwala', name: 'Gujranwala', division: 'Gujranwala' },
  { id: 'gujrat', name: 'Gujrat', division: 'Gujranwala' },
  { id: 'hafizabad', name: 'Hafizabad', division: 'Gujranwala' },
  { id: 'jhang', name: 'Jhang', division: 'Faisalabad' },
  { id: 'jhelum', name: 'Jhelum', division: 'Rawalpindi' },
  { id: 'kasur', name: 'Kasur', division: 'Lahore' },
  { id: 'khanewal', name: 'Khanewal', division: 'Multan' },
  { id: 'khushab', name: 'Khushab', division: 'Sargodha' },
  { id: 'kot_addu', name: 'Kot Addu', division: 'D.G. Khan' },
  { id: 'lahore', name: 'Lahore', division: 'Lahore' },
  { id: 'layyah', name: 'Layyah', division: 'D.G. Khan' },
  { id: 'lodhran', name: 'Lodhran', division: 'Multan' },
  { id: 'mandi_bahauddin', name: 'Mandi Bahauddin', division: 'Gujranwala' },
  { id: 'mianwali', name: 'Mianwali', division: 'Sargodha' },
  { id: 'multan', name: 'Multan', division: 'Multan' },
  { id: 'murree', name: 'Murree', division: 'Rawalpindi' },
  { id: 'muzaffargarh', name: 'Muzaffargarh', division: 'D.G. Khan' },
  { id: 'nankana_sahib', name: 'Nankana Sahib', division: 'Lahore' },
  { id: 'narowal', name: 'Narowal', division: 'Gujranwala' },
  { id: 'okara', name: 'Okara', division: 'Sahiwal' },
  { id: 'pakpattan', name: 'Pakpattan', division: 'Sahiwal' },
  { id: 'rahim_yar_khan', name: 'Rahim Yar Khan', division: 'Bahawalpur' },
  { id: 'rajanpur', name: 'Rajanpur', division: 'D.G. Khan' },
  { id: 'rawalpindi', name: 'Rawalpindi', division: 'Rawalpindi' },
  { id: 'sahiwal', name: 'Sahiwal', division: 'Sahiwal' },
  { id: 'sargodha', name: 'Sargodha', division: 'Sargodha' },
  { id: 'sheikhupura', name: 'Sheikhupura', division: 'Lahore' },
  { id: 'sialkot', name: 'Sialkot', division: 'Gujranwala' },
  { id: 'toba_tek_singh', name: 'Toba Tek Singh', division: 'Faisalabad' },
  { id: 'vehari', name: 'Vehari', division: 'Multan' },
  { id: 'wazirabad', name: 'Wazirabad', division: 'Gujranwala' }
];

const users = [
  {
    id: 'usr_admin',
    username: 'admin',
    password: 'password123',
    name: 'Admin',
    role: 'ADMIN',
    districtId: 'all',
    districtName: 'Punjab PMU Command (Lahore)',
    designation: 'Project Director / Command Lead',
    email: 'admin@nrtc.com.pk'
  },
  {
    id: 'usr_lahore_pmu',
    username: 'lahore',
    password: 'password123',
    name: 'Admin',
    role: 'ADMIN',
    districtId: 'all',
    districtName: 'Punjab PMU Command (Lahore)',
    designation: 'Project Management Unit',
    email: 'lahore@nrtc.com.pk'
  }
];

districts.forEach(d => {
  if (d.id === 'lahore') return;
  users.push({
    id: `usr_${d.id}`,
    username: d.id,
    password: 'password123',
    name: d.name,
    role: 'DISTRICT_USER',
    districtId: d.id,
    districtName: d.name,
    division: d.division,
    designation: '',
    email: `${d.id}@nrtc.com.pk`
  });
});

fs.writeFileSync(path.join(__dirname, '../data/users.json'), JSON.stringify(users, null, 2), 'utf8');
console.log('Saved', users.length, 'clean users to data/users.json');
