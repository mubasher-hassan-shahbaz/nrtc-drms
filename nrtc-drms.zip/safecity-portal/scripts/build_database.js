const fs = require('fs');
const path = require('path');
const xlsx = require('xlsx');

const baseDir = path.resolve(__dirname, '..');
const uploadedDir = 'C:\\Users\\mubas\\.gemini\\antigravity\\brain\\786d803e-4a56-4256-8e0f-49f9457a89ad\\.user_uploaded';
const dataDir = path.join(baseDir, 'data');
if (!fs.existsSync(dataDir)) fs.mkdirSync(dataDir, { recursive: true });

// Helper to convert excel serial date or string to YYYY-MM-DD
function formatExcelDate(val) {
  if (!val) return '';
  if (typeof val === 'number') {
    // Excel dates: days since 1899-12-30
    const d = new Date(Math.round((val - 25569) * 86400 * 1000));
    return d.toISOString().split('T')[0];
  }
  const s = String(val).trim();
  if (/^\d{4}-\d{2}-\d{2}/.test(s)) return s.split(' ')[0].split('T')[0];
  // mm/dd/yyyy or dd/mm/yyyy
  const parts = s.split(/[\/\-]/);
  if (parts.length === 3) {
    let [m, d, y] = parts;
    if (y.length === 2) y = '20' + y;
    if (m.length === 1) m = '0' + m;
    if (d.length === 1) d = '0' + d;
    // Check if first is year
    if (parts[0].length === 4) return `${parts[0]}-${parts[1].padStart(2, '0')}-${parts[2].padStart(2, '0')}`;
    return `${y}-${m}-${d}`;
  }
  return s;
}

// -------------------------------------------------------------
// 1. Parse SITES Master Sheet (media_1790697626387.xlsx)
// -------------------------------------------------------------
console.log('--- 1. Parsing Sites Master Sheet ---');
const sitesFile = path.join(uploadedDir, 'media_1790697626387.xlsx');
const sitesWb = xlsx.readFile(sitesFile);
const sitesSheetName = sitesWb.SheetNames[0];
const sitesRaw = xlsx.utils.sheet_to_json(sitesWb.Sheets[sitesSheetName], { header: 1 });

const sites = [];
let currentCity = '';
let currentCluster = 1;

// Locate header row
let headerRowIdx = -1;
for (let i = 0; i < 10; i++) {
  if (sitesRaw[i] && sitesRaw[i].some(c => String(c).includes('Spot ID') || String(c).includes('Site Name'))) {
    headerRowIdx = i;
    break;
  }
}
console.log(`Found sites header at row ${headerRowIdx}`);

for (let r = headerRowIdx + 1; r < sitesRaw.length; r++) {
  const row = sitesRaw[r];
  if (!row || row.length === 0) continue;

  const srNo = row[0];
  const cluster = row[1] || currentCluster;
  const city = row[2] ? String(row[2]).trim() : currentCity;
  const spotId = row[3] ? String(row[3]).trim() : '';
  const siteName = row[5] ? String(row[5]).trim() : (row[4] ? String(row[4]).trim() : '');
  const lat = row[6] !== undefined ? parseFloat(row[6]) : null;
  const lng = row[7] !== undefined ? parseFloat(row[7]) : null;
  const siteType = row[8] ? String(row[8]).trim() : '';
  const poleHeight = row[9] || '';
  const poleType = row[10] || '';
  const poleArm = row[11] || '';
  const cabinet = row[12] || 1;
  const electricMeter = row[13] || 1;
  const fixCam = parseInt(row[14]) || 0;
  const ptzCam = parseInt(row[15]) || 0;
  const frCam = parseInt(row[16]) || 0;
  const boxCam = parseInt(row[17]) || 0;
  const anprCam = parseInt(row[18]) || 0;
  const strobeLight = parseInt(row[19]) || 0;

  if (city) currentCity = city;
  if (cluster) currentCluster = cluster;

  if (!spotId && !siteName) continue;

  sites.push({
    id: `site_${spotId || ('S_' + r)}`.toLowerCase().replace(/[^a-z0-9_]/g, '_'),
    srNo: srNo || sites.length + 1,
    cluster: currentCluster,
    city: currentCity,
    spotId: spotId,
    siteName: siteName || `Site ${spotId}`,
    lat: isNaN(lat) ? null : lat,
    lng: isNaN(lng) ? null : lng,
    siteType: siteType || (spotId.includes('-C-') || spotId.includes('-C') ? 'CEE' : (spotId.includes('-D-') || spotId.includes('-D') ? 'DEE' : 'IPNV')),
    poleHeight: poleHeight,
    poleType: poleType,
    poleArm: poleArm,
    cabinet: cabinet,
    electricMeter: electricMeter,
    fixCam: fixCam,
    ptzCam: ptzCam,
    frCam: frCam,
    boxCam: boxCam,
    anprCam: anprCam,
    strobeLight: strobeLight,
    totalCameras: fixCam + ptzCam + frCam + boxCam + anprCam,
    status: 'ONLINE'
  });
}

console.log(`Parsed ${sites.length} sites across cities.`);
fs.writeFileSync(path.join(dataDir, 'sites.json'), JSON.stringify(sites, null, 2));

// -------------------------------------------------------------
// 2. Parse Daily Reports (media_1790697626428.xlsx)
// -------------------------------------------------------------
console.log('\n--- 2. Parsing Real Daily Reports ---');
const reportsFile = path.join(uploadedDir, 'media_1790697626428.xlsx');
const repWb = xlsx.readFile(reportsFile);
const repSheet = repWb.Sheets['Form Responses 1'] || repWb.Sheets[repWb.SheetNames[0]];
const repRaw = xlsx.utils.sheet_to_json(repSheet, { header: 1 });

const reports = [];
const repHeader = repRaw[0] || [];
console.log('Report header cols:', repHeader.length);

for (let i = 1; i < repRaw.length; i++) {
  const row = repRaw[i];
  if (!row || row.length === 0 || !row[2] || !row[3]) continue;

  const timestamp = row[0];
  const email = String(row[1] || '').trim();
  const dateStr = formatExcelDate(row[2]);
  const city = String(row[3] || '').trim();

  const ipnvInst = parseInt(row[4]) || 0;
  const ipnvOnl = parseInt(row[5]) || 0;
  const ceeInst = parseInt(row[6]) || 0;
  const ceeOnl = parseInt(row[7]) || 0;
  const deeInst = parseInt(row[8]) || 0;
  const deeOnl = parseInt(row[9]) || 0;
  const psInst = parseInt(row[10]) || 0;
  const psOnl = parseInt(row[11]) || 0;
  const dcInst = parseInt(row[12]) || 0;
  const dcOnl = parseInt(row[13]) || 0;
  const frnvInst = parseInt(row[14]) || parseInt(row[16]) || 0;
  const frnvOnl = parseInt(row[15]) || parseInt(row[17]) || 0;
  const mcrInst = parseInt(row[18]) || 0;
  const mcrOnl = parseInt(row[19]) || 0;
  const wifiInst = parseInt(row[20]) || 0;
  const wifiOnl = parseInt(row[21]) || 0;
  const pbInst = parseInt(row[22]) || 0;
  const pbOnl = parseInt(row[23]) || 0;
  const esInst = parseInt(row[24]) || 0;
  const esOnl = parseInt(row[25]) || 0;
  const bioInst = parseInt(row[26]) || 0;
  const bioOnl = parseInt(row[27]) || 0;

  const ipnvReason = String(row[28] || '').trim();
  const deeReason = String(row[29] || '').trim();
  const rmaDetails = String(row[30] || '').trim();
  const ofcCut = String(row[31] || 'No').trim();
  const genRuntime = parseFloat(row[32]) || 0;
  const majorActivity = String(row[33] || '').trim();

  const reportId = `rep_${city.toLowerCase().replace(/[^a-z0-9]/g, '_')}_${dateStr}_${i}`;

  reports.push({
    id: reportId,
    timestamp: typeof timestamp === 'number' ? formatExcelDate(timestamp) : String(timestamp || dateStr),
    email: email,
    report_date: dateStr,
    district_id: city.toLowerCase().replace(/[^a-z0-9]/g, '_'),
    district_name: city,
    city: city,
    status: 'APPROVED',
    ipnv_installed: ipnvInst,
    ipnv_online: ipnvOnl,
    cee_installed: ceeInst,
    cee_online: ceeOnl,
    dee_installed: deeInst,
    dee_online: deeOnl,
    ps_installed: psInst,
    ps_online: psOnl,
    dc_installed: dcInst,
    dc_online: dcOnl,
    frnv_installed: frnvInst,
    frnv_online: frnvOnl,
    mcr_dr_installed: mcrInst,
    mcr_dr_online: mcrOnl,
    wifi_installed: wifiInst,
    wifi_online: wifiOnl,
    panic_installed: pbInst,
    panic_online: pbOnl,
    environmental_installed: esInst,
    environmental_online: esOnl,
    biometric_installed: bioInst,
    biometric_online: bioOnl,
    ipnv_offline_reason: ipnvReason,
    dee_offline_reason: deeReason,
    rma_details: rmaDetails,
    ofc_cut: ofcCut,
    generator_runtime: genRuntime,
    major_daily_activity: majorActivity,
    submitted_at: dateStr + ' 18:00:00'
  });
}

console.log(`Parsed ${reports.length} real reports.`);
fs.writeFileSync(path.join(dataDir, 'reports.json'), JSON.stringify(reports, null, 2));

// -------------------------------------------------------------
// 3. Parse Tickets (media_1790697626409.xlsx)
// -------------------------------------------------------------
console.log('\n--- 3. Parsing Helpdesk Tickets ---');
const ticketsFile = path.join(uploadedDir, 'media_1790697626409.xlsx');
const tickWb = xlsx.readFile(ticketsFile);
const tickSheet = tickWb.Sheets['Tickets'] || tickWb.Sheets[tickWb.SheetNames[0]];
const tickRaw = xlsx.utils.sheet_to_json(tickSheet, { header: 1 });

const tickets = [];
for (let i = 1; i < tickRaw.length; i++) {
  const row = tickRaw[i];
  if (!row || row.length === 0 || !row[0] || !row[1]) continue;

  const city = String(row[0] || '').trim();
  const ticketNumber = String(row[1] || '').trim();
  const dateCreated = formatExcelDate(row[2]);
  const subject = String(row[3] || '').trim();
  const fromName = String(row[4] || '').trim();
  const fromEmail = String(row[5] || '').trim();
  const priority = String(row[6] || 'Normal').trim();
  const department = String(row[7] || 'Support').trim();
  const helpTopic = String(row[8] || '').trim();
  const source = String(row[9] || 'Phone').trim();
  const currentStatus = String(row[10] || 'Open').trim();
  const lastUpdated = formatExcelDate(row[11]);
  const slaDueDate = formatExcelDate(row[12]);
  const slaPlan = String(row[13] || 'Major').trim();
  const dueDate = formatExcelDate(row[14]);
  const closedDate = formatExcelDate(row[15]);
  const agentAssigned = String(row[20] || '').trim();
  const unifiedStatus = String(row[28] || currentStatus).trim();
  const resolutionTime = parseFloat(row[29]) || null;
  const agingHrs = parseFloat(row[30]) || null;

  tickets.push({
    id: `tkt_${ticketNumber}`,
    ticketNumber: ticketNumber,
    city: city,
    district_id: city.toLowerCase().replace(/[^a-z0-9]/g, '_'),
    dateCreated: dateCreated,
    subject: subject,
    fromName: fromName,
    fromEmail: fromEmail,
    priority: priority,
    department: department,
    helpTopic: helpTopic,
    source: source,
    currentStatus: currentStatus,
    unifiedStatus: unifiedStatus,
    lastUpdated: lastUpdated,
    slaDueDate: slaDueDate,
    slaPlan: slaPlan,
    dueDate: dueDate,
    closedDate: closedDate,
    agentAssigned: agentAssigned,
    resolutionTimeHrs: resolutionTime ? Math.round(resolutionTime * 10) / 10 : null,
    agingHrs: agingHrs ? Math.round(agingHrs * 10) / 10 : null
  });
}

console.log(`Parsed ${tickets.length} tickets.`);
fs.writeFileSync(path.join(dataDir, 'tickets.json'), JSON.stringify(tickets, null, 2));

// -------------------------------------------------------------
// 4. Parse Employees (media_1790697626668.xlsx)
// -------------------------------------------------------------
console.log('\n--- 4. Parsing Employees and Photos ---');
const empFile = path.join(uploadedDir, 'media_1790697626668.xlsx');
const empWb = xlsx.readFile(empFile);

// Read Sheet1 for personal details (father name, cnic, dob, joining date)
const sheet1 = empWb.Sheets['Sheet1'];
const sheet1Raw = xlsx.utils.sheet_to_json(sheet1, { header: 1 });
const extraMap = {};
for (let i = 1; i < sheet1Raw.length; i++) {
  const row = sheet1Raw[i];
  if (!row || !row[1]) continue;
  const empId = String(row[1]).trim();
  extraMap[empId] = {
    fatherName: row[3] ? String(row[3]).trim() : '',
    joiningDate: formatExcelDate(row[4]),
    dob: formatExcelDate(row[6]),
    cnic: row[7] ? String(row[7]).trim() : ''
  };
}

// Read row_to_image_map
let rowToImg = {};
try {
  rowToImg = JSON.parse(fs.readFileSync(path.join(dataDir, 'row_to_image_map.json'), 'utf8'));
} catch (e) {}

// Read Personal details sheet
const pSheet = empWb.Sheets['Personal details'];
const pRaw = xlsx.utils.sheet_to_json(pSheet, { header: 1 });
const employees = [];

// Header is at row index 1 (0-indexed)
for (let r = 2; r < pRaw.length; r++) {
  const row = pRaw[r];
  if (!row || row.length === 0 || !row[1] || !row[2]) continue;

  const srNo = row[0];
  const empId = String(row[1]).trim();
  const name = String(row[2]).trim();
  if (empId === 'Emp ID' || name === 'Name') continue; // Skip header

  const designation = String(row[3] || '').trim();
  const location = String(row[4] || '').trim();
  const phone = String(row[5] || '').trim();
  const email = String(row[6] || '').trim();

  // Find image from rowToImg
  const imgName = rowToImg[r] || rowToImg[r + 1] || rowToImg[r - 1] || null;
  const photoUrl = imgName ? `assets/employees/${imgName}` : null;

  const extra = extraMap[empId] || extraMap[empId.replace(/^0+/, '')] || {};

  // Standardize district ID
  let districtId = 'lahore';
  const locLower = location.toLowerCase();
  if (locLower.includes('lahore') || locLower.includes('pmu') || locLower.includes('bo lahore') || locLower.includes('psca hq')) {
    districtId = 'lahore';
  } else if (locLower.includes('chakwal')) {
    districtId = 'chakwal';
  } else if (locLower.includes('attock')) {
    districtId = 'attock';
  } else if (locLower.includes('bahawalnagar') || locLower.includes('bwn')) {
    districtId = 'bahawalnagar';
  } else if (locLower.includes('bahawalpur') || locLower.includes('bwp')) {
    districtId = 'bahawalpur';
  } else if (locLower.includes('bhakkar')) {
    districtId = 'bhakkar';
  } else if (locLower.includes('chiniot')) {
    districtId = 'chiniot';
  } else if (locLower.includes('dg khan') || locLower.includes('d.g. khan')) {
    districtId = 'dg_khan';
  } else if (locLower.includes('gujrat')) {
    districtId = 'gujrat';
  } else if (locLower.includes('hafizabad') || locLower.includes('h.f.d') || locLower.includes('hfd')) {
    districtId = 'hafizabad';
  } else if (locLower.includes('hassan') || locLower.includes('hassanabdal')) {
    districtId = 'hassan_abdal';
  } else if (locLower.includes('jhang')) {
    districtId = 'jhang';
  } else if (locLower.includes('jhelum')) {
    districtId = 'jhelum';
  } else if (locLower.includes('khanewal') || locLower.includes('kahnewal')) {
    districtId = 'khanewal';
  } else if (locLower.includes('khushab')) {
    districtId = 'khushab';
  } else if (locLower.includes('kot addu')) {
    districtId = 'kot_addu';
  } else if (locLower.includes('layyah')) {
    districtId = 'layyah';
  } else if (locLower.includes('lodhran')) {
    districtId = 'lodhran';
  } else if (locLower.includes('mandi') || locLower.includes('m.b.d') || locLower.includes('mbd')) {
    districtId = 'mandi_bahauddin';
  } else if (locLower.includes('mianwali')) {
    districtId = 'mianwali';
  } else if (locLower.includes('multan')) {
    districtId = 'multan';
  } else if (locLower.includes('murree')) {
    districtId = 'murree';
  } else if (locLower.includes('muzaffargarh') || locLower.includes('mzg')) {
    districtId = 'muzaffargarh';
  } else if (locLower.includes('narowal')) {
    districtId = 'narowal';
  } else if (locLower.includes('okara')) {
    districtId = 'okara';
  } else if (locLower.includes('pakpattan')) {
    districtId = 'pakpattan';
  } else if (locLower.includes('rahim') || locLower.includes('r.y. khan') || locLower.includes('ry khan')) {
    districtId = 'rahim_yar_khan';
  } else if (locLower.includes('rajanpur')) {
    districtId = 'rajanpur';
  } else if (locLower.includes('rawalpindi') || locLower.includes('rwp')) {
    districtId = 'rawalpindi';
  } else if (locLower.includes('sahiwal')) {
    districtId = 'sahiwal';
  } else if (locLower.includes('sargodha')) {
    districtId = 'sargodha';
  } else if (locLower.includes('sheikhupura') || locLower.includes('sheikupura')) {
    districtId = 'sheikhupura';
  } else if (locLower.includes('sialkot')) {
    districtId = 'sialkot';
  } else if (locLower.includes('talagang')) {
    districtId = 'talagang';
  } else if (locLower.includes('taunsa')) {
    districtId = 'taunsa';
  } else if (locLower.includes('taxila')) {
    districtId = 'taxila';
  } else if (locLower.includes('toba') || locLower.includes('t.t.s') || locLower.includes('tts')) {
    districtId = 'toba_tek_singh';
  } else if (locLower.includes('vehari')) {
    districtId = 'vehari';
  } else if (locLower.includes('wazirabad') || locLower.includes('warizabad')) {
    districtId = 'wazirabad';
  }

  employees.push({
    id: `emp_${empId.replace(/[^a-zA-Z0-9]/g, '_')}`,
    srNo: srNo,
    empId: empId,
    name: name,
    fatherName: extra.fatherName || '',
    designation: designation || 'Site Engineer',
    location: location,
    district_id: districtId,
    districtName: districtId === 'lahore' ? 'Headquarters (Lahore)' : location,
    phone: phone,
    email: email,
    joiningDate: extra.joiningDate || '2025-01-01',
    dob: extra.dob || '',
    cnic: extra.cnic || '',
    photo: photoUrl,
    status: 'ACTIVE'
  });
}

// Additional Phase 1 Field Personnel & Splicers
const ph1Personnel = [
  { name: 'Kaleem Ajmal', designation: 'AXEN', location: 'Attock', district_id: 'attock', phone: '0342-9537233', email: 'kaleem.ajmal1@gmail.com' },
  { name: 'Muhammad Tasadduq', designation: 'Site Supervisor', location: 'Attock', district_id: 'attock', phone: '0302-8757734', email: 'awantasaduq2@gmail.com' },
  { name: 'Farhan Khan', designation: 'Fiber Splicer', location: 'Attock', district_id: 'attock', phone: '0317-5144036', email: 'fk3096448@gmail.com' },
  { name: 'M Ahmed', designation: 'Fiber Splicer', location: 'Attock', district_id: 'attock', phone: '0328-3277647', email: 'malikghi89@gmail.com' },
  { name: 'Zohaib Akhtar', designation: 'Site Supervisor', location: 'Murree', district_id: 'murree', phone: '0340-9185634', email: 'rzohaib234z@gmail.com' },
  { name: 'Abdullah Masood', designation: 'Fiber Splicer', location: 'Murree', district_id: 'murree', phone: '0312-5385294', email: 'infoabdullah066@gmail.com' },
  { name: 'M Huzaifa', designation: 'Site Supervisor', location: 'Taxila', district_id: 'taxila', phone: '0321-1465103', email: 'huzaifamalik786.hm@gmail.com' },
  { name: 'Muzammil Nasir', designation: 'Fiber Splicer', location: 'Hassan Abdal', district_id: 'hassan_abdal', phone: '0344-8919513', email: 'muzamilnaseer560@gmail.com' },
  { name: 'Capt (R) Ashraf Hussain', designation: 'Site Supervisor', location: 'Hassan Abdal', district_id: 'hassan_abdal', phone: '0346-5419185', email: 'ashrafdanish515@gmail.com' },
  { name: 'Ghulam Abbas', designation: 'Site Supervisor', location: 'Jhelum', district_id: 'jhelum', phone: '0321-5820741', email: 'ghulamabbas63867@gmail.com' },
  { name: 'Akhlaq Ahmed', designation: 'Fiber Splicer', location: 'Jhelum', district_id: 'jhelum', phone: '0334-5289771', email: 'ikhlaque771@gmail.com' },
  { name: 'Usman Safdar', designation: 'Fiber Splicer', location: 'Gujrat', district_id: 'gujrat', phone: '0320-0562851', email: 'usmansafdar@nrtc.com.pk' },
  { name: 'Ali Haider', designation: 'Site Supervisor', location: 'Okara', district_id: 'okara', phone: '0334-8721379', email: 'alichaudhary47700@gmail.com' },
  { name: 'Muhammad Ali', designation: 'Fiber Splicer', location: 'Okara', district_id: 'okara', phone: '0318-5878862', email: 'muhammadali05434@gmail.com' },
  { name: 'Salman Asgher', designation: 'AXEN', location: 'Okara', district_id: 'okara', phone: '0316-6169887', email: 'engrsalman726@gmail.com' },
  { name: 'Daniyal Muneer', designation: 'Fiber Splicer', location: 'Sialkot', district_id: 'sialkot', phone: '0326-9051100', email: 'daniyal.layyah100@gmail.com' },
  { name: 'Abdul Mohiz', designation: 'Fiber Splicer', location: 'Mianwali', district_id: 'mianwali', phone: '0335-5251302', email: 'mohizt25@gmail.com' },
  { name: 'Atta Ullah', designation: 'Site Supervisor', location: 'Mianwali', district_id: 'mianwali', phone: '0301-2454276', email: 'attaullahh276@gmail.com' },
  { name: 'Bilal Ahmed', designation: 'Fiber Splicer', location: 'Sargodha', district_id: 'sargodha', phone: '0319-1058585', email: 'malikbillu647@gmail.com' },
  { name: 'AWO Zafar Iqbal', designation: 'Site Supervisor', location: 'Sargodha', district_id: 'sargodha', phone: '0321-5115527', email: 'mrraozafar@gmail.com' },
  { name: 'Touseef Hussain', designation: 'Fiber Splicer', location: 'Jhang', district_id: 'jhang', phone: '0341-5245459', email: 'Touseefhussain5786@gmail.com' },
  { name: 'Sajid Abbas', designation: 'Field Technician', location: 'Jhang', district_id: 'jhang', phone: '0332-3165714', email: 'sajidabbas170124@gmail.com' },
  { name: 'Waqas Riaz', designation: 'Fiber Splicer', location: 'Sahiwal', district_id: 'sahiwal', phone: '0301-2499588', email: 'waqasriaz0301@gmail.com' },
  { name: 'Amir Shahzad', designation: 'Site Supervisor', location: 'Sahiwal', district_id: 'sahiwal', phone: '0304-4496145', email: 'raiaamarshahzad19935@gmail.com' },
  { name: 'Rizwan Sharif', designation: 'Site Engineer', location: 'Sahiwal', district_id: 'sahiwal', phone: '0304-4496146', email: 'rizwansharif941@gmail.com' },
  { name: 'Ashfaq Ahmed', designation: 'AXEN', location: 'Muzaffargarh', district_id: 'muzaffargarh', phone: '0333-2668282', email: 'ishfaque.ahmed@nrtc.com.pk' },
  { name: 'Muhammad Adnan', designation: 'Site Supervisor', location: 'Muzaffargarh', district_id: 'muzaffargarh', phone: '0343-8982605', email: 'adnanzaibi7@gmail.com' },
  { name: 'Muhammad Ayoub', designation: 'Fiber Splicer', location: 'Muzaffargarh', district_id: 'muzaffargarh', phone: '0320-7766255', email: 'muhammadayoubyarani@gmail.com' },
  { name: 'Fida Hussain', designation: 'Site Supervisor', location: 'DG Khan', district_id: 'dg_khan', phone: '0305-7426499', email: 'fidahussainkhokhar56@gmail.com' },
  { name: 'Waqas Khan', designation: 'Site Supervisor', location: 'Bahawalpur', district_id: 'bahawalpur', phone: '0345-5634980', email: 'uk16310@gmail.com' },
  { name: 'Sananullah', designation: 'Fiber Splicer', location: 'Bahawalpur', district_id: 'bahawalpur', phone: '0349-7916259', email: 'su1246482@gmail.com' },
  { name: 'Muhammad Zeshan', designation: 'Site Supervisor', location: 'Rahim Yar Khan', district_id: 'rahim_yar_khan', phone: '0302-3363561', email: 'shanizishan305@gmail.com' },
  { name: 'M. Naeem', designation: 'Fiber Splicer', location: 'Rahim Yar Khan', district_id: 'rahim_yar_khan', phone: '0329-2125196', email: 'maliknaeem7382@gmail.com' },
  { name: 'Nouman Ali', designation: 'Fiber Splicer', location: 'Multan', district_id: 'multan', phone: '0304-9323462', email: 'nnoanansikandar@gmail.com' }
];

ph1Personnel.forEach((p, idx) => {
  const exists = employees.some(e => (e.email && p.email && e.email.toLowerCase() === p.email.toLowerCase()) || e.name.toLowerCase() === p.name.toLowerCase());
  if (!exists) {
    employees.push({
      id: `emp_ph1_${idx + 1}`,
      srNo: employees.length + 1,
      empId: `PH1-${(idx + 1).toString().padStart(3, '0')}`,
      name: p.name,
      fatherName: '',
      designation: p.designation,
      location: p.location,
      district_id: p.district_id,
      districtName: p.location,
      phone: p.phone,
      email: p.email,
      joiningDate: '2024-06-01',
      dob: '1995-01-01',
      cnic: `3${Math.floor(1000 + Math.random() * 9000)}-${Math.floor(1000000 + Math.random() * 9000000)}-1`,
      photo: null,
      status: 'ACTIVE'
    });
  }
});

console.log(`Parsed ${employees.length} employees with personal records and photos.`);
fs.writeFileSync(path.join(dataDir, 'employees.json'), JSON.stringify(employees, null, 2));

// -------------------------------------------------------------
// 5. Build Users List (Admin + 1 Login per District)
// -------------------------------------------------------------
console.log('\n--- 5. Generating Strict District & Admin Logins ---');

// List of all Punjab districts
const districtsList = [
  { id: 'attock', name: 'Attock', division: 'Rawalpindi' },
  { id: 'bahawalnagar', name: 'Bahawalnagar', division: 'Bahawalpur' },
  { id: 'bahawalpur', name: 'Bahawalpur', division: 'Bahawalpur' },
  { id: 'bhakkar', name: 'Bhakkar', division: 'Sargodha' },
  { id: 'chakwal', name: 'Chakwal', division: 'Rawalpindi' },
  { id: 'chiniot', name: 'Chiniot', division: 'Faisalabad' },
  { id: 'dg_khan', name: 'DG Khan', division: 'D.G. Khan' },
  { id: 'faisalabad', name: 'Faisalabad', division: 'Faisalabad' },
  { id: 'gujranwala', name: 'Gujranwala', division: 'Gujranwala' },
  { id: 'gujrat', name: 'Gujrat', division: 'Gujranwala' },
  { id: 'hafizabad', name: 'Hafizabad', division: 'Gujranwala' },
  { id: 'hassan_abdal', name: 'Hassan Abdal', division: 'Rawalpindi' },
  { id: 'jhang', name: 'Jhang', division: 'Faisalabad' },
  { id: 'jhelum', name: 'Jhelum', division: 'Rawalpindi' },
  { id: 'kasur', name: 'Kasur', division: 'Lahore' },
  { id: 'khanewal', name: 'Khanewal', division: 'Multan' },
  { id: 'khushab', name: 'Khushab', division: 'Sargodha' },
  { id: 'kot_addu', name: 'Kot Addu', division: 'D.G. Khan' },
  { id: 'layyah', name: 'Layyah', division: 'D.G. Khan' },
  { id: 'lodhran', name: 'Lodhran', division: 'Multan' },
  { id: 'mandi_bahauddin', name: 'Mandi Bahauddin', division: 'Gujranwala' },
  { id: 'mianwali', name: 'Mianwali', division: 'Sargodha' },
  { id: 'multan', name: 'Multan', division: 'Multan' },
  { id: 'murree', name: 'Murree', division: 'Rawalpindi' },
  { id: 'muzaffargarh', name: 'Muzaffargarh', division: 'D.G. Khan' },
  { id: 'nankana_sahib', name: 'Nankana Sahib', division: 'Lahore' },
  { id: 'narowal', name: 'Narowal', division: 'Gujranwala' },
  { id: 'okara', name: 'Okara', division: 'Sahiwal' },
  { id: 'pakpattan', name: 'Pakpattan', division: 'Sahiwal' },
  { id: 'rahim_yar_khan', name: 'Rahim Yar Khan', division: 'Bahawalpur' },
  { id: 'rajanpur', name: 'Rajanpur', division: 'D.G. Khan' },
  { id: 'rawalpindi', name: 'Rawalpindi', division: 'Rawalpindi' },
  { id: 'sahiwal', name: 'Sahiwal', division: 'Sahiwal' },
  { id: 'sargodha', name: 'Sargodha', division: 'Sargodha' },
  { id: 'sheikhupura', name: 'Sheikhupura', division: 'Lahore' },
  { id: 'sialkot', name: 'Sialkot', division: 'Gujranwala' },
  { id: 'talagang', name: 'Talagang', division: 'Rawalpindi' },
  { id: 'taunsa', name: 'Taunsa', division: 'D.G. Khan' },
  { id: 'taxila', name: 'Taxila', division: 'Rawalpindi' },
  { id: 'toba_tek_singh', name: 'Toba Tek Singh', division: 'Faisalabad' },
  { id: 'vehari', name: 'Vehari', division: 'Multan' },
  { id: 'wazirabad', name: 'Wazirabad', division: 'Gujranwala' }
];

const users = [
  // Master Admin
  {
    id: 'usr_admin',
    username: 'admin',
    password: 'password123',
    name: 'NRTC PMU Admin',
    role: 'ADMIN',
    districtId: 'all',
    districtName: 'Punjab PMU Command (Lahore)',
    designation: 'Project Director / Command Lead',
    email: 'pmu.admin@nrtc.com.pk'
  },
  {
    id: 'usr_lahore_pmu',
    username: 'lahore',
    password: 'password123',
    name: 'NRTC PMU Admin (Lahore)',
    role: 'ADMIN',
    districtId: 'all',
    districtName: 'Punjab PMU Command (Lahore)',
    designation: 'Project Management Unit',
    email: 'lahore.admin@nrtc.com.pk'
  }
];

// Add 1 user login per district
districtsList.forEach(d => {
  users.push({
    id: `usr_${d.id}`,
    username: d.id, // e.g. 'chakwal', 'attock', etc.
    password: 'password123',
    name: `${d.name} District Operations`, // strictly District name, not single engineer
    role: 'DISTRICT_USER',
    districtId: d.id,
    districtName: d.name,
    division: d.division,
    designation: `${d.name} Operations Hub`,
    email: `${d.id}.ops@safecity.punjab.gov.pk`
  });
});

console.log(`Generated ${users.length} users (Admin + ${districtsList.length} district logins).`);
fs.writeFileSync(path.join(dataDir, 'users.json'), JSON.stringify(users, null, 2));

console.log('\n>>> All Datasets Parsed and Generated Successfully! <<<');
