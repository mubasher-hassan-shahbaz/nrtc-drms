const fs = require('fs');
const path = require('path');
const xlsx = require('xlsx');

const uploadedDir = 'C:/Users/mubas/.gemini/antigravity/brain/786d803e-4a56-4256-8e0f-49f9457a89ad/.user_uploaded';
const empFile = path.join(uploadedDir, 'media_1790697626668.xlsx');
const wb = xlsx.readFile(empFile);

const rowToImg = require('./effective_row_to_image.json');

// Ensure all media files are copied to assets/employees
const targetDir = path.join(__dirname, '../assets/employees');
if (!fs.existsSync(targetDir)) fs.mkdirSync(targetDir, { recursive: true });
const mediaDir = 'temp_emp_unzip/xl/media';
if (fs.existsSync(mediaDir)) {
  fs.readdirSync(mediaDir).forEach(f => {
    fs.copyFileSync(path.join(mediaDir, f), path.join(targetDir, f));
  });
}

// 1. Build Sheet1 lookup map
const sheet1 = xlsx.utils.sheet_to_json(wb.Sheets['Sheet1'], { header: 1 });
const s1Map = {};

function normalizeKey(str) {
  return String(str || '').toLowerCase().replace(/[^a-z0-9]/g, '');
}

function normalizeId(str) {
  if (!str) return '';
  return String(str).trim()
    .replace(/^0+/, '')
    .replace(/-0+/, '-')
    .toLowerCase()
    .replace(/[^a-z0-9]/g, '');
}

function normalizeName(str) {
  if (!str) return '';
  return String(str).toLowerCase()
    .replace(/\b(si|ti|m|retd|rted|ph-1|ph-2|ph1|ph2|maj|brig|engr|hafiz|sub|awo)\b/gi, '')
    .replace(/[^a-z0-9]/g, '');
}

function formatExcelDate(val) {
  if (!val) return '';
  if (typeof val === 'number') {
    const d = new Date((val - 25569) * 86400 * 1000);
    return isNaN(d.getTime()) ? '' : d.toISOString().split('T')[0];
  }
  return String(val).trim();
}

for (let i = 2; i < sheet1.length; i++) {
  const r = sheet1[i];
  if (!r || !r[2]) continue;
  const nameKey = normalizeKey(r[2]);
  const normNKey = normalizeName(r[2]);
  const empIdKey = r[1] ? normalizeKey(r[1]) : '';
  const normIKey = r[1] ? normalizeId(r[1]) : '';
  const obj = {
    empId: r[1] ? String(r[1]).trim() : '',
    name: String(r[2]).trim(),
    fatherName: r[3] ? String(r[3]).trim() : '',
    joiningDate: formatExcelDate(r[4]),
    designation: r[5] ? String(r[5]).trim() : '',
    dob: formatExcelDate(r[6]),
    cnic: r[7] ? String(r[7]).trim() : ''
  };
  if (nameKey) s1Map['name_' + nameKey] = obj;
  if (normNKey) s1Map['norm_name_' + normNKey] = obj;
  if (empIdKey) s1Map['id_' + empIdKey] = obj;
  if (normIKey) s1Map['norm_id_' + normIKey] = obj;
}

// 2. Build Ph2 New Haring lookup map
const ph2New = xlsx.utils.sheet_to_json(wb.Sheets['Ph2  New Haring'], { header: 1 });
const ph2Map = {};
for (let i = 1; i < ph2New.length; i++) {
  const r = ph2New[i];
  if (!r || !r[1]) continue;
  const k = normalizeKey(r[1]);
  const nk = normalizeName(r[1]);
  const pObj = {
    fatherName: r[2] ? String(r[2]).trim() : '',
    cnic: r[3] ? String(r[3]).trim() : '',
    qualification: r[4] ? String(r[4]).trim() : '',
    designation: r[5] ? String(r[5]).trim() : '',
    contact: r[6] ? String(r[6]).trim() : '',
    recommended: r[7] ? String(r[7]).trim() : '',
    reference: r[9] ? String(r[9]).trim() : ''
  };
  ph2Map[k] = pObj;
  if (nk) ph2Map[nk] = pObj;
}

// 3. District ID mapper
function mapDistrictId(location) {
  if (!location) return 'lahore';
  const loc = location.toLowerCase().trim();
  if (loc.includes('lahore') || loc.includes('pmu') || loc.includes('bo lahore') || loc.includes('psca hq') || loc.includes('pd house')) return 'lahore';
  if (loc.includes('attock')) return 'attock';
  if (loc.includes('bahawalnagar') || loc.includes('bwn')) return 'bahawalnagar';
  if (loc.includes('bahawalpur') || loc.includes('bwp')) return 'bahawalpur';
  if (loc.includes('bhakkar')) return 'bhakkar';
  if (loc.includes('chakwal')) return 'chakwal';
  if (loc.includes('chiniot')) return 'chiniot';
  if (loc.includes('dg khan') || loc.includes('d.g. khan')) return 'dg_khan';
  if (loc.includes('faisalabad') || loc.includes('fsd')) return 'faisalabad';
  if (loc.includes('gujranwala') || loc.includes('grw')) return 'gujranwala';
  if (loc.includes('gujrat')) return 'gujrat';
  if (loc.includes('hafizabad') || loc.includes('hfd') || loc.includes('h.f.d')) return 'hafizabad';
  if (loc.includes('hassan') || loc.includes('hassanabdal')) return 'hassan_abdal';
  if (loc.includes('jhang')) return 'jhang';
  if (loc.includes('jhelum')) return 'jhelum';
  if (loc.includes('kasur')) return 'kasur';
  if (loc.includes('khanewal') || loc.includes('kahnewal')) return 'khanewal';
  if (loc.includes('khushab')) return 'khushab';
  if (loc.includes('kot addu')) return 'kot_addu';
  if (loc.includes('layyah')) return 'layyah';
  if (loc.includes('lodhran')) return 'lodhran';
  if (loc.includes('mandi') || loc.includes('mbd') || loc.includes('m.b.d')) return 'mandi_bahauddin';
  if (loc.includes('mianwali')) return 'mianwali';
  if (loc.includes('multan')) return 'multan';
  if (loc.includes('murree')) return 'murree';
  if (loc.includes('muzaffargarh') || loc.includes('mzg')) return 'muzaffargarh';
  if (loc.includes('nankana')) return 'nankana_sahib';
  if (loc.includes('narowal')) return 'narowal';
  if (loc.includes('okara')) return 'okara';
  if (loc.includes('pakpattan')) return 'pakpattan';
  if (loc.includes('rahim') || loc.includes('ry khan') || loc.includes('r.y. khan')) return 'rahim_yar_khan';
  if (loc.includes('rajanpur')) return 'rajanpur';
  if (loc.includes('rawalpindi') || loc.includes('rwp')) return 'rawalpindi';
  if (loc.includes('sahiwal')) return 'sahiwal';
  if (loc.includes('sargodha')) return 'sargodha';
  if (loc.includes('sheikhupura') || loc.includes('sheikupura')) return 'sheikhupura';
  if (loc.includes('sialkot')) return 'sialkot';
  if (loc.includes('talagang')) return 'talagang';
  if (loc.includes('taunsa')) return 'taunsa';
  if (loc.includes('taxila')) return 'taxila';
  if (loc.includes('toba') || loc.includes('tts') || loc.includes('t.t.s')) return 'toba_tek_singh';
  if (loc.includes('vehari')) return 'vehari';
  if (loc.includes('wazirabad')) return 'wazirabad';
  return 'lahore';
}

// 4. Parse 'Personal details' sheet
const pRaw = xlsx.utils.sheet_to_json(wb.Sheets['Personal details'], { header: 1 });
const employees = [];
let phase = 'Phase 2';

for (let r = 0; r < pRaw.length; r++) {
  const row = pRaw[r];
  if (!row || row.length === 0) continue;
  
  const col0 = String(row[0] || '').trim();
  if (col0.includes('PH1 EMPLOYEES')) {
    phase = 'Phase 1';
    continue;
  }
  if (col0.includes('PERSONAL DETAILS') || col0.includes('Sr. No')) continue;
  
  // Must have name (col 2)
  const rawName = row[2] ? String(row[2]).trim() : '';
  if (!rawName || rawName === 'Name') continue;

  const srNo = typeof row[0] === 'number' ? row[0] : parseInt(row[0], 10) || (employees.length + 1);
  const rawEmpId = row[1] ? String(row[1]).trim() : '';
  const designation = row[3] ? String(row[3]).trim() : 'Site Staff';
  const location = row[4] ? String(row[4]).trim() : 'Punjab';
  const phone = row[5] ? String(row[5]).trim() : '';
  const email = (row[6] && String(row[6]).toLowerCase() !== 'undefined' && String(row[6]).toLowerCase() !== 'no email') ? String(row[6]).trim() : '';

  // Get photo for this row from effective_row_to_image.json
  const imgFile = rowToImg[r] || null;
  const photoUrl = imgFile ? `assets/employees/${imgFile}` : null;

  // Lookup in Sheet1 or Ph2 New Haring
  const nameKey = normalizeKey(rawName);
  const normNKey = normalizeName(rawName);
  const idKey = rawEmpId ? normalizeKey(rawEmpId) : '';
  const normIKey = rawEmpId ? normalizeId(rawEmpId) : '';
  const s1Data = (normIKey ? s1Map['norm_id_' + normIKey] : null) || 
                 (idKey ? s1Map['id_' + idKey] : null) || 
                 (normNKey ? s1Map['norm_name_' + normNKey] : null) || 
                 s1Map['name_' + nameKey] || {};
  const ph2Data = (normNKey ? ph2Map[normNKey] : null) || ph2Map[nameKey] || {};

  const fatherName = s1Data.fatherName || ph2Data.fatherName || '';
  const cnic = s1Data.cnic || ph2Data.cnic || '';
  const dob = s1Data.dob || '';
  const joiningDate = s1Data.joiningDate || (phase === 'Phase 1' ? '2024-06-01' : '2025-01-15');
  const qualification = ph2Data.qualification || '';
  const districtId = mapDistrictId(location);

  const empId = rawEmpId || (s1Data.empId) || `NRTC-${phase === 'Phase 1' ? 'PH1' : 'PH2'}-${String(srNo).padStart(3, '0')}`;

  employees.push({
    id: `emp_${empId.replace(/[^a-zA-Z0-9]/g, '_')}_${r}`,
    srNo: srNo,
    empId: empId,
    name: rawName,
    fatherName: fatherName,
    designation: designation,
    qualification: qualification,
    location: location,
    district_id: districtId,
    districtName: districtId === 'lahore' ? 'Headquarters (Lahore)' : location,
    phase: phase,
    phone: phone,
    email: email,
    joiningDate: joiningDate,
    dob: dob,
    cnic: cnic,
    photo: photoUrl,
    status: 'ACTIVE'
  });
}

console.log(`\nSuccessfully parsed ${employees.length} EXACT employees directly from Excel!`);
const withPhotos = employees.filter(e => e.photo).length;
console.log(`Employees with verified photos: ${withPhotos} / ${employees.length}`);

// Save to data/employees.json
const outPath = path.join(__dirname, '../data/employees.json');
fs.writeFileSync(outPath, JSON.stringify(employees, null, 2), 'utf8');
console.log(`Written verified employees to ${outPath}`);
