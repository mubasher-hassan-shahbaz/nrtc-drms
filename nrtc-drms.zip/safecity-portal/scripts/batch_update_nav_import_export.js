const fs = require('fs');

fs.readdirSync('.').forEach(file => {
  if (!file.endsWith('.html')) return;
  let content = fs.readFileSync(file, 'utf8');
  let changed = false;

  // Pattern 1: Both import link and export-excel link
  const pattern1 = /<a\s+href="import\.html"\s+id="nav-import"[^>]*>[\s\S]*?<\/a>\s*<a\s+href="javascript:void\(0\)"\s+onclick="exportCurrentReports\(\)"\s+id="nav-export-excel"[^>]*>[\s\S]*?<\/a>/;
  if (pattern1.test(content)) {
    const isActive = file === 'import.html' ? ' class="active"' : '';
    const replacement = `<a href="import.html" id="nav-import-export"${isActive}>
        <span class="nav-icon">⇄</span>Import / Export Data
      </a>`;
    content = content.replace(pattern1, replacement);
    changed = true;
  }

  // Pattern 2: Any remaining nav-export-excel
  if (content.includes('id="nav-export-excel"')) {
    content = content.replace(/<a\s+href="javascript:void\(0\)"\s+onclick="exportCurrentReports\(\)"\s+id="nav-export-excel"[^>]*>[\s\S]*?<\/a>/g, '');
    changed = true;
  }

  // Pattern 3: Any remaining nav-import (except on import.html where it is already nav-import-export)
  if (content.includes('id="nav-import"') && !content.includes('id="nav-import-export"')) {
    const isActive = file === 'import.html' ? ' class="active"' : '';
    content = content.replace(/<a\s+href="import\.html"\s+id="nav-import"[^>]*>[\s\S]*?<\/a>/g, `<a href="import.html" id="nav-import-export"${isActive}>
        <span class="nav-icon">⇄</span>Import / Export Data
      </a>`);
    changed = true;
  }

  if (changed) {
    fs.writeFileSync(file, content, 'utf8');
    console.log(`Updated navigation in ${file}`);
  }
});
console.log('Batch navigation update complete.');
