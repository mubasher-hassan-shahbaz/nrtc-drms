const fs = require('fs');
const XLSX = require('xlsx');

const users = require('../data/users.json');

const csvRows = ['#,Username (Login ID),Display Name,Role,District,Password,Email,Designation'];
const xlsxRows = [
  ['#', 'Username (Login ID)', 'Display Name', 'Role', 'District', 'Password', 'Email', 'Designation']
];

let idx = 1;
users.forEach(u => {
  csvRows.push([
    idx,
    u.username,
    `"${u.name}"`,
    u.role,
    `"${u.districtName || u.districtId}"`,
    u.password,
    `"${u.email || ''}"`,
    `"${u.designation || ''}"`
  ].join(','));

  xlsxRows.push([
    idx,
    u.username,
    u.name,
    u.role,
    u.districtName || u.districtId,
    u.password,
    u.email || '',
    u.designation || ''
  ]);
  idx++;
});

fs.writeFileSync('./data/portal-credentials.csv', csvRows.join('\n'), 'utf8');

const ws = XLSX.utils.aoa_to_sheet(xlsxRows);
const wb = XLSX.utils.book_new();
XLSX.utils.book_append_sheet(wb, ws, 'Portal Credentials');
XLSX.writeFile(wb, './data/portal-credentials.xlsx');

console.log('Successfully regenerated clean portal-credentials.csv and portal-credentials.xlsx with zero fake emails!');
