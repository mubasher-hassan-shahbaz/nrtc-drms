const xlsx = require('xlsx');
const wb = xlsx.readFile('C:/Users/mubas/.gemini/antigravity/brain/786d803e-4a56-4256-8e0f-49f9457a89ad/.user_uploaded/media_1790697626387.xlsx');
const ws = wb.Sheets['MASTER SHEET 19 Cities'];
const json = xlsx.utils.sheet_to_json(ws, { header: 1 });
console.log('Row 2 headers:');
json[2].forEach((h, idx) => console.log('  Col ' + idx + ': ' + h));
console.log('\nRow 3 sample values:');
json[3].forEach((v, idx) => console.log('  Col ' + idx + ': ' + v));
