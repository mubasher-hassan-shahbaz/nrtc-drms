/**
 * Batch update HTML files:
 * 1. Favicon -> favicon.png
 * 2. Brand icon -> assets/images/nrtc-logo.png
 * 3. Remove "Reset Demo Data" sidebar links
 * 4. Replace "Punjab Command & Control Operations" -> "NRTC Lahore Daily Report Management System (DRMS)"
 */
const fs = require('fs');
const path = require('path');

const rootDir = path.join(__dirname, '..');
const htmlFiles = fs.readdirSync(rootDir).filter(f => f.endsWith('.html'));

htmlFiles.forEach(file => {
  const filePath = path.join(rootDir, file);
  let content = fs.readFileSync(filePath, 'utf8');
  let changed = false;

  // 1. Favicon
  if (content.includes('href="favicon.svg"')) {
    content = content.replace(/href="favicon\.svg"/g, 'href="favicon.png"');
    changed = true;
  }
  if (!content.includes('favicon.png') && content.includes('</head>')) {
    content = content.replace('</head>', '  <link rel="icon" type="image/png" href="favicon.png">\n</head>');
    changed = true;
  }

  // 2. Brand Icon in Sidebar
  const oldBrandRegex = /<div class="brand-icon"[^>]*?>NRTC<\/div>/g;
  if (oldBrandRegex.test(content)) {
    content = content.replace(oldBrandRegex, '<img src="assets/images/nrtc-logo.png" alt="NRTC Logo" style="height:40px; width:auto; object-fit:contain;">');
    changed = true;
  }

  // Brand Icon in login.html
  const oldLoginLogoRegex = /<div class="login-logo-icon"[^>]*?>NRTC<\/div>/g;
  if (oldLoginLogoRegex.test(content)) {
    content = content.replace(oldLoginLogoRegex, '<img src="assets/images/nrtc-logo.png" alt="NRTC Logo" style="width:52px; height:auto; object-fit:contain;">');
    changed = true;
  }

  // 3. Remove Reset Demo Data from sidebar
  const resetRegex = /\s*<a href="javascript:void\(0\)" onclick="resetDemoData\(\)">[\s\S]*?Reset Demo Data\s*<\/a>/g;
  if (resetRegex.test(content)) {
    content = content.replace(resetRegex, '');
    changed = true;
  }

  // 4. Front Page Title replacement
  if (content.includes('Punjab Command & Control Operations')) {
    content = content.replace(/Punjab Command & Control Operations\s*[^\s<]*\s*/g, 'NRTC Lahore Daily Report Management System (DRMS)');
    changed = true;
  }

  if (changed) {
    fs.writeFileSync(filePath, content, 'utf8');
    console.log(`Updated ${file}`);
  }
});
