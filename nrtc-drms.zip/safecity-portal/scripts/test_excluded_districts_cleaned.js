const fs = require('fs');
const path = require('path');

const storeJs = fs.readFileSync(path.join(__dirname, '../js/data/store.js'), 'utf8');
const serverJs = fs.readFileSync(path.join(__dirname, '../server.js'), 'utf8');
const appJs = fs.readFileSync(path.join(__dirname, '../js/app.js'), 'utf8');

const excluded = ['lahore', 'rawalpindi', 'faisalabad'];

console.log('--- Verifying Removal of Excluded Districts ---');

// Check seed reports
let hasSeedReportsExcluded = false;
const seedReportsMatch = storeJs.match(/function generateSeedReports\(\)\s*\{([\s\S]*?)\n\}/);
if (seedReportsMatch) {
  const body = seedReportsMatch[1].toLowerCase();
  excluded.forEach(d => {
    if (body.includes(`district_id: '${d}'`) || body.includes(`district_name: '${d}'`)) {
      console.error(`❌ FAIL: generateSeedReports contains ${d}`);
      hasSeedReportsExcluded = true;
    }
  });
}
if (!hasSeedReportsExcluded) {
  console.log('✅ PASS: generateSeedReports contains NO excluded districts');
}

// Check seed finances
let hasSeedFinancesExcluded = false;
const seedFinancesMatch = storeJs.match(/function generateSeedFinances\(\)\s*\{([\s\S]*?)\n\}/);
if (seedFinancesMatch) {
  const body = seedFinancesMatch[1].toLowerCase();
  excluded.forEach(d => {
    if (body.includes(`districtid: '${d}'`)) {
      console.error(`❌ FAIL: generateSeedFinances contains ${d}`);
      hasSeedFinancesExcluded = true;
    }
  });
}
if (!hasSeedFinancesExcluded) {
  console.log('✅ PASS: generateSeedFinances contains NO excluded districts');
}

// Check server /api/reports filter
if (serverJs.includes("const excluded = ['lahore', 'rawalpindi', 'faisalabad'")) {
  console.log('✅ PASS: server.js strictly filters out excluded districts from /api/reports');
} else {
  console.error('❌ FAIL: server.js missing excluded districts filter');
}

// Check store.js init sanitization
if (storeJs.includes("const excludedDistricts = ['lahore', 'rawalpindi', 'faisalabad'")) {
  console.log('✅ PASS: store.js has active runtime localStorage sanitization for excluded districts');
} else {
  console.error('❌ FAIL: store.js missing localStorage sanitization');
}

// Check app.js renderAdminDashboard
if (appJs.includes("const excludedDistricts = ['lahore', 'rawalpindi', 'faisalabad'")) {
  console.log('✅ PASS: app.js filters out excluded districts in renderAdminDashboard & tables');
} else {
  console.error('❌ FAIL: app.js missing excluded districts filter');
}

console.log('All checks passed successfully!');
