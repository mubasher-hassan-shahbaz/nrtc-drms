const http = require('http');

function request(method, path, body = null, headers = {}) {
  return new Promise((resolve, reject) => {
    const url = new URL(path, 'http://localhost:3000');
    const options = {
      hostname: url.hostname,
      port: url.port,
      path: url.pathname + url.search,
      method: method,
      headers: {
        'Content-Type': 'application/json',
        ...headers
      }
    };

    const req = http.request(options, (res) => {
      let data = '';
      res.on('data', chunk => data += chunk);
      res.on('end', () => {
        try {
          const parsed = JSON.parse(data);
          resolve({ status: res.statusCode, body: parsed });
        } catch (e) {
          resolve({ status: res.statusCode, raw: data });
        }
      });
    });

    req.on('error', reject);
    if (body) {
      req.write(JSON.stringify(body));
    }
    req.end();
  });
}

async function runEndToEndFinanceTest() {
  console.log('====================================================');
  console.log('  STARTING END-TO-END FINANCE MODULE VERIFICATION');
  console.log('====================================================\n');

  // 1. Verify User Authentication / Roles
  console.log('Step 1: Verifying User Accounts & Roles...');
  const usersRes = await request('GET', '/api/users');
  const finAdmin = usersRes.body.find(u => u.username === 'finance_admin');
  const superAdmin = usersRes.body.find(u => u.username === 'superadmin');
  const chakwalUser = usersRes.body.find(u => u.username === 'chakwal');

  if (!finAdmin || finAdmin.role !== 'FINANCE_ADMIN') {
    throw new Error('Finance Admin user missing or incorrect role!');
  }
  if (!superAdmin || superAdmin.role !== 'SUPER_ADMIN') {
    throw new Error('Super Admin user missing or incorrect role!');
  }
  if (!chakwalUser || chakwalUser.role !== 'DISTRICT_USER') {
    throw new Error('Chakwal district user missing or incorrect role!');
  }
  console.log('✓ Finance Admin (FINANCE_ADMIN) exists.');
  console.log('✓ Super Admin (SUPER_ADMIN) exists.');
  console.log('✓ Chakwal Site Engineer (DISTRICT_USER) exists.\n');

  // 2. User Submits Monthly Expense (PKR 50,000)
  console.log('Step 2: User submits monthly expense claim (PKR 50,000)...');
  const expensePayload = {
    districtId: 'chakwal',
    districtName: 'Chakwal',
    userId: 'usr_chakwal',
    userName: 'Mubasher Hassan',
    month: '2026-10',
    year: '2026',
    category: 'FUEL',
    title: 'Backup Generator Diesel 150 Liters',
    amount: 50000,
    description: 'Monthly diesel quota for backup generator during scheduled maintenance',
    vendorName: 'PSO Station Kachehri Chowk',
    invoiceNumber: 'PSO-CKW-9901',
    expenseDate: '2026-10-01'
  };

  const createExpRes = await request('POST', '/api/finances', expensePayload);
  const createdExp = createExpRes.body.record || createExpRes.body;
  console.log(`✓ Expense claim created. ID: ${createdExp.id}`);
  console.log(`  - Amount: PKR ${createdExp.amount}`);
  console.log(`  - Paid Amount: PKR ${createdExp.paidAmount}`);
  console.log(`  - Remaining Balance: PKR ${createdExp.remainingBalance}`);
  console.log(`  - Payment Status: ${createdExp.paymentStatus}`);

  if (createdExp.paidAmount !== 0 || createdExp.remainingBalance !== 50000 || createdExp.paymentStatus !== 'NOT_PAID') {
    throw new Error(`Initial expense calculation failed! Expected balance: 50000, got: ${createdExp.remainingBalance}`);
  }

  // 3. User Submits a Finance Query
  console.log('\nStep 3: User submits a Finance Query...');
  const queryPayload = {
    districtId: 'chakwal',
    districtName: 'Chakwal',
    userId: 'usr_chakwal',
    userName: 'Mubasher Hassan',
    month: '2026-10',
    year: '2026',
    category: 'BUDGET_ALLOCATION',
    subject: 'Request for emergency diesel quota revision for Chakwal',
    message: 'Due to 6-hour load shedding, diesel quota needs revision for October 2026.'
  };

  const createQueryRes = await request('POST', '/api/finance-queries', queryPayload);
  const createdQuery = createQueryRes.body.query || createQueryRes.body;
  console.log(`✓ Finance query created. ID: ${createdQuery.id}`);
  console.log(`  - Subject: "${createdQuery.subject}"`);
  console.log(`  - Status: ${createdQuery.status}`);
  if (createdQuery.status !== 'Pending') {
    throw new Error(`Initial query status should be 'Pending', got: ${createdQuery.status}`);
  }

  // 4. Admin and Finance Admin Dashboard Visibility
  console.log('\nStep 4: Verifying visibility on Admin & Finance Admin dashboards...');
  const queriesRes = await request('GET', '/api/finance-queries');
  const foundQuery = queriesRes.body.find(q => q.id === createdQuery.id);
  if (!foundQuery) throw new Error('Submitted query not found in provincial finance queries!');
  console.log('✓ Submitted query appears in provincial queries pool.');

  const summaryRes = await request('GET', '/api/finances/summary');
  console.log('✓ Finance Summary KPIs:');
  console.log(`  - Total Expense: PKR ${summaryRes.body.totalExpense}`);
  console.log(`  - Total Paid: PKR ${summaryRes.body.totalPaid}`);
  console.log(`  - Total Outstanding: PKR ${summaryRes.body.totalOutstanding}`);
  console.log(`  - Pending Queries: ${summaryRes.body.pendingQueries}`);

  // 5. Security Check: District User attempts to disburse payment (Should be FORBIDDEN 403)
  console.log('\nStep 5: Security Test - District User attempts to disburse payment...');
  const unauthorizedPayRes = await request('POST', `/api/finances/${createdExp.id}/payments`, {
    userRole: 'DISTRICT_USER',
    amount: 10000,
    paymentDate: '2026-10-01',
    reference: 'HACK-01'
  });
  console.log(`  - HTTP Status: ${unauthorizedPayRes.status} (Expected: 403)`);
  if (unauthorizedPayRes.status !== 403) {
    throw new Error(`Security breach! Non-finance user was allowed to add payment (HTTP ${unauthorizedPayRes.status})`);
  }
  console.log('✓ RBAC Security enforced: District user successfully rejected from recording payments.');

  // 6. Finance Admin Records First Payment (PKR 30,000)
  console.log('\nStep 6: Finance Admin records first partial payment of PKR 30,000...');
  const payment1Res = await request('POST', `/api/finances/${createdExp.id}/payments`, {
    userRole: 'FINANCE_ADMIN',
    amount: 30000,
    paymentDate: '2026-10-01',
    reference: 'NBP-CHQ-89012',
    remarks: 'First tranche disbursed to Chakwal site account'
  });

  const updatedExp1 = payment1Res.body.record;
  console.log(`✓ Payment 1 recorded successfully.`);
  console.log(`  - Total Expense: PKR ${updatedExp1.amount}`);
  console.log(`  - Total Paid: PKR ${updatedExp1.paidAmount}`);
  console.log(`  - Remaining Balance: PKR ${updatedExp1.remainingBalance}`);
  console.log(`  - Payment Status: ${updatedExp1.paymentStatus}`);

  if (updatedExp1.paidAmount !== 30000 || updatedExp1.remainingBalance !== 20000 || updatedExp1.paymentStatus !== 'PARTIALLY_PAID') {
    throw new Error(`Payment calculation failed! Expected remainingBalance=20000, got ${updatedExp1.remainingBalance}, status=${updatedExp1.paymentStatus}`);
  }
  console.log('✓ Balance auto-calculated: 50,000 - 30,000 = 20,000 (Status: PARTIALLY_PAID)');

  // 7. Finance Admin Records Second Payment (PKR 20,000) to Clear Balance
  console.log('\nStep 7: Finance Admin records second payment of PKR 20,000...');
  const payment2Res = await request('POST', `/api/finances/${createdExp.id}/payments`, {
    userRole: 'FINANCE_ADMIN',
    amount: 20000,
    paymentDate: '2026-10-02',
    reference: 'IBFT-TXN-77391',
    remarks: 'Final settlement disbursed'
  });

  const updatedExp2 = payment2Res.body.record;
  console.log(`✓ Payment 2 recorded successfully.`);
  console.log(`  - Total Expense: PKR ${updatedExp2.amount}`);
  console.log(`  - Total Paid: PKR ${updatedExp2.paidAmount}`);
  console.log(`  - Remaining Balance: PKR ${updatedExp2.remainingBalance}`);
  console.log(`  - Payment Status: ${updatedExp2.paymentStatus}`);

  if (updatedExp2.paidAmount !== 50000 || updatedExp2.remainingBalance !== 0 || updatedExp2.paymentStatus !== 'FULLY_PAID') {
    throw new Error(`Final payment calculation failed! Expected remainingBalance=0, got ${updatedExp2.remainingBalance}, status=${updatedExp2.paymentStatus}`);
  }
  console.log('✓ Balance auto-calculated: 50,000 - 50,000 = 0 (Status: FULLY_PAID)');

  // 8. Finance Admin Updates Query Status & Adds Response Remarks
  console.log('\nStep 8: Finance Admin updates query status & response...');
  const updateQueryRes = await request('PUT', `/api/finance-queries/${createdQuery.id}`, {
    status: 'Resolved',
    response: 'Approved by PMU Command. Quota revised by +50 Liters for Chakwal.',
    respondedBy: 'Finance Admin'
  });
  const updatedQuery = updateQueryRes.body.query;
  console.log(`✓ Query updated to: ${updatedQuery.status}`);
  console.log(`  - Response Remarks: "${updatedQuery.response}"`);
  console.log(`  - Responded By: ${updatedQuery.respondedBy}`);

  if (updatedQuery.status !== 'Resolved' || !updatedQuery.response) {
    throw new Error('Query response update failed!');
  }

  // 9. District User verifies their updated record and query response
  console.log('\nStep 9: District user verifies updated expense and query response...');
  const userExpensesRes = await request('GET', '/api/finances?userId=usr_chakwal');
  const userExp = userExpensesRes.body.find(e => e.id === createdExp.id);
  if (!userExp || userExp.remainingBalance !== 0 || userExp.paymentStatus !== 'FULLY_PAID') {
    throw new Error('User does not see correct cleared expense!');
  }

  const userQueriesRes = await request('GET', '/api/finance-queries?userId=usr_chakwal');
  const userQ = userQueriesRes.body.find(q => q.id === createdQuery.id);
  if (!userQ || userQ.status !== 'Resolved') {
    throw new Error('User does not see resolved query!');
  }
  console.log('✓ District user sees Paid: 50,000, Balance: 0, Status: FULLY_PAID.');
  console.log('✓ District user sees Query Status: Resolved with official remarks.');

  console.log('\n====================================================');
  console.log('  ALL END-TO-END FINANCE MODULE TESTS PASSED (100%)');
  console.log('====================================================');
}

runEndToEndFinanceTest().catch(err => {
  console.error('\n❌ TEST FAILED:', err.message);
  process.exit(1);
});
