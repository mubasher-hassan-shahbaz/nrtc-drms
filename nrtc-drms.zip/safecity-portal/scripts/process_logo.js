const fs = require('fs');
const path = require('path');
const { PNG } = require('pngjs');

const inputPath = 'C:/Users/mubas/.gemini/antigravity/brain/786d803e-4a56-4256-8e0f-49f9457a89ad/.user_uploaded/media_1790723354181.png';
const outDir = path.join(__dirname, '../assets/images');
if (!fs.existsSync(outDir)) fs.mkdirSync(outDir, { recursive: true });

fs.createReadStream(inputPath)
  .pipe(new PNG({ filterType: 4 }))
  .on('parsed', function() {
    console.log(`Image loaded: ${this.width}x${this.height}`);

    // Scan all pixels: if near white (R>235, G>235, B>235), make transparent
    for (let y = 0; y < this.height; y++) {
      for (let x = 0; x < this.width; x++) {
        const idx = (this.width * y + x) << 2;
        const r = this.data[idx];
        const g = this.data[idx + 1];
        const b = this.data[idx + 2];
        const a = this.data[idx + 3];

        // Check if pixel is white or near white background
        if (r > 235 && g > 235 && b > 235) {
          // Smooth edge falloff
          const minVal = Math.min(r, g, b);
          if (minVal > 248) {
            this.data[idx + 3] = 0; // fully transparent
          } else {
            // slight feathering
            const alpha = Math.round(((248 - minVal) / 13) * 255);
            this.data[idx + 3] = Math.min(a, alpha);
          }
        }
      }
    }

    const outLogo = path.join(outDir, 'nrtc-logo.png');
    this.pack().pipe(fs.createWriteStream(outLogo)).on('finish', () => {
      console.log(`Saved transparent logo to: ${outLogo}`);
      
      // Also copy to root as favicon.png
      fs.copyFileSync(outLogo, path.join(__dirname, '../favicon.png'));
      console.log('Saved favicon.png');

      // Create an SVG wrapper for favicon.svg
      const b64 = fs.readFileSync(outLogo).toString('base64');
      const svgContent = `<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 100 100"><image href="data:image/png;base64,${b64}" width="100" height="100"/></svg>`;
      fs.writeFileSync(path.join(__dirname, '../favicon.svg'), svgContent, 'utf8');
      console.log('Saved favicon.svg');
    });
  })
  .on('error', err => {
    console.error('Error processing logo PNG:', err);
  });
