const fs = require('fs');
const path = require('path');
const XLSX = require('xlsx');

const uploadDir = 'C:\\Users\\mubas\\.gemini\\antigravity\\brain\\786d803e-4a56-4256-8e0f-49f9457a89ad\\.user_uploaded';

const file1 = path.join(uploadDir, 'media_1790893556088.xlsx');
const file2 = path.join(uploadDir, 'media_1790893556111.xlsx');

console.log('--- Inspecting File 1: media_1790893556088.xlsx ---');
const wb1 = XLSX.readFile(file1);
console.log('Sheet Names:', wb1.SheetNames);
for (const s of wb1.SheetNames) {
  const ws = wb1.Sheets[s];
  const json = XLSX.utils.sheet_to_json(ws);
  console.log(`Sheet "${s}" has ${json.length} rows`);
  if (json.length > 0) {
    console.log(`  Sample row keys:`, Object.keys(json[0]).slice(0, 8));
  }
}

console.log('\n--- Inspecting File 2: media_1790893556111.xlsx ---');
const wb2 = XLSX.readFile(file2);
console.log('Sheet Names:', wb2.SheetNames);
for (const s of wb2.SheetNames) {
  const ws = wb2.Sheets[s];
  const json = XLSX.utils.sheet_to_json(ws);
  console.log(`Sheet "${s}" has ${json.length} rows`);
  if (json.length > 0) {
    console.log(`  Sample row keys:`, Object.keys(json[0]).slice(0, 8));
  }
}
