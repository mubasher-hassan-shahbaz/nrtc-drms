# Master Prompt for Claude Code: Punjab Safe City Daily Reporting Portal

> **Purpose**: Use this prompt in **Claude Code** (or any agentic CLI) to scaffold and deploy the complete standalone **Next.js + Supabase + Tailwind CSS** application to production on Vercel + Supabase.

---

```markdown
You are an expert full-stack engineer tasked with building the "NRTC Safe City Daily Operations & SLA Reporting Portal" for the Punjab Safe Cities Authority (PSCA) surveillance project across all 37 districts of Punjab, Pakistan.

## Organization & Project Context
- Executing Organization: National Radio & Telecommunication Corporation (NRTC)
- Client Authority: Punjab Safe Cities Authority (PSCA), Government of the Punjab
- Scope: NRTC executes Operations & Maintenance (O&M) across all surveillance systems. NRTC has deputed Site Engineers and field technical staff in each of Punjab's 37 districts.
- Purpose: This portal is the internal operational reporting system where NRTC Field Engineers log daily equipment uptimes, offline justifications, RMA hardware dispatches, OFC cut incidents, and generator runtime hours. The NRTC Project Management Unit (PMU) audits and reviews these reports before compiling SLA performance summaries for the PSCA client.

## Tech Stack
- Framework: Next.js 15 (App Router, Server Actions, TypeScript)
- Styling: Tailwind CSS, Lucide React icons, shadcn/ui components
- Backend / Database: PostgreSQL via Supabase with Row Level Security (RLS)
- Auth: Supabase Auth (Email + Password, strict District-Site binding)
- Charts: Recharts (Availability trends, 7-day bar chart)
- Export: ExcelJS for CSV/XLSX export, @react-pdf/renderer for official PDF reports

## Architecture & Security Requirements
1. Strict Role-Based Access Control (RBAC):
   - DISTRICT_USER: NRTC District Resident Site Engineer assigned strictly to 1 district (e.g. Chakwal). They CANNOT change their district dropdown. They can only view, submit, and edit reports for their own district site.
   - ADMIN: NRTC Safe Cities Project Management Unit (PMU) Director / Operations Lead with Punjab-wide visibility across all 37 districts, audit privileges, report review & approval actions, and export capabilities.

2. 37 Punjab Districts:
   Attock, Bahawalnagar, Bahawalpur, Bhakkar, Chakwal, Chiniot, Dera Ghazi Khan, Faisalabad, Gujranwala, Gujrat, Hafizabad, Jhang, Jhelum, Kasur, Khanewal, Khushab, Kot Addu, Lahore, Layyah, Lodhran, Mandi Bahauddin, Mianwali, Multan, Murree, Muzaffargarh, Nankana Sahib, Narowal, Okara, Pakpattan, Rahim Yar Khan, Rajanpur, Rawalpindi, Sahiwal, Sargodha, Sheikhupura, Sialkot, Toba Tek Singh, Vehari, Wazirabad.

3. Complete Database Schema:
   - districts: id, name, division, base_ipnv, base_cee, base_dee, base_wifi
   - profiles: id (references auth.users), name, email, role, district_id, designation
   - daily_reports:
     id, user_id, district_id, report_date, submitted_at, status (DRAFT, SUBMITTED, APPROVED, NEEDS_REVISION),
     ipnv_installed, ipnv_online, cee_installed, cee_online, dee_installed, dee_online,
     ps_installed, ps_online, dc_installed, dc_online, frnv_installed, frnv_online,
     mcr_dr_installed, mcr_dr_online, wifi_installed, wifi_online,
     panic_installed, panic_online, environmental_installed, environmental_online,
     biometric_installed, biometric_online,
     ipnv_offline_reason, cee_offline_reason, ps_offline_reason, dc_offline_reason, rma_details,
     ofc_cut (Yes/No), ofc_location, ofc_type, ofc_details,
     generator_runtime, major_daily_activity, other_issues, attachments,
     admin_remarks, reviewed_by, reviewed_at.

4. Form Requirements:
   - 6-Step Wizard:
     * Step 1: Report Info (Date, District locked to profile, Reporting Officer)
     * Step 2: Camera Status (IPNV, CEE, DEE, PS, DC, FRNV, MCR/DR) with real-time automatic calculations:
       Availability % = (Online / Installed) * 100, Offline Count = Installed - Online
     * Step 3: Other Equipment (Public WiFi, Panic Buttons, Environmental Sensors, Biometrics)
     * Step 4: Offline / Fault / OFC Issues (Reason breakdown, RMA details, OFC Cut Radio [Yes/No], location, type, details)
     * Step 5: Generator & Daily Operations (Runtime hours, Fuel, Major Activities)
     * Step 6: Review & Submit (Summary preview, confirmation)

5. Admin Dashboard:
   - Punjab Overview (37 Districts, Reports Submitted Today vs. Pending, Provincial Average Uptime %, OFC Cuts)
   - District-wise filterable reports table (District, Date, Status, Search)
   - Modal Inspector with Admin Remarks and Review/Approve workflow
   - Excel & Printable PDF Export

Build this systematically in iterations, ensure TypeScript compiles cleanly, and configure the Supabase schema using the provided schema.sql.
```
