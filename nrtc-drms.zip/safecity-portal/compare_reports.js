const fs = require('fs');
const path = require('path');
const XLSX = require('xlsx');

const uploadDir = 'C:\\Users\\mubas\\.gemini\\antigravity\\brain\\786d803e-4a56-4256-8e0f-49f9457a89ad\\.user_uploaded';

// Check media_1790893556111.xlsx vs media_1790893556088.xlsx
const wb111 = XLSX.readFile(path.join(uploadDir, 'media_1790893556111.xlsx'));
const ws111 = wb111.Sheets['Form Responses 1'];
const data111 = XLSX.utils.sheet_to_json(ws111, { header: 1 });
console.log('media_1790893556111.xlsx Form Responses 1 rows:', data111.length);
console.log('Header 111:', data111[0]);
console.log('Row 1 111:', data111[1]);
console.log('Row 2 111:', data111[2]);

const wb088 = XLSX.readFile(path.join(uploadDir, 'media_1790893556088.xlsx'));
const ws088 = wb088.Sheets['Form Responses 1'];
const data088 = XLSX.utils.sheet_to_json(ws088, { header: 1 });
console.log('\nmedia_1790893556088.xlsx Form Responses 1 rows:', data088.length);
console.log('Header 088:', data088[0]);
console.log('Row 1 088:', data088[1]);
console.log('Row 2 088:', data088[2]);
