/**
 * DRMS Data Import Script
 * Imports Form Responses (reports) + NMS Tickets from uploaded xlsx files
 * Deduplicates against existing records.
 * Run: node import_data.js
 */

const XLSX = require('xlsx');
const fs = require('fs');
const path = require('path');

const DATA_DIR = path.join(__dirname, 'data');
const ARTIFACTS_DIR = path.join(
  'C:\\Users\\mubas\\.gemini\\antigravity\\brain\\786d803e-4a56-4256-8e0f-49f9457a89ad\\.user_uploaded'
);

// ─── Utility: Excel date serial → YYYY-MM-DD ───────────────────────────────
function excelDateToISO(serial) {
  if (!serial || isNaN(serial)) return null;
  const n = Math.round(Number(serial));
  if (n < 1000) return null; // not a date serial
  const date = new Date(Date.UTC(1899, 11, 30) + n * 86400000);
  if (isNaN(date.getTime())) return null;
  return date.toISOString().split('T')[0];
}

// ─── Utility: Excel datetime serial → ISO string ───────────────────────────
function excelDatetimeToISO(serial) {
  if (!serial || isNaN(serial)) return null;
  const n = Number(serial);
  if (n < 1000) return null;
  const date = new Date(Date.UTC(1899, 11, 30) + n * 86400000);
  if (isNaN(date.getTime())) return null;
  return date.toISOString();
}

// ─── Utility: slugify district name ────────────────────────────────────────
function slugify(name) {
  return String(name || '').toLowerCase().trim()
    .replace(/[^a-z0-9]+/g, '_')
    .replace(/_+/g, '_')
    .replace(/^_|_$/g, '');
}

// ─── Utility: clean string ─────────────────────────────────────────────────
function cs(val) {
  return String(val == null ? '' : val).trim();
}

// ─── Utility: parse number ─────────────────────────────────────────────────
function cn(val) {
  const n = Number(String(val || '').replace(/[^0-9.]/g, ''));
  return isNaN(n) ? 0 : n;
}

// ─── Load existing JSON ─────────────────────────────────────────────────────
function loadJSON(filename) {
  const fp = path.join(DATA_DIR, filename);
  if (!fs.existsSync(fp)) return [];
  try { return JSON.parse(fs.readFileSync(fp, 'utf8')); }
  catch (e) { console.error('Error loading', filename, e.message); return []; }
}

function saveJSON(filename, data) {
  fs.writeFileSync(path.join(DATA_DIR, filename), JSON.stringify(data, null, 2));
}

// ─── Official 37 District Map (normalize incoming names) ────────────────────
const DISTRICT_MAP = {
  'attock': 'Attock',
  'bahawalnagar': 'Bahawalnagar',
  'bahawalpur': 'Bahawalpur',
  'bhakkar': 'Bhakkar',
  'chakwal': 'Chakwal',
  'chiniot': 'Chiniot',
  'deraghazikhan': 'Dera Ghazi Khan',
  'dgkhan': 'Dera Ghazi Khan',
  'deraghazikhaan': 'Dera Ghazi Khan',
  'dg khan': 'Dera Ghazi Khan',
  'dera ghazi khan': 'Dera Ghazi Khan',
  'gujrat': 'Gujrat',
  'hafizabad': 'Hafizabad',
  'jhang': 'Jhang',
  'jhelum': 'Jhelum',
  'khanewal': 'Khanewal',
  'khushab': 'Khushab',
  'layyah': 'Layyah',
  'lodhran': 'Lodhran',
  'mandibahauddin': 'Mandi Bahauddin',
  'mandi bahauddin': 'Mandi Bahauddin',
  'mianwali': 'Mianwali',
  'multan': 'Multan',
  'muzaffargarh': 'Muzaffargarh',
  'narowal': 'Narowal',
  'okara': 'Okara',
  'pakpattan': 'Pakpattan',
  'rahimyarkhan': 'Rahim Yar Khan',
  'rahim yar khan': 'Rahim Yar Khan',
  'rajanpur': 'Rajanpur',
  'sahiwal': 'Sahiwal',
  'sargodha': 'Sargodha',
  'sheikhupura': 'Sheikhupura',
  'sialkot': 'Sialkot',
  'tobateksingh': 'Toba Tek Singh',
  'toba tek singh': 'Toba Tek Singh',
  'vehari': 'Vehari',
  'wazirabad': 'Wazirabad',
  'talagang': 'Talagang',
  'murree': 'Murree',
  'kotaddu': 'Kot Addu',
  'kot addu': 'Kot Addu',
  'taunsa': 'Taunsa',
  'hassanabdal': 'Hassan Abdal',
  'hassan abdal': 'Hassan Abdal',
  'hasanabdal': 'Hassan Abdal',
  'hasan abdal': 'Hassan Abdal',
  'taxila': 'Taxila',
};

function normalizeDistrict(raw) {
  const key = String(raw || '').toLowerCase().replace(/[^a-z ]/g, '').trim().replace(/\s+/g, ' ');
  return DISTRICT_MAP[key] || DISTRICT_MAP[key.replace(/\s/g, '')] || raw;
}

// ═══════════════════════════════════════════════════════════════════════════
// PART 1: Import Form Responses → reports.json
// ═══════════════════════════════════════════════════════════════════════════

function mapFormRowToReport(row, existingIds) {
  // Flexible column reading: both xlsx files have same structure with minor naming differences
  const get = (...keys) => {
    for (const k of keys) {
      if (row[k] !== undefined && row[k] !== null && row[k] !== '') return row[k];
    }
    return '';
  };

  // Date of Report
  const rawReportDate = get(
    'Date of Report',
    'Date',
    'Report Date',
    'Reporting Date'
  );
  let reportDate = '';
  if (typeof rawReportDate === 'number') {
    reportDate = excelDateToISO(rawReportDate);
  } else if (rawReportDate) {
    // Try to parse text dates
    const d = new Date(rawReportDate);
    if (!isNaN(d.getTime())) reportDate = d.toISOString().split('T')[0];
    else reportDate = cs(rawReportDate);
  }
  if (!reportDate) return null; // skip rows without date

  // Timestamp
  const rawTs = get('Timestamp', 'Submission Time', 'Time');
  let submittedAt = '';
  if (typeof rawTs === 'number') {
    submittedAt = excelDatetimeToISO(rawTs) || '';
  } else if (rawTs) {
    const d = new Date(rawTs);
    submittedAt = isNaN(d.getTime()) ? cs(rawTs) : d.toISOString();
  }

  const email = cs(get('Email Address', 'Email', 'email'));

  const rawCity = cs(get('City', 'District', 'City / District', 'City/District', 'Location'));
  const districtName = normalizeDistrict(rawCity) || rawCity;
  const districtId = slugify(districtName);

  if (!districtName) return null; // skip rows without district

  // Dedup key: district_id + report_date + email
  const dedupKey = `${districtId}||${reportDate}||${email}`;
  if (existingIds.has(dedupKey)) return null;
  existingIds.add(dedupKey);

  // Camera counts
  const ipnvInstalled = cn(get('IPNV Cameras: Total Installed', 'IPNV Cameras :  Total Installed', 'IPNV Cameras Total Installed', 'IPNV Installed'));
  const ipnvOnline   = cn(get('IPNV Cameras: Total Online', 'IPNV Cameras :  Total Online', 'IPNV Cameras Total Online', 'IPNV Online'));
  const ceeInstalled = cn(get('CEE Cameras: Total Installed', 'CEE Cameras :  Total Installed', 'CEE Installed'));
  const ceeOnline    = cn(get('CEE Cameras: Total Online', 'CEE Cameras :  Total Online', 'CEE Online'));
  const deeInstalled = cn(get('DEE Cameras: Total Installed', 'DEE Cameras :  Total Installed', 'DEE Installed'));
  const deeOnline    = cn(get('DEE Cameras: Total Online', 'DEE Cameras :  Total Online', 'DEE Online'));
  const psInstalled  = cn(get('Police Station (PS) Cameras: Total Installed', 'PS Cameras: Total Installed', 'PS Installed'));
  const psOnline     = cn(get('Police Station (PS) Cameras: Total Online', 'PS Cameras: Total Online', 'PS Online'));
  const dcInstalled  = cn(get('DC Office Cameras: Total Installed', 'DC Office Cameras :  Total Installed', 'DC Installed'));
  const dcOnline     = cn(get('DC Office Cameras: Total Online', 'DC Office Cameras :  Total Online', 'DC Online'));
  const frInstalled  = cn(get('FR NVR: Total Installed', 'FR NVR :  Total Installed', 'FR Installed', 'Facial Recognition (FR) Cameras : Total Installed', 'Facial Recognition (FR) Cameras: Total Installed'));
  const frOnline     = cn(get('FR NVR: Total Online', 'FR NVR :  Total Online', 'FR Online', 'Facial Recognition (FR) Cameras : Total Online', 'Facial Recognition (FR) Cameras: Total Online'));
  const mcrInstalled = cn(get('MCR / DR Cameras: Total Installed', 'MCR / DR Cameras :  Total Installed', 'MCR/DR Installed'));
  const mcrOnline    = cn(get('MCR / DR Cameras: Total Online', 'MCR / DR Cameras :  Total Online', 'MCR/DR Online'));
  const wifiInstalled = cn(get('WiFi APs: Total Installed', 'WiFi APs :  Total Installed', 'WiFi Installed'));
  const wifiOnline   = cn(get('WiFi APs: Total Online', 'WiFi APs :  Total Online', 'WiFi Online'));
  const panicInstalled = cn(get('Panic Buttons (PBs): Total Installed', 'Panic Buttons :  Total Installed', 'Panic Installed'));
  const panicOnline  = cn(get('Panic Buttons (PBs): Total Online', 'Panic Buttons :  Total Online', 'Panic Online'));
  const envInstalled = cn(get('Environmental Sensors (ES): Total Installed', 'Environmental Sensors :  Total Installed', 'Environmental Installed'));
  const envOnline    = cn(get('Environmental Sensors (ES): Total Online', 'Environmental Sensors :  Total Online', 'Environmental Online'));
  const bioInstalled = cn(get('Biometric Devices: Total Installed', 'Biometric Devices :  Total Installed', 'Biometric Installed'));
  const bioOnline    = cn(get('Biometric Devices: Total Online', 'Biometric Devices :  Total Online', 'Biometric Online'));

  const totalInstalled = ipnvInstalled + ceeInstalled + deeInstalled + psInstalled + dcInstalled + frInstalled + mcrInstalled;
  const totalOnline    = ipnvOnline + ceeOnline + deeOnline + psOnline + dcOnline + frOnline + mcrOnline;
  const uptimePct = totalInstalled > 0 ? parseFloat(((totalOnline / totalInstalled) * 100).toFixed(2)) : 0;

  const id = `rep_${districtId}_${reportDate.replace(/-/g, '')}_${Date.now()}_${Math.floor(Math.random() * 1000)}`;

  return {
    id,
    district_id: districtId,
    district_name: districtName,
    city: rawCity,
    report_date: reportDate,
    submitted_at: submittedAt || new Date().toISOString(),
    email: email,
    user_name: email ? email.split('@')[0] : 'Officer',
    status: 'SUBMITTED',
    ipnv_installed: ipnvInstalled,
    ipnv_online: ipnvOnline,
    cee_installed: ceeInstalled,
    cee_online: ceeOnline,
    dee_installed: deeInstalled,
    dee_online: deeOnline,
    ps_installed: psInstalled,
    ps_online: psOnline,
    dc_installed: dcInstalled,
    dc_online: dcOnline,
    frnv_installed: frInstalled,
    frnv_online: frOnline,
    mcr_dr_installed: mcrInstalled,
    mcr_dr_online: mcrOnline,
    wifi_installed: wifiInstalled,
    wifi_online: wifiOnline,
    panic_installed: panicInstalled,
    panic_online: panicOnline,
    environmental_installed: envInstalled,
    environmental_online: envOnline,
    biometric_installed: bioInstalled,
    biometric_online: bioOnline,
    total_cameras_installed: totalInstalled,
    total_cameras_online: totalOnline,
    uptime_percent: uptimePct,
    ipnv_offline_reason: cs(get('Reason for IPNV, CEE, PS, DC Offline Sites', 'IPNV / CEE / PS / DC Offline Reason', 'IPNV Offline Reason')),
    dee_offline_reason: cs(get('Reason for DEE Offline Sites', 'DEE Offline Reason')),
    rma_details: cs(get('RMA / Faulty Equipment Sent Details', 'RMA Details')),
    ofc_cut: cs(get('Any OFC Cut...?', 'OFC Cut', 'OFC Cut?')),
    generator_runtime: cn(get('Generator Run Time (Hours)', 'Generator Runtime (Hours)', 'Generator Hours')),
    major_daily_activity: cs(get('Major Daily Activity & Other Issues', 'Major Daily Activity', 'Daily Activity')),
    other_issues: cs(get('Other Issues', 'Other'))
  };
}

function importFormResponses(wb, sheetName, existingIds) {
  const ws = wb.Sheets[sheetName];
  if (!ws) return [];
  const rows = XLSX.utils.sheet_to_json(ws, { defval: '' });
  console.log(`  Sheet "${sheetName}": ${rows.length} rows`);
  const imported = [];
  for (const row of rows) {
    const r = mapFormRowToReport(row, existingIds);
    if (r) imported.push(r);
  }
  return imported;
}

// ═══════════════════════════════════════════════════════════════════════════
// PART 2: Import Tickets Generated → tickets.json
// ═══════════════════════════════════════════════════════════════════════════

function mapTicketRow(row, existingTicketNumbers) {
  const get = (...keys) => {
    for (const k of keys) {
      if (row[k] !== undefined && row[k] !== null && row[k] !== '') return row[k];
    }
    return '';
  };

  const ticketNumber = cs(get('Ticket Number', 'Ticket #', 'Ticket No', 'TicketNumber'));
  if (!ticketNumber) return null;

  // Dedup by ticket number
  if (existingTicketNumbers.has(ticketNumber)) return null;
  existingTicketNumbers.add(ticketNumber);

  const city = cs(get('City', 'District', 'Location'));
  const districtName = normalizeDistrict(city) || city;
  const districtId = slugify(districtName);

  const rawCreated = get('Date Created', 'Created Date', 'Date', 'Timestamp');
  let dateCreated = '';
  if (typeof rawCreated === 'number') dateCreated = excelDateToISO(rawCreated);
  else if (rawCreated) { const d = new Date(rawCreated); dateCreated = isNaN(d.getTime()) ? cs(rawCreated) : d.toISOString().split('T')[0]; }

  const rawUpdated = get('Last Updated', 'Updated Date');
  let lastUpdated = '';
  if (typeof rawUpdated === 'number') lastUpdated = excelDateToISO(rawUpdated);
  else if (rawUpdated) { const d = new Date(rawUpdated); lastUpdated = isNaN(d.getTime()) ? cs(rawUpdated) : d.toISOString().split('T')[0]; }

  const rawSlaDate = get('SLA Due Date', 'SLA Date');
  let slaDueDate = '';
  if (typeof rawSlaDate === 'number') slaDueDate = excelDateToISO(rawSlaDate);
  else if (rawSlaDate) { const d = new Date(rawSlaDate); slaDueDate = isNaN(d.getTime()) ? cs(rawSlaDate) : d.toISOString().split('T')[0]; }

  const rawDueDate = get('Due Date');
  let dueDate = '';
  if (typeof rawDueDate === 'number') dueDate = excelDateToISO(rawDueDate);
  else if (rawDueDate) { const d = new Date(rawDueDate); dueDate = isNaN(d.getTime()) ? cs(rawDueDate) : d.toISOString().split('T')[0]; }

  const rawClosed = get('Closed Date', 'Close Date', 'Resolution Date');
  let closedDate = '';
  if (typeof rawClosed === 'number') closedDate = excelDateToISO(rawClosed);
  else if (rawClosed) { const d = new Date(rawClosed); closedDate = isNaN(d.getTime()) ? cs(rawClosed) : d.toISOString().split('T')[0]; }

  return {
    id: `tkt_${ticketNumber}`,
    ticketNumber: ticketNumber,
    city: city,
    district_id: districtId,
    districtName: districtName,
    dateCreated: dateCreated,
    createdDateOnly: dateCreated,
    subject: cs(get('Subject', 'Title', 'Issue')),
    fromName: cs(get('From', 'Reporter', 'Submitted By')),
    fromEmail: cs(get('From Email', 'Email', 'Reporter Email')),
    priority: cs(get('Priority', 'Severity')) || 'Normal',
    department: cs(get('Department', 'Dept')),
    helpTopic: cs(get('Help Topic', 'Category')),
    source: cs(get('Source')),
    currentStatus: cs(get('Current Status', 'Status')) || 'Open',
    unifiedStatus: cs(get('Unified Status', 'Status', 'Current Status')) || 'Open',
    lastUpdated: lastUpdated,
    slaDueDate: slaDueDate,
    slaPlan: cs(get('SLA Plan', 'SLA')),
    dueDate: dueDate,
    closedDate: closedDate,
    overdue: cs(get('Overdue', 'Is Overdue')),
    resolutionTimeHrs: cn(get('Resolution Time (Hrs)', 'Resolution Time', 'Res Time')),
    agingHrs: cn(get('Aging (Hrs)', 'Aging Hours', 'Age')),
  };
}

function importTickets(wb, sheetName, existingTicketNumbers) {
  const ws = wb.Sheets[sheetName];
  if (!ws) return [];
  const rows = XLSX.utils.sheet_to_json(ws, { defval: '' });
  console.log(`  Sheet "${sheetName}": ${rows.length} rows`);
  const imported = [];
  for (const row of rows) {
    const t = mapTicketRow(row, existingTicketNumbers);
    if (t) imported.push(t);
  }
  return imported;
}

// ═══════════════════════════════════════════════════════════════════════════
// MAIN
// ═══════════════════════════════════════════════════════════════════════════

(function main() {
  const files = [
    'media_1790893556088.xlsx',
    'media_1790893556111.xlsx'
  ].map(f => path.join(ARTIFACTS_DIR, f));

  // ── Load existing data ────────────────────────────────────────────────────
  const existingReports = loadJSON('reports.json');
  const existingTickets = loadJSON('tickets.json');

  console.log(`\nExisting records: ${existingReports.length} reports, ${existingTickets.length} tickets`);

  // Build dedup sets
  const existingReportKeys = new Set();
  for (const r of existingReports) {
    const key = `${r.district_id}||${r.report_date}||${r.email || ''}`;
    existingReportKeys.add(key);
  }

  const existingTicketNumbers = new Set();
  for (const t of existingTickets) {
    existingTicketNumbers.add(cs(t.ticketNumber));
  }

  let newReports = [];
  let newTickets = [];

  for (const fp of files) {
    if (!fs.existsSync(fp)) {
      console.warn(`File not found: ${fp}`);
      continue;
    }

    console.log(`\nProcessing: ${path.basename(fp)}`);
    const wb = XLSX.readFile(fp);
    console.log('  Sheets:', wb.SheetNames.join(', '));

    // Import Form Responses from all sheets matching 'Form Response'
    for (const sheetName of wb.SheetNames) {
      if (sheetName.toLowerCase().includes('form response')) {
        const imported = importFormResponses(wb, sheetName, existingReportKeys);
        console.log(`  → ${imported.length} new reports from "${sheetName}"`);
        newReports = newReports.concat(imported);
      }
    }

    // Import Tickets from sheets matching 'ticket'
    for (const sheetName of wb.SheetNames) {
      if (sheetName.toLowerCase().includes('ticket')) {
        const imported = importTickets(wb, sheetName, existingTicketNumbers);
        console.log(`  → ${imported.length} new tickets from "${sheetName}"`);
        newTickets = newTickets.concat(imported);
      }
    }
  }

  // ── Merge and save ────────────────────────────────────────────────────────
  const mergedReports = [...existingReports, ...newReports];
  const mergedTickets = [...existingTickets, ...newTickets];

  saveJSON('reports.json', mergedReports);
  saveJSON('tickets.json', mergedTickets);

  console.log(`\n✓ Import complete.`);
  console.log(`  Reports: ${existingReports.length} existing + ${newReports.length} new = ${mergedReports.length} total`);
  console.log(`  Tickets: ${existingTickets.length} existing + ${newTickets.length} new = ${mergedTickets.length} total`);

  // ── District breakdown for reports ───────────────────────────────────────
  if (newReports.length > 0) {
    const byDistrict = {};
    for (const r of newReports) {
      byDistrict[r.district_name] = (byDistrict[r.district_name] || 0) + 1;
    }
    console.log('\nNew reports by district:');
    Object.entries(byDistrict).sort((a,b)=>b[1]-a[1]).forEach(([d, c]) => console.log(`  ${d}: ${c}`));
  }
})();
