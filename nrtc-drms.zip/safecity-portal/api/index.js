const app = require('../server.js');

function resolveRequestUrl(req) {
  // 1. If Vercel or reverse-proxy provided x-forwarded-uri or x-real-url, prefer it
  // (unless it points directly to the serverless function file api/index.js)
  const forwardedUri = req.headers && (req.headers['x-forwarded-uri'] || req.headers['x-real-url']);
  if (forwardedUri && forwardedUri.startsWith('/api') && !forwardedUri.startsWith('/api/index')) {
    return forwardedUri;
  }

  let rawUrl = req.url || '';

  // 2. Extract from __route query param if rewritten by vercel.json, preserving all other query parameters
  if (rawUrl.includes('__route=')) {
    try {
      const parsed = new URL(rawUrl, 'http://localhost');
      const route = parsed.searchParams.get('__route');
      parsed.searchParams.delete('__route');
      const search = parsed.searchParams.toString();
      return '/api/' + (route ? route.replace(/^\/+/, '') : '') + (search ? '?' + search : '');
    } catch (e) {}
  }

  if (req.query && req.query.__route) {
    const route = req.query.__route;
    try {
      const parsed = new URL(rawUrl || '/api', 'http://localhost');
      parsed.searchParams.delete('__route');
      const search = parsed.searchParams.toString();
      return '/api/' + route.replace(/^\/+/, '') + (search ? '?' + search : '');
    } catch (e) {
      return '/api/' + route.replace(/^\/+/, '');
    }
  }

  // 3. Direct /api/ endpoint (not pointing to /api/index.js or bare /api)
  if (rawUrl.startsWith('/api') && !rawUrl.startsWith('/api/index')) {
    return rawUrl;
  }

  return rawUrl;
}

module.exports = (req, res) => {
  // Resolve correct endpoint
  const resolvedUrl = resolveRequestUrl(req);
  if (resolvedUrl && resolvedUrl !== req.url) {
    req.url = resolvedUrl;
    // Clear Express / parseurl cache so Express re-parses path & query string
    delete req._parsedUrl;
    delete req._parsedOriginalUrl;
  }

  // Prevent Express body-parser hang if Vercel serverless runtime pre-parsed req.body
  if (req.body && typeof req.body === 'object' && Object.keys(req.body).length > 0) {
    req._body = true;
  }

  return app(req, res);
};
