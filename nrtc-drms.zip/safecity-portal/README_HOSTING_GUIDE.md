# 🚀 Live Hosting & Domain Deployment Guide — NRTC Safe City Portal

Yeh project **100% Production Ready** hai. Is portal ko domain aur hosting server py upload krny k baad **koi b coding ya setting change krny ki zaroorat nahi hai**.

---

## 📦 Ready-to-Upload Production Files

Aap k system py ready-to-upload ZIP file ban chuki hai:
📍 **ZIP File Location**: `C:\Users\mubas\.gemini\antigravity\scratch\safecity-portal-production.zip`
📁 **Source Directory**: `C:\Users\mubas\.gemini\antigravity\scratch\safecity-portal\`

---

## 🛠️ Method 1: cPanel / Shared Hosting (Hostinger, Namecheap, GoDaddy, etc.)

Sab sy asaan aur standard tareeqa cPanel File Manager ka hai:

1. Apny hosting account (cPanel) mein **Login** krain.
2. **File Manager** open krain aur **`public_html`** folder k andar jayen.
   *(Agar kisi subdomain py chalana hai to us subdomain k folder mein jayen).*
3. Top menu sy **Upload** py click krain aur `safecity-portal-production.zip` ko upload krain.
4. Upload mukammal hony k baad file py **Right Click** krain aur **Extract** py click krain.
5. Extract krny k baad ZIP file ko delete kr dain (ta k space clean rahy).
6. Browser open krain aur apna domain open krain:
   👉 **`https://yourdomain.com/`**
   
✨ **Website foran live ho jayegi bina kisi configuration k!**

---

## ☁️ Method 2: Netlify / Vercel (10 Seconds Free Cloud Hosting with Free SSL)

Agar aap k paas domain hai ya free cloud hosting py live krna chahty hain:

### Netlify (Drag & Drop):
1. [app.netlify.com](https://app.netlify.com) py login krain.
2. **Sites** tab mein jayen aur **`safecity-portal`** folder ko seedha browser mein **Drag & Drop** kr dain.
3. 5 seconds mein website live ho jayegi aur custom domain attach krny ka option b mil jaye ga.

### Vercel:
- Hum ny project k andar `vercel.json` pehly sy configure kr k rkh dia hai. CLI ya GitHub connect kr k direct deploy ho jaye ga.

---

## 💻 Method 3: VPS / Cloud Server (Ubuntu / Nginx / Apache)

Agar aap dedicated VPS (DigitalOcean, AWS EC2, Linode) use kr rhy hain:

1. Files ko `/var/www/safecity/` directory mein copy krain.
2. **Nginx Server Block** configuration:
```nginx
server {
    listen 80;
    server_name yourdomain.com www.yourdomain.com;
    root /var/www/safecity;
    index index.html;

    location / {
        try_files $uri $uri/ /index.html;
    }

    # Gzip Compression
    gzip on;
    gzip_types text/plain text/css application/json application/javascript text/xml application/xml image/svg+xml;
}
```
3. Nginx reload krain: `sudo systemctl reload nginx`.

---

## 🔒 Important: Free SSL Certificate (HTTPS)

Face Biometric Camera aur GPS Geolocation features k lye browser **HTTPS (Secure SSL)** mangta hai:
- cPanel mein **"SSL/TLS Status"** ya **"Let's Encrypt"** py ja kr 1-click Free AutoSSL activate kr lain.
- Netlify / Vercel / Cloudflare mein SSL automatic enable hota hai.

---

## 🔑 Default Login Credentials (Testing & Production)

Dashboard live hoty hi aap in credentials sy foran login kr sakty hain:

| Role | Username / Email | Default Password | Access Scope |
| :--- | :--- | :--- | :--- |
| **🛡️ PMU Administrator** | `admin` *(ya `admin@nrtc.com.pk`)* | `admin123` | Punjab-wide Command (All 37 Districts, Attendance Telemetry, Finance Audit, Users) |
| **📍 Chakwal Field Engineer** | `chakwal` | `chakwal123` | Chakwal Site Reporting, Attendance, Expenses, Analytics |
| **📍 Lahore Field Engineer** | `lahore` | `lahore123` | Lahore Site Reporting, Attendance, Expenses, Analytics |
| **📍 Rawalpindi Site** | `rawalpindi` | `rawalpindi123` | Rawalpindi Site Reporting, Attendance, Expenses, Analytics |
| **📍 Faisalabad Site** | `faisalabad` | `faisalabad123` | Faisalabad Site Reporting, Attendance, Expenses, Analytics |
| **📍 Multan Site** | `multan` | `multan123` | Multan Site Reporting, Attendance, Expenses, Analytics |
| **📍 All Other 32 Districts** | `[district-name]` *(e.g. `attock`, `gujrat`, `sialkot`)* | `[district-name]123` | Respective District Operations |

*(Note: Admin login k andar "User Management" sy aap kisi b user ya admin ka password, email, aur name permanently change kr sakty hain).*

---

## ✅ Pre-Configured Production Safeguards

Is package mein tamam production files pehly sy shamil hain:
- **`.htaccess`**: Apache/LiteSpeed speed optimization, Gzip compression, browser caching aur MIME types k lye.
- **`web.config`**: Windows Server / IIS hosting k lye.
- **`_redirects` & `_headers`**: Netlify aur Cloudflare Pages k lye.
- **`vercel.json`**: Vercel cloud hosting k lye.
- **`robots.txt`**: Internal operational data ko Google/Bing search indexing sy safe rkhny k lye.
- **`favicon.svg` & `favicon.ico`**: Browser tab icon ta k koi 404 console error na aaye.
- **100% Relative URLs**: Domain k root (`/`) py chalayein ya kisi folder (`/portal/`) mein, sab links perfect kaam krain gy.
