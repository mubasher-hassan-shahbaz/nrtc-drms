const fs = require('fs');

const rep = JSON.parse(fs.readFileSync('data/reports.json', 'utf8'));
const tkt = JSON.parse(fs.readFileSync('data/tickets.json', 'utf8'));
const ptclTkt = fs.existsSync('data/ptcl_tickets.json') ? JSON.parse(fs.readFileSync('data/ptcl_tickets.json', 'utf8')) : [];

console.log('Current data/reports.json count:', rep.length);
console.log('Current data/tickets.json count:', tkt.length);
console.log('Current data/ptcl_tickets.json count:', ptclTkt.length);
