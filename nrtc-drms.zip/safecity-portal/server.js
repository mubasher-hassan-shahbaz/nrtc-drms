/**
 * Punjab Safe City Portal - Node.js Express Server
 * Serves the portal with API endpoints for real data.
 * All data loaded from JSON files derived from Excel uploads.
 */
const express = require('express');
const cors = require('cors');
const path = require('path');
const fs = require('fs');
const multer = require('multer');

const app = express();
const PORT = process.env.PORT || 3000;

// Middleware
app.use(cors());
app.use(express.json({ limit: '10mb' }));
app.use(express.urlencoded({ extended: true }));

// Dynamic API cache control middleware (prevent Vercel CDN/browser stale caches)
app.use('/api', (req, res, next) => {
  res.setHeader('Cache-Control', 'no-store, no-cache, must-revalidate, proxy-revalidate');
  res.setHeader('Pragma', 'no-cache');
  res.setHeader('Expires', '0');
  res.setHeader('Surrogate-Control', 'no-store');
  next();
});

// Guard static middleware from intercepting /api requests or triggering 301 folder redirects on /api
app.use((req, res, next) => {
  if (req.path.startsWith('/api') || req.url.startsWith('/api')) {
    return next();
  }
  next();
});

// Static file serving
app.use(express.static(path.join(__dirname, 'public')));
app.use('/assets', express.static(path.join(__dirname, 'assets')));
app.use('/css', express.static(path.join(__dirname, 'css')));
app.use('/js', express.static(path.join(__dirname, 'js')));
app.use('/uploads', express.static(path.join(__dirname, 'uploads')));
// Serve static root files with index: false, redirect: false so /api is never redirected
app.use((req, res, next) => {
  if (req.path.startsWith('/api') || req.url.startsWith('/api')) return next();
  express.static(path.join(__dirname), { index: false, redirect: false })(req, res, next);
});

// File upload configuration
const storage = multer.diskStorage({
  destination: (req, file, cb) => {
    const uploadDir = path.join(__dirname, 'uploads', req.params.type || 'misc');
    if (!fs.existsSync(uploadDir)) fs.mkdirSync(uploadDir, { recursive: true });
    cb(null, uploadDir);
  },
  filename: (req, file, cb) => {
    const timestamp = Date.now();
    cb(null, `${timestamp}_${file.originalname}`);
  }
});
const upload = multer({ storage, limits: { fileSize: 50 * 1024 * 1024 } });

// ============================================================
// DATA LOADING UTILITIES & SERVERLESS IN-MEMORY REPOSITORY
// ============================================================
const memoryStore = {};

function resolveDataFile(filename) {
  const candidates = [
    process.env.DATA_DIR ? path.join(process.env.DATA_DIR, filename) : null,
    path.join(__dirname, 'data', filename),
    path.join(__dirname, 'public', 'data', filename),
    path.join(process.cwd(), 'data', filename),
    path.join(process.cwd(), 'public', 'data', filename),
    path.join(__dirname, '..', 'data', filename),
    path.join(__dirname, '..', 'public', 'data', filename)
  ].filter(Boolean);

  for (const p of candidates) {
    if (fs.existsSync(p)) return p;
  }
  return path.join(__dirname, 'data', filename);
}

function loadJSON(filename) {
  if (memoryStore[filename] && Array.isArray(memoryStore[filename]) && memoryStore[filename].length > 0) {
    return memoryStore[filename];
  }

  // Check /tmp first for runtime serverless updates
  const tmpPath = path.join('/tmp', filename);
  if (fs.existsSync(tmpPath)) {
    try {
      const tmpData = JSON.parse(fs.readFileSync(tmpPath, 'utf8'));
      if (Array.isArray(tmpData) && tmpData.length > 0) {
        memoryStore[filename] = tmpData;
        return tmpData;
      }
    } catch (e) {}
  }

  const filePath = resolveDataFile(filename);
  if (!fs.existsSync(filePath)) {
    return memoryStore[filename] || [];
  }

  try {
    const data = JSON.parse(fs.readFileSync(filePath, 'utf8'));
    memoryStore[filename] = data;
    return data;
  } catch (e) {
    console.error(`Error loading ${filename}:`, e.message);
    return memoryStore[filename] || [];
  }
}

function saveJSON(filename, data) {
  memoryStore[filename] = data;

  // 1. Try writing to original data directory (local environment)
  try {
    const filePath = resolveDataFile(filename);
    fs.writeFileSync(filePath, JSON.stringify(data, null, 2));
  } catch (err) {
    // 2. On serverless (read-only filesystem on Vercel), persist to /tmp
    try {
      const tmpPath = path.join('/tmp', filename);
      fs.writeFileSync(tmpPath, JSON.stringify(data, null, 2));
    } catch (tmpErr) {
      console.warn(`Write to /tmp/${filename} failed:`, tmpErr.message);
    }
  }
}

// ============================================================
// RBAC, PERMISSIONS & DISTRICT ACCESS SECURITY ENGINE
// ============================================================

function getReqUser(req) {
  const users = loadJSON('users.json');
  const userId = req.headers['x-user-id'] || (req.body && req.body.userId) || (req.query && req.query.userId);
  if (userId) {
    const found = users.find(u => u.id === userId || u.username.toLowerCase() === String(userId).toLowerCase());
    if (found) return found;
  }
  const role = (req.headers['x-user-role'] || (req.body && req.body.userRole) || '').toUpperCase();
  if (role) {
    const byRole = users.find(u => u.role.toUpperCase() === role);
    if (byRole) return byRole;
    return {
      role,
      accessLevel: role,
      districtId: req.headers['x-district-id'] || 'all',
      districts: ['all'],
      permissions: role === 'READ_ONLY_ADMIN' ? ['view', 'export'] : ['view', 'create', 'edit', 'update', 'delete', 'approve', 'close', 'acknowledge', 'export', 'import'],
      active: true
    };
  }
  return null;
}

function userHasPermission(user, perm) {
  if (!user) return true; // public or unauthenticated read
  if (user.active === false) return false;
  if (user.role === 'SUPER_ADMIN' || user.role === 'ADMIN') return true;
  if (user.role === 'READ_ONLY_ADMIN') {
    return perm === 'view' || perm === 'export';
  }
  if (Array.isArray(user.permissions)) {
    return user.permissions.includes(perm);
  }
  return false;
}

function userHasDistrictAccess(user, district) {
  if (!user || !district || district === 'all') return true;
  if (user.role === 'SUPER_ADMIN' || user.role === 'ADMIN' || user.role === 'FINANCE_ADMIN' || user.role === 'PTCL_ADMIN') return true;
  if (user.districtId === 'all') return true;
  
  const userDistricts = (user.districts && Array.isArray(user.districts) && user.districts.length > 0)
    ? user.districts
    : [user.districtId];

  if (userDistricts.includes('all')) return true;

  const clean = s => String(s || '').toLowerCase().replace(/[^a-z0-9]/g, '');
  const target = clean(district);

  return userDistricts.some(d => {
    const dClean = clean(d);
    return dClean === target || dClean.includes(target) || target.includes(dClean);
  });
}

function requirePermission(perm) {
  return function(req, res, next) {
    const user = getReqUser(req);
    if (!user) return next();
    if (user.active === false) {
      return res.status(403).json({ success: false, error: 'Your account has been deactivated. Access suspended.' });
    }
    if (!userHasPermission(user, perm)) {
      return res.status(403).json({
        success: false,
        error: `Permission denied: '${perm}' permission is required for this action.`
      });
    }
    next();
  };
}

function denyReadOnly(req, res, next) {
  const user = getReqUser(req);
  if (user) {
    if (user.active === false) {
      return res.status(403).json({ success: false, error: 'Your account has been deactivated. Access suspended.' });
    }
    if (user.role === 'READ_ONLY_ADMIN' || user.accessLevel === 'Read Only') {
      return res.status(403).json({
        success: false,
        error: 'Read-only access. Modification actions are not permitted.'
      });
    }
  }
  const role = (
    req.body && req.body.userRole ||
    req.headers['x-user-role'] ||
    ''
  ).toUpperCase();
  if (role === 'READ_ONLY_ADMIN') {
    return res.status(403).json({
      success: false,
      error: 'Read-only access. Modification actions are not permitted.'
    });
  }
  next();
}

// --- AUTH ---
app.post('/api/auth/login', (req, res) => {
  const { username, password } = req.body;
  if (!username || !password) {
    return res.status(400).json({ success: false, message: 'Username and password required.' });
  }
  const users = loadJSON('users.json');
  const inputUser = username.toLowerCase().trim();
  const user = users.find(u => {
    if (u.password !== password) return false;
    const dbUser = u.username.toLowerCase();
    if (dbUser === inputUser) return true;
    if ((dbUser === 'hasanabdal' || dbUser === 'hassan_abdal') && (inputUser === 'hasanabdal' || inputUser === 'hassanabdal' || inputUser === 'hassan_abdal')) return true;
    if (dbUser === 'dg_khan' && (inputUser === 'dgkhan' || inputUser === 'deraghazikhan')) return true;
    if (dbUser === 'rahim_yar_khan' && (inputUser === 'rahimyarkhan' || inputUser === 'ryk')) return true;
    if (dbUser === 'mandi_bahauddin' && (inputUser === 'mandibahauddin' || inputUser === 'mbd')) return true;
    if (dbUser === 'toba_tek_singh' && (inputUser === 'tobateksingh' || inputUser === 'tts')) return true;
    if (dbUser === 'kot_addu' && inputUser === 'kotaddu') return true;
    return false;
  });
  if (!user) {
    return res.status(401).json({ success: false, message: 'Invalid credentials.' });
  }
  if (user.active === false) {
    return res.status(403).json({
      success: false,
      message: 'Your account has been deactivated. Please contact your System Administrator.'
    });
  }
  const { password: _, ...safeUser } = user;
  res.json({ success: true, user: safeUser });
});

// Current Authenticated User Profile (always fetches fresh from users.json database)
app.get(['/api/auth/me', '/api/users/me'], (req, res) => {
  const users = loadJSON('users.json');
  const user = getReqUser(req);
  if (!user) {
    return res.status(401).json({ success: false, message: 'Authentication required.' });
  }
  const fresh = users.find(u => u.id === user.id || (user.username && u.username && u.username.toLowerCase() === user.username.toLowerCase()));
  if (fresh) {
    const { password: _, ...safeUser } = fresh;
    return res.json({ success: true, user: safeUser });
  }
  const { password: _, ...safeUser } = user;
  res.json({ success: true, user: safeUser });
});

// --- DISTRICTS & SITES ---
app.get('/api/districts', (req, res) => {
  const sites = loadJSON('sites.json');
  const reports = loadJSON('reports.json');
  const employees = loadJSON('employees.json');

  // Aggregate districts from sites
  const districtMap = {};
  sites.forEach(site => {
    const c = site.city;
    if (!c) return;
    if (!districtMap[c]) {
      districtMap[c] = { name: c, id: c.toLowerCase().replace(/[^a-z0-9]/g, '_'), siteCount: 0, totalCameras: 0, onlineCameras: 0, employeeCount: 0 };
    }
    districtMap[c].siteCount++;
    districtMap[c].totalCameras += site.totalCameras || 0;
  });

  // Add employee counts
  employees.forEach(emp => {
    const dName = emp.location ? emp.location.trim() : '';
    if (districtMap[dName]) districtMap[dName].employeeCount++;
  });

  res.json(Object.values(districtMap));
});

function isDeeSite(s) {
  if (!s) return false;
  const t = (s.siteType || '').toUpperCase();
  const spot = (s.spotId || '').toUpperCase();
  const name = (s.siteName || '').toUpperCase();
  if (t === 'DEE') return true;
  if (/-D\d+|-D-\d+/i.test(spot)) return true;
  if (/\bDEE\b/i.test(name)) return true;
  return false;
}

function isMcrSite(s) {
  if (!s) return false;
  const t = (s.siteType || '').toUpperCase();
  const spot = (s.spotId || '').toUpperCase();
  const name = (s.siteName || '').toUpperCase();
  if (t === 'MCR' || t === 'MDC') return true;
  if (/\bMCR\b|\bMDC\b/i.test(spot) || spot.endsWith('-MDC') || spot.endsWith('-MCR')) return true;
  if (/\bMCR\b|\bMDC\b/i.test(name) || /control\s*room|cotrol\s*room/i.test(name) || /ppic3/i.test(name)) return true;
  return false;
}

function filterSitesList(sites, query) {
  const { city, district, site, type, siteType, status, search } = query;
  const distParam = district || city;
  let result = sites;

  if (distParam && distParam !== 'all') {
    const target = distParam.toLowerCase().replace(/[^a-z0-9]/g, '');
    result = result.filter(s => {
      const c = (s.city || '').toLowerCase().replace(/[^a-z0-9]/g, '');
      const dId = (s.district_id || '').toLowerCase().replace(/[^a-z0-9]/g, '');
      if (c === target || dId === target) return true;
      if (target.includes('dg') && (c.includes('ghazi') || dId.includes('dg'))) return true;
      if (target.includes('ryk') && (c.includes('rahim') || dId.includes('rahim'))) return true;
      if (target.includes('hassan') && (c.includes('hasan') || dId.includes('hasan'))) return true;
      if (target.includes('hasan') && (c.includes('hassan') || dId.includes('hassan'))) return true;
      return c.includes(target) || target.includes(c);
    });
  }

  if (site && site !== 'all') {
    const sTarget = site.toLowerCase().trim();
    result = result.filter(s => {
      const spot = (s.spotId || '').toLowerCase().trim();
      const name = (s.siteName || '').toLowerCase().trim();
      const id = (s.id || '').toLowerCase().trim();
      return spot === sTarget || name === sTarget || id === sTarget || spot.includes(sTarget) || name.includes(sTarget);
    });
  }

  const tParam = type || siteType;
  if (tParam && tParam !== 'all') {
    const tLower = tParam.toLowerCase();
    const wantsDee = tLower.includes('dee') || tLower.includes('ptcl');
    const wantsMcr = tLower.includes('mcr') || tLower.includes('mdc') || tLower.includes('ptcl');

    if (wantsDee && wantsMcr) {
      result = result.filter(s => isDeeSite(s) || isMcrSite(s));
    } else if (wantsDee) {
      result = result.filter(isDeeSite);
    } else if (wantsMcr) {
      result = result.filter(isMcrSite);
    } else {
      result = result.filter(s => s.siteType && s.siteType.toLowerCase() === tLower);
    }

    result = result.map(s => {
      const cat = isMcrSite(s) ? 'MCR' : (isDeeSite(s) ? 'DEE' : (s.siteType || 'SITE'));
      return { ...s, siteCategory: cat };
    });

    const seen = new Set();
    result = result.filter(s => {
      const key = `${(s.city || '').toLowerCase()}_${(s.spotId || s.id || '').toUpperCase()}`;
      if (!key || seen.has(key)) return false;
      seen.add(key);
      return true;
    });
  }

  if (status && status !== 'all') {
    const stUpper = status.toUpperCase();
    result = result.filter(s => (s.status || 'ONLINE').toUpperCase() === stUpper);
  }

  if (search) {
    const qLower = search.toLowerCase().trim();
    result = result.filter(s => {
      const hay = [s.spotId, s.siteName, s.city, s.district, s.siteType, s.poleType, s.id].filter(Boolean).join(' ').toLowerCase();
      return hay.includes(qLower);
    });
  }

  return result;
}

function mapSiteToExportRow(s, idx) {
  return {
    'Sr #': idx + 1,
    'Spot ID': s.spotId || '',
    'Site Name': s.siteName || '',
    'District': s.city || s.district || '',
    'Site Type': s.siteType || '',
    'Pole Height (m)': s.poleHeight != null ? s.poleHeight : '',
    'Pole Type': s.poleType || '',
    'Pole Arm (m)': s.poleArm != null ? s.poleArm : '',
    'Cabinet': s.cabinet != null ? s.cabinet : '',
    'Electric Meter': s.electricMeter != null ? s.electricMeter : '',
    'Fixed Cameras': s.fixCam || 0,
    'PTZ Cameras': s.ptzCam || 0,
    'ANPR Cameras': s.anprCam || 0,
    'FR Cameras': s.frCam || 0,
    'Box Cameras': s.boxCam || 0,
    'Strobe Light': s.strobeLight || 0,
    'Total Cameras': s.totalCameras || 0,
    'Latitude': s.lat || '',
    'Longitude': s.lng || '',
    'Status': s.status || 'ONLINE'
  };
}

app.get('/api/sites', (req, res) => {
  let sites = loadJSON('sites.json');
  sites = filterSitesList(sites, req.query);
  const { limit } = req.query;
  if (limit) sites = sites.slice(0, parseInt(limit));
  res.json(sites);
});

// Export Filtered Sites (Excel .xlsx / CSV)
app.get('/api/sites/export', (req, res) => {
  const { format = 'xlsx' } = req.query;
  let sites = loadJSON('sites.json');
  sites = filterSitesList(sites, req.query);

  const rows = sites.map(mapSiteToExportRow);

  if (format === 'csv') {
    const headers = rows.length > 0 ? Object.keys(rows[0]) : [
      'Sr #', 'Spot ID', 'Site Name', 'District', 'Site Type', 'Total Cameras', 'Latitude', 'Longitude', 'Status'
    ];
    const escapeCsv = val => {
      if (val == null) return '""';
      const str = String(val).replace(/"/g, '""');
      return `"${str}"`;
    };
    const csvContent = '\uFEFF' + [
      headers.join(','),
      ...rows.map(r => headers.map(h => escapeCsv(r[h])).join(','))
    ].join('\r\n');

    res.setHeader('Content-Disposition', 'attachment; filename="Punjab_SafeCity_37_Districts_Sites_Export.csv"');
    res.setHeader('Content-Type', 'text/csv; charset=utf-8');
    return res.send(csvContent);
  } else {
    try {
      const XLSX = require('xlsx');
      const wb = XLSX.utils.book_new();
      const ws = XLSX.utils.json_to_sheet(rows.length > 0 ? rows : [{
        'Sr #': '', 'Spot ID': '', 'Site Name': '', 'District': '', 'Status': '', 'Message': 'No matching sites found'
      }]);
      XLSX.utils.book_append_sheet(wb, ws, 'District Sites');
      const buffer = XLSX.write(wb, { type: 'buffer', bookType: 'xlsx' });
      res.setHeader('Content-Disposition', 'attachment; filename="Punjab_SafeCity_37_Districts_Sites_Export.xlsx"');
      res.setHeader('Content-Type', 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet');
      return res.send(buffer);
    } catch (err) {
      console.error('Sites XLSX export error:', err);
      res.status(500).json({ error: 'Failed to generate Excel file.' });
    }
  }
});

app.get('/api/sites/:siteId', (req, res) => {
  const sites = loadJSON('sites.json');
  const site = sites.find(s => s.id === req.params.siteId || s.spotId === req.params.siteId);
  if (!site) return res.status(404).json({ error: 'Site not found' });
  res.json(site);
});

// --- EMPLOYEES ---
app.get('/api/employees', (req, res) => {
  const { district, designation, status } = req.query;
  let emps = loadJSON('employees.json');
  if (district && district !== 'all') {
    emps = emps.filter(e => e.district_id === district || (e.location && e.location.toLowerCase().includes(district.toLowerCase())));
  }
  if (designation) emps = emps.filter(e => e.designation && e.designation.toLowerCase().includes(designation.toLowerCase()));
  if (status && status !== 'all') emps = emps.filter(e => e.status === status.toUpperCase());
  res.json(emps);
});

app.get('/api/employees/:id', (req, res) => {
  const emps = loadJSON('employees.json');
  const emp = emps.find(e => e.id === req.params.id || e.empId === req.params.id);
  if (!emp) return res.status(404).json({ error: 'Employee not found' });
  res.json(emp);
});

app.post('/api/employees', denyReadOnly, (req, res) => {
  const emps = loadJSON('employees.json');
  const newEmp = { id: `emp_${Date.now()}`, ...req.body, status: 'ACTIVE' };
  emps.push(newEmp);
  saveJSON('employees.json', emps);
  res.json({ success: true, employee: newEmp });
});

app.put('/api/employees/:id', denyReadOnly, (req, res) => {
  const emps = loadJSON('employees.json');
  const idx = emps.findIndex(e => e.id === req.params.id);
  if (idx === -1) return res.status(404).json({ error: 'Employee not found' });
  emps[idx] = { ...emps[idx], ...req.body };
  saveJSON('employees.json', emps);
  res.json({ success: true, employee: emps[idx] });
});

app.delete('/api/employees/:id', denyReadOnly, (req, res) => {
  let emps = loadJSON('employees.json');
  const idx = emps.findIndex(e => e.id === req.params.id);
  if (idx === -1) return res.status(404).json({ error: 'Employee not found' });
  emps.splice(idx, 1);
  saveJSON('employees.json', emps);
  res.json({ success: true });
});

// --- REPORTS ---
function normalizeReportDateStr(dStr) {
  if (!dStr) return '';
  dStr = String(dStr).trim();
  const dmyMatch = dStr.match(/^(\d{1,2})[-\/](\d{1,2})[-\/](\d{4})$/);
  if (dmyMatch) {
    const day = dmyMatch[1].padStart(2, '0');
    const month = dmyMatch[2].padStart(2, '0');
    const year = dmyMatch[3];
    return `${year}-${month}-${day}`;
  }
  const ymdMatch = dStr.match(/^(\d{4})[-\/](\d{1,2})[-\/](\d{1,2})$/);
  if (ymdMatch) {
    const year = ymdMatch[1];
    const month = ymdMatch[2].padStart(2, '0');
    const day = ymdMatch[3].padStart(2, '0');
    return `${year}-${month}-${day}`;
  }
  return dStr;
}

function normDistrict(s) {
  let x = String(s || '').toLowerCase().replace(/[^a-z0-9]/g, '');
  if (x === 'hasanabdal' || x === 'hassanabdal') return 'hassanabdal';
  if (x === 'deraghazikhan' || x === 'dgkhan') return 'deraghazikhan';
  if (x === 'tobateksingh' || x === 'ttsingh') return 'tobateksingh';
  if (x === 'rahimyarkhan' || x === 'ryk') return 'rahimyarkhan';
  return x;
}

function filterReportsList(reports, query, reqUser) {
  const { district, site, date, fromDate, toDate, status, search } = query;
  let result = reports;
  const clean = normDistrict;

  // 1. Mandatory District Isolation for non-provincial users
  if (reqUser && !['SUPER_ADMIN', 'ADMIN', 'FINANCE_ADMIN', 'PTCL_ADMIN'].includes(reqUser.role)) {
    const userDistricts = (reqUser.districts && Array.isArray(reqUser.districts) && reqUser.districts.length > 0)
      ? reqUser.districts
      : [reqUser.districtId];
    if (!userDistricts.includes('all')) {
      const allowedClean = userDistricts.map(clean);
      result = result.filter(r => {
        const dId = clean(r.district_id);
        const dName = clean(r.district_name);
        const city = clean(r.city);
        return allowedClean.some(ud => ud === dId || ud === dName || ud === city || dId.includes(ud) || dName.includes(ud) || city.includes(ud));
      });
    }
  }

  if (district && district !== 'all') {
    const dClean = clean(district);
    result = result.filter(r => {
      const dId = clean(r.district_id);
      const dName = clean(r.district_name);
      const city = clean(r.city);
      return dId === dClean || dName === dClean || city === dClean ||
             dId.includes(dClean) || dName.includes(dClean) || city.includes(dClean);
    });
  }

  if (site && site !== 'all') {
    const sLower = site.toLowerCase().trim();
    result = result.filter(r => {
      const hay = [
        r.city,
        r.district_name,
        r.major_daily_activity,
        r.ipnv_offline_reason,
        r.dee_offline_reason,
        r.rma_details,
        r.ofc_cut
      ].filter(Boolean).join(' ').toLowerCase();
      return hay.includes(sLower);
    });
  }

  if (date) {
    const targetDate = normalizeReportDateStr(date);
    result = result.filter(r => normalizeReportDateStr(r.report_date) === targetDate);
  }

  const normFrom = normalizeReportDateStr(fromDate);
  const normTo = normalizeReportDateStr(toDate);

  if (normFrom) {
    result = result.filter(r => normalizeReportDateStr(r.report_date) >= normFrom);
  }
  if (normTo) {
    result = result.filter(r => normalizeReportDateStr(r.report_date) <= normTo);
  }

  if (status && status !== 'all') {
    const stUpper = status.toUpperCase();
    if (stUpper === 'COMPLIANT') {
      result = result.filter(r => (parseFloat(r.uptime_percent) || 0) >= 95.0);
    } else if (stUpper === 'AT_RISK' || stUpper === 'AT RISK') {
      result = result.filter(r => {
        const u = parseFloat(r.uptime_percent) || 0;
        return u >= 90.0 && u < 95.0;
      });
    } else if (stUpper === 'BREACH') {
      result = result.filter(r => (parseFloat(r.uptime_percent) || 0) < 90.0);
    } else {
      result = result.filter(r => {
        const curStatus = (r.status || '').toUpperCase();
        if (stUpper === 'SUBMITTED' && (curStatus === 'SUBMITTED' || curStatus === 'PENDING')) return true;
        return curStatus === stUpper;
      });
    }
  }

  if (query.siteType && query.siteType !== 'all') {
    const st = query.siteType.toUpperCase();
    if (st === 'IPNV') result = result.filter(r => Number(r.ipnv_installed) > 0);
    else if (st === 'CEE') result = result.filter(r => Number(r.cee_installed) > 0);
    else if (st === 'DEE') result = result.filter(r => Number(r.dee_installed) > 0);
    else if (st === 'PS') result = result.filter(r => Number(r.ps_installed) > 0);
    else if (st === 'DC') result = result.filter(r => Number(r.dc_installed) > 0);
    else if (st === 'FRNV') result = result.filter(r => Number(r.frnv_installed) > 0);
    else if (st === 'MCR' || st === 'DR' || st === 'MCR/DR') result = result.filter(r => Number(r.mcr_dr_installed) > 0);
  }

  if (search) {
    const sLower = search.toLowerCase().trim();
    result = result.filter(r => {
      const hay = [
        r.id,
        r.district_name,
        r.city,
        r.user_name,
        r.email,
        r.report_date,
        r.major_daily_activity,
        r.ipnv_offline_reason,
        r.dee_offline_reason,
        r.rma_details,
        r.ofc_cut,
        r.admin_remarks
      ].filter(Boolean).join(' ').toLowerCase();
      return hay.includes(sLower);
    });
  }

  result.sort((a, b) => new Date(b.report_date) - new Date(a.report_date));
  return result;
}

function mapReportToExportRow(r) {
  const ipnvInst = Number(r.ipnv_installed) || 0;
  const ipnvOn = Number(r.ipnv_online) || 0;
  const ipnvPct = ipnvInst > 0 ? ((ipnvOn / ipnvInst) * 100).toFixed(1) + '%' : '0.0%';

  const ceeInst = Number(r.cee_installed) || 0;
  const ceeOn = Number(r.cee_online) || 0;
  const ceePct = ceeInst > 0 ? ((ceeOn / ceeInst) * 100).toFixed(1) + '%' : '0.0%';

  const deeInst = Number(r.dee_installed) || 0;
  const deeOn = Number(r.dee_online) || 0;
  const deePct = deeInst > 0 ? ((deeOn / deeInst) * 100).toFixed(1) + '%' : '0.0%';

  let uptimePct = r.uptime_percent;
  if (!uptimePct) {
    const totInst = (Number(r.total_cameras_installed) || (ipnvInst + ceeInst + deeInst));
    const totOn = (Number(r.total_cameras_online) || (ipnvOn + ceeOn + deeOn));
    uptimePct = totInst > 0 ? ((totOn / totInst) * 100).toFixed(1) : '0.0';
  }
  if (!String(uptimePct).endsWith('%')) uptimePct = uptimePct + '%';

  return {
    'Report ID': r.id || '',
    'Date': r.report_date || '',
    'District': r.district_name || r.city || '',
    'City': r.city || '',
    'Engineer / Officer': r.user_name || (r.email ? r.email.split('@')[0] : 'Officer'),
    'Email': r.email || '',
    'Status': r.status || 'SUBMITTED',
    'Submitted At': r.submitted_at || '',
    'Total Cameras Installed': r.total_cameras_installed || (ipnvInst + ceeInst + deeInst),
    'Total Cameras Online': r.total_cameras_online || (ipnvOn + ceeOn + deeOn),
    'Camera Health %': uptimePct,
    'IPNV Installed': ipnvInst,
    'IPNV Online': ipnvOn,
    'IPNV %': ipnvPct,
    'CEE Installed': ceeInst,
    'CEE Online': ceeOn,
    'CEE %': ceePct,
    'DEE Installed': deeInst,
    'DEE Online': deeOn,
    'DEE %': deePct,
    'PS Installed': Number(r.ps_installed) || 0,
    'PS Online': Number(r.ps_online) || 0,
    'DC Installed': Number(r.dc_installed) || 0,
    'DC Online': Number(r.dc_online) || 0,
    'FRNV Installed': Number(r.frnv_installed) || 0,
    'FRNV Online': Number(r.frnv_online) || 0,
    'MCR/DR Installed': Number(r.mcr_dr_installed) || 0,
    'MCR/DR Online': Number(r.mcr_dr_online) || 0,
    'WiFi AP Installed': Number(r.wifi_installed) || 0,
    'WiFi AP Online': Number(r.wifi_online) || 0,
    'Panic Installed': Number(r.panic_installed) || 0,
    'Panic Online': Number(r.panic_online) || 0,
    'Environmental Online': Number(r.environmental_online) || 0,
    'Biometric Online': Number(r.biometric_online) || 0,
    'OFC Cut': r.ofc_cut || 'No',
    'OFC Location / Details': [r.ofc_location, r.ofc_type, r.ofc_details].filter(Boolean).join(' | ') || '',
    'Generator Runtime (Hours)': Number(r.generator_runtime) || 0,
    'Major Daily Activity': r.major_daily_activity || '',
    'IPNV/CEE Offline Reason': r.ipnv_offline_reason || '',
    'DEE Offline Reason': r.dee_offline_reason || '',
    'RMA Details': r.rma_details || '',
    'Other Issues': r.other_issues || '',
    'PMU Admin Remarks': r.admin_remarks || ''
  };
}

// ============================================================
// 24-HOUR DAILY REPORTING CYCLE & STATUS ENGINE
// ============================================================

function parseReportTimestamp(val) {
  if (!val) return null;
  if (typeof val === 'string') {
    const s = val.trim();
    const m = s.match(/^(\d{4})-(\d{2})-(\d{2})[ T](\d{2}):(\d{2})(?::(\d{2}))?/);
    if (m) {
      return new Date(parseInt(m[1], 10), parseInt(m[2], 10) - 1, parseInt(m[3], 10), parseInt(m[4], 10), parseInt(m[5], 10), m[6] ? parseInt(m[6], 10) : 0);
    }
    const d = new Date(s);
    if (!isNaN(d.getTime())) return d;
  } else if (val instanceof Date && !isNaN(val.getTime())) {
    return val;
  }
  return null;
}

function formatCycleDateString(d) {
  const y = d.getFullYear();
  const m = String(d.getMonth() + 1).padStart(2, '0');
  const day = String(d.getDate()).padStart(2, '0');
  return `${y}-${m}-${day}`;
}

function formatCycleDisplayLabel(cycleStart, cycleEnd) {
  const months = ['Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun', 'Jul', 'Aug', 'Sep', 'Oct', 'Nov', 'Dec'];
  const d1 = String(cycleStart.getDate()).padStart(2, '0');
  const m1 = months[cycleStart.getMonth()];
  const d2 = String(cycleEnd.getDate()).padStart(2, '0');
  const m2 = months[cycleEnd.getMonth()];
  return `${d1} ${m1} 12:00 AM → ${d2} ${m2} 12:00 AM`;
}

function calculateDailyReportingCycleStatus({ reports, users, dateStr, districtFilter, reqUser }) {
  const excludedDistricts = ['lahore', 'rawalpindi', 'faisalabad', 'kasur', 'gujranwala', 'nankana', 'nankana_sahib'];

  // 1. Establish 24-Hour Cycle Boundaries
  let cycleStart;
  let cycleEnd;
  let cycleDateStr;

  if (dateStr && /^\d{4}-\d{2}-\d{2}$/.test(dateStr.trim())) {
    const [y, m, d] = dateStr.trim().split('-').map(Number);
    cycleStart = new Date(y, m - 1, d, 0, 0, 0, 0);
    cycleEnd = new Date(y, m - 1, d + 1, 0, 0, 0, 0);
    cycleDateStr = dateStr.trim();
  } else {
    // Current live cycle as of now
    const now = new Date();
    const y = now.getFullYear();
    const m = now.getMonth();
    const d = now.getDate();
    cycleStart = new Date(y, m, d, 0, 0, 0, 0);
    cycleEnd = new Date(y, m, d + 1, 0, 0, 0, 0);
    cycleDateStr = formatCycleDateString(cycleStart);
  }

  const startMs = cycleStart.getTime();
  const endMs = cycleEnd.getTime();
  const cycleLabel = formatCycleDisplayLabel(cycleStart, cycleEnd);

  // 2. Identify Expected Active Users
  let expectedUsers = users.filter(u => {
    if (u.active === false) return false;
    if (u.deleted === true || u.status === 'DELETED' || u.status === 'INACTIVE') return false;

    // Reporting district workforce: DISTRICT_USER or DISTRICT_ADMIN or user with assigned districtId
    const isDistrictReporting = u.role === 'DISTRICT_USER' || u.role === 'DISTRICT_ADMIN' || (u.districtId && u.districtId !== 'all');
    if (!isDistrictReporting) return false;

    const uDist = (u.districtId || '').toLowerCase().replace(/[^a-z0-9]/g, '_');
    if (excludedDistricts.includes(uDist)) return false;

    return true;
  });

  // Role-based scoping: District users only see their own district
  if (reqUser && !['SUPER_ADMIN', 'ADMIN', 'FINANCE_ADMIN', 'PTCL_ADMIN', 'READ_ONLY_ADMIN'].includes(reqUser.role)) {
    const userDist = normDistrict(reqUser.districtId);
    expectedUsers = expectedUsers.filter(u => normDistrict(u.districtId) === userDist);
  } else if (districtFilter && districtFilter !== 'all') {
    const target = normDistrict(districtFilter);
    expectedUsers = expectedUsers.filter(u => {
      const dId = normDistrict(u.districtId);
      const dName = normDistrict(u.districtName);
      const dList = Array.isArray(u.districts) ? u.districts.map(normDistrict) : [];
      return dId === target || dName === target || dList.includes(target);
    });
  }

  // 3. Filter Reports Submitted within this 24-hour cycle window
  const cleanReports = reports.filter(r => !excludedDistricts.includes((r.district_id || '').toLowerCase()));
  const cycleReports = cleanReports.filter(r => {
    const t = parseReportTimestamp(r.submitted_at || r.timestamp || r.report_date);
    if (!t) return false;
    const ms = t.getTime();

    // Within standard 24h window (12:00 AM -> 12:00 AM midnight)
    if (ms >= startMs && ms <= endMs) return true;

    // Grace window for submissions near midnight (within 15 mins after midnight with report_date matching cycleDateStr)
    if (r.report_date === cycleDateStr && ms > endMs && ms <= endMs + 15 * 60 * 1000) return true;

    return false;
  });

  // 4. Map Expected Users to Received / Pending (One-Report-Per-User Rule)
  const userStatuses = [];
  const receivedReports = [];
  let receivedCount = 0;
  let pendingCount = 0;

  expectedUsers.forEach(u => {
    const uDist = normDistrict(u.districtId || u.districtName);
    const userCycleReports = cycleReports.filter(r => {
      if (r.user_id && r.user_id === u.id) return true;
      const rDist = normDistrict(r.district_id);
      const rName = normDistrict(r.district_name);
      const rCity = normDistrict(r.city);
      return rDist === uDist || rName === uDist || rCity === uDist;
    });

    if (userCycleReports.length > 0) {
      // Sort newest first to pick the latest report submitted in this cycle
      userCycleReports.sort((a, b) => {
        const ta = parseReportTimestamp(a.submitted_at || a.timestamp || a.report_date) || 0;
        const tb = parseReportTimestamp(b.submitted_at || b.timestamp || b.report_date) || 0;
        return tb - ta;
      });
      const rep = userCycleReports[0];
      receivedCount++;
      receivedReports.push(rep);
      userStatuses.push({
        userId: u.id,
        username: u.username,
        name: u.name,
        districtId: u.districtId,
        districtName: u.districtName || u.name,
        status: 'RECEIVED',
        reportId: rep.id,
        submittedAt: rep.submitted_at || rep.timestamp || rep.report_date,
        uptime: rep.uptime_percent || '98.5',
        report: rep
      });
    } else {
      pendingCount++;
      userStatuses.push({
        userId: u.id,
        username: u.username,
        name: u.name,
        districtId: u.districtId,
        districtName: u.districtName || u.name,
        status: 'PENDING',
        reportId: null,
        submittedAt: null,
        uptime: null,
        report: null
      });
    }
  });

  const totalExpected = expectedUsers.length;
  const complianceRate = totalExpected > 0 ? parseFloat(((receivedCount / totalExpected) * 100).toFixed(1)) : 0;

  return {
    cycle: {
      date: cycleDateStr,
      cycleStart: cycleStart.toISOString(),
      cycleEnd: cycleEnd.toISOString(),
      deadline: '12:00 AM (Midnight)',
      label: cycleLabel
    },
    summary: {
      totalExpected,
      received: receivedCount,
      pending: pendingCount,
      complianceRate
    },
    users: userStatuses,
    receivedReports
  };
}

app.get('/api/reports/daily-status', (req, res) => {
  const reqUser = getReqUser(req);
  if (reqUser && !userHasPermission(reqUser, 'view')) {
    return res.status(403).json({ success: false, error: 'Permission denied: view permission required.' });
  }

  const reports = loadJSON('reports.json');
  const users = loadJSON('users.json');
  const queryDate = req.query.date || '';
  const queryDistrict = req.query.district || '';

  const status = calculateDailyReportingCycleStatus({
    reports,
    users,
    dateStr: queryDate,
    districtFilter: queryDistrict,
    reqUser
  });

  res.json({ success: true, ...status });
});

app.get('/api/reports', (req, res) => {
  const reqUser = getReqUser(req);
  if (reqUser && !userHasPermission(reqUser, 'view')) {
    return res.status(403).json({ success: false, error: 'Permission denied: view permission required.' });
  }
  let reports = loadJSON('reports.json');
  reports = filterReportsList(reports, req.query, reqUser);
  const excluded = ['lahore', 'rawalpindi', 'faisalabad', 'kasur', 'gujranwala', 'nankana', 'nankana_sahib'];
  reports = reports.filter(r => !excluded.includes((r.district_id || '').toLowerCase()));
  reports.sort((a, b) => (b.report_date || '').localeCompare(a.report_date || ''));
  const limitParam = req.query.limit;
  if (limitParam && limitParam !== 'all' && limitParam !== '0') {
    const parsedLimit = parseInt(limitParam, 10);
    if (!isNaN(parsedLimit) && parsedLimit > 0) {
      reports = reports.slice(0, parsedLimit);
    }
  }
  res.json(reports);
});

// Export Filtered Reports (Excel .xlsx / CSV)
app.get('/api/reports/export', (req, res) => {
  const reqUser = getReqUser(req);
  if (reqUser && !userHasPermission(reqUser, 'export')) {
    return res.status(403).json({ success: false, error: 'Permission denied: export permission required.' });
  }
  const { format = 'xlsx' } = req.query;
  let reports = loadJSON('reports.json');
  reports = filterReportsList(reports, req.query, reqUser);

  const rows = reports.map(mapReportToExportRow);

  if (format === 'csv') {
    const headers = rows.length > 0 ? Object.keys(rows[0]) : [
      'Report ID', 'Date', 'District', 'City', 'Engineer / Officer', 'Status', 'Submitted At', 'Uptime %'
    ];
    const escapeCsv = val => {
      if (val == null) return '""';
      const str = String(val).replace(/"/g, '""');
      return `"${str}"`;
    };
    const csvContent = '\uFEFF' + [
      headers.join(','),
      ...rows.map(r => headers.map(h => escapeCsv(r[h])).join(','))
    ].join('\r\n');

    res.setHeader('Content-Disposition', 'attachment; filename="All_District_Sites_Report_Export.csv"');
    res.setHeader('Content-Type', 'text/csv; charset=utf-8');
    return res.send(csvContent);
  } else {
    try {
      const XLSX = require('xlsx');
      const wb = XLSX.utils.book_new();
      const ws = XLSX.utils.json_to_sheet(rows.length > 0 ? rows : [{
        'Report ID': '', 'Date': '', 'District': '', 'City': '', 'Status': '', 'Message': 'No matching records found'
      }]);
      XLSX.utils.book_append_sheet(wb, ws, 'District Reports');
      const buffer = XLSX.write(wb, { type: 'buffer', bookType: 'xlsx' });
      res.setHeader('Content-Disposition', 'attachment; filename="All_District_Sites_Report_Export.xlsx"');
      res.setHeader('Content-Type', 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet');
      return res.send(buffer);
    } catch (err) {
      console.error('Reports XLSX export error:', err);
      res.status(500).json({ error: 'Failed to generate Excel file.' });
    }
  }
});

app.post('/api/reports', denyReadOnly, requirePermission('create'), (req, res) => {
  const reqUser = getReqUser(req);
  const targetDist = req.body.district_id || req.body.district_name || req.body.city;
  if (reqUser && targetDist && !userHasDistrictAccess(reqUser, targetDist)) {
    return res.status(403).json({
      success: false,
      error: `Unauthorized district access. You are only permitted to submit reports for your assigned district(s).`
    });
  }
  const reports = loadJSON('reports.json');
  const newReport = {
    id: `rep_${Date.now()}`,
    submitted_at: new Date().toISOString(),
    status: 'PENDING',
    ...req.body
  };
  reports.push(newReport);
  saveJSON('reports.json', reports);
  res.json({ success: true, report: newReport });
});

app.put('/api/reports/:id', denyReadOnly, requirePermission('edit'), (req, res) => {
  const reports = loadJSON('reports.json');
  const idx = reports.findIndex(r => r.id === req.params.id);
  if (idx === -1) return res.status(404).json({ error: 'Report not found' });
  const reqUser = getReqUser(req);
  const curReport = reports[idx];
  const targetDist = curReport.district_id || curReport.district_name || curReport.city;
  if (reqUser && targetDist && !userHasDistrictAccess(reqUser, targetDist)) {
    return res.status(403).json({
      success: false,
      error: 'Unauthorized district access: This report belongs to another district.'
    });
  }
  reports[idx] = { ...reports[idx], ...req.body };
  saveJSON('reports.json', reports);
  res.json({ success: true, report: reports[idx] });
});

// --- TICKETS ---
app.get('/api/tickets', (req, res) => {
  const reqUser = getReqUser(req);
  if (reqUser && !userHasPermission(reqUser, 'view')) {
    return res.status(403).json({ success: false, error: 'Permission denied: view permission required.' });
  }
  const { district, status, priority, limit } = req.query;
  let tickets = loadJSON('tickets.json');
  const clean = s => String(s || '').toLowerCase().replace(/[^a-z0-9]/g, '');

  if (reqUser && !['SUPER_ADMIN', 'ADMIN', 'FINANCE_ADMIN', 'PTCL_ADMIN'].includes(reqUser.role)) {
    const userDistricts = (reqUser.districts && Array.isArray(reqUser.districts) && reqUser.districts.length > 0)
      ? reqUser.districts
      : [reqUser.districtId];
    if (!userDistricts.includes('all')) {
      const allowedClean = userDistricts.map(clean);
      tickets = tickets.filter(t => {
        const dId = clean(t.district_id);
        const city = clean(t.city);
        return allowedClean.some(ud => ud === dId || ud === city || dId.includes(ud) || city.includes(ud));
      });
    }
  }

  if (district && district !== 'all') {
    const dClean = clean(district);
    tickets = tickets.filter(t => clean(t.district_id) === dClean || clean(t.city) === dClean || clean(t.city).includes(dClean));
  }
  if (status && status !== 'all') tickets = tickets.filter(t => t.currentStatus === status || t.unifiedStatus === status);
  if (priority && priority !== 'all') tickets = tickets.filter(t => t.priority === priority);
  tickets.sort((a, b) => new Date(b.dateCreated) - new Date(a.dateCreated));
  if (limit) tickets = tickets.slice(0, parseInt(limit));
  res.json(tickets);
});

app.post('/api/tickets', denyReadOnly, requirePermission('create'), (req, res) => {
  const reqUser = getReqUser(req);
  const targetDist = req.body.district_id || req.body.city;
  if (reqUser && targetDist && !userHasDistrictAccess(reqUser, targetDist)) {
    return res.status(403).json({
      success: false,
      error: 'Unauthorized district access: You are only permitted to create tickets for your assigned district(s).'
    });
  }
  const tickets = loadJSON('tickets.json');
  const newTicket = {
    id: `tkt_${Date.now()}`,
    dateCreated: new Date().toISOString().split('T')[0],
    currentStatus: 'Open',
    unifiedStatus: 'Open',
    ticketNumber: `TKT-${Date.now()}`,
    ...req.body
  };
  tickets.push(newTicket);
  saveJSON('tickets.json', tickets);
  res.json({ success: true, ticket: newTicket });
});

app.put('/api/tickets/:id', denyReadOnly, requirePermission('update'), (req, res) => {
  const tickets = loadJSON('tickets.json');
  const idx = tickets.findIndex(t => t.id === req.params.id || t.ticketNumber === req.params.id);
  if (idx === -1) return res.status(404).json({ error: 'Ticket not found' });
  const reqUser = getReqUser(req);
  const curTicket = tickets[idx];
  const targetDist = curTicket.district_id || curTicket.city;
  if (reqUser && targetDist && !userHasDistrictAccess(reqUser, targetDist)) {
    return res.status(403).json({
      success: false,
      error: 'Unauthorized district access: This ticket belongs to another district.'
    });
  }
  tickets[idx] = { ...tickets[idx], ...req.body };
  saveJSON('tickets.json', tickets);
  res.json({ success: true, ticket: tickets[idx] });
});

// --- USERS MANAGEMENT (Admin Authority) ---
app.get('/api/users', (req, res) => {
  const reqUser = getReqUser(req);
  if (reqUser && !userHasPermission(reqUser, 'view')) {
    return res.status(403).json({ success: false, error: 'Permission denied: view permission required.' });
  }
  const users = loadJSON('users.json').map(u => {
    const { password: _, ...safe } = u;
    return safe;
  });
  res.json(users);
});

app.post('/api/users', denyReadOnly, requirePermission('create'), (req, res) => {
  const reqUser = getReqUser(req);
  if (reqUser && reqUser.role !== 'ADMIN' && reqUser.role !== 'SUPER_ADMIN') {
    return res.status(403).json({ success: false, error: 'Only Administrators can create portal users.' });
  }

  const users = loadJSON('users.json');
  const username = (req.body.username || '').toLowerCase().trim();
  if (!username) return res.status(400).json({ success: false, error: 'Username is required.' });

  const exists = users.find(u => u.username.toLowerCase() === username);
  if (exists) return res.status(409).json({ success: false, error: 'Username already exists.' });

  if (req.body.email) {
    const emailExists = users.find(u => u.email && u.email.toLowerCase() === req.body.email.toLowerCase().trim());
    if (emailExists) return res.status(409).json({ success: false, error: 'A user with this email address already exists.' });
  }

  const role = req.body.role || 'DISTRICT_USER';
  let accessLevel = req.body.accessLevel;
  if (!accessLevel) {
    if (role === 'SUPER_ADMIN') accessLevel = 'Super Admin / Full Admin';
    else if (role === 'ADMIN') accessLevel = 'All Punjab Admin';
    else if (role === 'READ_ONLY_ADMIN') accessLevel = 'Read Only';
    else if (role === 'FINANCE_ADMIN') accessLevel = 'Finance Admin';
    else if (role === 'PTCL_ADMIN') accessLevel = 'PTCL Admin';
    else if (role === 'USER') accessLevel = 'User';
    else accessLevel = 'District Admin';
  }

  let districts = req.body.districts;
  if (!Array.isArray(districts) || districts.length === 0) {
    districts = (['ADMIN', 'SUPER_ADMIN', 'FINANCE_ADMIN', 'PTCL_ADMIN'].includes(role) || req.body.districtId === 'all')
      ? ['all']
      : (req.body.districtId ? [req.body.districtId] : ['chakwal']);
  }

  let permissions = req.body.permissions;
  if (!Array.isArray(permissions) || permissions.length === 0) {
    if (role === 'READ_ONLY_ADMIN') {
      permissions = ['view', 'export'];
    } else if (['ADMIN', 'SUPER_ADMIN'].includes(role)) {
      permissions = ['view', 'create', 'edit', 'update', 'delete', 'approve', 'close', 'acknowledge', 'export', 'import'];
    } else if (role === 'FINANCE_ADMIN') {
      permissions = ['view', 'create', 'edit', 'update', 'approve', 'export'];
    } else if (role === 'PTCL_ADMIN') {
      permissions = ['view', 'update', 'export'];
    } else {
      permissions = ['view', 'create', 'edit', 'update', 'close', 'acknowledge', 'export'];
    }
  }

  const primaryDistrict = districts.includes('all') ? 'all' : districts[0];
  const primaryDistrictName = req.body.districtName || (districts.includes('all') ? 'All 37 Districts (Provincial Access)' : districts.join(', '));

  const newUser = {
    id: `usr_${Date.now()}`,
    name: req.body.name || username,
    username: username,
    password: req.body.password || 'password123',
    role: role,
    accessLevel: accessLevel,
    districtId: primaryDistrict,
    districtName: primaryDistrictName,
    districts: districts,
    permissions: permissions,
    designation: req.body.designation || (role === 'ADMIN' ? 'Command Lead' : (role === 'FINANCE_ADMIN' ? 'Accounts Lead' : 'District Admin')),
    email: req.body.email || '',
    employeeId: req.body.employeeId || `NRTC-ENG-${Math.floor(1000 + Math.random() * 9000)}`,
    active: req.body.active !== false,
    createdAt: new Date().toISOString()
  };

  users.push(newUser);
  saveJSON('users.json', users);
  const { password: _, ...safeUser } = newUser;
  res.status(201).json({ success: true, user: safeUser });
});

app.put('/api/users/:id', denyReadOnly, requirePermission('edit'), (req, res) => {
  const reqUser = getReqUser(req);
  if (reqUser && reqUser.role !== 'ADMIN' && reqUser.role !== 'SUPER_ADMIN') {
    return res.status(403).json({ success: false, error: 'Only Administrators can update user accounts.' });
  }

  const users = loadJSON('users.json');
  const idx = users.findIndex(u => u.id === req.params.id || u.username === req.params.id);
  if (idx === -1) return res.status(404).json({ success: false, error: 'User not found.' });

  const isPrimaryAdmin = users[idx].id === 'usr_admin' || users[idx].username === 'admin';
  if (isPrimaryAdmin) {
    if (req.body.active === false) {
      return res.status(400).json({ success: false, error: 'Cannot deactivate the primary PMU Administrator account.' });
    }
    if (req.body.role && req.body.role !== 'ADMIN' && req.body.role !== 'SUPER_ADMIN') {
      return res.status(400).json({ success: false, error: 'Cannot remove administrative role from primary Administrator.' });
    }
  }

  const u = users[idx];
  const updated = { ...u, ...req.body };

  if (req.body.password && String(req.body.password).trim()) {
    updated.password = String(req.body.password).trim();
  }

  if (req.body.districts && Array.isArray(req.body.districts)) {
    updated.districts = req.body.districts;
    if (req.body.districts.includes('all')) {
      updated.districtId = 'all';
      updated.districtName = 'All 37 Districts (Provincial Access)';
    } else if (req.body.districts.length > 0) {
      updated.districtId = req.body.districts[0];
    }
  }

  if (req.body.permissions && Array.isArray(req.body.permissions)) {
    updated.permissions = req.body.permissions;
  }

  if (req.body.active !== undefined) {
    updated.active = req.body.active !== false;
  }

  users[idx] = updated;
  saveJSON('users.json', users);
  const { password: _, ...safe } = updated;
  res.json({ success: true, user: safe, message: 'User updated successfully. Changes take effect immediately / at next login.' });
});

app.put('/api/users/:id/status', denyReadOnly, requirePermission('edit'), (req, res) => {
  const reqUser = getReqUser(req);
  if (reqUser && reqUser.role !== 'ADMIN' && reqUser.role !== 'SUPER_ADMIN') {
    return res.status(403).json({ success: false, error: 'Only Administrators can change user activation status.' });
  }

  const users = loadJSON('users.json');
  const idx = users.findIndex(u => u.id === req.params.id || u.username === req.params.id);
  if (idx === -1) return res.status(404).json({ success: false, error: 'User not found.' });

  if ((users[idx].id === 'usr_admin' || users[idx].username === 'admin') && req.body.active === false) {
    return res.status(400).json({ success: false, error: 'Cannot deactivate the primary PMU Administrator account.' });
  }

  const newStatus = req.body.active === true;
  users[idx].active = newStatus;
  saveJSON('users.json', users);
  const { password: _, ...safe } = users[idx];
  res.json({ success: true, user: safe, message: `User status changed to ${newStatus ? 'Active' : 'Inactive'}.` });
});

app.put('/api/users/:id/password', denyReadOnly, requirePermission('edit'), (req, res) => {
  const reqUser = getReqUser(req);
  if (reqUser && reqUser.role !== 'ADMIN' && reqUser.role !== 'SUPER_ADMIN') {
    return res.status(403).json({ success: false, error: 'Only Administrators can reset user credentials.' });
  }

  const users = loadJSON('users.json');
  const idx = users.findIndex(u => u.id === req.params.id || u.username === req.params.id);
  if (idx === -1) return res.status(404).json({ success: false, error: 'User not found.' });

  if (!req.body.password || !String(req.body.password).trim()) {
    return res.status(400).json({ success: false, error: 'New password is required.' });
  }

  users[idx].password = String(req.body.password).trim();
  saveJSON('users.json', users);
  res.json({ success: true, message: 'Password updated successfully. The user must sign in using this new password.' });
});

app.delete('/api/users/:id', denyReadOnly, requirePermission('delete'), (req, res) => {
  const reqUser = getReqUser(req);
  if (reqUser && reqUser.role !== 'ADMIN' && reqUser.role !== 'SUPER_ADMIN') {
    return res.status(403).json({ success: false, error: 'Only Administrators can delete user accounts.' });
  }

  let users = loadJSON('users.json');
  const idx = users.findIndex(u => u.id === req.params.id);
  if (idx === -1) return res.status(404).json({ error: 'User not found' });
  if (users[idx].id === 'usr_admin' || users[idx].username === 'admin') {
    return res.status(400).json({ error: 'Cannot delete the primary PMU Administrator account.' });
  }
  if (users[idx].role === 'ADMIN' && users.filter(u => u.role === 'ADMIN').length <= 1) {
    return res.status(400).json({ error: 'Cannot delete the only admin user.' });
  }
  users.splice(idx, 1);
  saveJSON('users.json', users);
  res.json({ success: true, message: 'User account removed permanently.' });
});

// --- ATTENDANCE ---
app.get('/api/attendance', (req, res) => {
  const { district, date } = req.query;
  let records = loadJSON('attendance.json');
  if (district && district !== 'all') records = records.filter(r => r.district_id === district);
  if (date) records = records.filter(r => r.date === date);
  records.sort((a, b) => new Date(b.created_at) - new Date(a.created_at));
  res.json(records);
});

app.post('/api/attendance', denyReadOnly, (req, res) => {
  const records = loadJSON('attendance.json');
  const newRecord = {
    id: `att_${Date.now()}`,
    created_at: new Date().toISOString(),
    ...req.body
  };
  records.push(newRecord);
  saveJSON('attendance.json', records);
  res.json({ success: true, record: newRecord });
});

// --- FINANCES & PAYMENTS ENGINE ---
function normalizeFinanceRecord(r) {
  const amount = Number(r.amount) || 0;
  const payments = Array.isArray(r.payments) ? r.payments : [];
  const paidAmount = payments.reduce((sum, p) => sum + (Number(p.amount) || 0), 0);
  const remainingBalance = Math.max(0, amount - paidAmount);
  
  let paymentStatus = 'NOT_PAID';
  if (paidAmount > 0 && paidAmount < amount) {
    paymentStatus = 'PARTIALLY_PAID';
  } else if (paidAmount >= amount && amount > 0) {
    paymentStatus = 'FULLY_PAID';
  }

  let status = r.status || 'PENDING_APPROVAL';
  if (paymentStatus === 'FULLY_PAID' && status === 'APPROVED') {
    status = 'PAID';
  }

  return {
    ...r,
    id: r.id || `fin_${Date.now()}`,
    amount,
    paidAmount,
    remainingBalance,
    paymentStatus,
    status,
    payments,
    userId: r.userId || r.user_id || `usr_${(r.districtId || r.district_id || 'site').toLowerCase()}`,
    userName: r.userName || r.user_name || 'Site Engineer',
    districtId: (r.districtId || r.district_id || 'chakwal').toLowerCase(),
    districtName: r.districtName || r.district_name || 'District',
    month: r.month || (r.expenseDate ? r.expenseDate.substring(0, 7) : new Date().toISOString().substring(0, 7)),
    year: r.year || (r.expenseDate ? r.expenseDate.substring(0, 4) : '2026'),
    expenseDate: r.expenseDate || (r.created_at ? r.created_at.substring(0, 10) : new Date().toISOString().substring(0, 10)),
    category: r.category || 'PETTY_CASH',
    title: r.title || r.description || 'Operational Expense',
    description: r.description || r.title || '',
    vendorName: r.vendorName || 'General Supplier',
    invoiceNumber: r.invoiceNumber || 'INV-000',
    paymentMethod: r.paymentMethod || 'CASH',
    billUrl: r.billUrl || r.receiptUrl || '',
    created_at: r.created_at || r.createdAt || new Date().toISOString()
  };
}

// 1. Get All / Filtered Expenses
app.get(['/api/finances', '/api/expenses'], (req, res) => {
  const { district, month, year, status, category, userId, search } = req.query;
  let records = loadJSON('finances.json').map(normalizeFinanceRecord);

  if (userId) {
    records = records.filter(r => String(r.userId).toLowerCase() === String(userId).toLowerCase());
  }
  if (district && district !== 'all') {
    records = records.filter(r => r.districtId === district.toLowerCase() || (r.district_id && r.district_id === district.toLowerCase()));
  }
  if (month && month !== 'all') {
    records = records.filter(r => String(r.month) === String(month) || (r.expenseDate && r.expenseDate.includes(month)));
  }
  if (year && year !== 'all') {
    records = records.filter(r => String(r.year) === String(year) || (r.expenseDate && r.expenseDate.startsWith(String(year))));
  }
  if (status && status !== 'all') {
    records = records.filter(r => r.status === status || r.paymentStatus === status);
  }
  if (category && category !== 'all') {
    records = records.filter(r => r.category === category.toUpperCase());
  }
  if (search) {
    const q = search.toLowerCase();
    records = records.filter(r => 
      (r.title && r.title.toLowerCase().includes(q)) ||
      (r.description && r.description.toLowerCase().includes(q)) ||
      (r.vendorName && r.vendorName.toLowerCase().includes(q)) ||
      (r.invoiceNumber && r.invoiceNumber.toLowerCase().includes(q)) ||
      (r.userName && r.userName.toLowerCase().includes(q)) ||
      (r.districtName && r.districtName.toLowerCase().includes(q))
    );
  }

  records.sort((a, b) => new Date(b.created_at || b.expenseDate) - new Date(a.created_at || a.expenseDate));
  res.json(records);
});

// 2. Submit New Expense
app.post(['/api/finances', '/api/expenses'], denyReadOnly, (req, res) => {
  const records = loadJSON('finances.json');
  const amount = Number(req.body.amount) || 0;
  if (amount <= 0) {
    return res.status(400).json({ success: false, error: 'Expense amount must be greater than zero.' });
  }

  const newRecord = normalizeFinanceRecord({
    id: `fin_${Date.now()}_${Math.floor(Math.random() * 1000)}`,
    ...req.body,
    amount,
    paidAmount: 0,
    remainingBalance: amount,
    paymentStatus: 'NOT_PAID',
    payments: [],
    status: 'PENDING_APPROVAL',
    created_at: new Date().toISOString()
  });

  records.unshift(newRecord);
  saveJSON('finances.json', records);
  res.json({ success: true, record: newRecord });
});

// 2b. Finances Summary / KPIs (must be before :id to prevent route clash)
app.get('/api/finances/summary', (req, res) => {
  const { district, userId } = req.query;
  let records = loadJSON('finances.json').map(normalizeFinanceRecord);

  if (userId) {
    records = records.filter(r => String(r.userId).toLowerCase() === String(userId).toLowerCase());
  } else if (district && district !== 'all') {
    records = records.filter(r => r.districtId === district.toLowerCase());
  }

  const queries = loadJSON('finance_queries.json');
  let filteredQueries = queries;
  if (userId) {
    filteredQueries = queries.filter(q => String(q.userId).toLowerCase() === String(userId).toLowerCase());
  } else if (district && district !== 'all') {
    filteredQueries = queries.filter(q => (q.districtId || '').toLowerCase() === district.toLowerCase());
  }
  const pendingQueries = filteredQueries.filter(q => q.status === 'Pending' || q.status === 'Under Review').length;

  const totalExpense = records.reduce((s, r) => s + (r.amount || 0), 0);
  const totalPaid = records.reduce((s, r) => s + (r.paidAmount || 0), 0);
  const totalOutstanding = Math.max(0, totalExpense - totalPaid);

  res.json({
    totalExpense,
    totalPaid,
    totalOutstanding,
    pendingQueries,
    totalRecords: records.length,
    fullyPaidCount: records.filter(r => r.paymentStatus === 'FULLY_PAID').length,
    partiallyPaidCount: records.filter(r => r.paymentStatus === 'PARTIALLY_PAID').length,
    notPaidCount: records.filter(r => r.paymentStatus === 'NOT_PAID').length,
    pendingApprovalCount: records.filter(r => r.status === 'PENDING_APPROVAL').length,
    approvedCount: records.filter(r => r.status === 'APPROVED' || r.status === 'PAID').length,
    rejectedCount: records.filter(r => r.status === 'REJECTED').length
  });
});

// 3. Get Single Expense
app.get('/api/finances/:id', (req, res) => {
  const records = loadJSON('finances.json');
  const raw = records.find(r => r.id === req.params.id);
  if (!raw) return res.status(404).json({ success: false, error: 'Expense record not found.' });
  res.json(normalizeFinanceRecord(raw));
});

// 4. Record Payment (Restricted to Finance Admin / Super Admin)
app.post('/api/finances/:id/payments', (req, res) => {
  const userRole = (req.body.userRole || req.headers['x-user-role'] || '').toUpperCase();
  if (userRole && userRole !== 'FINANCE_ADMIN' && userRole !== 'SUPER_ADMIN' && userRole !== 'ADMIN') {
    return res.status(403).json({ success: false, error: 'Forbidden: Only Finance Admin can record disbursements and payments.' });
  }

  const paymentAmount = Number(req.body.amount);
  if (!paymentAmount || paymentAmount <= 0) {
    return res.status(400).json({ success: false, error: 'Payment amount must be greater than zero.' });
  }

  const records = loadJSON('finances.json');
  const idx = records.findIndex(r => r.id === req.params.id);
  if (idx === -1) {
    return res.status(404).json({ success: false, error: 'Expense record not found.' });
  }

  const exp = normalizeFinanceRecord(records[idx]);
  const payment = {
    id: `pay_${Date.now()}_${Math.floor(Math.random() * 1000)}`,
    amount: paymentAmount,
    paymentDate: req.body.paymentDate || new Date().toISOString().split('T')[0],
    reference: req.body.reference || 'N/A',
    remarks: req.body.remarks || 'Disbursement recorded',
    proofUrl: req.body.proofUrl || '',
    enteredBy: req.body.enteredBy || 'Finance Admin',
    enteredAt: new Date().toISOString()
  };

  exp.payments.push(payment);
  const updated = normalizeFinanceRecord(exp);
  records[idx] = updated;
  saveJSON('finances.json', records);

  res.json({ success: true, record: updated, payment });
});

// 5. Update Expense Status (PMU / Finance Approval / Rejection)
app.put('/api/finances/:id/status', (req, res) => {
  const records = loadJSON('finances.json');
  const idx = records.findIndex(r => r.id === req.params.id);
  if (idx === -1) return res.status(404).json({ success: false, error: 'Expense record not found.' });

  const { newStatus, remarks, reviewedBy } = req.body;
  records[idx].status = newStatus || records[idx].status;
  records[idx].pmuRemarks = remarks || records[idx].pmuRemarks;
  records[idx].reviewedBy = reviewedBy || 'NRTC PMU Admin';
  records[idx].reviewedAt = new Date().toISOString();

  const updated = normalizeFinanceRecord(records[idx]);
  records[idx] = updated;
  saveJSON('finances.json', records);
  res.json({ success: true, record: updated });
});


// 7. Finance Queries (User Inquiries & PMU Resolution)
app.get('/api/finance-queries', (req, res) => {
  const { userId, district, status } = req.query;
  let queries = loadJSON('finance_queries.json');

  if (userId) {
    queries = queries.filter(q => String(q.userId).toLowerCase() === String(userId).toLowerCase());
  }
  if (district && district !== 'all') {
    queries = queries.filter(q => (q.districtId || '').toLowerCase() === district.toLowerCase());
  }
  if (status && status !== 'all') {
    queries = queries.filter(q => q.status.toLowerCase() === status.toLowerCase());
  }

  queries.sort((a, b) => new Date(b.createdAt) - new Date(a.createdAt));
  res.json(queries);
});

app.post('/api/finance-queries', denyReadOnly, (req, res) => {
  const queries = loadJSON('finance_queries.json');
  if (!req.body.subject || !req.body.message) {
    return res.status(400).json({ success: false, error: 'Subject and detailed message are required.' });
  }

  const newQuery = {
    id: `fq_${Date.now()}_${Math.floor(Math.random() * 1000)}`,
    userId: req.body.userId || 'usr_site',
    userName: req.body.userName || 'Site Engineer',
    districtId: (req.body.districtId || 'chakwal').toLowerCase(),
    districtName: req.body.districtName || 'District',
    subject: req.body.subject,
    category: req.body.category || 'General Inquiry',
    message: req.body.message,
    attachmentUrl: req.body.attachmentUrl || '',
    status: 'Pending',
    response: '',
    respondedBy: '',
    respondedAt: null,
    createdAt: new Date().toISOString()
  };

  queries.unshift(newQuery);
  saveJSON('finance_queries.json', queries);
  res.json({ success: true, query: newQuery });
});

app.put('/api/finance-queries/:id', denyReadOnly, (req, res) => {
  const queries = loadJSON('finance_queries.json');
  const idx = queries.findIndex(q => q.id === req.params.id);
  if (idx === -1) return res.status(404).json({ success: false, error: 'Query not found.' });

  const { status, response, respondedBy } = req.body;
  if (status) queries[idx].status = status;
  if (response !== undefined) queries[idx].response = response;
  queries[idx].respondedBy = respondedBy || 'Finance Admin';
  queries[idx].respondedAt = new Date().toISOString();

  saveJSON('finance_queries.json', queries);
  res.json({ success: true, query: queries[idx] });
});

// ============================================================
// PTCL TICKET MANAGEMENT MODULE
// ============================================================

function formatResolutionDuration(ms) {
  if (ms == null || isNaN(ms)) return '—';
  const totalSeconds = Math.floor(ms / 1000);
  const days = Math.floor(totalSeconds / 86400);
  const hours = Math.floor((totalSeconds % 86400) / 3600);
  const minutes = Math.floor((totalSeconds % 3600) / 60);

  const parts = [];
  if (days > 0) parts.push(`${days}d`);
  if (hours > 0 || days > 0) parts.push(`${hours}h`);
  parts.push(`${minutes}m`);
  return parts.join(' ');
}

// 1. Get PTCL Tickets with Date Range and Faceted Filters
app.get('/api/ptcl-tickets', (req, res) => {
  const { userId, district, site, status, priority, fromDate, toDate, search } = req.query;
  let tickets = loadJSON('ptcl_tickets.json');

  if (userId) {
    tickets = tickets.filter(t => String(t.userId).toLowerCase() === String(userId).toLowerCase());
  }

  if (district && district !== 'all') {
    const dLower = district.toLowerCase();
    tickets = tickets.filter(t => 
      (t.districtId || '').toLowerCase() === dLower || 
      (t.districtName || '').toLowerCase() === dLower
    );
  }

  if (site && site !== 'all') {
    const sLower = site.toLowerCase();
    tickets = tickets.filter(t => 
      (t.siteId || '').toLowerCase() === sLower || 
      (t.siteName || '').toLowerCase().includes(sLower)
    );
  }

  if (status && status !== 'all') {
    const stLower = status.toLowerCase();
    tickets = tickets.filter(t => (t.status || '').toLowerCase() === stLower);
  }

  if (priority && priority !== 'all') {
    const pLower = priority.toLowerCase();
    tickets = tickets.filter(t => (t.priority || '').toLowerCase() === pLower);
  }

  // Date/Time range filtering (From Date/Time -> To Date/Time)
  if (fromDate) {
    const fromTime = new Date(fromDate).getTime();
    if (!isNaN(fromTime)) {
      tickets = tickets.filter(t => new Date(t.createdAt).getTime() >= fromTime);
    }
  }

  if (toDate) {
    const toTime = new Date(toDate).getTime();
    if (!isNaN(toTime)) {
      tickets = tickets.filter(t => new Date(t.createdAt).getTime() <= toTime);
    }
  }

  if (search) {
    const q = search.toLowerCase();
    tickets = tickets.filter(t => 
      (t.ticketId || '').toLowerCase().includes(q) ||
      (t.siteId || '').toLowerCase().includes(q) ||
      (t.siteName || '').toLowerCase().includes(q) ||
      (t.issue || '').toLowerCase().includes(q) ||
      (t.description || '').toLowerCase().includes(q) ||
      (t.userName || '').toLowerCase().includes(q) ||
      (t.districtName || '').toLowerCase().includes(q)
    );
  }

  // Sort newest first
  tickets.sort((a, b) => new Date(b.createdAt) - new Date(a.createdAt));
  res.json(tickets);
});

// 2. Get PTCL Ticket Summary KPIs
app.get('/api/ptcl-tickets/summary', (req, res) => {
  const { userId, district } = req.query;
  let tickets = loadJSON('ptcl_tickets.json');

  if (userId) {
    tickets = tickets.filter(t => String(t.userId).toLowerCase() === String(userId).toLowerCase());
  }
  if (district && district !== 'all') {
    const dLower = district.toLowerCase();
    tickets = tickets.filter(t => 
      (t.districtId || '').toLowerCase() === dLower || 
      (t.districtName || '').toLowerCase() === dLower
    );
  }

  const total = tickets.length;
  const open = tickets.filter(t => t.status === 'Open').length;
  const inProgress = tickets.filter(t => t.status === 'In Progress').length;
  const resolved = tickets.filter(t => t.status === 'Resolved').length;
  const closedTickets = tickets.filter(t => t.status === 'Closed');
  const closed = closedTickets.length;

  let avgResolutionTimeStr = 'N/A';
  let avgResolutionTimeMs = 0;
  const validClosedDurations = closedTickets
    .map(t => t.resolutionTimeMs)
    .filter(ms => typeof ms === 'number' && !isNaN(ms) && ms >= 0);

  if (validClosedDurations.length > 0) {
    const sumMs = validClosedDurations.reduce((a, b) => a + b, 0);
    avgResolutionTimeMs = Math.round(sumMs / validClosedDurations.length);
    avgResolutionTimeStr = formatResolutionDuration(avgResolutionTimeMs);
  }

  res.json({
    totalTickets: total,
    open,
    inProgress,
    resolved,
    closed,
    avgResolutionTime: avgResolutionTimeStr,
    avgResolutionTimeMs
  });
});

// 3. Create PTCL Ticket (Only DISTRICT_USER or SUPER_ADMIN)
app.post('/api/ptcl-tickets', denyReadOnly, (req, res) => {
  const userRole = req.body.userRole || '';
  if (userRole === 'ADMIN' || userRole === 'PTCL_ADMIN') {
    return res.status(403).json({ success: false, error: 'Only district field users can create PTCL tickets.' });
  }

  const { 
    districtId, districtName, 
    siteId, siteName, sites, siteIds, siteNames,
    issue, issues, category,
    description, priority, attachmentUrl, attachmentName 
  } = req.body;

  // Process selected DEE sites (one or multiple)
  let normalizedSites = [];
  if (Array.isArray(sites) && sites.length > 0) {
    normalizedSites = sites.map(s => {
      if (typeof s === 'string') return { siteId: s, siteName: s };
      return { 
        siteId: s.siteId || s.spotId || s.id || '', 
        siteName: s.siteName || s.name || s.siteId || '' 
      };
    });
  } else if (Array.isArray(siteIds) && siteIds.length > 0) {
    normalizedSites = siteIds.map((sid, i) => ({
      siteId: sid,
      siteName: (Array.isArray(siteNames) && siteNames[i]) || sid
    }));
  } else if (siteId) {
    normalizedSites = [{ siteId, siteName: siteName || siteId }];
  }

  // Process selected issues (one or multiple)
  let normalizedIssues = [];
  if (Array.isArray(issues) && issues.length > 0) {
    normalizedIssues = issues.map(iss => String(iss).trim()).filter(Boolean);
  } else if (issue) {
    normalizedIssues = String(issue).split(',').map(iss => iss.trim()).filter(Boolean);
  }

  if (normalizedSites.length === 0) {
    return res.status(400).json({ success: false, error: 'At least one site (DEE or MCR) must be selected.' });
  }
  if (normalizedIssues.length === 0) {
    return res.status(400).json({ success: false, error: 'At least one issue option must be selected.' });
  }
  if (!description) {
    return res.status(400).json({ success: false, error: 'Description is required.' });
  }

  const primarySiteId = normalizedSites.map(s => s.siteId).join(', ');
  const primarySiteName = normalizedSites.map(s => s.siteName).join(', ');
  const primaryIssue = normalizedIssues.join(', ');

  const tickets = loadJSON('ptcl_tickets.json');
  const now = new Date();
  const year = now.getFullYear();
  const nextNum = tickets.length + 1;
  const ticketId = `PTCL-${year}-${String(nextNum).padStart(4, '0')}`;
  const nowIso = now.toISOString();

  const newTicket = {
    id: ticketId,
    ticketId: ticketId,
    userId: req.body.userId || 'usr_district',
    userName: req.body.userName || 'District User',
    userRole: req.body.userRole || 'DISTRICT_USER',
    districtId: (districtId || req.body.districtId || '').toLowerCase(),
    districtName: districtName || 'District',
    sites: normalizedSites,
    siteIds: normalizedSites.map(s => s.siteId),
    siteNames: normalizedSites.map(s => s.siteName),
    siteId: primarySiteId,
    siteName: primarySiteName,
    issues: normalizedIssues,
    issue: primaryIssue,
    category: category || primaryIssue,
    priority: priority || 'Medium',
    description: description,
    attachmentUrl: attachmentUrl || '',
    attachmentName: attachmentName || '',
    status: 'Open',
    createdAt: nowIso,
    resolvedAt: null,
    acknowledgedAt: null,
    closedAt: null,
    resolutionTimeMs: null,
    resolutionTimeStr: null,
    ptclRemarks: '',
    history: [
      {
        action: 'Ticket Created',
        status: 'Open',
        performedBy: req.body.userName || 'District User',
        userRole: req.body.userRole || 'DISTRICT_USER',
        userId: req.body.userId || '',
        remarks: `Complaint logged for ${normalizedSites.length} site(s) (${primarySiteId}) with issues: ${primaryIssue}`,
        timestamp: nowIso
      }
    ]
  };

  tickets.unshift(newTicket);
  saveJSON('ptcl_tickets.json', tickets);
  res.status(201).json({ success: true, ticket: newTicket });
});

// 4. Update Ticket Status / Progress & Remarks (PTCL Admin & Super Admin only)
app.put('/api/ptcl-tickets/:id/status', (req, res) => {
  const { newStatus, remarks, userName, userRole, userId } = req.body;
  if (userRole !== 'PTCL_ADMIN' && userRole !== 'SUPER_ADMIN') {
    return res.status(403).json({ success: false, error: 'Only PTCL Admin can update ticket progress/remarks.' });
  }

  // PTCL Admin cannot close or acknowledge ticket (reserved for creator user)
  if (newStatus === 'Closed' && userRole !== 'SUPER_ADMIN') {
    return res.status(403).json({ success: false, error: 'Only the user who created the ticket can acknowledge and close it.' });
  }

  const tickets = loadJSON('ptcl_tickets.json');
  const idx = tickets.findIndex(t => t.id === req.params.id || t.ticketId === req.params.id);
  if (idx === -1) return res.status(404).json({ success: false, error: 'PTCL Ticket not found.' });

  const ticket = tickets[idx];
  const nowIso = new Date().toISOString();

  if (newStatus) {
    ticket.status = newStatus;
    if (newStatus === 'Resolved') {
      ticket.resolvedAt = nowIso;
    }
  }

  if (remarks) {
    ticket.ptclRemarks = remarks;
  }

  if (!ticket.history) ticket.history = [];
  ticket.history.push({
    action: newStatus === 'Resolved' ? 'Ticket Resolved' : 'Status Updated',
    status: ticket.status,
    performedBy: userName || 'PTCL NOC Admin',
    userRole: userRole || 'PTCL_ADMIN',
    userId: userId || '',
    remarks: remarks || `Status updated to ${ticket.status}`,
    timestamp: nowIso
  });

  tickets[idx] = ticket;
  saveJSON('ptcl_tickets.json', tickets);
  res.json({ success: true, ticket });
});

// 5. User Acknowledgement & Closure (Only User who created the ticket, or Super Admin)
app.put('/api/ptcl-tickets/:id/acknowledge', (req, res) => {
  const { userId, userName, userRole, remarks } = req.body;
  const tickets = loadJSON('ptcl_tickets.json');
  const idx = tickets.findIndex(t => t.id === req.params.id || t.ticketId === req.params.id);
  if (idx === -1) return res.status(404).json({ success: false, error: 'PTCL Ticket not found.' });

  const ticket = tickets[idx];

  // Security check: Only the user who created the ticket can acknowledge and close it
  if (userRole !== 'SUPER_ADMIN') {
    if (!userId || String(ticket.userId).toLowerCase() !== String(userId).toLowerCase()) {
      return res.status(403).json({ success: false, error: 'Unauthorized: Only the user who created this ticket can acknowledge and close it.' });
    }
  }

  if (ticket.status === 'Closed') {
    return res.status(400).json({ success: false, error: 'Ticket is already closed.' });
  }

  const nowIso = new Date().toISOString();
  ticket.status = 'Closed';
  ticket.acknowledgedAt = nowIso;
  ticket.closedAt = nowIso;

  // Auto calculate Resolution Time = Closed Date/Time - Created Date/Time
  const startMs = new Date(ticket.createdAt).getTime();
  const endMs = new Date(nowIso).getTime();
  const diffMs = Math.max(0, endMs - startMs);
  ticket.resolutionTimeMs = diffMs;
  ticket.resolutionTimeStr = formatResolutionDuration(diffMs);

  if (!ticket.history) ticket.history = [];
  ticket.history.push({
    action: 'User Acknowledged & Closed',
    status: 'Closed',
    performedBy: userName || 'District User',
    userRole: userRole || 'DISTRICT_USER',
    userId: userId || ticket.userId,
    remarks: remarks || `User confirmed link resolution on DEE site(s) and closed ticket. Total resolution time: ${ticket.resolutionTimeStr}`,
    timestamp: nowIso
  });

  tickets[idx] = ticket;
  saveJSON('ptcl_tickets.json', tickets);
  res.json({ success: true, ticket });
});

// 6. Close Ticket (Direct close by creator or Super Admin)
app.put('/api/ptcl-tickets/:id/close', (req, res) => {
  const { userId, userName, userRole, remarks } = req.body;
  const tickets = loadJSON('ptcl_tickets.json');
  const idx = tickets.findIndex(t => t.id === req.params.id || t.ticketId === req.params.id);
  if (idx === -1) return res.status(404).json({ success: false, error: 'PTCL Ticket not found.' });

  const ticket = tickets[idx];

  // Security check: Only the user who created the ticket can close it
  if (userRole !== 'SUPER_ADMIN') {
    if (!userId || String(ticket.userId).toLowerCase() !== String(userId).toLowerCase()) {
      return res.status(403).json({ success: false, error: 'Unauthorized: Only the user who created this ticket can close it.' });
    }
  }

  if (ticket.status === 'Closed') {
    return res.status(400).json({ success: false, error: 'Ticket is already closed.' });
  }

  const nowIso = new Date().toISOString();
  ticket.status = 'Closed';
  if (!ticket.acknowledgedAt) ticket.acknowledgedAt = nowIso;
  ticket.closedAt = nowIso;

  // Auto calculate Resolution Time
  const startMs = new Date(ticket.createdAt).getTime();
  const endMs = new Date(nowIso).getTime();
  const diffMs = Math.max(0, endMs - startMs);
  ticket.resolutionTimeMs = diffMs;
  ticket.resolutionTimeStr = formatResolutionDuration(diffMs);

  if (!ticket.history) ticket.history = [];
  ticket.history.push({
    action: 'Ticket Closed',
    status: 'Closed',
    performedBy: userName || 'District User',
    userRole: userRole || 'DISTRICT_USER',
    userId: userId || ticket.userId,
    remarks: remarks || `Ticket closed by creator. Total resolution time: ${ticket.resolutionTimeStr}`,
    timestamp: nowIso
  });

  tickets[idx] = ticket;
  saveJSON('ptcl_tickets.json', tickets);
  res.json({ success: true, ticket });
});

// 6. Export Filtered Records (Excel .xlsx / CSV)
app.get('/api/ptcl-tickets/export', (req, res) => {
  const { userId, district, site, status, priority, fromDate, toDate, search, format } = req.query;
  let tickets = loadJSON('ptcl_tickets.json');

  if (userId) {
    tickets = tickets.filter(t => String(t.userId).toLowerCase() === String(userId).toLowerCase());
  }
  if (district && district !== 'all') {
    const dLower = district.toLowerCase();
    tickets = tickets.filter(t => 
      (t.districtId || '').toLowerCase() === dLower || 
      (t.districtName || '').toLowerCase() === dLower
    );
  }
  if (site && site !== 'all') {
    const sLower = site.toLowerCase();
    tickets = tickets.filter(t => 
      (t.siteId || '').toLowerCase() === sLower || 
      (t.siteName || '').toLowerCase().includes(sLower)
    );
  }
  if (status && status !== 'all') {
    const stLower = status.toLowerCase();
    tickets = tickets.filter(t => (t.status || '').toLowerCase() === stLower);
  }
  if (priority && priority !== 'all') {
    const pLower = priority.toLowerCase();
    tickets = tickets.filter(t => (t.priority || '').toLowerCase() === pLower);
  }
  if (fromDate) {
    const fromTime = new Date(fromDate).getTime();
    if (!isNaN(fromTime)) {
      tickets = tickets.filter(t => new Date(t.createdAt).getTime() >= fromTime);
    }
  }
  if (toDate) {
    const toTime = new Date(toDate).getTime();
    if (!isNaN(toTime)) {
      tickets = tickets.filter(t => new Date(t.createdAt).getTime() <= toTime);
    }
  }
  if (search) {
    const q = search.toLowerCase();
    tickets = tickets.filter(t => 
      (t.ticketId || '').toLowerCase().includes(q) ||
      (t.siteId || '').toLowerCase().includes(q) ||
      (t.siteName || '').toLowerCase().includes(q) ||
      (t.issue || '').toLowerCase().includes(q) ||
      (t.description || '').toLowerCase().includes(q) ||
      (t.userName || '').toLowerCase().includes(q) ||
      (t.districtName || '').toLowerCase().includes(q)
    );
  }

  tickets.sort((a, b) => new Date(b.createdAt) - new Date(a.createdAt));

  // Required columns:
  // Ticket ID | User | District | Site | Issue | Priority | Created Date/Time | Status | Resolved Date/Time | Acknowledged Date/Time | Closed Date/Time | Resolution Time | Remarks
  const rows = tickets.map(t => ({
    'Ticket ID': t.ticketId || t.id,
    'User': t.userName || 'N/A',
    'District': t.districtName || 'N/A',
    'Site': (t.sites && t.sites.length > 0) ? t.sites.map(s => `${s.siteId} (${s.siteName})`).join('; ') : `${t.siteId || ''} ${t.siteName ? '- ' + t.siteName : ''}`.trim(),
    'Issue': t.issue || '',
    'Priority': t.priority || 'Medium',
    'Created Date/Time': t.createdAt ? new Date(t.createdAt).toLocaleString('en-PK', { timeZone: 'Asia/Karachi' }) : '—',
    'Status': t.status || 'Open',
    'Resolved Date/Time': t.resolvedAt ? new Date(t.resolvedAt).toLocaleString('en-PK', { timeZone: 'Asia/Karachi' }) : '—',
    'Acknowledged Date/Time': t.acknowledgedAt ? new Date(t.acknowledgedAt).toLocaleString('en-PK', { timeZone: 'Asia/Karachi' }) : '—',
    'Closed Date/Time': t.closedAt ? new Date(t.closedAt).toLocaleString('en-PK', { timeZone: 'Asia/Karachi' }) : '—',
    'Resolution Time': t.resolutionTimeStr || '—',
    'Remarks': t.ptclRemarks || ''
  }));

  const isCsv = (format || '').toLowerCase() === 'csv';

  if (isCsv) {
    const headers = [
      'Ticket ID', 'User', 'District', 'Site', 'Issue', 'Priority',
      'Created Date/Time', 'Status', 'Resolved Date/Time', 'Acknowledged Date/Time', 'Closed Date/Time',
      'Resolution Time', 'Remarks'
    ];
    const escapeCsv = val => {
      if (val == null) return '""';
      const str = String(val).replace(/"/g, '""');
      return `"${str}"`;
    };
    const csvContent = [
      headers.join(','),
      ...rows.map(r => headers.map(h => escapeCsv(r[h])).join(','))
    ].join('\r\n');

    res.setHeader('Content-Disposition', 'attachment; filename="PTCL_Tickets_Export.csv"');
    res.setHeader('Content-Type', 'text/csv; charset=utf-8');
    return res.send(csvContent);
  } else {
    try {
      const XLSX = require('xlsx');
      const wb = XLSX.utils.book_new();
      const ws = XLSX.utils.json_to_sheet(rows.length > 0 ? rows : [{
        'Ticket ID': '', 'User': '', 'District': '', 'Site': '', 'Issue': '', 'Priority': '',
        'Created Date/Time': '', 'Status': '', 'Resolved Date/Time': '', 'Closed Date/Time': '',
        'Resolution Time': '', 'Remarks': ''
      }]);
      XLSX.utils.book_append_sheet(wb, ws, 'PTCL Tickets');
      const buffer = XLSX.write(wb, { type: 'buffer', bookType: 'xlsx' });
      res.setHeader('Content-Disposition', 'attachment; filename="PTCL_Tickets_Export.xlsx"');
      res.setHeader('Content-Type', 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet');
      return res.send(buffer);
    } catch (err) {
      console.error('XLSX export error:', err);
      res.status(500).json({ error: 'Failed to generate Excel file.' });
    }
  }
});


// --- FILE UPLOAD ---
app.post('/api/upload/:type', upload.single('file'), (req, res) => {
  if (!req.file) return res.status(400).json({ error: 'No file uploaded.' });
  const fileUrl = `/uploads/${req.params.type}/${req.file.filename}`;
  res.json({ success: true, url: fileUrl, filename: req.file.filename });
});

// --- ANALYTICS SUMMARY ---
app.get('/api/analytics/summary', (req, res) => {
  const reports = loadJSON('reports.json');
  const tickets = loadJSON('tickets.json');
  const employees = loadJSON('employees.json');
  const sites = loadJSON('sites.json');

  // Last 30 days reports for average SLA calculation (strictly percentage-based out of 100%)
  const thirtyDaysAgo = new Date();
  thirtyDaysAgo.setDate(thirtyDaysAgo.getDate() - 30);
  const thirtyDaysAgoStr = thirtyDaysAgo.toISOString().split('T')[0];

  const recentReports = reports.filter(r => (r.report_date || '') >= thirtyDaysAgoStr);
  const reportsToCompute = recentReports.length > 0 ? recentReports : reports;
  const validReports = reportsToCompute.filter(r => r.uptime_percent !== undefined && r.uptime_percent !== null && !isNaN(parseFloat(r.uptime_percent)));
  const sumUptime = validReports.reduce((s, r) => s + Math.min(100, Math.max(0, parseFloat(r.uptime_percent))), 0);
  const overallOnlineRate = validReports.length > 0 ? parseFloat((sumUptime / validReports.length).toFixed(1)) : 0;

  const openTickets = tickets.filter(t => t.currentStatus === 'Open' || t.unifiedStatus === 'Open');
  const closedTickets = tickets.filter(t => t.currentStatus === 'Resolved' || t.currentStatus === 'Closed');
  const highPriorityTickets = openTickets.filter(t => t.priority === 'High' || t.priority === 'Urgent');

  res.json({
    totalDistricts: [...new Set(sites.map(s => s.city))].length,
    totalSites: sites.length,
    totalEmployees: employees.filter(e => e.status === 'ACTIVE').length,
    totalReports: reports.length,
    recentReports: recentReports.length,
    totalTickets: tickets.length,
    openTickets: openTickets.length,
    closedTickets: closedTickets.length,
    highPriorityTickets: highPriorityTickets.length,
    overallOnlineRate: overallOnlineRate
  });
});

// --- SLA SUMMARY API (Strictly percentage-based across valid submitted reports) ---
const OFFICIAL_37_DISTRICTS = [
  'Attock', 'Bahawalnagar', 'Bahawalpur', 'Bhakkar', 'Chakwal', 'Chiniot', 'Dera Ghazi Khan',
  'Gujrat', 'Hafizabad', 'Jhang', 'Jhelum', 'Khanewal', 'Khushab', 'Layyah', 'Lodhran',
  'Mandi Bahauddin', 'Mianwali', 'Multan', 'Muzaffargarh', 'Narowal', 'Okara', 'Pakpattan',
  'Rahim Yar Khan', 'Rajanpur', 'Sahiwal', 'Sargodha', 'Sheikhupura', 'Sialkot',
  'Toba Tek Singh', 'Vehari', 'Wazirabad', 'Talagang', 'Murree', 'Kot Addu', 'Taunsa',
  'Hassan Abdal', 'Taxila'
];

app.get('/api/analytics/sla-summary', (req, res) => {
  let reports = loadJSON('reports.json');
  reports = filterReportsList(reports, req.query);

  const clean = s => String(s || '').toLowerCase().replace(/[^a-z0-9]/g, '');

  const districtSummaries = OFFICIAL_37_DISTRICTS.map(dName => {
    const dClean = clean(dName);
    const matched = reports.filter(r => clean(r.district_name) === dClean || clean(r.district_id) === dClean || clean(r.city) === dClean);

    if (matched.length > 0) {
      const sumSla = matched.reduce((acc, r) => acc + Math.min(100, Math.max(0, parseFloat(r.uptime_percent) || 0)), 0);
      const avgSla = parseFloat((sumSla / matched.length).toFixed(1));
      
      // Supporting latest report inventory
      const sorted = [...matched].sort((a, b) => new Date(b.report_date) - new Date(a.report_date));
      const latest = sorted[0];

      return {
        district: dName,
        reportsCount: matched.length,
        avgSla: avgSla,
        status: avgSla >= 95.0 ? 'COMPLIANT' : (avgSla >= 90.0 ? 'AT RISK' : 'BREACH'),
        latestReportDate: latest.report_date || '',
        installedCameras: Number(latest.total_cameras_installed) || 0,
        onlineCameras: Number(latest.total_cameras_online) || 0,
        hasData: true
      };
    } else {
      return {
        district: dName,
        reportsCount: 0,
        avgSla: null,
        status: 'NO DATA',
        latestReportDate: 'No Submissions',
        installedCameras: 0,
        onlineCameras: 0,
        hasData: false
      };
    }
  });

  const reportingDistricts = districtSummaries.filter(d => d.hasData);
  const provincialAvg = reportingDistricts.length > 0
    ? parseFloat((reportingDistricts.reduce((acc, d) => acc + d.avgSla, 0) / reportingDistricts.length).toFixed(1))
    : null;

  res.json({
    totalFilteredReports: reports.length,
    provincialAvgSla: provincialAvg,
    districts: districtSummaries
  });
});

app.get('/api/analytics/sla-export', (req, res) => {
  const { format = 'xlsx' } = req.query;
  let reports = loadJSON('reports.json');
  reports = filterReportsList(reports, req.query);

  const clean = s => String(s || '').toLowerCase().replace(/[^a-z0-9]/g, '');

  const districtRows = OFFICIAL_37_DISTRICTS.map((dName, idx) => {
    const dClean = clean(dName);
    const matched = reports.filter(r => clean(r.district_name) === dClean || clean(r.district_id) === dClean || clean(r.city) === dClean);

    if (matched.length > 0) {
      const sumSla = matched.reduce((acc, r) => acc + Math.min(100, Math.max(0, parseFloat(r.uptime_percent) || 0)), 0);
      const avgSla = parseFloat((sumSla / matched.length).toFixed(1));
      const sorted = [...matched].sort((a, b) => new Date(b.report_date) - new Date(a.report_date));
      const latest = sorted[0];

      return {
        'Sr #': idx + 1,
        'District': dName,
        'Submitted Reports': matched.length,
        'Average Camera SLA %': avgSla + '%',
        'SLA Benchmark': '>= 95.0%',
        'Compliance Status': avgSla >= 95.0 ? 'COMPLIANT' : (avgSla >= 90.0 ? 'AT RISK' : 'BREACH'),
        'Installed Cameras': Number(latest.total_cameras_installed) || 0,
        'Online Cameras': Number(latest.total_cameras_online) || 0,
        'Latest Report Date': latest.report_date || ''
      };
    } else {
      return {
        'Sr #': idx + 1,
        'District': dName,
        'Submitted Reports': 0,
        'Average Camera SLA %': 'N/A (No Data)',
        'SLA Benchmark': '>= 95.0%',
        'Compliance Status': 'NO DATA',
        'Installed Cameras': 0,
        'Online Cameras': 0,
        'Latest Report Date': 'No Submissions'
      };
    }
  });

  if (format === 'csv') {
    const headers = Object.keys(districtRows[0]);
    const escapeCsv = val => {
      if (val == null) return '""';
      const str = String(val).replace(/"/g, '""');
      return `"${str}"`;
    };
    const csvContent = '\uFEFF' + [
      headers.join(','),
      ...districtRows.map(r => headers.map(h => escapeCsv(r[h])).join(','))
    ].join('\r\n');

    res.setHeader('Content-Disposition', 'attachment; filename="Camera_SLA_Performance_37_Districts.csv"');
    res.setHeader('Content-Type', 'text/csv; charset=utf-8');
    return res.send(csvContent);
  } else {
    try {
      const XLSX = require('xlsx');
      const wb = XLSX.utils.book_new();
      const wsDist = XLSX.utils.json_to_sheet(districtRows);
      XLSX.utils.book_append_sheet(wb, wsDist, 'District SLA Performance');

      const buffer = XLSX.write(wb, { type: 'buffer', bookType: 'xlsx' });
      res.setHeader('Content-Disposition', 'attachment; filename="Camera_SLA_Performance_37_Districts.xlsx"');
      res.setHeader('Content-Type', 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet');
      return res.send(buffer);
    } catch (err) {
      console.error('SLA export error:', err);
      res.status(500).json({ error: 'Failed to generate Excel file.' });
    }
  }
});

// --- SERVE UPLOADED FILES ---
app.use('/uploads', express.static(path.join(__dirname, 'uploads')));

// --- DOWNLOAD CREDENTIALS EXCEL (admin only endpoint) ---
app.get('/api/download/credentials', (req, res) => {
  const xlsxPath = path.join(DATA_DIR, 'portal-credentials.xlsx');
  const csvPath = path.join(DATA_DIR, 'portal-credentials.csv');
  if (fs.existsSync(xlsxPath)) {
    res.download(xlsxPath, 'NRTC-Portal-Credentials.xlsx');
  } else if (fs.existsSync(csvPath)) {
    res.download(csvPath, 'NRTC-Portal-Credentials.csv');
  } else {
    res.status(404).json({ error: 'Credentials file not found. Run: node scripts/generate_credentials_xlsx.js' });
  }
});

// Regenerate credentials on demand
app.post('/api/admin/regenerate-credentials', (req, res) => {
  const { execSync } = require('child_process');
  try {
    execSync('node scripts/generate_credentials_xlsx.js', { cwd: __dirname });
    res.json({ success: true, message: 'Credentials file regenerated.' });
  } catch (e) {
    res.status(500).json({ error: e.message });
  }
});

// --- CATCH ALL: Serve index.html for SPA routes ---
app.get(['/', '/login', '/dashboard', '/admin-overview', '/employees', '/sites', '/tickets', '/finance', '/ptcl-tickets'], (req, res) => {
  const page = req.path.replace('/', '') || 'index';
  const filePath = path.join(__dirname, `${page}.html`);
  if (fs.existsSync(filePath)) {
    res.sendFile(filePath);
  } else {
    res.sendFile(path.join(__dirname, 'index.html'));
  }
});

// Start the server (standalone execution)
if (require.main === module) {
  const server = app.listen(PORT, () => {
    console.log(`\n====================================================`);
    console.log(`  Punjab Safe City Portal - NRTC O&M System`);
    console.log(`  Server running on: http://localhost:${PORT}`);
    console.log(`  Login: admin / password123`);
    console.log(`  Or by district name (e.g.: chakwal / password123)`);
    console.log(`====================================================\n`);
  });

  server.on('error', (err) => {
    if (err.code === 'EADDRINUSE') {
      console.warn(`\n[PORT IN USE] Port ${PORT} is already active. Existing portal server is serving requests at http://localhost:${PORT}\n`);
      process.exit(0);
    } else {
      console.error('Server error:', err);
      process.exit(1);
    }
  });
}

module.exports = app;
