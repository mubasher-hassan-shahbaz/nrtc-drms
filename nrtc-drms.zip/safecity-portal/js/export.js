/**
 * Punjab Safe City Authority - Export Module
 * Handles Excel / CSV data export and official Printable PDF generation.
 */

const SafeCityExport = {
  /**
   * Export array of daily reports to a CSV / Excel format.
   */
  exportToCSV(reports, customFilename) {
    if (!reports || reports.length === 0) {
      alert('No reports available to export.');
      return;
    }

    const headers = [
      'Report ID',
      'Date',
      'District Site',
      'Organization',
      'Client Authority',
      'NRTC Site Engineer',
      'NRTC Employee ID',
      'Status',
      'Submitted At',
      'IPNV Installed',
      'IPNV Online',
      'IPNV %',
      'CEE Installed',
      'CEE Online',
      'CEE %',
      'DEE Installed',
      'DEE Online',
      'DEE %',
      'PS Installed',
      'PS Online',
      'DC Installed',
      'DC Online',
      'FRNV Installed',
      'FRNV Online',
      'MCR/DR Installed',
      'MCR/DR Online',
      'WiFi AP Installed',
      'WiFi AP Online',
      'Panic Installed',
      'Panic Online',
      'Environmental Online',
      'Biometric Online',
      'Overall Camera %',
      'OFC Cut (Yes/No)',
      'OFC Location',
      'OFC Cut Type',
      'OFC Details',
      'Generator Runtime (Hours)',
      'Major Daily Activities',
      'Offline Reasons',
      'RMA Details',
      'Other Issues',
      'NRTC PMU Remarks',
      'Reviewed By',
      'Reviewed At'
    ];

    const rows = reports.map(r => {
      const ipnvPct = window.SafeCityStore ? window.SafeCityStore.calculatePercentage(r.ipnv_online, r.ipnv_installed) : '';
      const ceePct = window.SafeCityStore ? window.SafeCityStore.calculatePercentage(r.cee_online, r.cee_installed) : '';
      const deePct = window.SafeCityStore ? window.SafeCityStore.calculatePercentage(r.dee_online, r.dee_installed) : '';
      const overallPct = window.SafeCityStore ? window.SafeCityStore.getDistrictOverallUptime(r) : '';

      return [
        r.id || '',
        r.report_date || '',
        r.district_name || '',
        'NRTC',
        'Punjab Safe Cities Authority (PSCA)',
        r.user_name || 'NRTC Engineer',
        r.employee_id || 'NRTC-ENG-4182',
        r.status || 'SUBMITTED',
        r.submitted_at || '',
        r.ipnv_installed || 0,
        r.ipnv_online || 0,
        ipnvPct + '%',
        r.cee_installed || 0,
        r.cee_online || 0,
        ceePct + '%',
        r.dee_installed || 0,
        r.dee_online || 0,
        deePct + '%',
        r.ps_installed || 0,
        r.ps_online || 0,
        r.dc_installed || 0,
        r.dc_online || 0,
        r.frnv_installed || 0,
        r.frnv_online || 0,
        r.mcr_dr_installed || 0,
        r.mcr_dr_online || 0,
        r.wifi_installed || 0,
        r.wifi_online || 0,
        r.panic_installed || 0,
        r.panic_online || 0,
        r.environmental_online || 0,
        r.biometric_online || 0,
        overallPct + '%',
        r.ofc_cut || 'No',
        r.ofc_location || '',
        r.ofc_type || '',
        r.ofc_details || '',
        r.generator_runtime || 0,
        r.major_daily_activity || '',
        r.ipnv_offline_reason || '',
        r.rma_details || '',
        r.other_issues || '',
        r.admin_remarks || '',
        r.reviewed_by || '',
        r.reviewed_at || ''
      ].map(val => {
        const escaped = ('' + val).replace(/"/g, '""');
        return `"${escaped}"`;
      }).join(',');
    });

    const csvContent = '\uFEFF' + headers.join(',') + '\n' + rows.join('\n');
    const blob = new Blob([csvContent], { type: 'text/csv;charset=utf-8;' });
    const url = URL.createObjectURL(blob);
    const link = document.createElement('a');
    
    const today = new Date().toISOString().split('T')[0];
    link.setAttribute('href', url);
    link.setAttribute('download', customFilename || `NRTC_PSCA_Punjab_Daily_Reports_${today}.csv`);
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
  },

  /**
   * Generates a printable, formal Punjab Safe City Authority official report view.
   */
  printReport(report) {
    if (!report) return;

    const overallPct = window.SafeCityStore ? window.SafeCityStore.getDistrictOverallUptime(report) : 0;
    const ipnvPct = window.SafeCityStore ? window.SafeCityStore.calculatePercentage(report.ipnv_online, report.ipnv_installed) : 0;
    const ceePct = window.SafeCityStore ? window.SafeCityStore.calculatePercentage(report.cee_online, report.cee_installed) : 0;
    const deePct = window.SafeCityStore ? window.SafeCityStore.calculatePercentage(report.dee_online, report.dee_installed) : 0;
    const wifiPct = window.SafeCityStore ? window.SafeCityStore.calculatePercentage(report.wifi_online, report.wifi_installed) : 0;

    const printWindow = window.open('', '_blank');
    printWindow.document.write(`
      <!DOCTYPE html>
      <html>
      <head>
        <title>Safe City Daily Report - ${report.district_name} - ${report.report_date}</title>
        <style>
          body { font-family: 'Segoe UI', Arial, sans-serif; padding: 25px; color: #111; line-height: 1.4; }
          .header { text-align: center; border-bottom: 2px solid #0f3460; padding-bottom: 12px; margin-bottom: 20px; }
          .header h1 { margin: 0; font-size: 20pt; color: #0f3460; text-transform: uppercase; letter-spacing: 1px; }
          .header h2 { margin: 4px 0 0 0; font-size: 13pt; color: #444; font-weight: normal; }
          .meta-grid { display: grid; grid-template-columns: repeat(3, 1fr); gap: 10px; background: #f4f6f9; padding: 12px; border-radius: 6px; margin-bottom: 20px; font-size: 10pt; }
          .meta-item strong { display: block; color: #555; font-size: 8pt; text-transform: uppercase; }
          .section-title { font-size: 12pt; font-weight: bold; color: #0f3460; margin: 18px 0 8px 0; border-bottom: 1px solid #ddd; padding-bottom: 4px; }
          table { width: 100%; border-collapse: collapse; margin-bottom: 15px; font-size: 10pt; }
          th, td { border: 1px solid #cbd5e1; padding: 7px 10px; text-align: left; }
          th { background: #f1f5f9; font-weight: bold; }
          .badge { display: inline-block; padding: 2px 8px; border-radius: 99px; font-weight: bold; font-size: 9pt; }
          .badge-ok { background: #dcfce7; color: #166534; }
          .badge-warn { background: #fef9c3; color: #854d0e; }
          .badge-danger { background: #fee2e2; color: #991b1b; }
          .box { border: 1px solid #e2e8f0; padding: 10px; border-radius: 6px; background: #fafafa; margin-bottom: 12px; font-size: 9.5pt; }
          .signatures { display: flex; justify-content: space-between; margin-top: 50px; padding-top: 20px; }
          .sign-block { text-align: center; width: 260px; border-top: 1px solid #333; padding-top: 8px; font-size: 10pt; }
          @media print {
            button { display: none; }
          }
        </style>
      </head>
      <body>
        <div class="header">
          <div style="font-size:12pt; font-weight:bold; color:#1e3a8a; letter-spacing:1px; margin-bottom:4px;">NATIONAL RADIO & TELECOMMUNICATION CORPORATION (NRTC)</div>
          <h1>Safe City Daily Operations & SLA Report</h1>
          <h2>Punjab Safe Cities Authority (PSCA) Surveillance Infrastructure Project</h2>
        </div>

        <div class="meta-grid">
          <div class="meta-item"><strong>District Project Site</strong> ${report.district_name}</div>
          <div class="meta-item"><strong>Report Date</strong> ${report.report_date}</div>
          <div class="meta-item"><strong>Status</strong> <span class="badge ${report.status === 'APPROVED' ? 'badge-ok' : 'badge-warn'}">${report.status || 'SUBMITTED'}</span></div>
          <div class="meta-item"><strong>NRTC Site Engineer</strong> ${report.user_name || 'NRTC Engineer'}</div>
          <div class="meta-item"><strong>Executing Body / Client</strong> NRTC / PSCA Punjab</div>
          <div class="meta-item"><strong>Overall Camera Health</strong> <strong>${overallPct}%</strong></div>
        </div>

        <div class="section-title">1. Surveillance Cameras & Video Streams</div>
        <table>
          <thead>
            <tr>
              <th>Equipment Category</th>
              <th>Installed</th>
              <th>Online</th>
              <th>Offline</th>
              <th>Availability</th>
            </tr>
          </thead>
          <tbody>
            <tr>
              <td><strong>IPNV (IP Network Video)</strong></td>
              <td>${report.ipnv_installed}</td>
              <td>${report.ipnv_online}</td>
              <td>${report.ipnv_installed - report.ipnv_online}</td>
              <td><strong>${ipnvPct}%</strong></td>
            </tr>
            <tr>
              <td><strong>CEE (City Entrance / Exit)</strong></td>
              <td>${report.cee_installed}</td>
              <td>${report.cee_online}</td>
              <td>${report.cee_installed - report.cee_online}</td>
              <td><strong>${ceePct}%</strong></td>
            </tr>
            <tr>
              <td><strong>DEE (District Entrance / Exit)</strong></td>
              <td>${report.dee_installed}</td>
              <td>${report.dee_online}</td>
              <td>${report.dee_installed - report.dee_online}</td>
              <td><strong>${deePct}%</strong></td>
            </tr>
            <tr>
              <td><strong>Police Station (PS) Cameras</strong></td>
              <td>${report.ps_installed || 0}</td>
              <td>${report.ps_online || 0}</td>
              <td>${(report.ps_installed || 0) - (report.ps_online || 0)}</td>
              <td>${window.SafeCityStore.calculatePercentage(report.ps_online, report.ps_installed)}%</td>
            </tr>
            <tr>
              <td><strong>District Complex (DC) Cameras</strong></td>
              <td>${report.dc_installed || 0}</td>
              <td>${report.dc_online || 0}</td>
              <td>${(report.dc_installed || 0) - (report.dc_online || 0)}</td>
              <td>${window.SafeCityStore.calculatePercentage(report.dc_online, report.dc_installed)}%</td>
            </tr>
            <tr>
              <td><strong>FRNV (Facial Recognition Video)</strong></td>
              <td>${report.frnv_installed || 0}</td>
              <td>${report.frnv_online || 0}</td>
              <td>${(report.frnv_installed || 0) - (report.frnv_online || 0)}</td>
              <td>${window.SafeCityStore.calculatePercentage(report.frnv_online, report.frnv_installed)}%</td>
            </tr>
          </tbody>
        </table>

        <div class="section-title">2. Auxiliary Infrastructure & Field Systems</div>
        <table>
          <thead>
            <tr>
              <th>Component</th>
              <th>Installed</th>
              <th>Online / Operational</th>
              <th>Status</th>
            </tr>
          </thead>
          <tbody>
            <tr>
              <td>Public WiFi Access Points (APs)</td>
              <td>${report.wifi_installed || 0}</td>
              <td>${report.wifi_online || 0}</td>
              <td>${wifiPct}% Operational</td>
            </tr>
            <tr>
              <td>Emergency Panic Buttons</td>
              <td>${report.panic_installed || 0}</td>
              <td>${report.panic_online || 0}</td>
              <td>${window.SafeCityStore.calculatePercentage(report.panic_online, report.panic_installed)}% Functional</td>
            </tr>
            <tr>
              <td>Air Quality / Environmental Sensors</td>
              <td>${report.environmental_installed || 0}</td>
              <td>${report.environmental_online || 0}</td>
              <td>Active</td>
            </tr>
            <tr>
              <td>Biometric Attendance Units</td>
              <td>${report.biometric_installed || 0}</td>
              <td>${report.biometric_online || 0}</td>
              <td>Active</td>
            </tr>
            <tr>
              <td>Generator Backup Runtime</td>
              <td colspan="2"><strong>${report.generator_runtime || 0} Hours</strong> logged today</td>
              <td>Operational</td>
            </tr>
          </tbody>
        </table>

        <div class="section-title">3. Optical Fiber Cable (OFC) Status & Outages</div>
        <div class="box">
          <p><strong>OFC Cut Incident:</strong> ${report.ofc_cut === 'Yes' ? '<span class="badge badge-danger">YES - CUT REPORTED</span>' : '<span class="badge badge-ok">NO CUTS - RUNNING NORMAL</span>'}</p>
          ${report.ofc_cut === 'Yes' ? `
            <p><strong>Cut Location:</strong> ${report.ofc_location || 'N/A'}</p>
            <p><strong>Cut Type:</strong> ${report.ofc_type || 'N/A'}</p>
            <p><strong>Details & Restoration:</strong> ${report.ofc_details || 'N/A'}</p>
          ` : ''}
        </div>

        <div class="section-title">4. Offline Justifications & Fault Reasons</div>
        <div class="box">
          <p><strong>IPNV Offline Reason:</strong> ${report.ipnv_offline_reason || 'None reported.'}</p>
          <p><strong>CEE Offline Reason:</strong> ${report.cee_offline_reason || 'None reported.'}</p>
          <p><strong>RMA / Maintenance Details:</strong> ${report.rma_details || 'None pending.'}</p>
        </div>

        <div class="section-title">5. Major Daily Operations & Incidents</div>
        <div class="box">
          <p>${report.major_daily_activity || 'Routine continuous surveillance and municipal monitoring performed without incident.'}</p>
          ${report.other_issues ? `<p><strong>Other Issues:</strong> ${report.other_issues}</p>` : ''}
        </div>

        ${report.admin_remarks ? `
          <div class="section-title">6. NRTC Project Management Unit (PMU) Remarks</div>
          <div class="box" style="background:#eff6ff; border-color:#bfdbfe;">
            <p><strong>Reviewer:</strong> ${report.reviewed_by || 'NRTC PMU Command Lead'} (${report.reviewed_at || ''})</p>
            <p><strong>Remarks:</strong> ${report.admin_remarks}</p>
          </div>
        ` : ''}

        <div class="signatures">
          <div class="sign-block">
            <strong>${report.user_name || 'NRTC Site Engineer'}</strong><br>
            NRTC Resident Site Engineer (${report.district_name} Site)<br>
            National Radio & Telecommunication Corporation
          </div>
          <div class="sign-block">
            <strong>Project Director / Operations Lead</strong><br>
            NRTC Safe Cities Project Management Unit (PMU)<br>
            Submitted for PSCA Client Review & SLA Oversight
          </div>
        </div>

        <div style="margin-top:30px; text-align:center;">
          <button onclick="window.print()" style="padding:10px 20px; font-size:12pt; background:#0f3460; color:#fff; border:none; border-radius:5px; cursor:pointer;">Print / Save as PDF</button>
        </div>
      </body>
      </html>
    `);
    printWindow.document.close();
  },

  /**
   * Filters reports based on flexible criteria:
   * mode: 'range' | 'month' | 'specific' | 'all'
   * startDate: YYYY-MM-DD
   * endDate: YYYY-MM-DD
   * month: 1-12 (or '01' - '12')
   * year: YYYY (e.g. 2026)
   * specificDate: YYYY-MM-DD
   * districtId: 'all' or district id (e.g. 'chakwal', 'lahore')
   * status: 'all' | 'APPROVED' | 'SUBMITTED'
   */
  filterReports(options = {}) {
    const all = window.store ? window.store.getAllReports() : [];
    const mode = options.mode || 'all';
    const districtId = (options.districtId || 'all').toLowerCase();
    const status = (options.status || 'all').toUpperCase();

    return all.filter(r => {
      // District Filter
      if (districtId !== 'all' && (r.district_id || '').toLowerCase() !== districtId) {
        return false;
      }
      // Status Filter
      if (status !== 'ALL' && (r.status || '').toUpperCase() !== status) {
        return false;
      }

      // Date Filters
      const rDate = r.report_date;
      if (!rDate) return false;

      if (mode === 'range') {
        if (options.startDate && rDate < options.startDate) return false;
        if (options.endDate && rDate > options.endDate) return false;
      } else if (mode === 'month') {
        if (options.year && options.month) {
          const mStr = String(options.month).padStart(2, '0');
          const prefix = `${options.year}-${mStr}`;
          if (!rDate.startsWith(prefix)) return false;
        }
      } else if (mode === 'specific') {
        if (options.specificDate && rDate !== options.specificDate) return false;
      }

      return true;
    });
  },

  /**
   * Export reports matching filter options with custom, human-readable file naming.
   */
  exportFilteredReports(options = {}) {
    const filtered = this.filterReports(options);
    if (!filtered || filtered.length === 0) {
      if (typeof showToast === 'function') {
        showToast('No reports matched the selected filter criteria to export.', 'warning');
      } else {
        alert('No reports matched the selected filter criteria to export.');
      }
      return false;
    }

    // Determine district slug
    let distSlug = 'All_Punjab_37_Districts';
    if (options.districtId && options.districtId !== 'all') {
      const dObj = window.getDistrictById ? window.getDistrictById(options.districtId) : null;
      distSlug = dObj ? dObj.name.replace(/\s+/g, '_') : options.districtId;
    }

    let filename = '';
    const mode = options.mode || 'all';
    if (mode === 'month') {
      const months = ['Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun', 'Jul', 'Aug', 'Sep', 'Oct', 'Nov', 'Dec'];
      const mIdx = parseInt(options.month) - 1;
      const mName = months[mIdx] || options.month;
      filename = `NRTC_PSCA_${distSlug}_Monthly_Report_${options.year}_${mName}.csv`;
    } else if (mode === 'range') {
      const s = options.startDate || 'start';
      const e = options.endDate || 'end';
      filename = `NRTC_PSCA_${distSlug}_Report_${s}_to_${e}.csv`;
    } else if (mode === 'specific') {
      filename = `NRTC_PSCA_${distSlug}_Daily_Report_${options.specificDate}.csv`;
    } else {
      filename = `NRTC_PSCA_${distSlug}_Complete_Historical_Archive.csv`;
    }

    this.exportToCSV(filtered, filename);
    if (typeof showToast === 'function') {
      showToast(`Successfully exported ${filtered.length} report(s) to ${filename}`, 'success');
    }
    return true;
  }
};

window.SafeCityExport = SafeCityExport;
