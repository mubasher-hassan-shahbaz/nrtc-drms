/**
 * Punjab Safe City Authority - District Registry
 * All 37 administrative districts across Punjab, Pakistan.
 * Includes GPS center coordinates, geofence operational radii, and telemetry verifiers.
 */
const PUNJAB_DISTRICTS = [
  {
    "id": "attock",
    "name": "Attock",
    "baseIpnw": 95,
    "baseCee": 24,
    "baseDee": 12,
    "baseWifi": 15,
    "lat": 33.766,
    "lng": 72.3609,
    "radiusKm": 35,
    "centerName": "Safe City Site Attock"
  },
  {
    "id": "bahawalnagar",
    "name": "Bahawalnagar",
    "baseIpnw": 129,
    "baseCee": 24,
    "baseDee": 30,
    "baseWifi": 18,
    "lat": 29.9984,
    "lng": 73.2536,
    "radiusKm": 35,
    "centerName": "Safe City Control Center Bahawalnagar"
  },
  {
    "id": "bahawalpur",
    "name": "Bahawalpur",
    "baseIpnw": 220,
    "baseCee": 45,
    "baseDee": 20,
    "baseWifi": 30,
    "lat": 29.3956,
    "lng": 71.6836,
    "radiusKm": 35,
    "centerName": "Divisional Police Lines Bahawalpur"
  },
  {
    "id": "bhakkar",
    "name": "Bhakkar",
    "baseIpnw": 120,
    "baseCee": 37,
    "baseDee": 30,
    "baseWifi": 15,
    "lat": 31.6253,
    "lng": 71.0657,
    "radiusKm": 35,
    "centerName": "District Police HQ Bhakkar"
  },
  {
    "id": "chakwal",
    "name": "Chakwal",
    "baseIpnw": 160,
    "baseCee": 24,
    "baseDee": 17,
    "baseWifi": 19,
    "lat": 32.9328,
    "lng": 72.8631,
    "radiusKm": 35,
    "centerName": "Police Lines / Safe City Chakwal"
  },
  {
    "id": "chiniot",
    "name": "Chiniot",
    "baseIpnw": 114,
    "baseCee": 36,
    "baseDee": 52,
    "baseWifi": 18,
    "lat": 31.72,
    "lng": 72.9789,
    "radiusKm": 30,
    "centerName": "Safe City Node Chiniot"
  },
  {
    "id": "dg_khan",
    "name": "Dera Ghazi Khan",
    "baseIpnw": 160,
    "baseCee": 32,
    "baseDee": 16,
    "baseWifi": 20,
    "lat": 30.0561,
    "lng": 70.6403,
    "radiusKm": 35,
    "centerName": "Regional Police HQ D.G. Khan"
  },
  {
    "id": "gujrat",
    "name": "Gujrat",
    "baseIpnw": 210,
    "baseCee": 42,
    "baseDee": 20,
    "baseWifi": 28,
    "lat": 32.5742,
    "lng": 74.0754,
    "radiusKm": 30,
    "centerName": "District Police HQ Gujrat"
  },
  {
    "id": "hafizabad",
    "name": "Hafizabad",
    "baseIpnw": 113,
    "baseCee": 39,
    "baseDee": 27,
    "baseWifi": 15,
    "lat": 32.0679,
    "lng": 73.6854,
    "radiusKm": 30,
    "centerName": "Safe City Cell Hafizabad"
  },
  {
    "id": "hasanabdal",
    "name": "Hassan Abdal",
    "baseIpnw": 51,
    "baseCee": 10,
    "baseDee": 8,
    "baseWifi": 10,
    "lat": 33.82,
    "lng": 72.69,
    "radiusKm": 25,
    "centerName": "Safe City Node Hassan Abdal"
  },
  {
    "id": "jhang",
    "name": "Jhang",
    "baseIpnw": 140,
    "baseCee": 28,
    "baseDee": 14,
    "baseWifi": 18,
    "lat": 31.2781,
    "lng": 72.3188,
    "radiusKm": 35,
    "centerName": "Safe City Control Room Jhang"
  },
  {
    "id": "jhelum",
    "name": "Jhelum",
    "baseIpnw": 110,
    "baseCee": 25,
    "baseDee": 12,
    "baseWifi": 16,
    "lat": 32.9405,
    "lng": 73.7276,
    "radiusKm": 35,
    "centerName": "Police Lines / Control Room Jhelum"
  },
  {
    "id": "khanewal",
    "name": "Khanewal",
    "baseIpnw": 137,
    "baseCee": 28,
    "baseDee": 17,
    "baseWifi": 18,
    "lat": 30.3017,
    "lng": 71.9321,
    "radiusKm": 35,
    "centerName": "District Police Lines Khanewal"
  },
  {
    "id": "khushab",
    "name": "Khushab",
    "baseIpnw": 128,
    "baseCee": 36,
    "baseDee": 10,
    "baseWifi": 15,
    "lat": 32.2955,
    "lng": 72.3525,
    "radiusKm": 35,
    "centerName": "Safe City Node Khushab (Jauharabad)"
  },
  {
    "id": "kot_addu",
    "name": "Kot Addu",
    "baseIpnw": 103,
    "baseCee": 30,
    "baseDee": 26,
    "baseWifi": 14,
    "lat": 30.47,
    "lng": 70.9667,
    "radiusKm": 30,
    "centerName": "Sub-Divisional Safe City Center Kot Addu"
  },
  {
    "id": "layyah",
    "name": "Layyah",
    "baseIpnw": 117,
    "baseCee": 42,
    "baseDee": 30,
    "baseWifi": 16,
    "lat": 30.9613,
    "lng": 70.9419,
    "radiusKm": 35,
    "centerName": "District Police HQ Layyah"
  },
  {
    "id": "lodhran",
    "name": "Lodhran",
    "baseIpnw": 107,
    "baseCee": 27,
    "baseDee": 39,
    "baseWifi": 15,
    "lat": 29.5405,
    "lng": 71.6336,
    "radiusKm": 30,
    "centerName": "Safe City Site Lodhran"
  },
  {
    "id": "mandi_bahauddin",
    "name": "Mandi Bahauddin",
    "baseIpnw": 137,
    "baseCee": 21,
    "baseDee": 34,
    "baseWifi": 18,
    "lat": 32.587,
    "lng": 73.4912,
    "radiusKm": 30,
    "centerName": "District Control Room Mandi Bahauddin"
  },
  {
    "id": "mianwali",
    "name": "Mianwali",
    "baseIpnw": 95,
    "baseCee": 20,
    "baseDee": 10,
    "baseWifi": 12,
    "lat": 32.5853,
    "lng": 71.5436,
    "radiusKm": 35,
    "centerName": "Safe City Ops Center Mianwali"
  },
  {
    "id": "multan",
    "name": "Multan",
    "baseIpnw": 850,
    "baseCee": 160,
    "baseDee": 65,
    "baseWifi": 100,
    "lat": 30.1575,
    "lng": 71.5249,
    "radiusKm": 40,
    "centerName": "Safe City Integrated Command Multan"
  },
  {
    "id": "murree",
    "name": "Murree",
    "baseIpnw": 130,
    "baseCee": 30,
    "baseDee": 15,
    "baseWifi": 22,
    "lat": 33.907,
    "lng": 73.3943,
    "radiusKm": 25,
    "centerName": "Tourism Police Safe City Station Murree"
  },
  {
    "id": "muzaffargarh",
    "name": "Muzaffargarh",
    "baseIpnw": 135,
    "baseCee": 28,
    "baseDee": 14,
    "baseWifi": 18,
    "lat": 30.075,
    "lng": 71.1921,
    "radiusKm": 35,
    "centerName": "Police Lines Muzaffargarh"
  },
  {
    "id": "narowal",
    "name": "Narowal",
    "baseIpnw": 99,
    "baseCee": 27,
    "baseDee": 22,
    "baseWifi": 15,
    "lat": 32.102,
    "lng": 74.873,
    "radiusKm": 30,
    "centerName": "Safe City Operations Narowal"
  },
  {
    "id": "okara",
    "name": "Okara",
    "baseIpnw": 160,
    "baseCee": 32,
    "baseDee": 16,
    "baseWifi": 20,
    "lat": 30.8081,
    "lng": 73.4506,
    "radiusKm": 35,
    "centerName": "District Police HQ Okara"
  },
  {
    "id": "pakpattan",
    "name": "Pakpattan",
    "baseIpnw": 115,
    "baseCee": 42,
    "baseDee": 39,
    "baseWifi": 18,
    "lat": 30.341,
    "lng": 73.3866,
    "radiusKm": 30,
    "centerName": "Safe City Monitoring Center Pakpattan"
  },
  {
    "id": "rahim_yar_khan",
    "name": "Rahim Yar Khan",
    "baseIpnw": 240,
    "baseCee": 48,
    "baseDee": 22,
    "baseWifi": 30,
    "lat": 28.4212,
    "lng": 70.2989,
    "radiusKm": 40,
    "centerName": "Safe City Project Rahim Yar Khan"
  },
  {
    "id": "rajanpur",
    "name": "Rajanpur",
    "baseIpnw": 98,
    "baseCee": 19,
    "baseDee": 34,
    "baseWifi": 15,
    "lat": 29.1035,
    "lng": 70.325,
    "radiusKm": 35,
    "centerName": "Safe City Hub Rajanpur"
  },
  {
    "id": "sahiwal",
    "name": "Sahiwal",
    "baseIpnw": 230,
    "baseCee": 45,
    "baseDee": 20,
    "baseWifi": 30,
    "lat": 30.6682,
    "lng": 73.1114,
    "radiusKm": 35,
    "centerName": "Divisional Control Room Sahiwal"
  },
  {
    "id": "sargodha",
    "name": "Sargodha",
    "baseIpnw": 320,
    "baseCee": 60,
    "baseDee": 28,
    "baseWifi": 40,
    "lat": 32.0836,
    "lng": 72.6711,
    "radiusKm": 35,
    "centerName": "Safe City Control Complex Sargodha"
  },
  {
    "id": "sheikhupura",
    "name": "Sheikhupura",
    "baseIpnw": 260,
    "baseCee": 50,
    "baseDee": 24,
    "baseWifi": 35,
    "lat": 31.7131,
    "lng": 73.9783,
    "radiusKm": 35,
    "centerName": "Safe City Ops Center Sheikhupura"
  },
  {
    "id": "sialkot",
    "name": "Sialkot",
    "baseIpnw": 420,
    "baseCee": 80,
    "baseDee": 36,
    "baseWifi": 55,
    "lat": 32.4945,
    "lng": 74.5229,
    "radiusKm": 35,
    "centerName": "District Police Lines Sialkot"
  },
  {
    "id": "talagang",
    "name": "Talagang",
    "baseIpnw": 117,
    "baseCee": 29,
    "baseDee": 23,
    "baseWifi": 16,
    "lat": 32.9298,
    "lng": 72.4158,
    "radiusKm": 30,
    "centerName": "Safe City Site Talagang"
  },
  {
    "id": "taunsa",
    "name": "Taunsa",
    "baseIpnw": 100,
    "baseCee": 15,
    "baseDee": 0,
    "baseWifi": 12,
    "lat": 30.7042,
    "lng": 70.6506,
    "radiusKm": 30,
    "centerName": "Safe City Site Taunsa"
  },
  {
    "id": "taxila",
    "name": "Taxila",
    "baseIpnw": 66,
    "baseCee": 13,
    "baseDee": 8,
    "baseWifi": 10,
    "lat": 33.746,
    "lng": 72.809,
    "radiusKm": 25,
    "centerName": "Safe City Node Taxila"
  },
  {
    "id": "toba_tek_singh",
    "name": "Toba Tek Singh",
    "baseIpnw": 120,
    "baseCee": 47,
    "baseDee": 27,
    "baseWifi": 16,
    "lat": 30.9709,
    "lng": 72.4826,
    "radiusKm": 30,
    "centerName": "Safe City Unit Toba Tek Singh"
  },
  {
    "id": "vehari",
    "name": "Vehari",
    "baseIpnw": 112,
    "baseCee": 34,
    "baseDee": 32,
    "baseWifi": 18,
    "lat": 30.0419,
    "lng": 72.3489,
    "radiusKm": 35,
    "centerName": "District Police Complex Vehari"
  },
  {
    "id": "wazirabad",
    "name": "Wazirabad",
    "baseIpnw": 127,
    "baseCee": 51,
    "baseDee": 35,
    "baseWifi": 20,
    "lat": 32.443,
    "lng": 74.1197,
    "radiusKm": 25,
    "centerName": "Sub-Divisional Safe City Center Wazirabad"
  }
];

function getDistrictById(id) {
  if (!id) return null;
  const cleanId = String(id).toLowerCase().replace(/[^a-z0-9]/g, '');
  return PUNJAB_DISTRICTS.find(d => {
    const dClean = d.id.toLowerCase().replace(/[^a-z0-9]/g, '');
    const nameClean = d.name.toLowerCase().replace(/[^a-z0-9]/g, '');
    if (dClean === cleanId || nameClean === cleanId) return true;
    if (cleanId === 'dgkhan' && (dClean.includes('dg') || nameClean.includes('ghazi'))) return true;
    if (cleanId === 'deraghazikhan' && (dClean.includes('dg') || nameClean.includes('ghazi'))) return true;
    if (cleanId === 'rahimyarkhan' && (dClean.includes('rahim') || nameClean.includes('rahim'))) return true;
    if (cleanId === 'hassanabdal' && (dClean.includes('hasan') || nameClean.includes('hasan'))) return true;
    return false;
  }) || null;
}

function getDistrictByName(name) {
  return getDistrictById(name);
}

/**
 * Calculates straight-line distance in kilometers between two GPS coordinates using Haversine formula.
 */
function calculateDistanceKm(lat1, lon1, lat2, lon2) {
  if (lat1 === undefined || lon1 === undefined || lat2 === undefined || lon2 === undefined) return null;
  const toRad = x => (x * Math.PI) / 180;
  const R = 6371; // Earth's mean radius in km

  const dLat = toRad(lat2 - lat1);
  const dLon = toRad(lon2 - lon1);
  const a =
    Math.sin(dLat / 2) * Math.sin(dLat / 2) +
    Math.cos(toRad(lat1)) * Math.cos(toRad(lat2)) * Math.sin(dLon / 2) * Math.sin(dLon / 2);
  const c = 2 * Math.atan2(Math.sqrt(a), Math.sqrt(1 - a));
  const d = R * c;
  return Math.round(d * 100) / 100; // 2 decimal places
}

/**
 * Verifies if given coordinates are within the assigned district boundary.
 * Returns { isInside, distanceKm, radiusKm, district }
 */
function verifyDistrictLocation(districtId, lat, lon) {
  const dist = getDistrictById(districtId);
  if (!dist) {
    return { isInside: false, distanceKm: null, radiusKm: 0, district: null, error: 'District not found' };
  }
  const distance = calculateDistanceKm(dist.lat, dist.lng, lat, lon);
  const isInside = distance !== null && distance <= dist.radiusKm;
  return {
    isInside,
    distanceKm: distance,
    radiusKm: dist.radiusKm,
    district: dist
  };
}

if (typeof window !== 'undefined') {
  window.PUNJAB_DISTRICTS = PUNJAB_DISTRICTS;
  window.getDistrictById = getDistrictById;
  window.getDistrictByName = getDistrictByName;
  window.calculateDistanceKm = calculateDistanceKm;
  window.verifyDistrictLocation = verifyDistrictLocation;
}

if (typeof module !== 'undefined' && module.exports) {
  module.exports = {
    PUNJAB_DISTRICTS,
    getDistrictById,
    getDistrictByName,
    calculateDistanceKm,
    verifyDistrictLocation
  };
}
