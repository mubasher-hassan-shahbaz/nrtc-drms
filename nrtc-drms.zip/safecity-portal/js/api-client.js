/**
 * Punjab Safe City Portal - Unified API Client
 * Connects the frontend to the Node.js backend API.
 * Replaces old localStorage-only store for persistent data.
 */
const API_BASE = (function() {
  if (typeof window === 'undefined') return '';

  // Allow explicit override if defined
  if (window.PORTAL_API_BASE) return window.PORTAL_API_BASE;

  const hostname = (window.location && window.location.hostname) || '';
  const port = (window.location && window.location.port) || '';

  // 1. If running on a deployed host (e.g. Vercel, Netlify, custom domain):
  // Hostname is not localhost/127.0.0.1. We MUST use relative paths ('') so all
  // requests (/api/...) go directly to the same host/protocol/port via HTTPS.
  // Never append :3000 on Vercel or cloud platforms!
  const isLocalhost = hostname === 'localhost' || hostname === '127.0.0.1' || hostname === '';
  if (!isLocalhost) {
    return '';
  }

  // 2. If running locally on port 3000 (served directly by node server.js):
  // Relative paths are preferred and work directly on the same origin.
  if (port === '3000') {
    return '';
  }

  // 3. If running locally via another static dev server (e.g. Live Server on port 5500) or file://:
  // Point to the local backend server on port 3000.
  return 'http://localhost:3000';
})();


const SafeCityAPI = {
  // Current session (in-memory + sessionStorage)
  session: {
    user: null,
    token: null
  },

  // ---- AUTH ----
  async login(username, password) {
    try {
      const res = await fetch(`${API_BASE}/api/auth/login`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ username, password })
      });
      const data = await res.json();
      if (data.success) {
        this.session.user = data.user;
        sessionStorage.setItem('portal_user', JSON.stringify(data.user));
        if (window.store && typeof window.store.setCurrentUser === 'function') {
          window.store.setCurrentUser(data.user);
        }
      }
      return data;
    } catch (err) {
      console.warn('API login network fetch failed, checking local store fallback...', err);
      if (window.store && typeof window.store.login === 'function') {
        const localRes = window.store.login(username, password);
        if (localRes && localRes.success) {
          this.session.user = localRes.user;
          sessionStorage.setItem('portal_user', JSON.stringify(localRes.user));
          return localRes;
        }
      }
      throw err;
    }
  },

  logout() {
    this.session.user = null;
    sessionStorage.removeItem('portal_user');
    window.location.replace('login.html');
  },

  getCurrentUser() {
    if (this.session.user) return this.session.user;
    const saved = sessionStorage.getItem('portal_user');
    if (saved) {
      this.session.user = JSON.parse(saved);
      return this.session.user;
    }
    return null;
  },

  async getMe() {
    try {
      const res = await fetch(`${API_BASE}/api/auth/me`, {
        headers: this._getAuthHeaders()
      });
      const data = await res.json();
      if (data.success && data.user) {
        this.session.user = data.user;
        sessionStorage.setItem('portal_user', JSON.stringify(data.user));
        if (window.store && typeof window.store.setCurrentUser === 'function') {
          window.store.setCurrentUser(data.user);
        }
        return data.user;
      }
    } catch (e) {}
    return this.getCurrentUser();
  },

  isAuthenticated() {
    return !!this.getCurrentUser();
  },

  _getAuthHeaders() {
    const user = this.getCurrentUser();
    const headers = {};
    if (user) {
      headers['x-user-id'] = user.id || '';
      headers['x-user-role'] = user.role || '';
      headers['x-district-id'] = user.districtId || '';
      if (user.districts && Array.isArray(user.districts)) {
        headers['x-user-districts'] = JSON.stringify(user.districts);
      }
      if (user.permissions && Array.isArray(user.permissions)) {
        headers['x-user-permissions'] = JSON.stringify(user.permissions);
      }
    }
    return headers;
  },

  // ---- GENERIC FETCH ----
  async get(path) {
    const headers = this._getAuthHeaders();
    const res = await fetch(`${API_BASE}${path}`, { headers });
    if (!res.ok) {
      const errBody = await res.json().catch(() => ({}));
      throw new Error(errBody.error || `API Error ${res.status}: ${path}`);
    }
    return res.json();
  },

  async post(path, body) {
    const headers = { 'Content-Type': 'application/json', ...this._getAuthHeaders() };
    const res = await fetch(`${API_BASE}${path}`, {
      method: 'POST',
      headers,
      body: JSON.stringify(body)
    });
    return res.json();
  },

  async put(path, body) {
    const headers = { 'Content-Type': 'application/json', ...this._getAuthHeaders() };
    const res = await fetch(`${API_BASE}${path}`, {
      method: 'PUT',
      headers,
      body: JSON.stringify(body)
    });
    return res.json();
  },

  async del(path) {
    const headers = this._getAuthHeaders();
    const res = await fetch(`${API_BASE}${path}`, { method: 'DELETE', headers });
    return res.json();
  },

  // ---- SITES ----
  async getSites(params = {}) {
    const qs = new URLSearchParams(params).toString();
    try {
      const res = await this.get(`/api/sites${qs ? '?' + qs : ''}`);
      if (Array.isArray(res)) return res;
    } catch (e) {
      console.warn('API /api/sites call failed, falling back to data/sites.json', e);
    }
    try {
      const res = await fetch('data/sites.json');
      let sites = await res.json();
      if (params.city || params.district) {
        const target = (params.city || params.district).toLowerCase().replace(/[^a-z0-9]/g, '');
        sites = sites.filter(s => {
          const c = (s.city || '').toLowerCase().replace(/[^a-z0-9]/g, '');
          const dId = (s.district_id || '').toLowerCase().replace(/[^a-z0-9]/g, '');
          if (c === target || dId === target) return true;
          if (target.includes('dg') && (c.includes('ghazi') || dId.includes('dg'))) return true;
          if (target.includes('ryk') && (c.includes('rahim') || dId.includes('rahim'))) return true;
          return c.includes(target) || target.includes(c);
        });
      }
      if (params.type && params.type !== 'all') {
        sites = sites.filter(s => s.siteType && s.siteType.toLowerCase() === params.type.toLowerCase());
      }
      return sites;
    } catch (e2) {
      console.error('Failed to load sites fallback', e2);
      return [];
    }
  },

  async getSite(id) {
    return this.get(`/api/sites/${id}`);
  },

  // ---- EMPLOYEES ----
  async getEmployees(params = {}) {
    const qs = new URLSearchParams(params).toString();
    return this.get(`/api/employees${qs ? '?' + qs : ''}`);
  },

  async getEmployee(id) {
    return this.get(`/api/employees/${id}`);
  },

  async saveEmployee(emp) {
    if (emp.id && !emp.id.startsWith('new_')) {
      return this.put(`/api/employees/${emp.id}`, emp);
    }
    return this.post('/api/employees', emp);
  },

  async deleteEmployee(id) {
    return this.del(`/api/employees/${id}`);
  },

  // ---- REPORTS ----
  async getReports(params = {}) {
    const qs = new URLSearchParams(params).toString();
    return this.get(`/api/reports${qs ? '?' + qs : ''}`);
  },

  async saveReport(report) {
    if (report.id && !report.id.startsWith('new_')) {
      return this.put(`/api/reports/${report.id}`, report);
    }
    return this.post('/api/reports', report);
  },

  // ---- TICKETS ----
  async getTickets(params = {}) {
    const qs = new URLSearchParams(params).toString();
    return this.get(`/api/tickets${qs ? '?' + qs : ''}`);
  },

  async saveTicket(ticket) {
    if (ticket.id && !ticket.id.startsWith('new_')) {
      return this.put(`/api/tickets/${ticket.id}`, ticket);
    }
    return this.post('/api/tickets', ticket);
  },

  // ---- USERS ----
  async getUsers() {
    return this.get('/api/users');
  },

  async saveUser(user) {
    if (user.id && !user.id.startsWith('new_')) {
      return this.put(`/api/users/${user.id}`, user);
    }
    return this.post('/api/users', user);
  },

  async updateUserStatus(id, active) {
    return this.put(`/api/users/${id}/status`, { active });
  },

  async resetUserPassword(id, password) {
    return this.put(`/api/users/${id}/password`, { password });
  },

  async deleteUser(id) {
    return this.del(`/api/users/${id}`);
  },

  // ---- ATTENDANCE ----
  async getAttendance(params = {}) {
    const qs = new URLSearchParams(params).toString();
    return this.get(`/api/attendance${qs ? '?' + qs : ''}`);
  },

  async saveAttendance(record) {
    return this.post('/api/attendance', record);
  },

  // ---- FINANCES & PAYMENTS ----
  async getFinances(params = {}) {
    const qs = new URLSearchParams(params).toString();
    return this.get(`/api/finances${qs ? '?' + qs : ''}`);
  },

  async getFinanceById(id) {
    return this.get(`/api/finances/${id}`);
  },

  async saveFinance(record) {
    return this.post('/api/finances', record);
  },

  async addPayment(expenseId, paymentData) {
    return this.post(`/api/finances/${expenseId}/payments`, paymentData);
  },

  async updateExpenseStatus(expenseId, statusData) {
    return this.put(`/api/finances/${expenseId}/status`, statusData);
  },

  async getFinanceSummary(params = {}) {
    const qs = new URLSearchParams(params).toString();
    return this.get(`/api/finances/summary${qs ? '?' + qs : ''}`);
  },

  // ---- FINANCE QUERIES ----
  async getFinanceQueries(params = {}) {
    const qs = new URLSearchParams(params).toString();
    return this.get(`/api/finance-queries${qs ? '?' + qs : ''}`);
  },

  async saveFinanceQuery(queryData) {
    return this.post('/api/finance-queries', queryData);
  },

  async updateFinanceQuery(queryId, updateData) {
    return this.put(`/api/finance-queries/${queryId}`, updateData);
  },

  // ---- PTCL TICKETS ----
  async getPtclTickets(params = {}) {
    const qs = new URLSearchParams(params).toString();
    return this.get(`/api/ptcl-tickets${qs ? '?' + qs : ''}`);
  },

  async getPtclTicketSummary(params = {}) {
    const qs = new URLSearchParams(params).toString();
    return this.get(`/api/ptcl-tickets/summary${qs ? '?' + qs : ''}`);
  },

  async createPtclTicket(ticketData) {
    return this.post('/api/ptcl-tickets', ticketData);
  },

  async updatePtclTicketStatus(ticketId, updateData) {
    return this.put(`/api/ptcl-tickets/${ticketId}/status`, updateData);
  },

  async closePtclTicket(ticketId, closeData) {
    return this.put(`/api/ptcl-tickets/${ticketId}/close`, closeData);
  },

  async acknowledgePtclTicket(ticketId, ackData) {
    return this.put(`/api/ptcl-tickets/${ticketId}/acknowledge`, ackData);
  },

  getPtclExportUrl(params = {}) {
    const qs = new URLSearchParams(params).toString();
    return `${API_BASE}/api/ptcl-tickets/export${qs ? '?' + qs : ''}`;
  },

  getReportsExportUrl(params = {}) {
    const qs = new URLSearchParams(params).toString();
    return `${API_BASE}/api/reports/export${qs ? '?' + qs : ''}`;
  },

  getSitesExportUrl(params = {}) {
    const qs = new URLSearchParams(params).toString();
    return `${API_BASE}/api/sites/export${qs ? '?' + qs : ''}`;
  },

  // ---- FILE UPLOADS ----
  async uploadFile(type, file) {
    const formData = new FormData();
    formData.append('file', file);
    const res = await fetch(`${API_BASE}/api/upload/${type}`, {
      method: 'POST',
      body: formData
    });
    return res.json();
  },

  // ---- ANALYTICS ----
  async getAnalyticsSummary() {
    return this.get('/api/analytics/summary');
  },

  // ---- DISTRICTS ----
  async getDistricts() {
    return this.get('/api/districts');
  }
};

// Legacy compatibility: expose as window.api for all pages
window.api = SafeCityAPI;

// Auto-restore session
SafeCityAPI.getCurrentUser();
