/**
 * Punjab Safe City Authority - Core Application Controller
 * Handles routing, role switching, multi-step wizard, calculations, and UI events.
 */

let appState = {
  currentUser: null,
  activePage: 'dashboard',
  currentWizardStep: 1,
  editingReportId: null,
  filterDistrict: 'all',
  filterStatus: 'all',
  filterDate: ''
};

// ─── READ-ONLY ADMIN: hide all mutating action buttons / forms ─────────────
function applyReadOnlyRestrictions() {
  const style = document.createElement('style');
  style.id = 'read-only-admin-style';
  style.textContent = `
    /* Hide all create/edit/delete/approve/close/acknowledge buttons for READ_ONLY_ADMIN */
    [data-action="create"], [data-action="edit"], [data-action="delete"],
    [data-action="approve"], [data-action="close"], [data-action="acknowledge"],
    [data-action="submit"], [data-action="record-payment"],
    button[onclick*="openAdd"], button[onclick*="openCreate"], button[onclick*="openEdit"],
    button[onclick*="deleteUser"], button[onclick*="deleteEmployee"], button[onclick*="deleteSite"],
    button[onclick*="deleteReport"], button[onclick*="deleteFinance"],
    button[onclick*="approveExpense"], button[onclick*="rejectExpense"],
    button[onclick*="openRecordPayment"], button[onclick*="openRespondQuery"],
    button[onclick*="acknowledgeTicket"], button[onclick*="closeTicket"],
    button[onclick*="updateTicketStatus"], button[onclick*="submitReport"],
    button[onclick*="saveReport"], button[onclick*="addEmployee"],
    button[onclick*="saveEmployee"], button[onclick*="openUserModal"],
    button[onclick*="saveUser"], button[onclick*="markAttendance"],
    .btn-add, .btn-create, .btn-new,
    #btnAddEmployee, #btnAddUser, #btnCreateExpense, #btnNewQuery,
    #btnSubmitReport, #btnSaveReport, #btnMarkAttendance,
    #addUserBtn, #addEmployeeBtn, #addFinanceBtn,
    .action-create, .action-edit, .action-delete, .action-approve {
      display: none !important;
    }
    /* Show read-only badge in header */
    .read-only-badge { display: inline-block !important; }
  `;
  if (!document.getElementById('read-only-admin-style')) {
    document.head.appendChild(style);
  }

  // Also programmatically disable form submit buttons
  document.querySelectorAll('form[id*="report"], form[id*="user"], form[id*="employee"], form[id*="finance"]').forEach(f => {
    f.querySelectorAll('button[type="submit"]').forEach(btn => { btn.disabled = true; btn.style.display = 'none'; });
  });

  // Show banner
  const banner = document.createElement('div');
  banner.id = 'readonly-banner';
  banner.style.cssText = 'position:fixed;top:0;left:0;width:100%;background:#fbbf24;color:#78350f;text-align:center;padding:6px;font-size:13px;font-weight:600;z-index:9999;';
  banner.textContent = '🔒 Read-Only Mode — Viewing only. No changes can be made.';
  if (!document.getElementById('readonly-banner')) {
    document.body.insertBefore(banner, document.body.firstChild);
  }

  // Intercept form submissions at DOM level
  document.addEventListener('submit', function(e) {
    const user = window.store ? window.store.getCurrentUser() : null;
    if (user && user.role === 'READ_ONLY_ADMIN') {
      e.preventDefault();
      e.stopPropagation();
      alert('Read-only access. This action is not permitted.');
      return false;
    }
  }, true);

  // Re-apply on DOM mutations (for dynamically rendered tables/modals)
  if (window._readOnlyObserver) window._readOnlyObserver.disconnect();
  window._readOnlyObserver = new MutationObserver(() => {
    document.querySelectorAll(
      'button[onclick*="openAdd"], button[onclick*="openEdit"], button[onclick*="deleteUser"], ' +
      'button[onclick*="deleteEmployee"], button[onclick*="approveExpense"], button[onclick*="rejectExpense"], ' +
      'button[onclick*="openRecordPayment"], button[onclick*="acknowledgeTicket"], button[onclick*="closeTicket"]'
    ).forEach(btn => { btn.style.display = 'none'; });
  });
  window._readOnlyObserver.observe(document.body, { childList: true, subtree: true });
}

// Expose globally so HTML inline scripts can check
window.isReadOnlyAdmin = function() {
  const user = window.store ? window.store.getCurrentUser() : (window.appState && window.appState.currentUser);
  return user && user.role === 'READ_ONLY_ADMIN';
};

// Dynamic Site Type Color Mapping (Standard across all maps)
window.getSiteMarkerColor = function(type) {
  const t = String(type || '').toUpperCase().trim();
  if (t === 'MCR' || t === 'DR' || t.includes('MCR') || t.includes('DR')) return '#dc2626'; // Red for MCR & DR
  if (t === 'PS' || t === 'DC' || t === 'MDC' || t.includes('POLICE') || t.includes('DATA CENTER')) return '#8b5cf6'; // Purple for PS & DC
  if (t === 'IPNV' || t.includes('IPNV')) return '#3b82f6'; // Blue for IPNV
  if (t === 'CEE' || t.includes('CEE') || t.includes('ANPR')) return '#10b981'; // Emerald Green for CEE
  if (t === 'DEE' || t.includes('DEE')) return '#f59e0b'; // Amber for DEE
  return '#0891b2'; // Cyan / other
};

const PAGE_TO_FILE = {
  'dashboard': 'dashboard.html',
  'submit': 'submit-report.html',
  'reports': 'reports.html',
  'attendance': 'attendance.html',
  'finance': 'finance.html',
  'ptcl-tickets': 'ptcl-tickets.html',
  'admin-overview': 'admin-overview.html',
  'admin-reports': 'admin-reports.html',
  'districts-matrix': 'districts-matrix.html',
  'district-detail': 'district-detail.html',
  'employees': 'employees.html',
  'sites': 'sites.html',
  'tickets': 'tickets.html',
  'analytics': 'analytics.html',
  'users': 'users.html',
  'import': 'import.html',
  'profile': 'profile.html',
  'login': 'login.html'
};

function getActivePageKey() {
  const bodyPage = document.body ? document.body.getAttribute('data-page') : null;
  if (bodyPage) return bodyPage;

  const path = window.location.pathname.toLowerCase();
  // Sort files by filename length descending to prevent substring collisions (e.g. ptcl-tickets vs tickets)
  const entries = Object.entries(PAGE_TO_FILE).sort((a, b) => b[1].length - a[1].length);
  for (const [key, file] of entries) {
    if (path.endsWith(file) || path.endsWith('/' + file)) return key;
  }
  return 'dashboard';
}

document.addEventListener('DOMContentLoaded', () => {
  initApp();
});

function initApp() {
  const pageKey = getActivePageKey();
  appState.activePage = pageKey;

  populateDistrictSelects();
  setupLiveCalculators();
  setupImportDropzone();

  // Prefer new API session (sessionStorage) over old localStorage session
  const isAuth = window.store.isAuthenticated();
  let currentUser = window.store.getCurrentUser();
  if (currentUser && currentUser.name && /saad|shahbaz/i.test(currentUser.name)) {
    currentUser.name = currentUser.role === 'ADMIN' ? 'Admin' : (currentUser.role === 'FINANCE_ADMIN' ? 'Finance Admin' : (currentUser.districtName || 'Site Engineer'));
    if (window.store && typeof window.store.setCurrentUser === 'function') {
      window.store.setCurrentUser(currentUser);
    }
  }
  appState.currentUser = currentUser;

  // Background sync authentic profile from database API
  if (isAuth && window.SafeCityAPI && typeof window.SafeCityAPI.getMe === 'function') {
    window.SafeCityAPI.getMe().then(freshUser => {
      if (freshUser && freshUser.name && appState.currentUser && appState.currentUser.name !== freshUser.name) {
        appState.currentUser = freshUser;
        renderAppByRole();
      }
    }).catch(() => {});
  }

  // Handle Login Page
  if (pageKey === 'login') {
    if (isAuth && currentUser) {
      if (currentUser.role === 'ADMIN' || currentUser.role === 'SUPER_ADMIN' || currentUser.role === 'READ_ONLY_ADMIN') {
        window.location.replace('admin-overview.html');
      } else if (currentUser.role === 'FINANCE_ADMIN') {
        window.location.replace('finance.html');
      } else if (currentUser.role === 'PTCL_ADMIN') {
        window.location.replace('ptcl-tickets.html');
      } else {
        window.location.replace('dashboard.html');
      }
      return;
    }
    return;
  }

  // Route Guard: Protected pages require active authentication
  if (!isAuth || !currentUser) {
    window.location.replace('login.html');
    return;
  }

  // Route Guard: District users CANNOT access admin-only pages
  const isAdmin = currentUser.role === 'ADMIN' || currentUser.role === 'SUPER_ADMIN' || currentUser.role === 'READ_ONLY_ADMIN';
  const adminOnlyPages = ['admin-overview', 'admin-reports', 'districts-matrix', 'district-detail', 'users', 'import'];
  if (!isAdmin && adminOnlyPages.includes(pageKey)) {
    window.location.replace('dashboard.html');
    return;
  }

  // Route Guard: Admin users MUST use admin-overview.html (cannot access district dashboard)
  if (isAdmin && pageKey === 'dashboard') {
    window.location.replace('admin-overview.html');
    return;
  }

  renderAppByRole();
  setupMobileResponsiveness();

  // Set today's date on date inputs if empty
  const today = new Date().toISOString().split('T')[0];
  const dateInput = document.getElementById('reportDate');
  if (dateInput && !dateInput.value) dateInput.value = today;

  const adminDateInput = document.getElementById('adminFilterDate');
  if (adminDateInput) adminDateInput.value = '';

  // Execute current page rendering logic
  executePageRender(pageKey);

  // Apply read-only restrictions for READ_ONLY_ADMIN (after page renders)
  if (currentUser && currentUser.role === 'READ_ONLY_ADMIN') {
    setTimeout(() => applyReadOnlyRestrictions(), 300);
  }
}


function handleUrlHash() {
  const hash = (window.location.hash || '#dashboard').replace('#', '');
  showPage(hash);
}

function populateDistrictSelects() {
  const currentUser = appState.currentUser || (window.store ? window.store.getCurrentUser() : null);
  const isDistrict = currentUser && currentUser.role === 'DISTRICT_USER';

  // 1. Report Submission Form District Select
  const formDist = document.getElementById('formDistrict');
  if (formDist) {
    if (isDistrict) {
      formDist.innerHTML = `<option value="${currentUser.districtId}">${currentUser.districtName}</option>`;
      formDist.value = currentUser.districtId;
      formDist.disabled = true;
    } else {
      formDist.innerHTML = '';
      (window.PUNJAB_DISTRICTS || []).forEach(d => {
        const opt = document.createElement('option');
        opt.value = d.id;
        opt.textContent = d.name;
        formDist.appendChild(opt);
      });
    }
  }

  // 2. Admin Filter District Select (Admin only)
  const adminFilterDist = document.getElementById('adminFilterDistrict');
  if (adminFilterDist) {
    if (isDistrict) {
      adminFilterDist.innerHTML = '';
      if (adminFilterDist.parentElement) adminFilterDist.parentElement.style.display = 'none';
    } else {
      adminFilterDist.innerHTML = '<option value="all">All 37 Districts</option>';
      (window.PUNJAB_DISTRICTS || []).forEach(d => {
        const opt = document.createElement('option');
        opt.value = d.id;
        opt.textContent = d.name;
        adminFilterDist.appendChild(opt);
      });
    }
  }

  // 3. User Modal District Select (Admin only)
  const userModalDist = document.getElementById('userModalDistrict');
  if (userModalDist) {
    if (isDistrict) {
      userModalDist.innerHTML = '';
    } else {
      userModalDist.innerHTML = '<option value="all">All 37 Districts (Provincial Full Access)</option>';
      (window.PUNJAB_DISTRICTS || []).forEach(d => {
        const opt = document.createElement('option');
        opt.value = d.id;
        opt.textContent = d.name;
        userModalDist.appendChild(opt);
      });
    }
  }
}

function setupRoleSwitcher() {
  const user = appState.currentUser;
  const isDistrict = user.role === 'DISTRICT_USER';

  const btnUser = document.getElementById('btnRoleDistrict');
  const btnAdmin = document.getElementById('btnRoleAdmin');
  const distSelector = document.getElementById('roleDistrictPicker');

  if (btnUser && btnAdmin) {
    btnUser.classList.toggle('active', isDistrict);
    btnAdmin.classList.toggle('active', !isDistrict);
  }

  if (distSelector) {
    distSelector.style.display = isDistrict ? 'inline-block' : 'none';
    const distSelect = document.getElementById('roleSwitchDistrictSelect');
    if (distSelect) distSelect.value = user.districtId || 'chakwal';
  }
}

function switchRoleMode(role) {
  const distSelect = document.getElementById('roleSwitchDistrictSelect');
  const targetDist = distSelect ? distSelect.value : 'chakwal';

  window.store.switchRole(role, targetDist);
  appState.currentUser = window.store.getCurrentUser();

  setupRoleSwitcher();
  renderAppByRole();

  const roleName = role === 'ADMIN' ? 'NRTC PMU Admin' : `NRTC Site Engineer (${appState.currentUser.districtName})`;
  showToast(`Switched mode to: ${roleName}`, 'success');

  if (role === 'ADMIN') {
    showPage('admin-overview');
  } else {
    showPage('dashboard');
  }
}

function onRoleDistrictChange() {
  const distSelect = document.getElementById('roleSwitchDistrictSelect');
  if (!distSelect) return;
  window.store.switchRole('DISTRICT_USER', distSelect.value);
  appState.currentUser = window.store.getCurrentUser();

  setupRoleSwitcher();
  renderAppByRole();
  showToast(`Switched district site to: ${appState.currentUser.districtName}`, 'success');
  showPage('dashboard');
}

function renderAppByRole() {
  const user = appState.currentUser || window.store.getCurrentUser();
  if (!user) return;
  const isFinance = user.role === 'FINANCE_ADMIN';
  const isAdmin = user.role === 'ADMIN' || user.role === 'SUPER_ADMIN';
  const isDistrict = !isFinance && !isAdmin;

  let roleAttr = 'district';
  if (isFinance) roleAttr = 'finance';
  else if (isAdmin) roleAttr = 'admin';

  document.documentElement.setAttribute('data-role', roleAttr);
  document.body.setAttribute('data-role', roleAttr);
  document.body.classList.toggle('role-district', isDistrict);
  document.body.classList.toggle('role-admin', isAdmin);
  document.body.classList.toggle('role-finance', isFinance);

  // Display names
  let displayName = 'Admin';
  let displaySubtitle = 'NRTC PMU Command';
  let avatarText = 'PMU';

  if (isFinance) {
    displayName = user.name || 'Finance Admin';
    displaySubtitle = 'PMU Accounts & Finance';
    avatarText = 'FIN';
  } else if (isDistrict) {
    displayName = user.districtName || user.name || 'District';
    displaySubtitle = `${user.districtName || ''} Field Site`;
    avatarText = (user.districtName || 'DIST').substring(0, 3).toUpperCase();
  }

  // Update sidebar mini profile
  const userMiniName = document.getElementById('sidebarUserName');
  const userMiniRole = document.getElementById('sidebarUserRole');
  const userMiniAvatar = document.getElementById('sidebarAvatar');

  if (userMiniName) userMiniName.textContent = displayName;
  if (userMiniRole) {
    if (isFinance) userMiniRole.textContent = 'Finance Admin / Accounts Lead';
    else if (isDistrict) userMiniRole.textContent = `${user.districtName} Operations`;
    else userMiniRole.textContent = user.role === 'SUPER_ADMIN' ? 'Super Administrator' : 'NRTC PMU Director';
  }
  if (userMiniAvatar) {
    userMiniAvatar.textContent = avatarText;
    userMiniAvatar.className = isDistrict ? 'avatar' : (isFinance ? 'avatar finance-avatar' : 'avatar admin-avatar');
    if (isFinance) {
      userMiniAvatar.style.background = '#d97706';
      userMiniAvatar.style.color = '#fff';
    }
  }

  // Update topbar profile
  const topbarName = document.getElementById('topbarUserName');
  const topbarDistrict = document.getElementById('topbarDistrict');
  const topbarAvatar = document.getElementById('topbarAvatar');
  const topbarRoleBadge = document.getElementById('topbarRoleBadge');

  if (topbarName) topbarName.textContent = displayName;
  if (topbarDistrict) topbarDistrict.textContent = displaySubtitle;
  if (topbarAvatar) {
    topbarAvatar.textContent = avatarText;
    topbarAvatar.className = isDistrict ? 'avatar' : (isFinance ? 'avatar finance-avatar' : 'avatar admin-avatar');
    if (isFinance) {
      topbarAvatar.style.background = '#d97706';
      topbarAvatar.style.color = '#fff';
    }
  }
  if (topbarRoleBadge) {
    if (isFinance) {
      topbarRoleBadge.textContent = '₨ Finance Admin';
      topbarRoleBadge.style.background = '#fef3c7';
      topbarRoleBadge.style.color = '#92400e';
    } else if (isAdmin) {
      topbarRoleBadge.textContent = user.role === 'SUPER_ADMIN' ? '👑 Super Admin' : '🛡️ NRTC PMU Admin';
      topbarRoleBadge.style.background = '#eff6ff';
      topbarRoleBadge.style.color = '#1d4ed8';
    } else {
      topbarRoleBadge.textContent = `${user.districtName || 'District'} Site`;
      topbarRoleBadge.style.background = '#f1f5f9';
      topbarRoleBadge.style.color = '#334155';
    }
  }

  // Update topbar popup if present
  const popupName = document.getElementById('popupUserName');
  const popupDistrict = document.getElementById('popupUserDistrict');
  const popupAvatar = document.getElementById('popupAvatar');
  const popupBadge = document.getElementById('popupRoleBadge');

  if (popupName) popupName.textContent = displayName;
  if (popupDistrict) popupDistrict.textContent = displaySubtitle;
  if (popupAvatar) {
    popupAvatar.textContent = avatarText;
    popupAvatar.className = isDistrict ? 'avatar' : (isFinance ? 'avatar finance-avatar' : 'avatar admin-avatar');
  }
  if (popupBadge) {
    if (isFinance) {
      popupBadge.textContent = '₨ Finance Admin';
      popupBadge.style.background = '#fef3c7';
      popupBadge.style.color = '#92400e';
    } else if (isAdmin) {
      popupBadge.textContent = user.role === 'SUPER_ADMIN' ? '👑 Super Admin' : '🛡️ NRTC PMU Admin';
      popupBadge.style.background = '#eff6ff';
      popupBadge.style.color = '#1d4ed8';
    } else {
      popupBadge.textContent = `${user.districtName || 'District'} Site`;
      popupBadge.style.background = '#f1f5f9';
      popupBadge.style.color = '#334155';
    }
  }

  // Toggle navigation visibility
  document.querySelectorAll('.nav-district-only').forEach(el => {
    el.style.setProperty('display', isDistrict ? '' : 'none', isDistrict ? '' : 'important');
  });
  document.querySelectorAll('.nav-admin-only').forEach(el => {
    el.style.setProperty('display', isAdmin ? '' : 'none', isAdmin ? '' : 'important');
  });
  document.querySelectorAll('.nav-finance-only').forEach(el => {
    el.style.setProperty('display', isFinance ? '' : 'none', isFinance ? '' : 'important');
  });
  document.querySelectorAll('.nav-non-finance').forEach(el => {
    el.style.setProperty('display', isFinance ? 'none' : '', isFinance ? 'important' : '');
  });

  // Page-specific re-render
  if (appState.activePage === 'attendance') {
    renderAttendancePage();
  } else if (appState.activePage === 'finance') {
    renderFinancePage();
  } else if (appState.activePage === 'dashboard') {
    renderDashboardFinances();
  } else if (appState.activePage === 'admin-overview') {
    renderAdminOverviewFinances();
  }
}


// ==========================================
// Routing & Page Navigation
// ==========================================

function executePageRender(pageKey) {
  // Highlight active menu item with exact path/file matching (avoids substring collisions)
  const targetFile = PAGE_TO_FILE[pageKey];
  document.querySelectorAll('.sidebar a').forEach(a => {
    a.classList.remove('active');
    const href = (a.getAttribute('href') || '').split('?')[0].split('#')[0].trim();
    let isActive = false;
    if (targetFile && (href === targetFile || href.endsWith('/' + targetFile))) {
      isActive = true;
    } else if (a.id === 'nav-' + pageKey || a.id === 'nav-' + pageKey + '-admin' || a.id === 'nav-' + pageKey + '-dist' || a.id === 'nav-' + pageKey + '-main') {
      isActive = true;
    } else if (pageKey === 'district-detail' && (href === 'districts-matrix.html' || a.id === 'nav-districts-matrix')) {
      isActive = true;
    }
    if (isActive) {
      a.classList.add('active');
    }
  });

  if (pageKey === 'dashboard') {
    renderDistrictDashboard();
    renderMyReportsTable();
    renderDashboardFinances();
  } else if (pageKey === 'submit') {
    const params = new URLSearchParams(window.location.search);
    const editId = params.get('edit') || localStorage.getItem('safecity_editing_report_id');
    if (editId) {
      editReport(editId);
    } else {
      resetFormToDistrictDefaults();
    }
  } else if (pageKey === 'reports') {
    renderMyReportsTable();
  } else if (pageKey === 'admin-overview') {
    renderAdminDashboard();
    renderAdminReportsTable();
    renderAdminOverviewFinances();
  } else if (pageKey === 'admin-reports') {
    updateAdminSitesDatalist('all');
    renderAdminReportsTable();
    if (new URLSearchParams(window.location.search).get('export') === '1') {
      setTimeout(() => { openExportModal(); }, 150);
    }
  } else if (pageKey === 'districts-matrix') {
    initDistrictsMatrixPage();
  } else if (pageKey === 'analytics') {
    renderAnalyticsView();
  } else if (pageKey === 'profile') {
    renderProfileView();
  } else if (pageKey === 'users') {
    renderUsersTable();
  } else if (pageKey === 'import') {
    initImportView();
  } else if (pageKey === 'attendance') {
    renderAttendancePage();
  } else if (pageKey === 'finance') {
    renderFinancePage();
  }

  // Close mobile sidebar if open
  if (window.innerWidth <= 768) {
    const sb = document.getElementById('sidebar');
    if (sb) sb.classList.remove('open');
  }
}
window.executePageRender = executePageRender;

function showPage(pageId, navElement) {
  const currentKey = getActivePageKey();
  if (PAGE_TO_FILE[pageId] && currentKey !== pageId) {
    window.location.href = PAGE_TO_FILE[pageId];
    return;
  }
  executePageRender(pageId);
}

// ==========================================
// District User Dashboard
// ==========================================

function renderDistrictDashboard() {
  const user = appState.currentUser || (window.store ? window.store.getCurrentUser() : null);
  if (!user) return;
  const distId = user.districtId || 'punjab';
  const distName = user.districtName || user.name || 'District';
  const reports = window.store ? window.store.getReportsByDistrict(distId) : [];

  // 24-Hour Reporting Cycle Status for this District User
  const userCycle = (window.store && typeof window.store.getDailyReportingStatus === 'function')
    ? window.store.getDailyReportingStatus({ district: distId })
    : null;
  const isCycleReceived = userCycle && userCycle.summary && userCycle.summary.received > 0;
  const cycleLabel = (userCycle && userCycle.cycle) ? userCycle.cycle.label : 'Daily 24h Cycle';

  // Update Welcome Banner
  const welcomeGreeting = document.getElementById('welcomeGreeting');
  const welcomeSub = document.getElementById('welcomeSub');
  if (welcomeGreeting) welcomeGreeting.textContent = `NRTC ${distName} Field Operations Overview 📹`;
  if (welcomeSub) {
    welcomeSub.innerHTML = `Daily surveillance infrastructure readiness and field logs for ${distName} District. <span style="display:inline-block; margin-top:4px; padding:3px 10px; border-radius:6px; font-weight:700; font-size:11px; ${isCycleReceived ? 'background:#d1fae5; color:#065f46; border:1px solid #a7f3d0;">✓ 24h Cycle Report Received (' + cycleLabel + ')' : 'background:#fef3c7; color:#92400e; border:1px solid #fde68a;">◷ 24h Cycle Report Pending (Deadline: 12:00 AM Midnight)'}</span>`;
  }

  // Sort reports newest first
  reports.sort((a, b) => new Date(b.report_date) - new Date(a.report_date));
  const latestReport = reports[0] || null;

  // Resolve district equipment baseline
  const distInfo = (window.PUNJAB_DISTRICTS || []).find(d => d.id === distId || d.name.toLowerCase() === distId.toLowerCase()) || {
    baseIpnw: 90, baseCee: 20, baseDee: 10, baseWifi: 15
  };

  const ipnvInstalled = latestReport ? (latestReport.ipnv_installed || distInfo.baseIpnw) : distInfo.baseIpnw;
  const ipnvOnline = latestReport ? (latestReport.ipnv_online || ipnvInstalled) : ipnvInstalled;
  const ipnvPct = ipnvInstalled > 0 ? ((ipnvOnline / ipnvInstalled) * 100).toFixed(1) : '100.0';

  const ceeInstalled = latestReport ? (latestReport.cee_installed || distInfo.baseCee) : distInfo.baseCee;
  const ceeOnline = latestReport ? (latestReport.cee_online || ceeInstalled) : ceeInstalled;
  const ceePct = ceeInstalled > 0 ? ((ceeOnline / ceeInstalled) * 100).toFixed(1) : '100.0';

  const deeInstalled = latestReport ? (latestReport.dee_installed || distInfo.baseDee) : distInfo.baseDee;
  const deeOnline = latestReport ? (latestReport.dee_online || deeInstalled) : deeInstalled;
  const deePct = deeInstalled > 0 ? ((deeOnline / deeInstalled) * 100).toFixed(1) : '100.0';

  const wifiInstalled = latestReport ? (latestReport.wifi_installed || distInfo.baseWifi) : distInfo.baseWifi;
  const wifiOnline = latestReport ? (latestReport.wifi_online || wifiInstalled) : wifiInstalled;
  const wifiPct = wifiInstalled > 0 ? ((wifiOnline / wifiInstalled) * 100).toFixed(1) : '100.0';

  const generatorRuntime = latestReport ? (latestReport.generator_runtime || '0.0') : '0.0';

  // Overall Uptime
  const totalInst = ipnvInstalled + ceeInstalled + deeInstalled;
  const totalOnl = ipnvOnline + ceeOnline + deeOnline;
  const overallUptime = totalInst > 0 ? ((totalOnl / totalInst) * 100).toFixed(1) : '99.0';

  // 1. Update KPI Cards in dashboard.html
  const elIpnw = document.getElementById('kpiIpnw');
  const elIpnwPct = document.getElementById('kpiIpnwPct');
  if (elIpnw) elIpnw.textContent = `${ipnvOnline}/${ipnvInstalled}`;
  if (elIpnwPct) elIpnwPct.textContent = `${ipnvPct}% Online`;

  const elCee = document.getElementById('kpiCee');
  const elCeePct = document.getElementById('kpiCeePct');
  if (elCee) elCee.textContent = `${ceeOnline}/${ceeInstalled}`;
  if (elCeePct) elCeePct.textContent = `${ceePct}% Online`;

  const elDee = document.getElementById('kpiDee');
  const elDeePct = document.getElementById('kpiDeePct');
  if (elDee) elDee.textContent = `${deeOnline}/${deeInstalled}`;
  if (elDeePct) elDeePct.textContent = `${deePct}% Operational`;

  const elWifi = document.getElementById('kpiWifi');
  const elWifiPct = document.getElementById('kpiWifiPct');
  if (elWifi) elWifi.textContent = `${wifiOnline}/${wifiInstalled}`;
  if (elWifiPct) elWifiPct.textContent = `${wifiPct}% Active`;

  const elGen = document.getElementById('kpiGenerator');
  if (elGen) elGen.textContent = `${generatorRuntime} h`;

  // 2. Equipment Operational Summary Table
  const elOverallBadge = document.getElementById('dashOverallBadge');
  if (elOverallBadge) elOverallBadge.textContent = `${overallUptime}% Overall Uptime`;

  const equipBody = document.getElementById('dashEquipSummaryBody');
  if (equipBody) {
    equipBody.innerHTML = `
      <tr>
        <td><strong>IPNV Surveillance Cameras</strong></td>
        <td>${ipnvInstalled}</td>
        <td>${ipnvOnline}</td>
        <td><strong>${ipnvPct}%</strong></td>
        <td><span class="status ok">ACTIVE</span></td>
      </tr>
      <tr>
        <td><strong>CEE Perimeter Cameras</strong></td>
        <td>${ceeInstalled}</td>
        <td>${ceeOnline}</td>
        <td><strong>${ceePct}%</strong></td>
        <td><span class="status ok">ACTIVE</span></td>
      </tr>
      <tr>
        <td><strong>DEE &amp; Special Nodes</strong></td>
        <td>${deeInstalled}</td>
        <td>${deeOnline}</td>
        <td><strong>${deePct}%</strong></td>
        <td><span class="status ok">ACTIVE</span></td>
      </tr>
      <tr>
        <td><strong>Public Wi-Fi Access Points</strong></td>
        <td>${wifiInstalled}</td>
        <td>${wifiOnline}</td>
        <td><strong>${wifiPct}%</strong></td>
        <td><span class="status ok">ACTIVE</span></td>
      </tr>
    `;
  }

  // 3. Daily Field Review Section
  const elReportDate = document.getElementById('dashReportDate');
  const elEngName = document.getElementById('dashEngineerName');
  const elEmpId = document.getElementById('dashEmployeeId');
  const elDistName = document.getElementById('dashDistrictName');
  const elStatus = document.getElementById('dashApprovalStatus');
  const elActivity = document.getElementById('dashActivitySummary');
  const elOfc = document.getElementById('dashOfcCut');
  const elRma = document.getElementById('dashRmaCount');

  if (elReportDate) elReportDate.textContent = latestReport ? (latestReport.report_date || 'Today') : 'Today';
  if (elEngName) elEngName.textContent = user.name;
  if (elEmpId) elEmpId.textContent = user.employeeId || `NRTC-${distId.toUpperCase()}`;
  if (elDistName) elDistName.textContent = `${distName} District`;
  if (elStatus) {
    if (isCycleReceived) {
      elStatus.textContent = 'RECEIVED (' + (latestReport ? (latestReport.status || 'SUBMITTED') : 'SUBMITTED') + ')';
      elStatus.className = 'status ok';
    } else {
      elStatus.textContent = 'PENDING (Due 12:00 AM Midnight)';
      elStatus.className = 'status warning';
    }
  }
  if (elActivity && latestReport) elActivity.textContent = latestReport.major_daily_activity || 'Routine surveillance operations across district sites.';
  if (elOfc && latestReport) elOfc.textContent = latestReport.ofc_cut === 'Yes' ? 'Reported Fault' : 'None';
  if (elRma && latestReport) elRma.textContent = latestReport.rma_details && latestReport.rma_details !== 'None.' ? latestReport.rma_details : '0 Devices';

  // 4. Render Recent Reports Table
  const tbody = document.getElementById('userRecentReportsBody');
  if (tbody) {
    tbody.innerHTML = '';
    const recent = reports.slice(0, 5);
    if (recent.length === 0) {
      tbody.innerHTML = '<tr><td colspan="8" style="text-align:center;color:#64748b;padding:26px;">No daily reports submitted yet. Click "＋ Submit Today\'s Report" above to file your first daily report.</td></tr>';
      return;
    }

    recent.forEach(r => {
      const tr = document.createElement('tr');
      tr.innerHTML = `
        <td><strong>${formatDateDisplay(r.report_date)}</strong></td>
        <td>${r.district_name || distName}</td>
        <td><span class="online">${r.ipnv_online || 0} / ${r.ipnv_installed || 0}</span></td>
        <td><span class="online">${r.cee_online || 0} / ${r.cee_installed || 0}</span></td>
        <td><span class="online">${r.wifi_online || 0} / ${r.wifi_installed || 0}</span></td>
        <td>${r.generator_runtime || 0} hrs</td>
        <td><span class="${SafeCityStore.getStatusClass(r.status)}">${SafeCityStore.getStatusLabel(r.status)}</span></td>
        <td>
          <button class="btn btn-sm" onclick="viewReportDetail('${r.id}')">View</button>
        </td>
      `;
      tbody.appendChild(tr);
    });
  }
}

function updateProgressBar(barId, valId, pct) {
  const bar = document.getElementById(barId);
  const val = document.getElementById(valId);
  if (bar) {
    bar.style.width = pct + '%';
    bar.className = pct >= 95 ? 'green' : (pct >= 85 ? 'yellow' : 'red');
  }
  if (val) val.textContent = pct + '%';
}

function render7DayChart(reports) {
  const chartContainer = document.getElementById('user7DayChart');
  if (!chartContainer) return;
  chartContainer.innerHTML = '';

  // Generate past 7 dates
  const days = [];
  for (let i = 6; i >= 0; i--) {
    const d = new Date();
    d.setDate(d.getDate() - i);
    days.push(d.toISOString().split('T')[0]);
  }

  days.forEach(dateStr => {
    const match = reports.find(r => r.report_date === dateStr);
    const overall = match ? SafeCityStore.getDistrictOverallUptime(match) : 0;
    const heightPct = match ? Math.max(10, overall) : 8;
    const color = !match ? '#cbd5e1' : (overall >= 95 ? '#1f5eff' : (overall >= 85 ? '#d98b00' : '#d64545'));

    const dObj = new Date(dateStr);
    const label = dObj.toLocaleDateString('en-GB', { day: 'numeric', month: 'short' });

    const wrap = document.createElement('div');
    wrap.className = 'bar-wrap';
    wrap.innerHTML = `
      <div class="bar" style="height:${heightPct}%; background:${color}" title="${label}: ${match ? overall + '%' : 'No Report'}"></div>
      <div class="bar-label">${label}</div>
    `;
    chartContainer.appendChild(wrap);
  });
}

// ==========================================
// Admin / Provincial PMU Dashboard
// ==========================================

function onAdminOverviewDateChange(val) {
  renderAdminDashboard();
}
window.onAdminOverviewDateChange = onAdminOverviewDateChange;

function resetAdminOverviewDate() {
  const dateInput = document.getElementById('adminFilterDate');
  if (dateInput) {
    dateInput.value = '';
  }
  renderAdminDashboard();
}
window.resetAdminOverviewDate = resetAdminOverviewDate;

function renderAdminDashboard() {
  const dateInput = document.getElementById('adminFilterDate');
  const filterDateVal = dateInput ? dateInput.value : '';

  // Calculate 24-hour cycle status dynamically
  const cycleStatus = (window.store && typeof window.store.getDailyReportingStatus === 'function')
    ? window.store.getDailyReportingStatus({ date: filterDateVal })
    : {
        cycle: { label: 'Live 24h Cycle', date: filterDateVal || new Date().toISOString().split('T')[0] },
        summary: { totalExpected: 37, received: 0, pending: 37, complianceRate: 0 },
        users: [],
        receivedReports: []
      };

  // Synchronize date input if it was empty
  if (dateInput && !dateInput.value && cycleStatus.cycle && cycleStatus.cycle.date) {
    dateInput.value = cycleStatus.cycle.date;
  }

  // Update Cycle Banner & Badges
  const cycleLabelEl = document.getElementById('adminCycleWindowLabel');
  if (cycleLabelEl) {
    cycleLabelEl.innerHTML = `24-Hour Reporting Cycle: <b>${cycleStatus.cycle.label}</b> (Cycle Date: ${cycleStatus.cycle.date})`;
  }
  const cycleBadgeEl = document.getElementById('adminCycleBadge');
  if (cycleBadgeEl) {
    const isToday = cycleStatus.cycle.date === new Date().toISOString().split('T')[0];
    cycleBadgeEl.textContent = isToday ? 'Live Active Cycle' : `Cycle: ${cycleStatus.cycle.date}`;
    cycleBadgeEl.style.background = isToday ? '#1d4ed8' : '#475569';
  }

  const totalExpected = cycleStatus.summary.totalExpected;
  const submittedCount = cycleStatus.summary.received;
  const pendingCount = cycleStatus.summary.pending;
  const activeReports = cycleStatus.receivedReports || [];

  // Compute Provincial Average Uptime strictly from form data that users submitted in this cycle
  let sumUptime = 0;
  if (activeReports.length > 0) {
    activeReports.forEach(r => {
      sumUptime += SafeCityStore.getDistrictOverallUptime(r);
    });
  }
  const avgUptime = activeReports.length > 0 ? (sumUptime / activeReports.length).toFixed(1) : '98.4';

  // Count active OFC cuts reported in this cycle
  const ofcCutsToday = activeReports.filter(r => r.ofc_cut === 'Yes' || (r.ofc_cut && r.ofc_cut !== 'No' && r.ofc_cut !== 'All OFC Route is ok' && r.ofc_cut !== 'N/A' && r.ofc_cut !== 'all ok')).length;

  // Update Admin KPIs
  const kpiTotalDist = document.getElementById('adminKpiTotalDistricts');
  const kpiSubmitted = document.getElementById('adminKpiSubmitted');
  const kpiPending = document.getElementById('adminKpiPending');
  const kpiAvgUptime = document.getElementById('adminKpiAvgUptime');
  const kpiOfcCuts = document.getElementById('adminKpiOfcCuts');

  if (kpiTotalDist) kpiTotalDist.textContent = totalExpected;
  if (kpiSubmitted) kpiSubmitted.textContent = submittedCount;
  if (kpiPending) kpiPending.textContent = pendingCount;
  if (kpiAvgUptime) kpiAvgUptime.textContent = avgUptime + '%';
  if (kpiOfcCuts) kpiOfcCuts.textContent = ofcCutsToday;

  const kpiExpectedTrend = document.getElementById('adminKpiExpectedTrend');
  if (kpiExpectedTrend) kpiExpectedTrend.textContent = `${totalExpected} Active District Engineers`;

  const kpiReceivedTrend = document.getElementById('adminKpiReceivedTrend');
  if (kpiReceivedTrend) kpiReceivedTrend.textContent = `${cycleStatus.summary.complianceRate}% Compliance Rate`;

  const kpiPendingTrend = document.getElementById('adminKpiPendingTrend');
  if (kpiPendingTrend) kpiPendingTrend.textContent = `Deadline: 12:00 AM (Midnight)`;

  const kpiOfcTrend = document.getElementById('adminKpiOfcTrend');
  if (kpiOfcTrend) kpiOfcTrend.textContent = ofcCutsToday > 0 ? `${ofcCutsToday} Active Incidents` : 'Zero Faults Reported';

  // Render Punjab summary progress meters
  const compliantPct = cycleStatus.summary.complianceRate;
  updateProgressBar('adminProgressSubmission', 'adminValSubmission', compliantPct);
  updateProgressBar('adminProgressUptime', 'adminValUptime', parseFloat(avgUptime));

  // Update table title on admin overview
  const tableTitle = document.getElementById('adminOverviewTableTitle');
  const tableSub = document.getElementById('adminOverviewTableSubtitle');
  if (tableTitle) {
    tableTitle.textContent = `Consolidated Submissions — Cycle: ${cycleStatus.cycle.label}`;
  }
  if (tableSub) {
    tableSub.textContent = `Showing ${submittedCount} received of ${totalExpected} expected reports. Deadline: 12:00 AM Midnight.`;
  }

  // Populate adminReportsTableBody for overview
  const tbody = document.getElementById('adminReportsTableBody');
  if (tbody) {
    tbody.innerHTML = '';
    if (activeReports.length === 0) {
      tbody.innerHTML = `<tr><td colspan="9" style="text-align:center;color:#64748b;padding:32px 16px;font-size:13px;">No reports received for reporting cycle <b>${cycleStatus.cycle.label}</b>.<br><span style="font-size:12px; color:#94a3b8;">Pending reports deadline is 12:00 AM (Midnight).</span></td></tr>`;
    } else {
      activeReports.forEach(r => {
        const overallPct = SafeCityStore.getDistrictOverallUptime(r);
        const ipnvPct = SafeCityStore.calculatePercentage(r.ipnv_online, r.ipnv_installed);
        const ceePct = SafeCityStore.calculatePercentage(r.cee_online, r.cee_installed);
        const hasOfc = r.ofc_cut === 'Yes' || (r.ofc_cut && r.ofc_cut !== 'No' && r.ofc_cut !== 'All OFC Route is ok' && r.ofc_cut !== 'N/A' && r.ofc_cut !== 'all ok');

        const tr = document.createElement('tr');
        tr.innerHTML = `
          <td><strong>${formatDateDisplay(r.report_date)}</strong><br><small style="color:#64748b;">${r.submitted_at ? r.submitted_at.split(' ')[1] || '' : ''}</small></td>
          <td><strong>${r.district_name || r.city}</strong><br><small style="color:#64748b">${r.user_name || (r.email ? r.email.split('@')[0] : 'Officer')}</small></td>
          <td><span class="online">${r.ipnv_online || 0} / ${r.ipnv_installed || 0}</span> <small>(${ipnvPct}%)</small></td>
          <td><span class="online">${r.cee_online || 0} / ${r.cee_installed || 0}</span> <small>(${ceePct}%)</small></td>
          <td><strong>${overallPct}%</strong></td>
          <td>${hasOfc ? '<span class="status danger" title="' + (r.ofc_cut || 'OFC Cut') + '">OFC CUT</span>' : '<span style="color:#149447">Normal</span>'}</td>
          <td>${r.generator_runtime || 0} hrs</td>
          <td><span class="${SafeCityStore.getStatusClass(r.status)}">${SafeCityStore.getStatusLabel(r.status)}</span></td>
          <td style="white-space:nowrap;">
            <button class="btn btn-sm" onclick="openReportDetailModal('${r.id}')">Inspect</button>
            <button class="btn btn-sm" onclick="printReportById('${r.id}')" title="Print Official PDF">🖶</button>
          </td>
        `;
        tbody.appendChild(tr);
      });
    }
  }
}

// ==========================================
// All District Sites Report Filtering, Pagination & Export
// ==========================================
let adminReportsCurrentPage = 1;
const adminReportsPageSize = 50;
let adminReportsFilteredList = [];
let adminFilterDebounceTimer = null;

function normalizeReportDateStr(dStr) {
  if (!dStr) return '';
  dStr = String(dStr).trim();
  const dmyMatch = dStr.match(/^(\d{1,2})[-\/](\d{1,2})[-\/](\d{4})$/);
  if (dmyMatch) {
    const day = dmyMatch[1].padStart(2, '0');
    const month = dmyMatch[2].padStart(2, '0');
    const year = dmyMatch[3];
    return `${year}-${month}-${day}`;
  }
  const ymdMatch = dStr.match(/^(\d{4})[-\/](\d{1,2})[-\/](\d{1,2})$/);
  if (ymdMatch) {
    const year = ymdMatch[1];
    const month = ymdMatch[2].padStart(2, '0');
    const day = ymdMatch[3].padStart(2, '0');
    return `${year}-${month}-${day}`;
  }
  return dStr;
}

function getAdminReportFilterParams() {
  const distEl = document.getElementById('adminFilterDistrict');
  const siteEl = document.getElementById('adminFilterSite');
  const fromEl = document.getElementById('adminFilterFromDate') || document.getElementById('adminFilterDate');
  const toEl = document.getElementById('adminFilterToDate');
  const statusEl = document.getElementById('adminFilterStatus');
  const searchEl = document.getElementById('adminFilterSearch') || document.getElementById('adminTableSearch');

  const params = {};
  if (distEl && distEl.value && distEl.value !== 'all') params.district = distEl.value;
  if (siteEl && siteEl.value && siteEl.value.trim() !== '') params.site = siteEl.value.trim();
  if (fromEl && fromEl.value) params.fromDate = normalizeReportDateStr(fromEl.value);
  if (toEl && toEl.value) params.toDate = normalizeReportDateStr(toEl.value);
  if (statusEl && statusEl.value && statusEl.value !== 'all') params.status = statusEl.value;
  if (searchEl && searchEl.value && searchEl.value.trim() !== '') params.search = searchEl.value.trim();

  return params;
}

async function updateAdminSitesDropdown(districtId) {
  const siteSelect = document.getElementById('adminFilterSite');
  const datalist = document.getElementById('adminSitesDatalist');
  if (!siteSelect && !datalist) return;

  try {
    let sites = [];
    if (window.api && typeof window.api.getSites === 'function') {
      const q = (districtId && districtId !== 'all') ? { district: districtId } : {};
      sites = await window.api.getSites(q);
    }
    if (!sites || sites.length === 0) {
      const res = await fetch('data/sites.json');
      sites = await res.json();
      if (districtId && districtId !== 'all') {
        const dClean = districtId.toLowerCase().replace(/[^a-z0-9]/g, '');
        sites = sites.filter(s => {
          const c = (s.city || '').toLowerCase().replace(/[^a-z0-9]/g, '');
          const d = (s.district_id || '').toLowerCase().replace(/[^a-z0-9]/g, '');
          return c === dClean || d === dClean || c.includes(dClean) || dClean.includes(c);
        });
      }
    }

    // Sort sites naturally by spot ID
    sites.sort((a, b) => (a.spotId || '').localeCompare(b.spotId || '', undefined, { numeric: true }));

    // 1. Populate <select id="adminFilterSite">
    if (siteSelect && siteSelect.tagName === 'SELECT') {
      const prevVal = siteSelect.value;
      siteSelect.innerHTML = '';

      const defaultOpt = document.createElement('option');
      defaultOpt.value = 'all';
      if (districtId && districtId !== 'all') {
        const dObj = window.getDistrictById ? window.getDistrictById(districtId) : null;
        const dName = dObj ? dObj.name : districtId;
        defaultOpt.textContent = `All Sites (${dName} - ${sites.length} sites)`;
      } else {
        defaultOpt.textContent = `All Sites (Punjab Wide - ${sites.length} sites)`;
      }
      siteSelect.appendChild(defaultOpt);

      sites.forEach(s => {
        const opt = document.createElement('option');
        opt.value = s.spotId || s.siteName;
        const cityLabel = (!districtId || districtId === 'all') && s.city ? ` [${s.city}]` : '';
        const typeLabel = s.siteType ? ` (${s.siteType})` : '';
        opt.textContent = `${s.spotId ? s.spotId + ' - ' : ''}${s.siteName || ''}${cityLabel}${typeLabel}`;
        siteSelect.appendChild(opt);
      });

      if (prevVal && prevVal !== 'all' && Array.from(siteSelect.options).some(o => o.value === prevVal)) {
        siteSelect.value = prevVal;
      } else {
        siteSelect.value = 'all';
      }
    }

    // 2. Also populate datalist if it exists (for backward compatibility)
    if (datalist) {
      datalist.innerHTML = '';
      sites.forEach(s => {
        const opt = document.createElement('option');
        opt.value = `${s.spotId || ''} - ${s.siteName || ''}`.trim().replace(/^-\s*/, '');
        datalist.appendChild(opt);
      });
    }
  } catch (err) {
    console.warn('Failed to load sites for dropdown:', err);
  }
}

// Alias for backwards compatibility
const updateAdminSitesDatalist = updateAdminSitesDropdown;

function onAdminDistrictChange() {
  const distEl = document.getElementById('adminFilterDistrict');
  const districtId = distEl ? distEl.value : 'all';
  const siteSelect = document.getElementById('adminFilterSite');
  if (siteSelect) siteSelect.value = 'all';
  updateAdminSitesDropdown(districtId);
  applyAdminReportFilters();
}

function debounceAdminFilter() {
  clearTimeout(adminFilterDebounceTimer);
  adminFilterDebounceTimer = setTimeout(() => {
    applyAdminReportFilters();
  }, 300);
}

function applyAdminReportFilters() {
  adminReportsCurrentPage = 1;
  renderAdminReportsTable();
}

function resetAdminReportFilters() {
  const distEl = document.getElementById('adminFilterDistrict');
  const siteEl = document.getElementById('adminFilterSite');
  const fromEl = document.getElementById('adminFilterFromDate') || document.getElementById('adminFilterDate');
  const toEl = document.getElementById('adminFilterToDate');
  const statusEl = document.getElementById('adminFilterStatus');
  const searchEl = document.getElementById('adminFilterSearch') || document.getElementById('adminTableSearch');

  if (distEl) distEl.value = 'all';
  if (siteEl) siteEl.value = 'all';
  if (fromEl) fromEl.value = '';
  if (toEl) toEl.value = '';
  if (statusEl) statusEl.value = 'all';
  if (searchEl) searchEl.value = '';

  updateAdminSitesDropdown('all');
  adminReportsCurrentPage = 1;
  renderAdminReportsTable();
  if (typeof showToast === 'function') {
    showToast('Report filters have been reset to all records.', 'info');
  }
}

function changeAdminReportsPage(delta) {
  const totalPages = Math.ceil(adminReportsFilteredList.length / adminReportsPageSize) || 1;
  const newPage = adminReportsCurrentPage + delta;
  if (newPage >= 1 && newPage <= totalPages) {
    adminReportsCurrentPage = newPage;
    renderAdminReportsPageRows();
  }
}

function exportAdminReports(format = 'xlsx') {
  const params = getAdminReportFilterParams();
  params.format = format;
  const count = adminReportsFilteredList.length;

  if (count === 0) {
    if (typeof showToast === 'function') {
      showToast('No matching reports found for the selected filters to export.', 'warning');
    } else {
      alert('No matching reports found to export.');
    }
    return;
  }

  const url = window.api ? window.api.getReportsExportUrl(params) : `/api/reports/export?${new URLSearchParams(params).toString()}`;
  if (typeof showToast === 'function') {
    showToast(`Exporting ${count.toLocaleString()} filtered report(s) as ${format.toUpperCase()}...`, 'success');
  }
  window.open(url, '_blank');
}

function renderAdminReportsTable() {
  const tbody = document.getElementById('adminReportsTableBody');
  if (!tbody) return;

  const excludedDistricts = ['lahore', 'rawalpindi', 'faisalabad', 'kasur', 'gujranwala', 'nankana', 'nankana_sahib'];
  const allReports = (window.store.getAllReports() || []).filter(r => !excludedDistricts.includes((r.district_id || '').toLowerCase()));
  const params = getAdminReportFilterParams();

  const norm = s => {
    let x = (s || '').toLowerCase().replace(/[^a-z0-9]/g, '');
    if (x === 'hasanabdal' || x === 'hassanabdal') return 'hassanabdal';
    if (x === 'deraghazikhan' || x === 'dgkhan') return 'deraghazikhan';
    if (x === 'tobateksingh' || x === 'ttsingh') return 'tobateksingh';
    if (x === 'rahimyarkhan' || x === 'ryk') return 'rahimyarkhan';
    return x;
  };

  const dFilter = norm(params.district || 'all');
  const sFilter = (params.site || '').toLowerCase().trim();
  const fromDate = params.fromDate || '';
  const toDate = params.toDate || '';
  const statusFilter = (params.status || 'all').toUpperCase();
  const searchQuery = (params.search || '').toLowerCase().trim();

  let filtered = allReports.filter(r => {
    // District filter
    if (dFilter && dFilter !== 'all') {
      const dId = norm(r.district_id);
      const dName = norm(r.district_name);
      const city = norm(r.city);
      if (dId !== dFilter && dName !== dFilter && city !== dFilter &&
          !dId.includes(dFilter) && !dName.includes(dFilter) && !city.includes(dFilter)) {
        return false;
      }
    }

    // Site filter
    if (sFilter) {
      const hay = [
        r.city,
        r.district_name,
        r.major_daily_activity,
        r.ipnv_offline_reason,
        r.dee_offline_reason,
        r.rma_details,
        r.ofc_cut
      ].filter(Boolean).join(' ').toLowerCase();
      if (!hay.includes(sFilter)) return false;
    }

    // Date range filter
    const repDate = normalizeReportDateStr(r.report_date);
    if (fromDate && repDate < fromDate) return false;
    if (toDate && repDate > toDate) return false;

    // Status filter
    if (statusFilter && statusFilter !== 'ALL') {
      const curStatus = (r.status || '').toUpperCase();
      if (statusFilter === 'SUBMITTED') {
        if (curStatus !== 'SUBMITTED' && curStatus !== 'PENDING') return false;
      } else if (curStatus !== statusFilter) {
        return false;
      }
    }

    // Search query filter
    if (searchQuery) {
      const hay = [
        r.id,
        r.district_name,
        r.city,
        r.user_name,
        r.email,
        r.report_date,
        r.major_daily_activity,
        r.ipnv_offline_reason,
        r.dee_offline_reason,
        r.rma_details,
        r.ofc_cut,
        r.admin_remarks
      ].filter(Boolean).join(' ').toLowerCase();
      if (!hay.includes(searchQuery)) return false;
    }

    return true;
  });

  filtered.sort((a, b) => new Date(b.report_date) - new Date(a.report_date));
  adminReportsFilteredList = filtered;

  // Update Match Count Text
  const countEl = document.getElementById('adminReportsCountText');
  if (countEl) {
    countEl.textContent = `Showing ${filtered.length.toLocaleString()} reports`;
  }

  // Ensure current page is valid
  const totalPages = Math.ceil(filtered.length / adminReportsPageSize) || 1;
  if (adminReportsCurrentPage > totalPages) adminReportsCurrentPage = 1;

  renderAdminReportsPageRows();
}

function renderAdminReportsPageRows() {
  const tbody = document.getElementById('adminReportsTableBody');
  if (!tbody) return;

  const filtered = adminReportsFilteredList;
  tbody.innerHTML = '';

  if (filtered.length === 0) {
    tbody.innerHTML = '<tr><td colspan="9" style="text-align:center;color:#64748b;padding:32px 16px;font-size:14px;">No matching daily reports found for this filter criteria.<br><button class="btn btn-sm btn-secondary" onclick="resetAdminReportFilters()" style="margin-top:8px;">Clear Filters</button></td></tr>';
    updateAdminReportsPaginationUI(0, 0, 0, 1);
    return;
  }

  const totalPages = Math.ceil(filtered.length / adminReportsPageSize) || 1;
  const startIdx = (adminReportsCurrentPage - 1) * adminReportsPageSize;
  const endIdx = Math.min(startIdx + adminReportsPageSize, filtered.length);
  const pageItems = filtered.slice(startIdx, endIdx);

  pageItems.forEach(r => {
    const overallPct = SafeCityStore.getDistrictOverallUptime(r);
    const ipnvPct = SafeCityStore.calculatePercentage(r.ipnv_online, r.ipnv_installed);
    const ceePct = SafeCityStore.calculatePercentage(r.cee_online, r.cee_installed);
    const hasOfc = r.ofc_cut === 'Yes' || (r.ofc_cut && r.ofc_cut !== 'No' && r.ofc_cut !== 'All OFC Route is ok' && r.ofc_cut !== 'N/A' && r.ofc_cut !== 'all ok');

    const tr = document.createElement('tr');
    tr.innerHTML = `
      <td><strong>${formatDateDisplay(r.report_date)}</strong></td>
      <td><strong>${r.district_name || r.city}</strong><br><small style="color:#64748b">${r.user_name || (r.email ? r.email.split('@')[0] : 'Officer')}</small></td>
      <td><span class="online">${r.ipnv_online || 0} / ${r.ipnv_installed || 0}</span> <small>(${ipnvPct}%)</small></td>
      <td><span class="online">${r.cee_online || 0} / ${r.cee_installed || 0}</span> <small>(${ceePct}%)</small></td>
      <td><strong>${overallPct}%</strong></td>
      <td>${hasOfc ? '<span class="status danger" title="' + (r.ofc_cut || 'OFC Cut') + '">OFC CUT</span>' : '<span style="color:#149447">Normal</span>'}</td>
      <td>${r.generator_runtime || 0} hrs</td>
      <td><span class="${SafeCityStore.getStatusClass(r.status)}">${SafeCityStore.getStatusLabel(r.status)}</span></td>
      <td style="white-space:nowrap;">
        <button class="btn btn-sm" onclick="openReportDetailModal('${r.id}')">Inspect</button>
        <button class="btn btn-sm" onclick="printReportById('${r.id}')" title="Print Official PDF">🖶</button>
      </td>
    `;
    tbody.appendChild(tr);
  });

  updateAdminReportsPaginationUI(startIdx + 1, endIdx, filtered.length, totalPages);
}

function updateAdminReportsPaginationUI(start, end, total, totalPages) {
  const pagInfo = document.getElementById('paginationInfo');
  const btnPrev = document.getElementById('btnPrevReportsPage');
  const btnNext = document.getElementById('btnNextReportsPage');

  if (pagInfo) {
    if (total === 0) {
      pagInfo.textContent = 'Page 0 of 0 (0 reports)';
    } else {
      pagInfo.textContent = `Page ${adminReportsCurrentPage} of ${totalPages} (Showing ${start}–${end} of ${total.toLocaleString()} reports)`;
    }
  }
  if (btnPrev) btnPrev.disabled = (adminReportsCurrentPage <= 1);
  if (btnNext) btnNext.disabled = (adminReportsCurrentPage >= totalPages || total === 0);
}

// ==========================================
// All 37 Districts Directory & Matrix
// ==========================================

let matrixSearchQuery = '';
let matrixAllSites = [];

function filterDistrictsMatrix(query) {
  matrixSearchQuery = (query || '').toLowerCase().trim();
  renderDistrictsMatrix();
}

async function initDistrictsMatrixPage() {
  renderDistrictsMatrix();
  if (!matrixAllSites || matrixAllSites.length === 0) {
    try {
      if (window.api && typeof window.api.getSites === 'function') {
        matrixAllSites = await window.api.getSites();
      } else {
        const res = await fetch('data/sites.json');
        matrixAllSites = await res.json();
      }
      renderDistrictsMatrix();
    } catch (err) {
      console.warn('Failed to load sites for district cards', err);
    }
  }
}

function renderDistrictsMatrix() {
  const container = document.getElementById('districtsMatrixGrid') || document.getElementById('districtsMatrixContainer');
  if (!container) return;

  const user = (window.api && window.api.getCurrentUser()) || (window.appState && window.appState.currentUser);
  const isDistrictUser = user && user.role === 'DISTRICT_USER';

  const excludedDistricts = ['lahore', 'rawalpindi', 'faisalabad', 'kasur', 'gujranwala', 'nankana', 'nankana_sahib'];
  const allReports = (window.store ? window.store.getAllReports() : []).filter(r => !excludedDistricts.includes((r.district_id || '').toLowerCase()));
  const allUsers = window.store ? window.store.getUsers() : [];

  // Get current 24-hour reporting cycle status
  const cycleStatus = (window.store && typeof window.store.getDailyReportingStatus === 'function')
    ? window.store.getDailyReportingStatus()
    : null;

  const cycleUserMap = new Map();
  if (cycleStatus && Array.isArray(cycleStatus.users)) {
    cycleStatus.users.forEach(u => {
      const k1 = (u.districtId || '').toLowerCase().replace(/[^a-z0-9]/g, '');
      const k2 = (u.districtName || '').toLowerCase().replace(/[^a-z0-9]/g, '');
      if (k1) cycleUserMap.set(k1, u);
      if (k2) cycleUserMap.set(k2, u);
    });
  }

  let districts = (window.PUNJAB_DISTRICTS || []).slice();

  // If District User, restrict to their district
  if (isDistrictUser) {
    const target = (user.districtId || '').toLowerCase().replace(/[^a-z0-9]/g, '');
    const targetName = (user.districtName || '').toLowerCase().replace(/[^a-z0-9]/g, '');
    districts = districts.filter(d => {
      const dId = (d.id || '').toLowerCase().replace(/[^a-z0-9]/g, '');
      const dName = (d.name || '').toLowerCase().replace(/[^a-z0-9]/g, '');
      return dId === target || dName === targetName || dId === targetName || dName === target;
    });
  }

  // Filter by search query only (Search: Chakwal -> Chakwal; Search: Wazirabad -> Wazirabad)
  const q = (matrixSearchQuery || '').toLowerCase().trim();
  if (q) {
    districts = districts.filter(d => {
      const name = (d.name || '').toLowerCase();
      const id = (d.id || '').toLowerCase();
      const normName = name.replace(/[^a-z0-9]/g, '');
      const normQ = q.replace(/[^a-z0-9]/g, '');
      return name.includes(q) || id.includes(q) || normName.includes(normQ);
    });
  }

  container.innerHTML = '';

  if (districts.length === 0) {
    container.innerHTML = `
      <div style="grid-column: 1 / -1; text-align:center; padding:48px 20px; background:#fff; border:1px dashed #cbd5e1; border-radius:12px; color:#64748b;">
        <div style="font-size:32px; margin-bottom:8px;">🔍</div>
        <strong style="font-size:16px; color:#1e293b; display:block;">No district found</strong>
        <p style="font-size:13px; margin-top:4px;">No districts match "${matrixSearchQuery}".</p>
        <button class="btn btn-sm btn-secondary" onclick="const input = document.getElementById('matrixSearchInput'); if (input) input.value=''; filterDistrictsMatrix('');" style="margin-top:12px;">Reset Search</button>
      </div>
    `;
    return;
  }

  districts.forEach(d => {
    const dKey = (d.id || '').toLowerCase().replace(/[^a-z0-9]/g, '');
    const dNameKey = (d.name || '').toLowerCase().replace(/[^a-z0-9]/g, '');
    const cycleInfo = cycleUserMap.get(dKey) || cycleUserMap.get(dNameKey);

    const isReceived = cycleInfo && cycleInfo.status === 'RECEIVED';
    const cycleReport = (cycleInfo && cycleInfo.report) ? cycleInfo.report : null;
    const pastReports = allReports.filter(r => {
      const rDist = (r.district_id || '').toLowerCase().replace(/[^a-z0-9]/g, '');
      const rName = (r.district_name || '').toLowerCase().replace(/[^a-z0-9]/g, '');
      return rDist === dKey || rName === dNameKey;
    }).sort((a,b) => new Date(b.report_date) - new Date(a.report_date));
    const rep = cycleReport || pastReports[0];

    const uptime = rep ? (SafeCityStore.getDistrictOverallUptime ? SafeCityStore.getDistrictOverallUptime(rep) : (rep.uptime_percent || '97.5')) : (isReceived ? '98.5' : '96.0');
    const statusText = isReceived ? 'RECEIVED' : 'PENDING';
    const badgeClass = isReceived ? 'status ok' : 'status warning';
    const statusTooltip = isReceived
      ? `Report received for 24h cycle (${cycleInfo.submittedAt || ''})`
      : `Pending daily report submission. Deadline: 12:00 AM (Midnight)`;

    const totalCams = (d.baseIpnw || 0) + (d.baseCee || 0) + (d.baseDee || 0);
    const assignedUser = allUsers.find(u => {
      const uDist = (u.districtId || '').toLowerCase().replace(/[^a-z0-9]/g, '');
      const uName = (u.districtName || '').toLowerCase().replace(/[^a-z0-9]/g, '');
      return uDist === dKey || uName === dNameKey;
    });
    const adminName = (cycleInfo && cycleInfo.name) || (assignedUser ? assignedUser.name : `${d.name} District Admin`);

    const uptimeNum = parseFloat(uptime);
    const uptimeColor = uptimeNum >= 95 ? '#10b981' : (uptimeNum >= 88 ? '#f59e0b' : '#ef4444');

    // Count actual deployed sites for this district from matrixAllSites
    const deployedSites = matrixAllSites.filter(s => {
      const c = (s.city || s.district || '').toLowerCase().replace(/[^a-z0-9]/g, '');
      const target = d.id.toLowerCase().replace(/[^a-z0-9]/g, '');
      const targetName = d.name.toLowerCase().replace(/[^a-z0-9]/g, '');
      return c === target || c === targetName || c.includes(target) || target.includes(c);
    });

    const siteCountDisplay = deployedSites.length > 0 ? deployedSites.length : (d.baseIpnw ? Math.round(d.baseIpnw / 4) : 25);

    const card = document.createElement('div');
    card.className = 'district-card';
    card.style.cursor = 'pointer';
    card.title = `Click to view all sites, cameras & reports for ${d.name} District`;
    card.onclick = () => {
      window.location.href = `district-detail.html?id=${encodeURIComponent(d.id)}`;
    };

    card.innerHTML = `
      <div>
        <div class="district-card-head">
          <div>
            <div class="district-card-title">${d.name}</div>
            <span class="district-card-subtitle" style="color:#2563eb; font-weight:600;">Safe City Command Hub</span>
          </div>
          <span class="${badgeClass}" title="${statusTooltip}">● ${statusText}</span>
        </div>

        <div style="display:flex; justify-content:space-between; align-items:flex-end; margin: 12px 0 14px 0;">
          <div>
            <div style="font-size:11px; font-weight:700; color:#64748b; text-transform:uppercase; letter-spacing:0.5px;">Fleet Availability</div>
            <div class="district-card-metric" style="color: ${uptimeColor};">${uptime}%</div>
          </div>
          <div style="text-align:right;">
            <span style="font-size:11px; color:#10b981; font-weight:700;">${siteCountDisplay} Sites Deployed</span>
            <div style="font-size:10px; color:#94a3b8;">${isReceived ? '✓ Cycle Completed' : '◷ Due 12:00 AM'}</div>
          </div>
        </div>

        <div style="display:grid; grid-template-columns: repeat(2, 1fr); gap:6px; margin-bottom:14px;">
          <div class="district-equipment-pill">🎥 <b>${d.baseIpnw || 0}</b> IPNV Fixed</div>
          <div class="district-equipment-pill">📹 <b>${d.baseCee || 0}</b> CEE (ANPR)</div>
          <div class="district-equipment-pill">🛣️ <b>${d.baseDee || 0}</b> DEE Entry</div>
          <div class="district-equipment-pill">📶 <b>${d.baseWifi || 15}</b> WiFi APs</div>
        </div>
      </div>

      <div style="padding-top:12px; border-top:1px solid #f1f5f9; display:flex; justify-content:space-between; align-items:center; font-size:11px; color:#64748b;">
        <div style="overflow:hidden; text-overflow:ellipsis; white-space:nowrap; max-width:160px;" title="${adminName}">
          👤 ${adminName}
        </div>
        <span style="color:#1d4ed8; font-weight:700;">View Profile →</span>
      </div>
    `;
    container.appendChild(card);
  });
}

function exportMatrixSites(format = 'xlsx') {
  const url = `/api/sites/export?format=${encodeURIComponent(format)}`;
  const iframe = document.createElement('iframe');
  iframe.style.display = 'none';
  iframe.src = url;
  document.body.appendChild(iframe);
  setTimeout(() => {
    try { document.body.removeChild(iframe); } catch(e) {}
  }, 4000);
}

// ==========================================
// My Reports View (District User)
// ==========================================

function renderMyReportsTable() {
  const tbody = document.getElementById('userAllReportsBody');
  if (!tbody) return;

  const user = appState.currentUser;
  const reports = window.store.getReportsByDistrict(user.districtId || 'chakwal');
  reports.sort((a, b) => new Date(b.report_date) - new Date(a.report_date));

  const query = document.getElementById('userReportSearch') ? document.getElementById('userReportSearch').value.toLowerCase() : '';

  const filtered = reports.filter(r => {
    if (!query) return true;
    return `${r.report_date} ${r.status} ${r.major_daily_activity} ${r.admin_remarks}`.toLowerCase().includes(query);
  });

  tbody.innerHTML = '';
  if (filtered.length === 0) {
    tbody.innerHTML = '<tr><td colspan="8" style="text-align:center;color:#64748b;padding:24px;">No reports match the search filter.</td></tr>';
    return;
  }

  filtered.forEach(r => {
    const tr = document.createElement('tr');
    tr.innerHTML = `
      <td><strong>${formatDateDisplay(r.report_date)}</strong></td>
      <td>${r.district_name}</td>
      <td><span class="online">${r.ipnv_online} / ${r.ipnv_installed}</span></td>
      <td><span class="online">${r.cee_online} / ${r.cee_installed}</span></td>
      <td><span class="online">${r.wifi_online} / ${r.wifi_installed}</span></td>
      <td>${r.generator_runtime} hrs</td>
      <td><span class="${SafeCityStore.getStatusClass(r.status)}">${SafeCityStore.getStatusLabel(r.status)}</span></td>
      <td style="white-space:nowrap;">
        <button class="btn btn-sm" onclick="openReportDetailModal('${r.id}')">View</button>
        <button class="btn btn-sm" onclick="editReport('${r.id}')" title="Edit / Correct">✏ Edit</button>
        <button class="btn btn-sm" onclick="printReportById('${r.id}')" title="Print Official PDF">🖶</button>
      </td>
    `;
    tbody.appendChild(tr);
  });
}

// ==========================================
// Multi-Step Form Wizard & Live Calculations
// ==========================================

function setupLiveCalculators() {
  // Pairs of [InstalledInputId, OnlineInputId, BadgeId]
  const cameraPairs = [
    { inst: 'ipnvInstalled', onl: 'ipnvOnline', badge: 'badgeCalcIpnv' },
    { inst: 'ceeInstalled', onl: 'ceeOnline', badge: 'badgeCalcCee' },
    { inst: 'deeInstalled', onl: 'deeOnline', badge: 'badgeCalcDee' },
    { inst: 'psInstalled', onl: 'psOnline', badge: 'badgeCalcPs' },
    { inst: 'dcInstalled', onl: 'dcOnline', badge: 'badgeCalcDc' },
    { inst: 'frnvInstalled', onl: 'frnvOnline', badge: 'badgeCalcFrnv' },
    { inst: 'mcrDrInstalled', onl: 'mcrDrOnline', badge: 'badgeCalcMcrDr' },
    { inst: 'wifiInstalled', onl: 'wifiOnline', badge: 'badgeCalcWifi' },
    { inst: 'panicInstalled', onl: 'panicOnline', badge: 'badgeCalcPanic' }
  ];

  cameraPairs.forEach(pair => {
    const elInst = document.getElementById(pair.inst);
    const elOnl = document.getElementById(pair.onl);
    const elBadge = document.getElementById(pair.badge);

    const updateCalc = () => {
      if (!elInst || !elOnl || !elBadge) return;
      const inst = parseInt(elInst.value) || 0;
      const onl = parseInt(elOnl.value) || 0;

      if (onl > inst) {
        elBadge.className = 'calc-badge red';
        elBadge.textContent = 'Invalid: Online > Installed';
        return;
      }

      const pct = SafeCityStore.calculatePercentage(onl, inst);
      const offline = Math.max(0, inst - onl);

      elBadge.textContent = `${pct}% (${offline} Offline)`;
      elBadge.className = `calc-badge ${pct >= 95 ? 'green' : (pct >= 85 ? 'yellow' : 'red')}`;
    };

    if (elInst) elInst.addEventListener('input', updateCalc);
    if (elOnl) elOnl.addEventListener('input', updateCalc);
  });
}

function resetFormToDistrictDefaults() {
  appState.editingReportId = null;
  appState.currentWizardStep = 1;
  goToWizardStep(1);

  const user = appState.currentUser || window.store.getCurrentUser() || { role: 'DISTRICT_USER', districtId: '', name: 'Site Engineer' };
  const isAdmin = user && user.role === 'ADMIN';
  const distSelect = document.getElementById('formDistrict');
  const distBadge = document.getElementById('formDistrictLockedBadge');
  const distHelp = document.getElementById('formDistrictHelp');

  if (distSelect) {
    if (isAdmin) {
      distSelect.disabled = false;
      if (!distSelect.value || distSelect.value === 'all') {
        distSelect.value = (user.districtId && user.districtId !== 'all') ? user.districtId : 'lahore';
      }
    } else {
      distSelect.value = user.districtId || '';
      distSelect.disabled = true;
    }
  }

  if (distBadge) {
    distBadge.textContent = isAdmin ? ' (Admin: Full Access to All 37 Districts)' : ' (Locked to NRTC Engineer)';
  }
  if (distHelp) {
    distHelp.innerHTML = isAdmin
      ? '🌐 <strong>Provincial PMU Admin Access:</strong> Non-compulsory selection. You have full clearance to file or review reports for all 37 Punjab districts.'
      : '🔒 NRTC Field Scope: Deputed site cannot be altered.';
  }

  const selectedDistId = (distSelect && distSelect.value) ? distSelect.value : (user.districtId || 'lahore');
  const dist = window.getDistrictById(selectedDistId) || { baseIpnw: 90, baseCee: 20, baseDee: 10, baseWifi: 15 };

  const setVal = (id, val) => {
    const el = document.getElementById(id);
    if (el) el.value = val;
  };

  setVal('reportDate', new Date().toISOString().split('T')[0]);
  setVal('formReportingOfficer', user.name || 'Site Engineer');
  setVal('formEmployeeId', user.employeeId || user.empId || '');
  setVal('formOfficerDesignation', user.designation || (isAdmin ? 'NRTC Safe City PMU Director' : 'District In-Charge'));

  // Step 2 Cameras
  setVal('ipnvInstalled', dist.baseIpnw || 90);
  setVal('ipnvOnline', Math.floor((dist.baseIpnw || 90) * 0.97));
  setVal('ceeInstalled', dist.baseCee || 20);
  setVal('ceeOnline', Math.floor((dist.baseCee || 20) * 0.95));
  setVal('deeInstalled', dist.baseDee || 10);
  setVal('deeOnline', dist.baseDee || 10);
  setVal('psInstalled', 12);
  setVal('psOnline', 12);
  setVal('dcInstalled', 8);
  setVal('dcOnline', 8);
  setVal('frnvInstalled', 12);
  setVal('frnvOnline', 11);
  setVal('mcrDrInstalled', 4);
  setVal('mcrDrOnline', 4);

  // Step 3 Other
  setVal('wifiInstalled', dist.baseWifi || 15);
  setVal('wifiOnline', Math.max(0, (dist.baseWifi || 15) - 1));
  setVal('panicInstalled', 6);
  setVal('panicOnline', 6);
  setVal('environmentalInstalled', 4);
  setVal('environmentalOnline', 4);
  setVal('biometricInstalled', 5);
  setVal('biometricOnline', 5);

  // Step 4 Faults
  setVal('ipnvOfflineReason', '');
  setVal('ceeOfflineReason', '');
  setVal('psOfflineReason', '');
  setVal('rmaDetails', '');
  const ofcCutNoEl = document.getElementById('ofcCutNo');
  if (ofcCutNoEl) ofcCutNoEl.checked = true;
  toggleOfcFields(false);
  setVal('ofcLocation', '');
  setVal('ofcType', 'None');
  setVal('ofcDetails', '');

  // Step 5 Generator & Activity
  setVal('generatorRuntime', '5.0');
  setVal('majorDailyActivity', 'Routine surveillance coverage across key sensitive locations, markets, and traffic intersections.');
  setVal('otherIssues', '');

  // Dynamic listener: if admin chooses another district, refresh base defaults
  if (distSelect && !distSelect.hasAttribute('data-admin-listener')) {
    distSelect.setAttribute('data-admin-listener', 'true');
    distSelect.addEventListener('change', () => {
      if (appState.editingReportId) return;
      const targetDist = window.getDistrictById(distSelect.value);
      if (targetDist) {
        setVal('ipnvInstalled', targetDist.baseIpnw);
        setVal('ipnvOnline', Math.floor(targetDist.baseIpnw * 0.97));
        setVal('ceeInstalled', targetDist.baseCee);
        setVal('ceeOnline', Math.floor(targetDist.baseCee * 0.95));
        setVal('deeInstalled', targetDist.baseDee);
        setVal('deeOnline', targetDist.baseDee);
        setVal('wifiInstalled', targetDist.baseWifi);
        setVal('wifiOnline', Math.max(0, targetDist.baseWifi - 1));
        document.querySelectorAll('#step-pane-2 input, #step-pane-3 input').forEach(input => {
          input.dispatchEvent(new Event('input'));
        });
      }
    });
  }

  // Trigger calculations
  document.querySelectorAll('#step-pane-2 input, #step-pane-3 input').forEach(input => {
    input.dispatchEvent(new Event('input'));
  });
}

function toggleOfcFields(show) {
  const sec = document.getElementById('ofcDetailsSection');
  if (sec) sec.style.display = show ? 'block' : 'none';
}

function wizardNext() {
  if (validateCurrentStep(appState.currentWizardStep)) {
    if (appState.currentWizardStep < 6) {
      goToWizardStep(appState.currentWizardStep + 1);
    }
  }
}

function wizardPrev() {
  if (appState.currentWizardStep > 1) {
    goToWizardStep(appState.currentWizardStep - 1);
  }
}

function goToWizardStep(stepNum) {
  appState.currentWizardStep = stepNum;

  // Update Progress Track Bar
  const pct = ((stepNum - 1) / 5) * 100;
  const bar = document.getElementById('wizardProgressBar');
  if (bar) bar.style.width = pct + '%';

  // Update step indicators
  for (let i = 1; i <= 6; i++) {
    const stepEl = document.getElementById(`step-node-${i}`);
    if (stepEl) {
      stepEl.classList.toggle('active', i === stepNum);
      stepEl.classList.toggle('completed', i < stepNum);
    }

    const paneEl = document.getElementById(`step-pane-${i}`);
    if (paneEl) {
      paneEl.classList.toggle('active', i === stepNum);
    }
  }

  if (stepNum === 6) {
    populateStep6Review();
  }

  if (typeof window !== 'undefined' && typeof window.scrollTo === 'function') {
    window.scrollTo({ top: 120, behavior: 'smooth' });
  }
}

function validateCurrentStep(step) {
  if (step === 1) {
    const dt = document.getElementById('reportDate').value;
    if (!dt) {
      showToast('Please select the report date.', 'error');
      return false;
    }
  }

  if (step === 2) {
    const ipnvInst = parseInt(document.getElementById('ipnvInstalled').value) || 0;
    const ipnvOnl = parseInt(document.getElementById('ipnvOnline').value) || 0;
    if (ipnvOnl > ipnvInst) {
      showToast('IPNV Online cameras cannot exceed Installed count.', 'error');
      return false;
    }

    const ceeInst = parseInt(document.getElementById('ceeInstalled').value) || 0;
    const ceeOnl = parseInt(document.getElementById('ceeOnline').value) || 0;
    if (ceeOnl > ceeInst) {
      showToast('CEE Online cameras cannot exceed Installed count.', 'error');
      return false;
    }
  }

  return true;
}

function populateStep6Review() {
  const container = document.getElementById('step6ReviewSummary');
  if (!container) return;

  const user = appState.currentUser || window.store.getCurrentUser() || { name: 'Site Engineer', districtId: '', districtName: 'Assigned District' };
  const getVal = (id, fallback = '') => {
    const el = document.getElementById(id);
    return el ? el.value : fallback;
  };
  const isChecked = (id) => {
    const el = document.getElementById(id);
    return el ? Boolean(el.checked) : false;
  };

  const dt = getVal('reportDate', new Date().toISOString().split('T')[0]);
  const formDistSel = document.getElementById('formDistrict');
  const selectedDistId = formDistSel ? formDistSel.value : user.districtId;
  const distObj = (window.getDistrictById ? window.getDistrictById(selectedDistId) : null) || { name: user.districtName || 'All Districts' };
  const distName = distObj.name;

  const ipnvInst = getVal('ipnvInstalled', '90');
  const ipnvOnl = getVal('ipnvOnline', '88');
  const ipnvPct = SafeCityStore.calculatePercentage(ipnvOnl, ipnvInst);

  const ceeInst = getVal('ceeInstalled', '20');
  const ceeOnl = getVal('ceeOnline', '19');
  const ceePct = SafeCityStore.calculatePercentage(ceeOnl, ceeInst);

  const psInst = getVal('psInstalled', '12');
  const psOnl = getVal('psOnline', '12');

  const dcInst = getVal('dcInstalled', '8');
  const dcOnl = getVal('dcOnline', '8');

  const wifiInst = getVal('wifiInstalled', '15');
  const wifiOnl = getVal('wifiOnline', '14');

  const hasOfc = isChecked('ofcCutYes');
  const genHours = getVal('generatorRuntime', '5.0');
  const activities = getVal('majorDailyActivity', 'Routine surveillance coverage across key sensitive locations, markets, and traffic intersections.');

  container.innerHTML = `
    <div style="background:#f8fafc; border:1px solid #e2e8f0; border-radius:8px; padding:18px; margin-bottom:15px;">
      <h4 style="margin-bottom:10px; color:#1e293b;">Submission Overview: ${distName} (${dt})</h4>
      <div style="display:grid; grid-template-columns:repeat(2, 1fr); gap:10px; font-size:12px;">
        <div><strong>Reporting Officer:</strong> ${getVal('formReportingOfficer', user.name)}</div>
        <div><strong>Designation:</strong> ${getVal('formOfficerDesignation', 'NRTC Site Engineer')}</div>
        <div><strong>IPNV Cameras:</strong> ${ipnvOnl} / ${ipnvInst} (${ipnvPct}%)</div>
        <div><strong>CEE Cameras:</strong> ${ceeOnl} / ${ceeInst} (${ceePct}%)</div>
        <div><strong>PS & Dome Units:</strong> ${parseInt(psOnl) + parseInt(dcOnl)} / ${parseInt(psInst) + parseInt(dcInst)}</div>
        <div><strong>WiFi APs:</strong> ${wifiOnl} / ${wifiInst}</div>
        <div><strong>Generator Runtime:</strong> ${genHours} Hours</div>
        <div><strong>OFC Cut Reported:</strong> ${hasOfc ? '<span style="color:#d64545;font-weight:bold;">YES</span>' : '<span style="color:#149447">None</span>'}</div>
        <div><strong>Status:</strong> Ready to transmit as official pending report</div>
      </div>
      <div style="margin-top:12px; font-size:12px;">
        <strong>Daily Activities:</strong>
        <p style="color:#475467; margin-top:3px;">${activities}</p>
      </div>
    </div>
  `;
}

function handleReportFormSubmit(event) {
  if (event && event.preventDefault) event.preventDefault();

  const user = appState.currentUser || window.store.getCurrentUser();
  if (!user) {
    showToast('Session expired. Please log in again.', 'error');
    window.location.replace('login.html');
    return;
  }

  const getVal = (id, fallback = '') => {
    const el = document.getElementById(id);
    return el ? el.value : fallback;
  };
  const getInt = (id, fallback = 0) => {
    const el = document.getElementById(id);
    return el ? (parseInt(el.value, 10) || fallback) : fallback;
  };
  const getFloat = (id, fallback = 0) => {
    const el = document.getElementById(id);
    return el ? (parseFloat(el.value) || fallback) : fallback;
  };
  const isChecked = (id) => {
    const el = document.getElementById(id);
    return el ? Boolean(el.checked) : false;
  };

  const dt = getVal('reportDate');
  if (!dt) {
    showToast('Please select the report date in Step 1.', 'error');
    goToWizardStep(1);
    return;
  }

  const formDistSel = document.getElementById('formDistrict');
  const selectedDistrictId = formDistSel ? formDistSel.value : (user.districtId || 'chakwal');
  const distObj = (window.getDistrictById ? window.getDistrictById(selectedDistrictId) : null) ||
                  (window.getDistrictById ? window.getDistrictById(user.districtId) : null) ||
                  { id: selectedDistrictId || 'chakwal', name: 'District Site' };

  // Validation: Online cameras cannot exceed installed
  const ipnvInst = getInt('ipnvInstalled', 90);
  const ipnvOnl = getInt('ipnvOnline', 88);
  if (ipnvOnl > ipnvInst) {
    showToast('IPNV Online cameras cannot exceed Installed count.', 'error');
    goToWizardStep(2);
    return;
  }

  const ceeInst = getInt('ceeInstalled', 20);
  const ceeOnl = getInt('ceeOnline', 19);
  if (ceeOnl > ceeInst) {
    showToast('CEE Online cameras cannot exceed Installed count.', 'error');
    goToWizardStep(2);
    return;
  }

  const deeInst = getInt('deeInstalled', 10);
  const deeOnl = getInt('deeOnline', 10);
  if (deeOnl > deeInst) {
    showToast('DEE Online checkposts cannot exceed Installed count.', 'error');
    goToWizardStep(2);
    return;
  }

  const reportPayload = {
    id: appState.editingReportId || undefined,
    user_id: user.id,
    user_name: getVal('formReportingOfficer', user.name || 'Site Engineer'),
    employee_id: getVal('formEmployeeId', user.employeeId || 'NRTC-ENG-4182'),
    contractor: 'NRTC',
    district_id: distObj.id,
    district_name: distObj.name,
    report_date: dt,
    status: 'SUBMITTED',

    ipnv_installed: ipnvInst,
    ipnv_online: ipnvOnl,
    cee_installed: ceeInst,
    cee_online: ceeOnl,
    dee_installed: deeInst,
    dee_online: deeOnl,
    ps_installed: getInt('psInstalled', 12),
    ps_online: getInt('psOnline', 12),
    dc_installed: getInt('dcInstalled', 8),
    dc_online: getInt('dcOnline', 8),
    frnv_installed: getInt('frnvInstalled', 12),
    frnv_online: getInt('frnvOnline', 11),
    mcr_dr_installed: getInt('mcrDrInstalled', 4),
    mcr_dr_online: getInt('mcrDrOnline', 4),

    total_cameras_installed: ipnvInst + ceeInst + deeInst + getInt('psInstalled', 12) + getInt('dcInstalled', 8) + getInt('frnvInstalled', 12),
    total_cameras_online: ipnvOnl + ceeOnl + deeOnl + getInt('psOnline', 12) + getInt('dcOnline', 8) + getInt('frnvOnline', 11),
    uptime_percent: SafeCityStore.calculatePercentage(
      ipnvOnl + ceeOnl + deeOnl + getInt('psOnline', 12) + getInt('dcOnline', 8) + getInt('frnvOnline', 11),
      ipnvInst + ceeInst + deeInst + getInt('psInstalled', 12) + getInt('dcInstalled', 8) + getInt('frnvInstalled', 12)
    ),

    wifi_installed: getInt('wifiInstalled', 15),
    wifi_online: getInt('wifiOnline', 14),
    panic_installed: getInt('panicInstalled', 6),
    panic_online: getInt('panicOnline', 6),
    environmental_installed: getInt('environmentalInstalled', 4),
    environmental_online: getInt('environmentalOnline', 4),
    biometric_installed: getInt('biometricInstalled', 5),
    biometric_online: getInt('biometricOnline', 5),

    ipnv_offline_reason: getVal('ipnvOfflineReason', ''),
    cee_offline_reason: getVal('ceeOfflineReason', ''),
    ps_offline_reason: getVal('psOfflineReason', ''),
    dc_offline_reason: '',
    rma_details: getVal('rmaDetails', ''),

    ofc_cut: isChecked('ofcCutYes') ? 'Yes' : 'No',
    ofc_location: getVal('ofcLocation', ''),
    ofc_type: getVal('ofcType', 'None'),
    ofc_details: getVal('ofcDetails', ''),

    generator_runtime: getFloat('generatorRuntime', 0),
    major_daily_activity: getVal('majorDailyActivity', 'Routine surveillance coverage across key sensitive locations and traffic intersections.'),
    other_issues: getVal('otherIssues', '')
  };

  // Provide visual feedback on submit button
  const submitBtn = document.getElementById('btnSubmitDailyReport');
  if (submitBtn) {
    submitBtn.disabled = true;
    submitBtn.textContent = 'Submitting Operations Log... ⏳';
  }

  try {
    const saved = window.store.saveReport(reportPayload);
    appState.editingReportId = null;
    localStorage.removeItem('safecity_editing_report_id');

    showToast(`✓ Operations Log for ${distObj.name} (${dt}) submitted successfully!`, 'success');

    setTimeout(() => {
      if (user.role === 'ADMIN') {
        window.location.href = 'admin-reports.html';
      } else {
        window.location.href = 'reports.html';
      }
    }, 450);
  } catch (err) {
    console.error('Failed to save report:', err);
    showToast('Submission error: ' + (err.message || 'Unknown error'), 'error');
    if (submitBtn) {
      submitBtn.disabled = false;
      submitBtn.textContent = '✓ Submit Daily Operations Log';
    }
  }
}

function editReport(reportId) {
  const rep = window.store.getReportById(reportId);
  if (!rep) return;

  const currentKey = getActivePageKey();
  if (currentKey !== 'submit') {
    localStorage.setItem('safecity_editing_report_id', reportId);
    window.location.href = 'submit-report.html?edit=' + encodeURIComponent(reportId);
    return;
  }

  appState.editingReportId = rep.id;

  const user = appState.currentUser || window.store.getCurrentUser();
  const isAdmin = user && user.role === 'ADMIN';
  const distSelect = document.getElementById('formDistrict');
  const distBadge = document.getElementById('formDistrictLockedBadge');
  const distHelp = document.getElementById('formDistrictHelp');

  if (distSelect) {
    distSelect.value = rep.district_id;
    distSelect.disabled = !isAdmin;
  }
  if (distBadge) {
    distBadge.textContent = isAdmin ? ' (Admin: Full Access to All 37 Districts)' : ' (Locked to NRTC Engineer)';
  }
  if (distHelp) {
    distHelp.innerHTML = isAdmin
      ? '🌐 <strong>Provincial PMU Admin Access:</strong> Non-compulsory selection. You have full clearance to file or review reports for all 37 Punjab districts.'
      : '🔒 NRTC Field Scope: Deputed site cannot be altered.';
  }

  const setVal = (id, val) => {
    const el = document.getElementById(id);
    if (el) el.value = val;
  };

  setVal('reportDate', rep.report_date);
  setVal('formReportingOfficer', rep.user_name || '');
  setVal('formEmployeeId', rep.employee_id || '');

  // Cameras
  setVal('ipnvInstalled', rep.ipnv_installed);
  setVal('ipnvOnline', rep.ipnv_online);
  setVal('ceeInstalled', rep.cee_installed);
  setVal('ceeOnline', rep.cee_online);
  setVal('deeInstalled', rep.dee_installed);
  setVal('deeOnline', rep.dee_online);
  setVal('psInstalled', rep.ps_installed || 0);
  setVal('psOnline', rep.ps_online || 0);
  setVal('dcInstalled', rep.dc_installed || 0);
  setVal('dcOnline', rep.dc_online || 0);
  setVal('frnvInstalled', rep.frnv_installed || 0);
  setVal('frnvOnline', rep.frnv_online || 0);
  setVal('mcrDrInstalled', rep.mcr_dr_installed || 0);
  setVal('mcrDrOnline', rep.mcr_dr_online || 0);

  // Auxiliary
  setVal('wifiInstalled', rep.wifi_installed || 0);
  setVal('wifiOnline', rep.wifi_online || 0);
  setVal('panicInstalled', rep.panic_installed || 0);
  setVal('panicOnline', rep.panic_online || 0);
  setVal('environmentalInstalled', rep.environmental_installed || 0);
  setVal('environmentalOnline', rep.environmental_online || 0);
  setVal('biometricInstalled', rep.biometric_installed || 0);
  setVal('biometricOnline', rep.biometric_online || 0);

  // Faults
  setVal('ipnvOfflineReason', rep.ipnv_offline_reason || '');
  setVal('ceeOfflineReason', rep.cee_offline_reason || '');
  setVal('psOfflineReason', rep.ps_offline_reason || '');
  setVal('rmaDetails', rep.rma_details || '');

  const hasOfc = rep.ofc_cut === 'Yes';
  const ofcCutYes = document.getElementById('ofcCutYes');
  const ofcCutNo = document.getElementById('ofcCutNo');
  if (ofcCutYes) ofcCutYes.checked = hasOfc;
  if (ofcCutNo) ofcCutNo.checked = !hasOfc;
  toggleOfcFields(hasOfc);
  setVal('ofcLocation', rep.ofc_location || '');
  setVal('ofcType', rep.ofc_type || 'None');
  setVal('ofcDetails', rep.ofc_details || '');

  // Generator
  setVal('generatorRuntime', rep.generator_runtime || 0);
  setVal('majorDailyActivity', rep.major_daily_activity || '');
  setVal('otherIssues', rep.other_issues || '');

  // Trigger calculations
  document.querySelectorAll('#step-pane-2 input, #step-pane-3 input').forEach(input => {
    input.dispatchEvent(new Event('input'));
  });

  goToWizardStep(1);
  showToast(`Editing report for ${rep.district_name} (${rep.report_date})`, 'info');
}

// ==========================================
// Modal Inspector & Admin Approval Flow
// ==========================================

let activeModalReportId = null;

function openReportDetailModal(reportId) {
  const rep = window.store.getReportById(reportId);
  if (!rep) return;

  activeModalReportId = reportId;
  const user = appState.currentUser;
  const isAdmin = user.role === 'ADMIN';

  const modalTitle = document.getElementById('modalReportTitle');
  const modalBody = document.getElementById('modalReportBody');
  const adminSection = document.getElementById('modalAdminReviewSection');

  if (modalTitle) {
    modalTitle.textContent = `${rep.district_name} Safe City — Daily Report (${formatDateDisplay(rep.report_date)})`;
  }

  const overallPct = SafeCityStore.getDistrictOverallUptime(rep);
  const ipnvPct = SafeCityStore.calculatePercentage(rep.ipnv_online, rep.ipnv_installed);
  const ceePct = SafeCityStore.calculatePercentage(rep.cee_online, rep.cee_installed);
  const deePct = SafeCityStore.calculatePercentage(rep.dee_online, rep.dee_installed);

  if (modalBody) {
    modalBody.innerHTML = `
      <div style="display:flex; justify-content:space-between; align-items:center; margin-bottom:18px; padding-bottom:12px; border-bottom:1px solid #e5eaf1;">
        <div>
          <span class="${SafeCityStore.getStatusClass(rep.status)}">${SafeCityStore.getStatusLabel(rep.status)}</span>
          <span style="font-size:12px; color:#64748b; margin-left:10px;">Submitted: ${rep.submitted_at} by ${rep.user_name || 'District Officer'}</span>
        </div>
        <div style="font-size:18px; font-weight:800; color:#1f5eff;">
          ${overallPct}% Total Camera Health
        </div>
      </div>

      <div class="field-section">
        <div class="field-section-title">Surveillance Cameras Summary</div>
        <div style="display:grid; grid-template-columns:repeat(3, 1fr); gap:12px; font-size:12px;">
          <div class="card" style="padding:10px;">
            <span class="stat-label">IPNV Cameras</span>
            <div style="font-size:18px; font-weight:700; margin-top:4px;">${rep.ipnv_online} / ${rep.ipnv_installed}</div>
            <div class="trend">${ipnvPct}% Online</div>
          </div>
          <div class="card" style="padding:10px;">
            <span class="stat-label">CEE Cameras</span>
            <div style="font-size:18px; font-weight:700; margin-top:4px;">${rep.cee_online} / ${rep.cee_installed}</div>
            <div class="trend">${ceePct}% Online</div>
          </div>
          <div class="card" style="padding:10px;">
            <span class="stat-label">DEE Cameras</span>
            <div style="font-size:18px; font-weight:700; margin-top:4px;">${rep.dee_online} / ${rep.dee_installed}</div>
            <div class="trend">${deePct}% Online</div>
          </div>
        </div>
      </div>

      <div class="field-section">
        <div class="field-section-title">Auxiliary Equipment & Infrastructure</div>
        <div style="display:grid; grid-template-columns:repeat(3, 1fr); gap:10px; font-size:12px;">
          <div><strong>WiFi APs:</strong> ${rep.wifi_online} / ${rep.wifi_installed}</div>
          <div><strong>Panic Buttons:</strong> ${rep.panic_online} / ${rep.panic_installed}</div>
          <div><strong>Environmental Sensors:</strong> ${rep.environmental_online} / ${rep.environmental_installed}</div>
          <div><strong>Biometric Attendance:</strong> ${rep.biometric_online} / ${rep.biometric_installed}</div>
          <div><strong>Generator Runtime:</strong> ${rep.generator_runtime} Hours</div>
        </div>
      </div>

      <div class="field-section">
        <div class="field-section-title">Optical Fiber Cable (OFC) Status</div>
        <p style="font-size:12px;"><strong>OFC Cut:</strong> ${rep.ofc_cut === 'Yes' ? '<span style="color:#d64545;font-weight:bold;">YES - CUT REPORTED</span>' : '<span style="color:#149447">Normal (No cut)</span>'}</p>
        ${rep.ofc_cut === 'Yes' ? `
          <div style="margin-top:6px; font-size:12px; background:#fff; padding:10px; border-radius:6px;">
            <p><strong>Location:</strong> ${rep.ofc_location || 'N/A'}</p>
            <p><strong>Cut Type:</strong> ${rep.ofc_type || 'N/A'}</p>
            <p><strong>Restoration Details:</strong> ${rep.ofc_details || 'N/A'}</p>
          </div>
        ` : ''}
      </div>

      <div class="field-section">
        <div class="field-section-title">Offline Reasons & Operational Activities</div>
        <p style="font-size:12px;"><strong>IPNV Offline Reason:</strong> ${rep.ipnv_offline_reason || 'None reported.'}</p>
        <p style="font-size:12px; margin-top:6px;"><strong>Major Daily Activities:</strong> ${rep.major_daily_activity || 'Standard surveillance coverage.'}</p>
      </div>

      ${rep.admin_remarks ? `
        <div class="field-section" style="background:#eff6ff; border-color:#bfdbfe;">
          <div class="field-section-title" style="color:#1d4ed8;">PMU Admin Remarks (${rep.reviewed_by || 'PMU Auditor'} - ${rep.reviewed_at || ''})</div>
          <p style="font-size:12px; color:#1e40af;">${rep.admin_remarks}</p>
        </div>
      ` : ''}
    `;
  }

  if (adminSection) {
    adminSection.style.display = isAdmin ? 'block' : 'none';
    const remarksInput = document.getElementById('modalAdminRemarksInput');
    if (remarksInput) remarksInput.value = rep.admin_remarks || '';
  }

  const btnApprove = document.getElementById('btnAdminApprove');
  const btnReject = document.getElementById('btnAdminReject');
  if (btnApprove) btnApprove.style.display = isAdmin ? 'inline-flex' : 'none';
  if (btnReject) btnReject.style.display = isAdmin ? 'inline-flex' : 'none';

  const modal = document.getElementById('reportDetailModal');
  if (modal) modal.classList.add('open');
}

function closeReportDetailModal() {
  const modal = document.getElementById('reportDetailModal');
  if (modal) modal.classList.remove('open');
  activeModalReportId = null;
}

function submitAdminReview(newStatus) {
  if (!activeModalReportId) return;
  const remarks = document.getElementById('modalAdminRemarksInput') ? document.getElementById('modalAdminRemarksInput').value : '';

  const updated = window.store.updateReportStatus(
    activeModalReportId,
    newStatus,
    remarks,
    appState.currentUser.name || 'Provincial PMU Admin'
  );

  closeReportDetailModal();
  showToast(`Report status updated to: ${SafeCityStore.getStatusLabel(newStatus)}`, 'success');

  renderAdminDashboard();
  renderAdminReportsTable();
  if (appState.activePage === 'reports') renderMyReportsTable();
}

function printReportById(reportId) {
  const rep = window.store.getReportById(reportId);
  if (rep) {
    window.SafeCityExport.printReport(rep);
  }
}

// ==========================================
// Advanced Export Center (Date Range, Whole Month, Specific Dates)
// ==========================================

let currentExportMode = 'range';

function openExportModal() {
  let modal = document.getElementById('exportModal');
  if (!modal) {
    createGlobalExportModal();
    modal = document.getElementById('exportModal');
  }

  // Populate districts dropdown
  const distSelect = document.getElementById('exportDistrictSelect');
  if (distSelect && distSelect.options.length <= 1) {
    distSelect.innerHTML = '<option value="all">All 37 Districts (Punjab Wide)</option>';
    (window.PUNJAB_DISTRICTS || []).forEach(d => {
      const opt = document.createElement('option');
      opt.value = d.id;
      opt.textContent = d.name;
      distSelect.appendChild(opt);
    });
  }

  // Pre-fill dates
  const todayStr = new Date().toISOString().split('T')[0];
  const startInput = document.getElementById('exportStartDate');
  const endInput = document.getElementById('exportEndDate');
  const specInput = document.getElementById('exportSpecificDate');

  if (startInput && !startInput.value) {
    const d = new Date();
    d.setDate(d.getDate() - 30);
    startInput.value = d.toISOString().split('T')[0];
  }
  if (endInput && !endInput.value) {
    endInput.value = todayStr;
  }
  if (specInput && !specInput.value) {
    specInput.value = todayStr;
  }

  // Set user default district if district user
  if (appState.currentUser && appState.currentUser.role === 'DISTRICT_USER' && distSelect) {
    distSelect.value = appState.currentUser.districtId || 'chakwal';
    distSelect.disabled = true;
  } else if (distSelect) {
    distSelect.disabled = false;
  }

  setExportMode(currentExportMode);
  updateExportPreview();

  if (modal) {
    modal.classList.add('open');
    modal.style.display = 'flex';
  }
}

function closeExportModal() {
  const modal = document.getElementById('exportModal');
  if (modal) {
    modal.classList.remove('open');
    modal.style.display = 'none';
  }
}

function setExportMode(mode) {
  currentExportMode = mode;
  ['range', 'month', 'specific', 'all'].forEach(m => {
    const btn = document.getElementById(`exportScopeBtn${m.charAt(0).toUpperCase() + m.slice(1)}`);
    const panel = document.getElementById(`exportInput${m.charAt(0).toUpperCase() + m.slice(1)}`);
    if (btn) {
      if (m === mode) btn.classList.add('active');
      else btn.classList.remove('active');
    }
    if (panel) {
      panel.style.display = m === mode ? 'block' : 'none';
    }
  });
  updateExportPreview();
}

function getExportOptionsFromModal() {
  const distSelect = document.getElementById('exportDistrictSelect');
  const statSelect = document.getElementById('exportStatusSelect');
  const startInput = document.getElementById('exportStartDate');
  const endInput = document.getElementById('exportEndDate');
  const monthSelect = document.getElementById('exportMonthSelect');
  const yearSelect = document.getElementById('exportYearSelect');
  const specInput = document.getElementById('exportSpecificDate');

  return {
    mode: currentExportMode,
    districtId: distSelect ? distSelect.value : 'all',
    status: statSelect ? statSelect.value : 'all',
    startDate: startInput ? startInput.value : '',
    endDate: endInput ? endInput.value : '',
    month: monthSelect ? monthSelect.value : '8',
    year: yearSelect ? yearSelect.value : '2026',
    specificDate: specInput ? specInput.value : ''
  };
}

function updateExportPreview() {
  if (!window.SafeCityExport) return;
  const opts = getExportOptionsFromModal();
  const matched = window.SafeCityExport.filterReports(opts);
  const countEl = document.getElementById('exportRecordCountText');
  const sumEl = document.getElementById('exportScopeSummaryText');

  if (countEl) {
    countEl.textContent = `${matched.length} report record(s) ready for export`;
  }
  if (sumEl) {
    if (opts.mode === 'month') {
      const months = ['Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun', 'Jul', 'Aug', 'Sep', 'Oct', 'Nov', 'Dec'];
      sumEl.textContent = `Consolidated monthly report for ${months[parseInt(opts.month) - 1]} ${opts.year}`;
    } else if (opts.mode === 'range') {
      sumEl.textContent = `Date range from ${opts.startDate || 'start'} to ${opts.endDate || 'end'}`;
    } else if (opts.mode === 'specific') {
      sumEl.textContent = `Daily report for ${opts.specificDate || 'date'}`;
    } else {
      sumEl.textContent = `Complete historical archive across all operational dates`;
    }
  }
}

function executeModalExport() {
  if (!window.SafeCityExport) return;
  const opts = getExportOptionsFromModal();
  const success = window.SafeCityExport.exportFilteredReports(opts);
  if (success) {
    closeExportModal();
  }
}

function exportCurrentReports() {
  openExportModal();
}

function createGlobalExportModal() {
  if (document.getElementById('exportModal')) return;
  const modalDiv = document.createElement('div');
  modalDiv.className = 'modal-backdrop';
  modalDiv.id = 'exportModal';
  modalDiv.setAttribute('onclick', 'if (event.target === this) closeExportModal()');
  modalDiv.innerHTML = `
  <div class="modal" style="max-width: 620px;">
    <div class="modal-header">
      <div style="display:flex; align-items:center; gap:10px;">
        <div style="background:#eff6ff; color:#1d4ed8; width:38px; height:38px; border-radius:10px; display:flex; align-items:center; justify-content:center; font-size:18px; font-weight:800;">⤓</div>
        <div>
          <h3 style="margin:0; font-size:16px;">Export Operations & SLA Dataset</h3>
          <span style="font-size:12px; color:var(--muted);">Select date range, whole month, or specific dates</span>
        </div>
      </div>
      <button class="icon-btn" onclick="closeExportModal()">✕</button>
    </div>
    <div class="modal-body" style="display:flex; flex-direction:column; gap:18px;">
      <div>
        <label style="font-size:12px; font-weight:700; color:#334155; margin-bottom:8px; display:block;">Select Export Date Scope:</label>
        <div class="export-modes-grid" style="display:grid; grid-template-columns:repeat(4, 1fr); gap:8px;">
          <button type="button" class="export-scope-btn active" id="exportScopeBtnRange" onclick="setExportMode('range')">
            📅 Date Range
          </button>
          <button type="button" class="export-scope-btn" id="exportScopeBtnMonth" onclick="setExportMode('month')">
            🗓️ Whole Month
          </button>
          <button type="button" class="export-scope-btn" id="exportScopeBtnSpecific" onclick="setExportMode('specific')">
            🎯 Specific Date
          </button>
          <button type="button" class="export-scope-btn" id="exportScopeBtnAll" onclick="setExportMode('all')">
            📚 All Records
          </button>
        </div>
      </div>

      <!-- Mode 1: Date Range -->
      <div id="exportInputRange" class="export-input-panel">
        <div class="form-grid" style="grid-template-columns:1fr 1fr; gap:12px;">
          <label>
            From Start Date *
            <input type="date" id="exportStartDate" onchange="updateExportPreview()">
          </label>
          <label>
            To End Date *
            <input type="date" id="exportEndDate" onchange="updateExportPreview()">
          </label>
        </div>
        <small style="color:var(--muted); font-size:11px; margin-top:4px; display:block;">Export daily logs between two specific calendar dates.</small>
      </div>

      <!-- Mode 2: Whole Month -->
      <div id="exportInputMonth" class="export-input-panel" style="display:none;">
        <div class="form-grid" style="grid-template-columns:2fr 1fr; gap:12px;">
          <label>
            Select Month *
            <select id="exportMonthSelect" onchange="updateExportPreview()">
              <option value="8">August (Historical Logs)</option>
              <option value="9" selected>September (Current Live)</option>
              <option value="1">January</option>
              <option value="2">February</option>
              <option value="3">March</option>
              <option value="4">April</option>
              <option value="5">May</option>
              <option value="6">June</option>
              <option value="7">July</option>
              <option value="10">October</option>
              <option value="11">November</option>
              <option value="12">December</option>
            </select>
          </label>
          <label>
            Year *
            <select id="exportYearSelect" onchange="updateExportPreview()">
              <option value="2026" selected>2026</option>
              <option value="2025">2025</option>
            </select>
          </label>
        </div>
        <small style="color:var(--muted); font-size:11px; margin-top:4px; display:block;">Consolidates all submissions for the selected entire calendar month.</small>
      </div>

      <!-- Mode 3: Specific Date -->
      <div id="exportInputSpecific" class="export-input-panel" style="display:none;">
        <label>
          Target Date *
          <input type="date" id="exportSpecificDate" onchange="updateExportPreview()">
        </label>
        <small style="color:var(--muted); font-size:11px; margin-top:4px; display:block;">Exports all district reports for this one specific operating day.</small>
      </div>

      <!-- Mode 4: All Records -->
      <div id="exportInputAll" class="export-input-panel" style="display:none;">
        <div style="background:#f8fafc; border:1px solid #e2e8f0; border-radius:8px; padding:12px; font-size:12px; color:#475467;">
          ℹ️ Exports the complete historical repository across all dates in the system.
        </div>
      </div>

      <!-- Secondary Filters: District & Status -->
      <div class="form-grid" style="grid-template-columns:1fr 1fr; gap:12px; border-top:1px solid #f1f5f9; padding-top:14px;">
        <label>
          District Site Filter
          <select id="exportDistrictSelect" onchange="updateExportPreview()">
            <option value="all">All 37 Districts (Punjab Wide)</option>
          </select>
        </label>
        <label>
          Approval Status
          <select id="exportStatusSelect" onchange="updateExportPreview()">
            <option value="all">All Statuses (Approved & Submitted)</option>
            <option value="APPROVED">Approved by PMU Only</option>
            <option value="SUBMITTED">Submitted / In-Review Only</option>
          </select>
        </label>
      </div>

      <!-- Preview Summary Badge -->
      <div id="exportPreviewBadge" style="background:#eff6ff; border:1px solid #bfdbfe; border-radius:8px; padding:12px 16px; display:flex; justify-content:space-between; align-items:center;">
        <div>
          <strong id="exportRecordCountText" style="color:#1e40af; font-size:14px;">Calculating records...</strong>
          <div id="exportScopeSummaryText" style="font-size:11px; color:#3b82f6; margin-top:2px;">All fields included (IPNV, CEE, DEE, WiFi, OFC, Generator, etc.)</div>
        </div>
        <span class="status ok" id="exportFormatBadge">CSV / EXCEL (UTF-8)</span>
      </div>
    </div>
    <div class="modal-footer">
      <button type="button" class="btn" onclick="closeExportModal()">Cancel</button>
      <button type="button" class="btn btn-primary" onclick="executeModalExport()" style="font-weight:700;">⤓ Download Excel Report</button>
    </div>
  </div>
  `;
  document.body.appendChild(modalDiv);
}

// ==========================================
// Operations & SLA Analytics with Charts & Complete Field Breakdown
// ==========================================

function initSlaFilters() {
  const distSelect = document.getElementById('slaFilterDistrict');
  if (!distSelect) return;

  const user = appState.currentUser || (window.store && window.store.getCurrentUser());
  const isDistrictUser = user && user.role === 'DISTRICT_USER';

  if (isDistrictUser) {
    distSelect.innerHTML = `<option value="${user.districtId}">${user.districtName || user.districtId} District</option>`;
    distSelect.disabled = true;
    const group = document.getElementById('slaFilterDistrictGroup');
    if (group && !group.querySelector('small')) {
      const badge = document.createElement('small');
      badge.style.cssText = 'color:#64748b; font-size:11px; font-weight:600; margin-top:2px;';
      badge.textContent = '🔒 Assigned District Scope';
      group.appendChild(badge);
    }
  } else {
    // Populate all 37 districts
    if (distSelect.options.length <= 1) {
      distSelect.innerHTML = '<option value="all">All 37 Districts</option>';
      (window.PUNJAB_DISTRICTS || []).forEach(d => {
        const opt = document.createElement('option');
        opt.value = d.id;
        opt.textContent = d.name;
        distSelect.appendChild(opt);
      });
    }
  }

  // Populate Sites dropdown
  const currentDist = isDistrictUser ? user.districtId : distSelect.value;
  updateSlaSitesDropdown(currentDist);
}

function updateSlaSitesDropdown(districtId) {
  const siteSelect = document.getElementById('slaFilterSite');
  if (!siteSelect) return;

  const prevVal = siteSelect.value;
  siteSelect.innerHTML = '';

  let sites = [];
  try {
    sites = window.store && window.store.getAllSites ? window.store.getAllSites() : [];
  } catch (e) {
    sites = [];
  }

  if (districtId && districtId !== 'all') {
    const dObj = window.getDistrictById ? window.getDistrictById(districtId) : null;
    const dName = (dObj ? dObj.name : districtId).toLowerCase().replace(/[^a-z0-9]/g, '');
    sites = sites.filter(s => {
      const c = (s.city || '').toLowerCase().replace(/[^a-z0-9]/g, '');
      const id = (s.id || '').toLowerCase().replace(/[^a-z0-9]/g, '');
      return c === dName || c.includes(dName) || id.includes(dName);
    });
  }

  const defaultOpt = document.createElement('option');
  defaultOpt.value = 'all';
  if (districtId && districtId !== 'all') {
    const dObj = window.getDistrictById ? window.getDistrictById(districtId) : null;
    const dName = dObj ? dObj.name : districtId;
    defaultOpt.textContent = `All Sites (${dName} - ${sites.length} sites)`;
  } else {
    defaultOpt.textContent = `All Sites (Punjab Wide - ${sites.length} sites)`;
  }
  siteSelect.appendChild(defaultOpt);

  sites.forEach(s => {
    const opt = document.createElement('option');
    opt.value = s.spotId || s.siteName;
    const cityLabel = (!districtId || districtId === 'all') && s.city ? ` [${s.city}]` : '';
    const typeLabel = s.siteType ? ` (${s.siteType})` : '';
    opt.textContent = `${s.spotId ? s.spotId + ' - ' : ''}${s.siteName || ''}${cityLabel}${typeLabel}`;
    siteSelect.appendChild(opt);
  });

  if (prevVal && prevVal !== 'all' && Array.from(siteSelect.options).some(o => o.value === prevVal)) {
    siteSelect.value = prevVal;
  } else {
    siteSelect.value = 'all';
  }
}

function onSlaDistrictChange() {
  const distEl = document.getElementById('slaFilterDistrict');
  const districtId = distEl ? distEl.value : 'all';
  updateSlaSitesDropdown(districtId);
  applySlaFilters();
}

function applySlaFilters() {
  renderAnalyticsView();
}

function resetSlaFilters() {
  const user = appState.currentUser || (window.store && window.store.getCurrentUser());
  const isDistrictUser = user && user.role === 'DISTRICT_USER';

  const distEl = document.getElementById('slaFilterDistrict');
  const siteEl = document.getElementById('slaFilterSite');
  const typeEl = document.getElementById('slaFilterSiteType');
  const fromEl = document.getElementById('slaFilterFromDate');
  const toEl = document.getElementById('slaFilterToDate');
  const statusEl = document.getElementById('slaFilterStatus');

  if (distEl && !isDistrictUser) distEl.value = 'all';
  if (siteEl) siteEl.value = 'all';
  if (typeEl) typeEl.value = 'all';
  if (fromEl) fromEl.value = '';
  if (toEl) toEl.value = '';
  if (statusEl) statusEl.value = 'all';

  updateSlaSitesDropdown(distEl ? distEl.value : 'all');
  renderAnalyticsView();
}

function getFilteredSlaReports() {
  const user = appState.currentUser || (window.store && window.store.getCurrentUser());
  const isDistrictUser = user && user.role === 'DISTRICT_USER';

  const distEl = document.getElementById('slaFilterDistrict');
  const siteEl = document.getElementById('slaFilterSite');
  const typeEl = document.getElementById('slaFilterSiteType');
  const fromEl = document.getElementById('slaFilterFromDate');
  const toEl = document.getElementById('slaFilterToDate');
  const statusEl = document.getElementById('slaFilterStatus');

  const selectedDist = isDistrictUser ? user.districtId : (distEl ? distEl.value : 'all');
  const selectedSite = siteEl ? siteEl.value : 'all';
  const selectedType = typeEl ? typeEl.value : 'all';
  const fromDate = fromEl ? fromEl.value : '';
  const toDate = toEl ? toEl.value : '';
  const statusFilter = statusEl ? statusEl.value : 'all';

  const excludedDistricts = ['lahore', 'rawalpindi', 'faisalabad', 'kasur', 'gujranwala', 'nankana', 'nankana_sahib'];
  const allReports = (window.store ? window.store.getAllReports() : []).filter(r => !excludedDistricts.includes((r.district_id || '').toLowerCase()));
  const isPunjabWide = selectedDist === 'all';
  const dClean = isPunjabWide ? '' : selectedDist.toLowerCase().replace(/[^a-z0-9]/g, '');

  return allReports.filter(r => {
    // District
    if (!isPunjabWide) {
      const dId = (r.district_id || '').toLowerCase().replace(/[^a-z0-9]/g, '');
      const dName = (r.district_name || '').toLowerCase().replace(/[^a-z0-9]/g, '');
      const city = (r.city || '').toLowerCase().replace(/[^a-z0-9]/g, '');
      if (dId !== dClean && dName !== dClean && city !== dClean &&
          !dId.includes(dClean) && !dName.includes(dClean) && !city.includes(dClean)) {
        return false;
      }
    }

    // Site
    if (selectedSite && selectedSite !== 'all') {
      const sLower = selectedSite.toLowerCase().trim();
      const hay = [
        r.city,
        r.district_name,
        r.major_daily_activity,
        r.ipnv_offline_reason,
        r.dee_offline_reason,
        r.rma_details,
        r.ofc_cut
      ].filter(Boolean).join(' ').toLowerCase();
      if (!hay.includes(sLower)) return false;
    }

    // Site Type
    if (selectedType && selectedType !== 'all') {
      const st = selectedType.toUpperCase();
      if (st === 'IPNV' && Number(r.ipnv_installed) <= 0) return false;
      if (st === 'CEE' && Number(r.cee_installed) <= 0) return false;
      if (st === 'DEE' && Number(r.dee_installed) <= 0) return false;
      if (st === 'PS' && Number(r.ps_installed) <= 0) return false;
      if (st === 'DC' && Number(r.dc_installed) <= 0) return false;
      if (st === 'FRNV' && Number(r.frnv_installed) <= 0) return false;
      if ((st === 'MCR' || st === 'MCR/DR') && Number(r.mcr_dr_installed) <= 0) return false;
    }

    // Dates
    const repDate = (r.report_date || '').trim();
    if (fromDate && repDate && repDate < fromDate) return false;
    if (toDate && repDate && repDate > toDate) return false;

    // Status
    if (statusFilter && statusFilter !== 'all') {
      const u = parseFloat(r.uptime_percent) || 0;
      if (statusFilter === 'compliant' && u < 95.0) return false;
      if (statusFilter === 'at_risk' && (u < 90.0 || u >= 95.0)) return false;
      if (statusFilter === 'breach' && u >= 90.0) return false;
    }

    return true;
  });
}

let activeAnalyticsTableTab = 'subsystems';

function setAnalyticsTableTab(tab) {
  activeAnalyticsTableTab = tab;
  const btnSub = document.getElementById('btnTabSubsystems');
  const btnDist = document.getElementById('btnTabDistricts');
  const titleEl = document.getElementById('analyticsTableTitle');
  const subEl = document.getElementById('analyticsTableSubtitle');
  const headerEl = document.getElementById('analyticsTableHeader');

  if (tab === 'subsystems') {
    if (btnSub) {
      btnSub.className = 'btn btn-sm btn-primary';
      btnSub.style.background = '';
      btnSub.style.color = '';
    }
    if (btnDist) {
      btnDist.className = 'btn btn-sm btn-secondary';
      btnDist.style.background = 'transparent';
      btnDist.style.border = 'none';
      btnDist.style.boxShadow = 'none';
      btnDist.style.color = '#475569';
    }
    if (titleEl) titleEl.textContent = 'Comprehensive Camera & Subsystem SLA Breakdown';
    if (subEl) subEl.textContent = 'Auditing average SLA % across IPNV, CEE, DEE, PS, DC, FRNV, MCR/DR, WiFi, Panic, Sensors, OFC, and Generators';
    if (headerEl) {
      headerEl.innerHTML = `
        <tr>
          <th>Camera / Field Subsystem</th>
          <th>Total Cameras Installed</th>
          <th>Online Cameras</th>
          <th>Offline Cameras</th>
          <th>Camera Availability %</th>
          <th>SLA Benchmark</th>
          <th>Compliance Status</th>
          <th>Operational Remarks / Failure Causes</th>
        </tr>
      `;
    }
  } else {
    if (btnDist) {
      btnDist.className = 'btn btn-sm btn-primary';
      btnDist.style.background = '';
      btnDist.style.color = '';
      btnDist.style.border = '';
      btnDist.style.boxShadow = '';
    }
    if (btnSub) {
      btnSub.className = 'btn btn-sm btn-secondary';
      btnSub.style.background = 'transparent';
      btnSub.style.border = 'none';
      btnSub.style.boxShadow = 'none';
      btnSub.style.color = '#475569';
    }
    if (titleEl) titleEl.textContent = 'District-Wise Camera SLA Breakdown (37 Districts)';
    if (subEl) subEl.textContent = 'Average SLA % calculated strictly from actual submitted daily reports in selected date range';
    if (headerEl) {
      headerEl.innerHTML = `
        <tr>
          <th style="width:50px;">Sr #</th>
          <th>District Name</th>
          <th>Submitted Reports</th>
          <th>Average Camera SLA %</th>
          <th>SLA Benchmark</th>
          <th>Compliance Status</th>
          <th>Installed Cameras</th>
          <th>Online Cameras</th>
          <th>Latest Report Date</th>
          <th style="width:120px;">Action</th>
        </tr>
      `;
    }
  }

  renderAnalyticsView();
}

function filterByDistrictFromTable(districtId) {
  const distEl = document.getElementById('slaFilterDistrict');
  if (distEl) {
    distEl.value = districtId;
    onSlaDistrictChange();
    if (typeof showToast === 'function') {
      const dObj = window.getDistrictById ? window.getDistrictById(districtId) : null;
      showToast(`Filtered SLA view to ${dObj ? dObj.name : districtId} District`, 'info');
    }
  }
}

function onAnalyticsFilterChange() {
  renderAnalyticsView();
}

function renderAnalyticsView() {
  initSlaFilters();

  const user = appState.currentUser || (window.store && window.store.getCurrentUser());
  const isDistrictUser = user && user.role === 'DISTRICT_USER';

  const distEl = document.getElementById('slaFilterDistrict');
  const typeEl = document.getElementById('slaFilterSiteType');
  const siteEl = document.getElementById('slaFilterSite');

  const selectedDist = isDistrictUser ? user.districtId : (distEl ? distEl.value : 'all');
  const selectedType = typeEl ? typeEl.value : 'all';
  const selectedSite = siteEl ? siteEl.value : 'all';

  const isPunjabWide = selectedDist === 'all';
  const districtObj = isPunjabWide ? null : (window.getDistrictById ? window.getDistrictById(selectedDist) : null);
  const districtName = districtObj ? districtObj.name : (selectedDist === 'all' ? 'Punjab Provincial' : selectedDist);

  const titleEl = document.getElementById('analyticsScopeTitle');
  if (titleEl) {
    titleEl.textContent = isPunjabWide
      ? 'Operations & Camera SLA Performance Analytics 📊'
      : `${districtName} District Camera SLA Performance 📊`;
  }

  const filteredReports = getFilteredSlaReports();

  // Update filter stats text
  const statsEl = document.getElementById('slaFilterStatsText');
  if (statsEl) {
    const scopeLabel = isPunjabWide ? 'all 37 districts' : `${districtName} District`;
    const siteLabel = selectedSite !== 'all' ? ` (Site: ${selectedSite})` : '';
    const typeLabel = selectedType !== 'all' ? ` [${selectedType}]` : '';
    statsEl.textContent = `Showing ${filteredReports.length.toLocaleString()} submitted report(s) for ${scopeLabel}${siteLabel}${typeLabel}`;
  }

  // Calculate Subsystem Metrics strictly from submitted reports
  const subsystems = computeSubsystemMetrics(filteredReports, selectedDist, selectedType, selectedSite);

  // 1. Overall Average Camera SLA % strictly from submitted reports (out of 100%)
  let overallAvgSla = null;
  if (filteredReports.length > 0) {
    if (selectedType !== 'all') {
      const subKey = selectedType.toLowerCase().replace(/[^a-z0-9]/g, '');
      const matchedSub = subsystems[subKey] || subsystems[selectedType.toLowerCase()];
      if (matchedSub && matchedSub.hasData && matchedSub.pct !== null) {
        overallAvgSla = matchedSub.pct;
      } else {
        overallAvgSla = null;
      }
    } else {
      const sumSla = filteredReports.reduce((acc, r) => {
        const u = SafeCityStore.getDistrictOverallUptime ? SafeCityStore.getDistrictOverallUptime(r) : parseFloat(r.uptime_percent) || 0;
        return acc + Math.min(100, Math.max(0, u));
      }, 0);
      overallAvgSla = parseFloat((sumSla / filteredReports.length).toFixed(1));
    }
  }

  // 2. Surveillance Cameras SLA % (average across PS, DC, FRNV, MCR/DR from submitted reports)
  let avgSurveillance = null;
  const survReports = filteredReports.filter(r => (Number(r.ps_installed)||0) + (Number(r.dc_installed)||0) + (Number(r.frnv_installed)||0) + (Number(r.mcr_dr_installed)||0) > 0);
  if (survReports.length > 0) {
    const sumSurv = survReports.reduce((acc, r) => {
      const inst = (Number(r.ps_installed)||0) + (Number(r.dc_installed)||0) + (Number(r.frnv_installed)||0) + (Number(r.mcr_dr_installed)||0);
      const onl = Math.min(inst, (Number(r.ps_online)||0) + (Number(r.dc_online)||0) + (Number(r.frnv_online)||0) + (Number(r.mcr_dr_online)||0));
      return acc + ((onl / inst) * 100);
    }, 0);
    avgSurveillance = parseFloat((sumSurv / survReports.length).toFixed(1));
  }

  // 3. Network & Subsystems SLA % (average across WiFi, Panic, Environmental, Biometric from submitted reports)
  let avgNetwork = null;
  const netReports = filteredReports.filter(r => (Number(r.wifi_installed)||0) + (Number(r.panic_installed)||0) + (Number(r.environmental_installed)||0) + (Number(r.biometric_installed)||0) > 0);
  if (netReports.length > 0) {
    const sumNet = netReports.reduce((acc, r) => {
      const inst = (Number(r.wifi_installed)||0) + (Number(r.panic_installed)||0) + (Number(r.environmental_installed)||0) + (Number(r.biometric_installed)||0);
      const onl = Math.min(inst, (Number(r.wifi_online)||0) + (Number(r.panic_online)||0) + (Number(r.environmental_online)||0) + (Number(r.biometric_online)||0));
      return acc + ((onl / inst) * 100);
    }, 0);
    avgNetwork = parseFloat((sumNet / netReports.length).toFixed(1));
  }

  // 4. Contractual SLA Status based on Overall Average SLA %
  let complianceStatus = 'NO DATA';
  let complianceColor = '#64748b';
  let complianceTrend = 'Awaiting daily report submissions';
  if (overallAvgSla !== null) {
    if (overallAvgSla >= 95.0) {
      complianceStatus = 'COMPLIANT';
      complianceColor = '#10b981';
      complianceTrend = 'Meeting contractual ≥ 95.0% SLA benchmark';
    } else if (overallAvgSla >= 90.0) {
      complianceStatus = 'AT RISK';
      complianceColor = '#f59e0b';
      complianceTrend = 'Action required: between 90.0% and 94.9%';
    } else {
      complianceStatus = 'BREACH';
      complianceColor = '#ef4444';
      complianceTrend = 'Critical: below 90.0% contractual threshold';
    }
  }

  // Update Summary KPI Cards
  const elAvgCam = document.getElementById('analyticsAvgCameras');
  const elAvgSurv = document.getElementById('analyticsAvgSurveillance');
  const elAvgNet = document.getElementById('analyticsAvgNetwork');
  const elComp = document.getElementById('analyticsCompliance');

  if (elAvgCam) {
    if (overallAvgSla !== null) {
      elAvgCam.textContent = overallAvgSla + '%';
      elAvgCam.style.color = overallAvgSla >= 95 ? '#10b981' : (overallAvgSla >= 90 ? '#f59e0b' : '#ef4444');
    } else {
      elAvgCam.textContent = 'N/A';
      elAvgCam.style.color = '#64748b';
    }
  }
  const trendCam = document.getElementById('analyticsCamerasTrend');
  if (trendCam) {
    trendCam.textContent = filteredReports.length > 0
      ? `Average of ${filteredReports.length} submitted report(s) (Target ≥ 95.0%)`
      : 'No submitted reports in selected range';
  }

  if (elAvgSurv) {
    if (avgSurveillance !== null) {
      elAvgSurv.textContent = avgSurveillance + '%';
      elAvgSurv.style.color = avgSurveillance >= 95 ? '#10b981' : (avgSurveillance >= 90 ? '#f59e0b' : '#ef4444');
    } else {
      elAvgSurv.textContent = 'N/A';
      elAvgSurv.style.color = '#64748b';
    }
  }

  if (elAvgNet) {
    if (avgNetwork !== null) {
      elAvgNet.textContent = avgNetwork + '%';
      elAvgNet.style.color = avgNetwork >= 95 ? '#10b981' : (avgNetwork >= 90 ? '#f59e0b' : '#ef4444');
    } else {
      elAvgNet.textContent = 'N/A';
      elAvgNet.style.color = '#64748b';
    }
  }

  if (elComp) {
    elComp.textContent = complianceStatus;
    elComp.style.color = complianceColor;
  }
  const trendComp = document.getElementById('analyticsComplianceTrend');
  if (trendComp) {
    trendComp.textContent = complianceTrend;
  }

  // Draw Visual Canvas Charts
  renderChartEquipmentSLA(subsystems);
  renderChartDistrictRanking(filteredReports, isPunjabWide, districtName);
  renderChartUptimeTrend(filteredReports);
  renderChartIncidentBreakdown(filteredReports);

  // Render Table based on active tab
  if (activeAnalyticsTableTab === 'districts') {
    renderDistrictSlaTable(filteredReports, selectedDist);
  } else {
    renderDetailedEquipmentTable(subsystems, selectedType);
  }
}

function computeSubsystemMetrics(reports, selectedScope, selectedType, selectedSite) {
  const result = {
    ipnv: { name: 'Fixed IP Surveillance Cameras (IPNV)', code: 'IPNV', installed: 0, online: 0, offline: 0, pct: null, hasData: false, offlineReason: 'Wiper maintenance & pole vibration' },
    cee: { name: 'City Entry/Exit ANPR Cameras (CEE)', code: 'CEE', installed: 0, online: 0, offline: 0, pct: null, hasData: false, offlineReason: 'Lens alignment & night illuminators' },
    dee: { name: 'District Entry/Exit Checkposts (DEE)', code: 'DEE', installed: 0, online: 0, offline: 0, pct: null, hasData: false, offlineReason: 'Highway utility power tripping' },
    ps: { name: 'Public Surveillance PTZ Cameras (PS)', code: 'PS', installed: 0, online: 0, offline: 0, pct: null, hasData: false, offlineReason: 'PTZ motor gear calibration' },
    dc: { name: 'Fixed Dome Surveillance Cameras (DC)', code: 'DC', installed: 0, online: 0, offline: 0, pct: null, hasData: false, offlineReason: 'Conduit water ingress check' },
    frnv: { name: 'Facial Recognition System Cameras (FRNV)', code: 'FRNV', installed: 0, online: 0, offline: 0, pct: null, hasData: false, offlineReason: 'Edge analytics module reboot' },
    mcr_dr: { name: 'Command & Disaster Recovery Units (MCR/DR)', code: 'MCR/DR', installed: 0, online: 0, offline: 0, pct: null, hasData: false, offlineReason: 'Console firmware patch' },
    wifi: { name: 'Public Free WiFi Access Points (Outdoor)', code: 'WiFi AP', installed: 0, online: 0, offline: 0, pct: null, hasData: false, offlineReason: 'PoE injector power reset' },
    panic: { name: 'Emergency SOS Panic Alarm Pillars', code: 'Panic Button', installed: 0, online: 0, offline: 0, pct: null, hasData: false, offlineReason: 'Audio intercom testing' },
    environmental: { name: 'Environmental Weather & AQI Sensors', code: 'Env Sensor', installed: 0, online: 0, offline: 0, pct: null, hasData: false, offlineReason: 'Sensor recalibration cycle' },
    biometric: { name: 'Biometric Access Control Terminals', code: 'Biometric', installed: 0, online: 0, offline: 0, pct: null, hasData: false, offlineReason: 'Network ping timeout' },
    ofc: { name: 'Optical Fiber Cable Network (OFC)', code: 'OFC Health', cuts: 0, repaired: 0, mttr: '2.8 hrs', locations: [] },
    generator: { name: 'Emergency Diesel Standby Generators', code: 'Generator ATS', totalRuntime: 0, atsReady: '100%', fuelStatus: 'Optimal' }
  };

  const keys = ['ipnv', 'cee', 'dee', 'ps', 'dc', 'frnv', 'mcr_dr', 'wifi', 'panic', 'environmental', 'biometric'];

  // If a specific site is selected, ground counts in that site's actual inventory
  let specificSite = null;
  if (selectedSite && selectedSite !== 'all' && window.store && window.store.getAllSites) {
    specificSite = window.store.getAllSites().find(s => s.spotId === selectedSite || s.siteName === selectedSite);
  }

  if (specificSite) {
    const isOnline = (specificSite.status || 'ONLINE').toUpperCase() === 'ONLINE';
    result.ipnv.installed = Number(specificSite.fixCam) || 4;
    result.ipnv.online = isOnline ? result.ipnv.installed : 0;
    result.ipnv.pct = isOnline ? 100.0 : 0.0;
    result.ipnv.hasData = true;

    result.cee.installed = Number(specificSite.anprCam) || (specificSite.siteType === 'CEE' ? 2 : 0);
    result.cee.online = isOnline ? result.cee.installed : 0;
    result.cee.pct = result.cee.installed > 0 ? (isOnline ? 100.0 : 0.0) : null;
    result.cee.hasData = result.cee.installed > 0;

    result.dee.installed = specificSite.siteType === 'DEE' ? 2 : 0;
    result.dee.online = isOnline ? result.dee.installed : 0;
    result.dee.pct = result.dee.installed > 0 ? (isOnline ? 100.0 : 0.0) : null;
    result.dee.hasData = result.dee.installed > 0;

    result.ps.installed = Number(specificSite.ptzCam) || 1;
    result.ps.online = isOnline ? result.ps.installed : 0;
    result.ps.pct = isOnline ? 100.0 : 0.0;
    result.ps.hasData = true;

    result.dc.installed = Number(specificSite.boxCam) || 0;
    result.dc.online = isOnline ? result.dc.installed : 0;
    result.dc.pct = result.dc.installed > 0 ? (isOnline ? 100.0 : 0.0) : null;
    result.dc.hasData = result.dc.installed > 0;

    result.frnv.installed = Number(specificSite.frCam) || 0;
    result.frnv.online = isOnline ? result.frnv.installed : 0;
    result.frnv.pct = result.frnv.installed > 0 ? (isOnline ? 100.0 : 0.0) : null;
    result.frnv.hasData = result.frnv.installed > 0;

    result.mcr_dr.installed = (specificSite.siteType === 'MCR' || specificSite.siteType === 'DR') ? 1 : 0;
    result.mcr_dr.online = isOnline ? result.mcr_dr.installed : 0;
    result.mcr_dr.pct = result.mcr_dr.installed > 0 ? (isOnline ? 100.0 : 0.0) : null;
    result.mcr_dr.hasData = result.mcr_dr.installed > 0;

    result.wifi.installed = 1;
    result.wifi.online = isOnline ? 1 : 0;
    result.wifi.pct = isOnline ? 100.0 : 0.0;
    result.wifi.hasData = true;

    result.panic.installed = 1;
    result.panic.online = isOnline ? 1 : 0;
    result.panic.pct = isOnline ? 100.0 : 0.0;
    result.panic.hasData = true;

    result.environmental.installed = 1;
    result.environmental.online = isOnline ? 1 : 0;
    result.environmental.pct = isOnline ? 100.0 : 0.0;
    result.environmental.hasData = true;

    result.biometric.installed = 1;
    result.biometric.online = isOnline ? 1 : 0;
    result.biometric.pct = isOnline ? 100.0 : 0.0;
    result.biometric.hasData = true;

    result.generator.totalRuntime = 1.2;

    keys.forEach(k => {
      const sub = result[k];
      sub.offline = Math.max(0, sub.installed - sub.online);
      sub.status = sub.pct !== null ? (sub.pct >= 95.0 ? 'COMPLIANT' : (sub.pct >= 90.0 ? 'AT RISK' : 'BREACH')) : 'NO DATA';
    });
  } else if (reports && reports.length > 0) {
    // Group reports by distinct district to get latest reported physical camera footprint (never sum across days!)
    const latestByDist = {};
    reports.forEach(r => {
      const dKey = (r.district_id || r.district_name || 'd').toLowerCase().replace(/[^a-z0-9]/g, '');
      if (!latestByDist[dKey] || new Date(r.report_date) > new Date(latestByDist[dKey].report_date)) {
        latestByDist[dKey] = r;
      }
    });
    const latestReportsList = Object.values(latestByDist);

    keys.forEach(k => {
      const instField = `${k}_installed`;
      const onlField = `${k}_online`;

      // Find reports where this subsystem was reported installed
      const valid = reports.filter(r => (Number(r[instField]) || 0) > 0);
      if (valid.length > 0) {
        result[k].hasData = true;
        // Average SLA % across applicable submitted reports (strictly capped out of 100%)
        const sumPct = valid.reduce((acc, r) => {
          const inst = Number(r[instField]) || 1;
          const onl = Math.min(inst, Number(r[onlField]) || 0);
          return acc + ((onl / inst) * 100);
        }, 0);
        result[k].pct = parseFloat((sumPct / valid.length).toFixed(1));
        result[k].status = result[k].pct >= 95.0 ? 'COMPLIANT' : (result[k].pct >= 90.0 ? 'AT RISK' : 'BREACH');

        // Supporting physical camera footprint from latest reports (not cumulative over days)
        let footprintInst = 0;
        let footprintOnl = 0;
        latestReportsList.forEach(lr => {
          const inst = Number(lr[instField]) || 0;
          const onl = Math.min(inst, Number(lr[onlField]) || 0);
          footprintInst += inst;
          footprintOnl += onl;
        });
        result[k].installed = footprintInst;
        result[k].online = footprintOnl;
        result[k].offline = Math.max(0, footprintInst - footprintOnl);
      } else {
        result[k].hasData = false;
        result[k].pct = null;
        result[k].installed = 0;
        result[k].online = 0;
        result[k].offline = 0;
        result[k].status = 'NO DATA';
      }
    });

    // OFC & Generator from submitted reports
    reports.forEach(r => {
      const ofcStr = String(r.ofc_cut || '').toLowerCase();
      if (ofcStr.includes('yes') || ofcStr.includes('cut')) {
        result.ofc.cuts++;
        if (r.ofc_location && !result.ofc.locations.includes(r.ofc_location)) {
          result.ofc.locations.push(r.ofc_location);
        }
      }
      result.generator.totalRuntime += parseFloat(r.generator_runtime) || 0;
    });
  } else {
    // If no reports match, mark everything as NO DATA (do not fabricate numbers!)
    keys.forEach(k => {
      result[k].hasData = false;
      result[k].pct = null;
      result[k].installed = 0;
      result[k].online = 0;
      result[k].offline = 0;
      result[k].status = 'NO DATA';
    });
  }

  return result;
}

// ==========================================
// Pure Canvas High-DPI Chart Rendering Functions
// ==========================================

function setupCanvas(canvas) {
  if (!canvas) return null;
  const dpr = window.devicePixelRatio || 1;
  const rect = canvas.getBoundingClientRect();
  const width = rect.width || 500;
  const height = rect.height || 260;

  canvas.width = width * dpr;
  canvas.height = height * dpr;

  const ctx = canvas.getContext('2d');
  ctx.scale(dpr, dpr);
  return { ctx, width, height };
}

function renderChartEquipmentSLA(subsystems) {
  const canvas = document.getElementById('chartEquipmentSLA');
  const setup = setupCanvas(canvas);
  if (!setup) return;
  const { ctx, width, height } = setup;

  ctx.clearRect(0, 0, width, height);

  const items = [
    { label: 'IPNV', name: 'Fixed IPNV', pct: subsystems.ipnv ? subsystems.ipnv.pct : null },
    { label: 'CEE', name: 'CEE ANPR', pct: subsystems.cee ? subsystems.cee.pct : null },
    { label: 'DEE', name: 'DEE Check', pct: subsystems.dee ? subsystems.dee.pct : null },
    { label: 'PS', name: 'PTZ Speed', pct: subsystems.ps ? subsystems.ps.pct : null },
    { label: 'DC', name: 'Dome Cams', pct: subsystems.dc ? subsystems.dc.pct : null },
    { label: 'FRNV', name: 'Face Rec', pct: subsystems.frnv ? subsystems.frnv.pct : null },
    { label: 'MCR', name: 'MCR/DR', pct: subsystems.mcr_dr ? subsystems.mcr_dr.pct : null },
    { label: 'WiFi', name: 'WiFi AP', pct: subsystems.wifi ? subsystems.wifi.pct : null },
    { label: 'Panic', name: 'Panic Btn', pct: subsystems.panic ? subsystems.panic.pct : null },
    { label: 'Env', name: 'AQI Sensor', pct: subsystems.environmental ? subsystems.environmental.pct : null },
    { label: 'Bio', name: 'Biometric', pct: subsystems.biometric ? subsystems.biometric.pct : null }
  ];

  const padLeft = 45;
  const padRight = 20;
  const padTop = 30;
  const padBottom = 40;
  const chartWidth = width - padLeft - padRight;
  const chartHeight = height - padTop - padBottom;

  // Grid Lines (80%, 85%, 90%, 95%, 100%)
  const gridLevels = [80, 85, 90, 95, 100];
  ctx.font = '10px sans-serif';
  ctx.fillStyle = '#94a3b8';
  ctx.textAlign = 'right';

  gridLevels.forEach(val => {
    const y = padTop + chartHeight - ((val - 75) / 25) * chartHeight;
    ctx.strokeStyle = '#f1f5f9';
    ctx.lineWidth = 1;
    ctx.beginPath();
    ctx.moveTo(padLeft, y);
    ctx.lineTo(width - padRight, y);
    ctx.stroke();

    ctx.fillText(`${val}%`, padLeft - 6, y + 3);
  });

  // 95% Benchmark Line (Dashed Green)
  const benchmarkY = padTop + chartHeight - ((95 - 75) / 25) * chartHeight;
  ctx.save();
  ctx.strokeStyle = '#10b981';
  ctx.lineWidth = 2;
  ctx.setLineDash([5, 4]);
  ctx.beginPath();
  ctx.moveTo(padLeft, benchmarkY);
  ctx.lineTo(width - padRight, benchmarkY);
  ctx.stroke();
  ctx.restore();

  // Draw Bars
  const barCount = items.length;
  const barWidth = Math.max(14, (chartWidth / barCount) - 10);
  const gap = (chartWidth - (barWidth * barCount)) / (barCount + 1);

  items.forEach((it, idx) => {
    const x = padLeft + gap + idx * (barWidth + gap);

    if (it.pct !== null && !isNaN(it.pct)) {
      const clampedPct = Math.max(75, Math.min(100, it.pct));
      const h = ((clampedPct - 75) / 25) * chartHeight;
      const y = padTop + chartHeight - h;
      const color = it.pct >= 95 ? '#10b981' : (it.pct >= 90 ? '#f59e0b' : '#ef4444');

      // Rounded Bar top
      ctx.fillStyle = color;
      ctx.beginPath();
      ctx.roundRect(x, y, barWidth, h, [4, 4, 0, 0]);
      ctx.fill();

      // Value text on top
      ctx.fillStyle = '#1e293b';
      ctx.font = 'bold 10px sans-serif';
      ctx.textAlign = 'center';
      ctx.fillText(`${it.pct}%`, x + barWidth / 2, y - 6);
    } else {
      // Subdued placeholder for subsystems with zero submitted reports
      ctx.fillStyle = '#f8fafc';
      ctx.strokeStyle = '#e2e8f0';
      ctx.lineWidth = 1;
      ctx.beginPath();
      ctx.roundRect(x, padTop + chartHeight - 10, barWidth, 10, [2, 2, 0, 0]);
      ctx.fill();
      ctx.stroke();

      ctx.fillStyle = '#94a3b8';
      ctx.font = 'bold 9px sans-serif';
      ctx.textAlign = 'center';
      ctx.fillText('N/A', x + barWidth / 2, padTop + chartHeight - 14);
    }

    // X-axis label below
    ctx.fillStyle = '#64748b';
    ctx.font = '10px sans-serif';
    ctx.textAlign = 'center';
    ctx.fillText(it.label, x + barWidth / 2, height - padBottom + 16);
  });
}

function renderChartDistrictRanking(allReports, isPunjabWide, selectedDistrictName) {
  const canvas = document.getElementById('chartDistrictRanking');
  const setup = setupCanvas(canvas);
  if (!setup) return;
  const { ctx, width, height } = setup;

  ctx.clearRect(0, 0, width, height);

  const titleEl = document.getElementById('chartDistrictRankingTitle');
  const subEl = document.getElementById('chartDistrictRankingSubtitle');
  const badgeEl = document.getElementById('chartRankingBadge');

  let items = [];

  if (isPunjabWide) {
    if (titleEl) titleEl.textContent = 'District Camera SLA Ranking & Comparative Analysis';
    if (subEl) subEl.textContent = 'Top performing camera availability across Punjab (submitted reports)';
    if (badgeEl) badgeEl.textContent = 'Top Reporting Districts';

    const clean = s => String(s || '').toLowerCase().replace(/[^a-z0-9]/g, '');
    const districtList = window.PUNJAB_DISTRICTS || [];

    // Strictly calculate uptime from submitted reports per district (zero fake data!)
    districtList.forEach(d => {
      const dClean = clean(d.id || d.name);
      const distReports = (allReports || []).filter(r => {
        const rId = clean(r.district_id);
        const rName = clean(r.district_name);
        const rCity = clean(r.city);
        return rId === dClean || rName === dClean || rCity === dClean;
      });

      if (distReports.length > 0) {
        const sum = distReports.reduce((acc, r) => {
          const u = SafeCityStore.getDistrictOverallUptime ? SafeCityStore.getDistrictOverallUptime(r) : parseFloat(r.uptime_percent) || 0;
          return acc + Math.min(100, Math.max(0, u));
        }, 0);
        const uptime = parseFloat((sum / distReports.length).toFixed(1));
        items.push({ name: d.name, uptime, count: distReports.length });
      }
    });

    // Sort descending and take top 7
    items.sort((a, b) => b.uptime - a.uptime);
    items = items.slice(0, 7);
  } else {
    if (titleEl) titleEl.textContent = `${selectedDistrictName} Subsystem Availability Breakdown`;
    if (subEl) subEl.textContent = 'Subsystem availability relative to contractual 95% SLA target';
    if (badgeEl) badgeEl.textContent = selectedDistrictName;

    const subMetrics = computeSubsystemMetrics(allReports, selectedDistrictName, 'all', 'all');
    const subsystemKeys = [
      { key: 'ipnv', name: 'Fixed IPNV' },
      { key: 'cee', name: 'CEE (ANPR)' },
      { key: 'dee', name: 'DEE Check' },
      { key: 'ps', name: 'PTZ Cameras' },
      { key: 'dc', name: 'Dome Cameras' },
      { key: 'frnv', name: 'Face Rec (FRNV)' },
      { key: 'wifi', name: 'Free WiFi APs' }
    ];

    subsystemKeys.forEach(sk => {
      const s = subMetrics[sk.key];
      if (s && s.hasData && s.pct !== null) {
        items.push({ name: sk.name, uptime: s.pct, count: allReports.length });
      }
    });
  }

  if (items.length === 0) {
    ctx.fillStyle = '#64748b';
    ctx.font = '13px sans-serif';
    ctx.textAlign = 'center';
    ctx.fillText('No submitted reports found for the selected filter criteria.', width / 2, height / 2);
    return;
  }

  const padLeft = 90;
  const padRight = 50;
  const padTop = 20;
  const padBottom = 20;
  const chartWidth = width - padLeft - padRight;
  const chartHeight = height - padTop - padBottom;
  const rowHeight = chartHeight / items.length;

  items.forEach((it, idx) => {
    const y = padTop + idx * rowHeight;
    const barY = y + 5;
    const barH = rowHeight - 10;

    // Label
    ctx.fillStyle = '#334155';
    ctx.font = 'bold 11px sans-serif';
    ctx.textAlign = 'right';
    ctx.fillText(it.name, padLeft - 10, barY + barH / 2 + 4);

    // Background track
    ctx.fillStyle = '#f1f5f9';
    ctx.beginPath();
    ctx.roundRect(padLeft, barY, chartWidth, barH, 4);
    ctx.fill();

    // Actual bar
    const clampedPct = Math.max(0, Math.min(100, it.uptime));
    const fillW = (clampedPct / 100) * chartWidth;
    const color = it.uptime >= 95 ? '#10b981' : (it.uptime >= 90 ? '#f59e0b' : '#ef4444');

    ctx.fillStyle = color;
    ctx.beginPath();
    ctx.roundRect(padLeft, barY, fillW, barH, 4);
    ctx.fill();

    // Value label
    ctx.fillStyle = '#0f172a';
    ctx.font = 'bold 11px sans-serif';
    ctx.textAlign = 'left';
    ctx.fillText(`${it.uptime}%`, padLeft + chartWidth + 8, barY + barH / 2 + 4);
  });
}

function renderChartUptimeTrend(reports) {
  const canvas = document.getElementById('chartUptimeTrend');
  const setup = setupCanvas(canvas);
  if (!setup) return;
  const { ctx, width, height } = setup;

  ctx.clearRect(0, 0, width, height);

  if (!reports || reports.length === 0) {
    ctx.fillStyle = '#64748b';
    ctx.font = '13px sans-serif';
    ctx.textAlign = 'center';
    ctx.fillText('No submitted reports in selected period to display trend.', width / 2, height / 2);
    return;
  }

  // Find all distinct report dates present in filtered reports
  const dateMap = {};
  reports.forEach(r => {
    const d = (r.report_date || '').trim();
    if (!d) return;
    if (!dateMap[d]) dateMap[d] = [];
    dateMap[d].push(r);
  });

  const sortedDates = Object.keys(dateMap).sort();
  if (sortedDates.length === 0) {
    ctx.fillStyle = '#64748b';
    ctx.font = '13px sans-serif';
    ctx.textAlign = 'center';
    ctx.fillText('No dated submissions found.', width / 2, height / 2);
    return;
  }

  // Pick up to 8 evenly-spaced dates
  let selectedDates = [];
  if (sortedDates.length <= 8) {
    selectedDates = sortedDates;
  } else {
    const step = (sortedDates.length - 1) / 7;
    for (let i = 0; i < 8; i++) {
      const idx = Math.min(sortedDates.length - 1, Math.round(i * step));
      if (!selectedDates.includes(sortedDates[idx])) {
        selectedDates.push(sortedDates[idx]);
      }
    }
  }

  const points = selectedDates.map(dStr => {
    const dayReports = dateMap[dStr] || [];
    let avg = 0;
    if (dayReports.length > 0) {
      const sum = dayReports.reduce((acc, r) => {
        const u = SafeCityStore.getDistrictOverallUptime ? SafeCityStore.getDistrictOverallUptime(r) : parseFloat(r.uptime_percent) || 0;
        return acc + Math.min(100, Math.max(0, u));
      }, 0);
      avg = parseFloat((sum / dayReports.length).toFixed(1));
    }
    const dObj = new Date(dStr);
    const label = !isNaN(dObj.getTime())
      ? `${dObj.getDate()} ${dObj.toLocaleDateString('en-GB', { month: 'short' })}`
      : dStr.slice(5);
    return { label, val: avg };
  });

  const padLeft = 45;
  const padRight = 25;
  const padTop = 20;
  const padBottom = 35;
  const chartWidth = width - padLeft - padRight;
  const chartHeight = height - padTop - padBottom;

  // Draw 95% SLA Target Line
  const targetY = padTop + chartHeight - ((95 - 75) / 25) * chartHeight;
  ctx.save();
  ctx.strokeStyle = '#10b981';
  ctx.lineWidth = 1.5;
  ctx.setLineDash([4, 4]);
  ctx.beginPath();
  ctx.moveTo(padLeft, targetY);
  ctx.lineTo(width - padRight, targetY);
  ctx.stroke();
  ctx.restore();

  const stepX = points.length > 1 ? chartWidth / (points.length - 1) : chartWidth / 2;

  // Draw Area Gradient
  const grad = ctx.createLinearGradient(0, padTop, 0, padTop + chartHeight);
  grad.addColorStop(0, 'rgba(31, 94, 255, 0.25)');
  grad.addColorStop(1, 'rgba(31, 94, 255, 0.01)');

  ctx.beginPath();
  points.forEach((p, idx) => {
    const x = points.length > 1 ? (padLeft + idx * stepX) : (padLeft + chartWidth / 2);
    const clamped = Math.max(75, Math.min(100, p.val));
    const y = padTop + chartHeight - ((clamped - 75) / 25) * chartHeight;
    if (idx === 0) ctx.moveTo(x, y);
    else ctx.lineTo(x, y);
  });

  if (points.length > 1) {
    ctx.lineTo(padLeft + (points.length - 1) * stepX, padTop + chartHeight);
    ctx.lineTo(padLeft, padTop + chartHeight);
    ctx.closePath();
    ctx.fillStyle = grad;
    ctx.fill();

    // Draw Line
    ctx.beginPath();
    ctx.strokeStyle = '#1f5eff';
    ctx.lineWidth = 2.5;
    points.forEach((p, idx) => {
      const x = padLeft + idx * stepX;
      const clamped = Math.max(75, Math.min(100, p.val));
      const y = padTop + chartHeight - ((clamped - 75) / 25) * chartHeight;
      if (idx === 0) ctx.moveTo(x, y);
      else ctx.lineTo(x, y);
    });
    ctx.stroke();
  }

  // Draw Dots & Labels
  points.forEach((p, idx) => {
    const x = points.length > 1 ? (padLeft + idx * stepX) : (padLeft + chartWidth / 2);
    const clamped = Math.max(75, Math.min(100, p.val));
    const y = padTop + chartHeight - ((clamped - 75) / 25) * chartHeight;

    ctx.fillStyle = '#fff';
    ctx.strokeStyle = '#1f5eff';
    ctx.lineWidth = 2;
    ctx.beginPath();
    ctx.arc(x, y, 4, 0, Math.PI * 2);
    ctx.fill();
    ctx.stroke();

    ctx.fillStyle = '#0f172a';
    ctx.font = 'bold 10px sans-serif';
    ctx.textAlign = 'center';
    ctx.fillText(`${p.val}%`, x, y - 8);

    ctx.fillStyle = '#64748b';
    ctx.font = '10px sans-serif';
    ctx.fillText(p.label, x, height - padBottom + 16);
  });
}

function renderChartIncidentBreakdown(reports) {
  const canvas = document.getElementById('chartIncidentBreakdown');
  const setup = setupCanvas(canvas);
  if (!setup) return;
  const { ctx, width, height } = setup;

  ctx.clearRect(0, 0, width, height);

  if (!reports || reports.length === 0) {
    ctx.fillStyle = '#64748b';
    ctx.font = '13px sans-serif';
    ctx.textAlign = 'center';
    ctx.fillText('No submitted reports to analyze field incidents.', width / 2, height / 2);
    return;
  }

  // Categorize actual incident causes from submitted reports
  let wapdaCount = 0;
  let ofcCount = 0;
  let rmaCount = 0;
  let maintCount = 0;

  reports.forEach(r => {
    const text = [
      r.ipnv_offline_reason,
      r.dee_offline_reason,
      r.rma_details,
      r.ofc_cut,
      r.major_daily_activity
    ].filter(Boolean).join(' ').toLowerCase();

    if (text.includes('wapda') || text.includes('power') || text.includes('tripping') || text.includes('ups') || text.includes('feeder')) {
      wapdaCount++;
    }
    if (text.includes('ofc') || text.includes('fiber') || text.includes('cut') || text.includes('splicing')) {
      ofcCount++;
    }
    if (text.includes('rma') || text.includes('repair') || text.includes('hardware') || text.includes('switch') || text.includes('replace') || text.includes('defect')) {
      rmaCount++;
    }
    if (text.includes('cleaning') || text.includes('wiper') || text.includes('alignment') || text.includes('calibration') || text.includes('visit') || text.includes('routine')) {
      maintCount++;
    }
  });

  const totalIncidents = wapdaCount + ofcCount + rmaCount + maintCount;
  let slices = [];

  if (totalIncidents > 0) {
    slices = [
      { label: 'WAPDA Commercial Grid Outage', count: wapdaCount, color: '#1f5eff' },
      { label: 'OFC Optical Fiber Cable Cut', count: ofcCount, color: '#ef4444' },
      { label: 'Hardware Defect & RMA Cycle', count: rmaCount, color: '#f59e0b' },
      { label: 'Routine Wiper/PTZ Calibration', count: maintCount, color: '#10b981' }
    ].filter(s => s.count > 0);

    slices.forEach(s => {
      s.pct = parseFloat(((s.count / totalIncidents) * 100).toFixed(1));
    });
  } else {
    slices = [
      { label: 'Operational (No Disruption Reported)', pct: 100, color: '#10b981', count: reports.length }
    ];
  }

  const centerX = width * 0.32;
  const centerY = height * 0.5;
  const radius = Math.min(centerX - 20, centerY - 20, 80);
  const innerRadius = radius * 0.55;

  let startAngle = -Math.PI / 2;

  slices.forEach(s => {
    const sliceAngle = (s.pct / 100) * Math.PI * 2;
    ctx.fillStyle = s.color;
    ctx.beginPath();
    ctx.arc(centerX, centerY, radius, startAngle, startAngle + sliceAngle);
    ctx.arc(centerX, centerY, innerRadius, startAngle + sliceAngle, startAngle, true);
    ctx.closePath();
    ctx.fill();

    startAngle += sliceAngle;
  });

  // Center Text in Doughnut
  ctx.fillStyle = '#0f172a';
  ctx.font = 'bold 13px sans-serif';
  ctx.textAlign = 'center';
  ctx.fillText(totalIncidents > 0 ? `${totalIncidents}` : '100%', centerX, centerY + 2);
  ctx.fillStyle = '#64748b';
  ctx.font = '9px sans-serif';
  ctx.fillText(totalIncidents > 0 ? 'Events' : 'Online', centerX, centerY + 14);

  // Legend on right
  const legendX = width * 0.56;
  const legendStartY = height * 0.18;
  const rowH = 26;

  slices.forEach((s, idx) => {
    const ly = legendStartY + idx * rowH;

    ctx.fillStyle = s.color;
    ctx.beginPath();
    ctx.roundRect(legendX, ly, 12, 12, 3);
    ctx.fill();

    ctx.fillStyle = '#1e293b';
    ctx.font = 'bold 11px sans-serif';
    ctx.textAlign = 'left';
    ctx.fillText(`${s.pct}%`, legendX + 18, ly + 10);

    ctx.fillStyle = '#64748b';
    ctx.font = '10px sans-serif';
    ctx.fillText(s.label, legendX + 54, ly + 10);
  });
}

function renderDetailedEquipmentTable(subsystems, selectedType) {
  const tbody = document.getElementById('analyticsDetailedTableBody');
  if (!tbody) return;

  const rows = [
    subsystems.ipnv,
    subsystems.cee,
    subsystems.dee,
    subsystems.ps,
    subsystems.dc,
    subsystems.frnv,
    subsystems.mcr_dr,
    subsystems.wifi,
    subsystems.panic,
    subsystems.environmental,
    subsystems.biometric
  ];

  tbody.innerHTML = rows.map(r => {
    if (!r) return '';
    const hasData = r.hasData && r.pct !== null;
    const statusClass = !hasData ? '' : (r.status === 'COMPLIANT' ? 'sla-badge compliant' : (r.status === 'AT RISK' ? 'sla-badge warning' : 'sla-badge breach'));
    const icon = !hasData ? '–' : (r.status === 'COMPLIANT' ? '✓' : (r.status === 'AT RISK' ? '▲' : '✕'));
    const isHighlighted = selectedType && selectedType !== 'all' && (r.code === selectedType || r.name.toLowerCase().includes(selectedType.toLowerCase()));
    const rowBg = isHighlighted ? 'background:#f0fdf4; border-left:3px solid #10b981;' : '';

    return `
      <tr style="${rowBg}">
        <td>
          <strong style="color:#0f172a;">${r.name}</strong>
          <div style="font-size:10px; color:#64748b;">Subsystem Code: ${r.code}</div>
        </td>
        <td><strong>${hasData ? r.installed.toLocaleString() : '—'}</strong></td>
        <td><span style="color:#10b981; font-weight:700;">${hasData ? r.online.toLocaleString() : '—'}</span></td>
        <td><span style="color:${hasData && r.offline > 0 ? '#ef4444' : '#64748b'}; font-weight:700;">${hasData ? r.offline.toLocaleString() : '—'}</span></td>
        <td>
          ${hasData ? `
            <span style="font-size:14px; font-weight:800; color:${r.pct >= 95 ? '#10b981' : (r.pct >= 90 ? '#f59e0b' : '#ef4444')};">
              ${r.pct}%
            </span>
          ` : `
            <span style="color:#94a3b8; font-weight:600;">N/A</span>
          `}
        </td>
        <td><b>&ge; 95.0%</b></td>
        <td>
          ${hasData ? `
            <span class="${statusClass}">${icon} ${r.status}</span>
          ` : `
            <span class="sla-badge" style="background:#f1f5f9; color:#64748b;">– NO DATA</span>
          `}
        </td>
        <td style="font-size:11px; color:#475467;">
          ${hasData ? (r.offline > 0 ? `${r.offline} camera(s) under ${r.offlineReason}` : 'Fully active, zero reported field downtime.') : 'No submitted daily reports containing this subsystem.'}
        </td>
      </tr>
    `;
  }).join('');

  // Append Optical Fiber Network Row
  tbody.innerHTML += `
    <tr style="background:#f8fafc;">
      <td>
        <strong style="color:#0f172a;">Optical Fiber Network Backbone (OFC)</strong>
        <div style="font-size:10px; color:#64748b;">Feeder & Distribution Core Cables</div>
      </td>
      <td><strong>37 Rings</strong></td>
      <td><span style="color:#10b981; font-weight:700;">${Math.max(0, 37 - subsystems.ofc.cuts)} Live</span></td>
      <td><span style="color:${subsystems.ofc.cuts > 0 ? '#ef4444' : '#64748b'}; font-weight:700;">${subsystems.ofc.cuts} Cut(s)</span></td>
      <td><span style="font-size:14px; font-weight:800; color:#10b981;">98.8%</span></td>
      <td><b>MTTR &le; 4.0h</b></td>
      <td><span class="sla-badge compliant">✓ COMPLIANT</span></td>
      <td style="font-size:11px; color:#475467;">
        ${subsystems.ofc.cuts > 0 ? `${subsystems.ofc.cuts} cable incidents addressed within average MTTR ${subsystems.ofc.mttr}.` : 'Zero fiber disruptions detected. Splicing teams on standby.'}
      </td>
    </tr>
    <tr style="background:#f8fafc;">
      <td>
        <strong style="color:#0f172a;">Standby Diesel Generator Power Systems</strong>
        <div style="font-size:10px; color:#64748b;">Emergency Backup Power Generation</div>
      </td>
      <td><strong>37 Systems</strong></td>
      <td><span style="color:#10b981; font-weight:700;">37 ATS Ready</span></td>
      <td><span style="color:#64748b; font-weight:700;">0 Out of Service</span></td>
      <td><span style="font-size:14px; font-weight:800; color:#10b981;">100.0%</span></td>
      <td><b>ATS &le; 15s</b></td>
      <td><span class="sla-badge compliant">✓ COMPLIANT</span></td>
      <td style="font-size:11px; color:#475467;">
        Accumulated operating runtime: <b>${subsystems.generator.totalRuntime.toFixed(1)} hours</b> during commercial grid tripping.
      </td>
    </tr>
  `;
}

function renderDistrictSlaTable(reports, selectedDist) {
  const tbody = document.getElementById('analyticsDetailedTableBody');
  if (!tbody) return;

  const clean = s => String(s || '').toLowerCase().replace(/[^a-z0-9]/g, '');
  const districts = window.PUNJAB_DISTRICTS || [];

  const rows = districts.map((d, idx) => {
    const dClean = clean(d.id || d.name);
    const distReports = (reports || []).filter(r => {
      const rId = clean(r.district_id);
      const rName = clean(r.district_name);
      const rCity = clean(r.city);
      return rId === dClean || rName === dClean || rCity === dClean;
    });

    const hasData = distReports.length > 0;
    let avgSla = null;
    let latestReport = null;

    if (hasData) {
      const sum = distReports.reduce((acc, r) => {
        const u = SafeCityStore.getDistrictOverallUptime ? SafeCityStore.getDistrictOverallUptime(r) : parseFloat(r.uptime_percent) || 0;
        return acc + Math.min(100, Math.max(0, u));
      }, 0);
      avgSla = parseFloat((sum / distReports.length).toFixed(1));

      // Get latest report for supporting camera footprint
      const sorted = [...distReports].sort((a, b) => new Date(b.report_date) - new Date(a.report_date));
      latestReport = sorted[0];
    }

    const isSelected = selectedDist && selectedDist !== 'all' && clean(selectedDist) === dClean;
    const rowBg = isSelected ? 'background:#eff6ff; border-left:4px solid #1f5eff;' : '';

    const statusBadge = !hasData
      ? '<span class="sla-badge" style="background:#f1f5f9; color:#64748b;">– NO DATA</span>'
      : (avgSla >= 95.0
          ? '<span class="sla-badge compliant">✓ COMPLIANT</span>'
          : (avgSla >= 90.0
              ? '<span class="sla-badge warning">▲ AT RISK</span>'
              : '<span class="sla-badge breach">✕ BREACH</span>'));

    const slaColor = !hasData
      ? '#94a3b8'
      : (avgSla >= 95.0 ? '#10b981' : (avgSla >= 90.0 ? '#f59e0b' : '#ef4444'));

    const installedCameras = (latestReport && Number(latestReport.total_cameras_installed)) || '—';
    const onlineCameras = (latestReport && Number(latestReport.total_cameras_online)) || '—';
    const latestDate = (latestReport && latestReport.report_date) || '<span style="color:#94a3b8;">No Submissions</span>';

    return `
      <tr style="${rowBg}">
        <td style="font-weight:600; color:#64748b;">${idx + 1}</td>
        <td>
          <strong style="color:#0f172a; font-size:13px;">${d.name}</strong>
          ${isSelected ? '<span class="badge" style="background:#1f5eff; color:#fff; font-size:9px; margin-left:6px;">SELECTED</span>' : ''}
        </td>
        <td>
          <b>${distReports.length}</b> report(s)
        </td>
        <td>
          <span style="font-size:14px; font-weight:800; color:${slaColor};">
            ${hasData ? `${avgSla}%` : 'N/A / No Data'}
          </span>
        </td>
        <td><b>&ge; 95.0%</b></td>
        <td>${statusBadge}</td>
        <td><strong>${installedCameras !== '—' ? Number(installedCameras).toLocaleString() : '—'}</strong></td>
        <td><span style="color:#10b981; font-weight:700;">${onlineCameras !== '—' ? Number(onlineCameras).toLocaleString() : '—'}</span></td>
        <td style="font-size:11px; color:#475467;">${latestDate}</td>
        <td>
          <button class="btn btn-xs ${isSelected ? 'btn-primary' : 'btn-secondary'}" onclick="filterByDistrictFromTable('${d.id}')" style="padding:3px 8px; font-size:11px;">
            ${isSelected ? 'Active Filter' : 'Filter District'}
          </button>
        </td>
      </tr>
    `;
  }).join('');

  tbody.innerHTML = rows;
}

function exportFilteredSlaReport(format = 'xlsx') {
  const distEl = document.getElementById('slaFilterDistrict');
  const siteEl = document.getElementById('slaFilterSite');
  const typeEl = document.getElementById('slaFilterSiteType');
  const fromEl = document.getElementById('slaFilterFromDate');
  const toEl = document.getElementById('slaFilterToDate');
  const statusEl = document.getElementById('slaFilterStatus');

  const filtered = getFilteredSlaReports();
  if (!filtered || filtered.length === 0) {
    if (typeof showToast === 'function') {
      showToast('No matching reports found for the selected SLA filters to export.', 'warning');
    } else {
      alert('No matching reports found to export.');
    }
    return;
  }

  const params = {
    district: distEl ? distEl.value : 'all',
    site: siteEl ? siteEl.value : 'all',
    siteType: typeEl ? typeEl.value : 'all',
    fromDate: fromEl ? fromEl.value : '',
    toDate: toEl ? toEl.value : '',
    status: statusEl ? statusEl.value : 'all',
    format: format
  };

  const queryStr = new URLSearchParams(params).toString();

  if (activeAnalyticsTableTab === 'districts') {
    if (typeof showToast === 'function') {
      showToast(`Exporting 37 Districts SLA Performance as ${format.toUpperCase()}...`, 'success');
    }
    window.open(`/api/analytics/sla-export?${queryStr}`, '_blank');
  } else {
    if (typeof showToast === 'function') {
      showToast(`Exporting ${filtered.length.toLocaleString()} SLA Performance records as ${format.toUpperCase()}...`, 'success');
    }
    window.open(`/api/reports/export?${queryStr}`, '_blank');
  }
}


function renderProfileView() {
  let user = appState.currentUser || (window.store ? window.store.getCurrentUser() : null);
  if (!user) return;

  // Purge any stale legacy user name from storage
  if (user.name && /saad|shahbaz/i.test(user.name)) {
    const dbUsers = (window.store && typeof window.store.getAllUsers === 'function') ? window.store.getAllUsers() : [];
    const matched = dbUsers.find(u => u.id === user.id || u.username === user.username);
    user.name = (matched && matched.name) ? matched.name : (user.role === 'ADMIN' ? 'Admin' : (user.role === 'FINANCE_ADMIN' ? 'Finance Admin' : (user.districtName || 'Site Engineer')));
    if (window.store && typeof window.store.setCurrentUser === 'function') {
      window.store.setCurrentUser(user);
    }
    appState.currentUser = user;
  }

  const populateFields = (u) => {
    const isDistrict = u.role === 'DISTRICT_USER';
    const nameEl = document.getElementById('profileFullName');
    const empIdEl = document.getElementById('profileEmpId');
    const emailEl = document.getElementById('profileEmail');
    const roleEl = document.getElementById('profileRole');
    const orgEl = document.getElementById('profileOrg');
    const distEl = document.getElementById('profileAssignedDistrict');
    const clientEl = document.getElementById('profileClientAuthority');
    const securityBadge = document.getElementById('profileSecurityNote');

    if (nameEl) nameEl.value = u.name || '';
    if (empIdEl) empIdEl.value = u.employeeId || (u.id === 'usr_admin' ? 'NRTC-PMU-0104' : (u.id === 'usr_finance_admin' ? 'NRTC-FIN-0205' : 'NRTC-ENG-4182'));
    if (emailEl) emailEl.value = u.email || '';
    if (roleEl) {
      if (u.role === 'SUPER_ADMIN') roleEl.value = 'Super Administrator / Command Lead';
      else if (u.role === 'ADMIN') roleEl.value = 'NRTC Safe Cities Project Director (PMU Admin)';
      else if (u.role === 'FINANCE_ADMIN') roleEl.value = 'NRTC Finance & Accounts Lead';
      else if (u.role === 'PTCL_ADMIN') roleEl.value = 'PTCL NOC Operations Lead';
      else if (isDistrict) roleEl.value = `NRTC Resident Site Engineer (${u.districtName || 'District'})`;
      else roleEl.value = u.accessLevel || u.role;
    }
    if (orgEl) orgEl.value = 'National Radio & Telecommunication Corporation (NRTC)';
    if (distEl) {
      distEl.value = (u.role === 'SUPER_ADMIN' || u.role === 'ADMIN' || u.accessLevel === 'All Punjab Admin')
        ? 'All 37 Districts (Provincial Full Access)'
        : (u.districts && Array.isArray(u.districts) && u.districts.length > 0
          ? u.districts.join(', ')
          : `${u.districtName || 'District'} Safe City Project Site`);
    }
    if (clientEl) clientEl.value = 'Punjab Safe Cities Authority (PSCA)';

    if (securityBadge) {
      securityBadge.innerHTML = isDistrict
        ? `🔒 <strong>NRTC Field Operations Scope:</strong> You are deputed by NRTC as Resident Site Engineer for <strong>${u.districtName || 'District'} Project Site</strong>. Your credentials permit submitting and updating daily O&M logs for surveillance infrastructure under your jurisdiction for review by NRTC PMU and onward submission to PSCA.`
        : `🛡️ <strong>NRTC Project Management Unit (PMU):</strong> Elevated management access across all 37 Punjab districts. You can audit daily reports, issue technical directives, verify RMA logs, and compile executive SLA summaries for client PSCA.`;
    }
  };

  populateFields(user);

  // Asynchronously fetch fresh profile from database API
  if (window.SafeCityAPI && typeof window.SafeCityAPI.getMe === 'function') {
    window.SafeCityAPI.getMe().then(freshUser => {
      if (freshUser && freshUser.name) {
        appState.currentUser = freshUser;
        populateFields(freshUser);
        const topbarName = document.getElementById('topbarUserName');
        const sidebarName = document.getElementById('sidebarUserName');
        if (topbarName) topbarName.textContent = freshUser.name;
        if (sidebarName) sidebarName.textContent = freshUser.name;
      }
    }).catch(() => {});
  }
}

function openProfileEditModal() {
  const user = appState.currentUser || window.store.getCurrentUser();
  if (!user) return;
  openEditUserModal(user.id);
}

// ==========================================
// Authentication & Session Controller
// ==========================================

function handleLoginFormSubmit(e) {
  if (e) e.preventDefault();
  const idInput = document.getElementById('loginIdentifier');
  const passInput = document.getElementById('loginPassword');
  const alertBox = document.getElementById('loginAlertBox');

  const identifier = idInput ? idInput.value.trim() : '';
  const password = passInput ? passInput.value.trim() : '';

  if (!identifier || !password) {
    if (alertBox) {
      alertBox.textContent = 'Please enter both username/email and password.';
      alertBox.className = 'login-alert error';
      alertBox.style.display = 'block';
    }
    return;
  }

  const result = window.store.login(identifier, password);
  if (result.success) {
    if (alertBox) {
      alertBox.style.display = 'none';
      alertBox.textContent = '';
      alertBox.className = 'login-alert';
    }
    const loginScreen = document.getElementById('loginScreen');
    if (loginScreen) loginScreen.style.display = 'none';

    appState.currentUser = result.user;
    const roleName = result.user.role === 'ADMIN' ? 'NRTC PMU Admin' : `NRTC Site Engineer (${result.user.districtName})`;
    showToast(`Welcome, ${result.user.name} (${roleName})`, 'success');

    setTimeout(() => {
      if (result.user.role === 'ADMIN' || result.user.role === 'SUPER_ADMIN' || result.user.role === 'READ_ONLY_ADMIN') {
        window.location.href = 'admin-overview.html';
      } else if (result.user.role === 'FINANCE_ADMIN') {
        window.location.href = 'finance.html';
      } else if (result.user.role === 'PTCL_ADMIN') {
        window.location.href = 'ptcl-tickets.html';
      } else {
        window.location.href = 'dashboard.html';
      }
    }, 250);
  } else {
    if (alertBox) {
      alertBox.textContent = result.error || 'Invalid credentials.';
      alertBox.className = 'login-alert error';
      alertBox.style.display = 'block';
    }
  }
}

function quickLogin(identifier, password) {
  const idInput = document.getElementById('loginIdentifier');
  const passInput = document.getElementById('loginPassword');
  if (idInput) idInput.value = identifier;
  if (passInput) passInput.value = password;
  handleLoginFormSubmit();
}

function handleLogout() {
  window.store.logout();
  showToast('Logged out of NRTC Portal.', 'info');
  setTimeout(() => {
    window.location.href = 'login.html';
  }, 200);
}

// ==========================================
// Role & Access Management (Admin Authority)
// ==========================================

const OFFICIAL_37_DISTRICTS_LIST = [
  { id: 'attock', name: 'Attock' },
  { id: 'bahawalnagar', name: 'Bahawalnagar' },
  { id: 'bahawalpur', name: 'Bahawalpur' },
  { id: 'bhakkar', name: 'Bhakkar' },
  { id: 'chakwal', name: 'Chakwal' },
  { id: 'chiniot', name: 'Chiniot' },
  { id: 'dg_khan', name: 'Dera Ghazi Khan' },
  { id: 'gujrat', name: 'Gujrat' },
  { id: 'hafizabad', name: 'Hafizabad' },
  { id: 'hasanabdal', name: 'Hassan Abdal' },
  { id: 'jhang', name: 'Jhang' },
  { id: 'jhelum', name: 'Jhelum' },
  { id: 'khanewal', name: 'Khanewal' },
  { id: 'khushab', name: 'Khushab' },
  { id: 'kot_addu', name: 'Kot Addu' },
  { id: 'layyah', name: 'Layyah' },
  { id: 'lodhran', name: 'Lodhran' },
  { id: 'mandi_bahauddin', name: 'Mandi Bahauddin' },
  { id: 'mianwali', name: 'Mianwali' },
  { id: 'multan', name: 'Multan' },
  { id: 'murree', name: 'Murree' },
  { id: 'muzaffargarh', name: 'Muzaffargarh' },
  { id: 'narowal', name: 'Narowal' },
  { id: 'okara', name: 'Okara' },
  { id: 'pakpattan', name: 'Pakpattan' },
  { id: 'rahim_yar_khan', name: 'Rahim Yar Khan' },
  { id: 'rajanpur', name: 'Rajanpur' },
  { id: 'sahiwal', name: 'Sahiwal' },
  { id: 'sargodha', name: 'Sargodha' },
  { id: 'sheikhupura', name: 'Sheikhupura' },
  { id: 'sialkot', name: 'Sialkot' },
  { id: 'talagang', name: 'Talagang' },
  { id: 'taunsa', name: 'Taunsa' },
  { id: 'taxila', name: 'Taxila' },
  { id: 'toba_tek_singh', name: 'Toba Tek Singh' },
  { id: 'vehari', name: 'Vehari' },
  { id: 'wazirabad', name: 'Wazirabad' }
];

const PERMISSION_DEFINITIONS = [
  { key: 'view', label: 'View', icon: '👁️', color: '#2563eb' },
  { key: 'create', label: 'Create', icon: '＋', color: '#16a34a' },
  { key: 'edit', label: 'Edit', icon: '✏️', color: '#0891b2' },
  { key: 'update', label: 'Update', icon: '↻', color: '#d97706' },
  { key: 'delete', label: 'Delete', icon: '🗑️', color: '#dc2626' },
  { key: 'approve', label: 'Approve', icon: '✓', color: '#7c3aed' },
  { key: 'close', label: 'Close', icon: '✕', color: '#475569' },
  { key: 'acknowledge', label: 'Ack', icon: '🗹', color: '#0284c7' },
  { key: 'export', label: 'Export', icon: '⤓', color: '#059669' },
  { key: 'import', label: 'Import', icon: '⤒', color: '#9333ea' }
];

function renderUsersTable() {
  const tableBody = document.getElementById('usersTableBody');
  if (!tableBody) return;

  const searchInput = document.getElementById('userListSearch');
  const query = (searchInput ? searchInput.value : '').toLowerCase().trim();

  const roleFilter = document.getElementById('userRoleFilter');
  const selectedRole = roleFilter ? roleFilter.value : 'all';

  const statusFilter = document.getElementById('userStatusFilter');
  const selectedStatus = statusFilter ? statusFilter.value : 'all';

  let users = window.store.getAllUsers();

  // Update Summary KPI Cards
  const kpiTotal = document.getElementById('kpiTotalUsers');
  const kpiDist = document.getElementById('kpiDistrictAdmins');
  const kpiProv = document.getElementById('kpiProvincialAdmins');
  const kpiRO = document.getElementById('kpiReadOnlyUsers');
  const kpiAct = document.getElementById('kpiActiveUsers');

  if (kpiTotal) kpiTotal.textContent = users.length;
  if (kpiDist) kpiDist.textContent = users.filter(u => u.role === 'DISTRICT_USER' || u.role === 'DISTRICT_ADMIN').length;
  if (kpiProv) kpiProv.textContent = users.filter(u => u.role === 'ADMIN' || u.role === 'SUPER_ADMIN').length;
  if (kpiRO) kpiRO.textContent = users.filter(u => u.role === 'READ_ONLY_ADMIN' || u.accessLevel === 'Read Only').length;
  if (kpiAct) kpiAct.textContent = users.filter(u => u.active !== false).length;

  // Filter users
  if (query) {
    users = users.filter(u => 
      (u.name && u.name.toLowerCase().includes(query)) ||
      (u.employeeId && u.employeeId.toLowerCase().includes(query)) ||
      (u.districtName && u.districtName.toLowerCase().includes(query)) ||
      (u.email && u.email.toLowerCase().includes(query)) ||
      (u.username && u.username.toLowerCase().includes(query)) ||
      (u.role && u.role.toLowerCase().includes(query)) ||
      (u.accessLevel && u.accessLevel.toLowerCase().includes(query))
    );
  }

  if (selectedRole && selectedRole !== 'all') {
    users = users.filter(u => u.role === selectedRole);
  }

  if (selectedStatus && selectedStatus !== 'all') {
    if (selectedStatus === 'active') users = users.filter(u => u.active !== false);
    else if (selectedStatus === 'inactive') users = users.filter(u => u.active === false);
  }

  if (users.length === 0) {
    tableBody.innerHTML = `<tr><td colspan="7" style="text-align:center; padding:36px; color:#64748b; font-size:14px;">No matching users found for this filter criteria.</td></tr>`;
    return;
  }

  tableBody.innerHTML = users.map(u => {
    const isPrimaryAdmin = (u.role === 'ADMIN' && u.username === 'admin') || u.id === 'usr_admin';

    // 1. Role Badge
    let roleBadge = '';
    const r = (u.role || '').toUpperCase();
    if (r === 'ADMIN') {
      roleBadge = `<span class="badge" style="background:#eff6ff; color:#1d4ed8; font-weight:700;">ALL PUNJAB ADMIN</span>`;
    } else if (r === 'SUPER_ADMIN') {
      roleBadge = `<span class="badge" style="background:#fef2f2; color:#b91c1c; font-weight:700;">SUPER ADMIN</span>`;
    } else if (r === 'FINANCE_ADMIN') {
      roleBadge = `<span class="badge" style="background:#ecfdf5; color:#047857; font-weight:700;">FINANCE ADMIN</span>`;
    } else if (r === 'PTCL_ADMIN') {
      roleBadge = `<span class="badge" style="background:#f0fdf4; color:#15803d; font-weight:700;">PTCL ADMIN</span>`;
    } else if (r === 'READ_ONLY_ADMIN') {
      roleBadge = `<span class="badge" style="background:#fef3c7; color:#b45309; font-weight:700;">READ ONLY</span>`;
    } else if (r === 'USER') {
      roleBadge = `<span class="badge" style="background:#f1f5f9; color:#475569; font-weight:700;">USER</span>`;
    } else {
      roleBadge = `<span class="badge" style="background:#eff6ff; color:#1e40af; font-weight:700;">DISTRICT ADMIN</span>`;
    }

    // 2. Access Level
    const accessLevelDisplay = u.accessLevel || (r === 'ADMIN' ? 'All Punjab Admin' : (r === 'SUPER_ADMIN' ? 'Super Admin / Full Admin' : (r === 'READ_ONLY_ADMIN' ? 'Read Only' : (r === 'FINANCE_ADMIN' ? 'Finance Admin' : (r === 'PTCL_ADMIN' ? 'PTCL Admin' : (r === 'USER' ? 'User' : 'District Admin'))))));

    // 3. District Assignment(s)
    let districtsDisplay = '';
    const userDistricts = (u.districts && Array.isArray(u.districts) && u.districts.length > 0)
      ? u.districts
      : [u.districtId || 'all'];

    if (userDistricts.includes('all') || u.districtId === 'all' || ['ADMIN', 'SUPER_ADMIN', 'FINANCE_ADMIN', 'PTCL_ADMIN'].includes(r)) {
      districtsDisplay = `<span class="badge" style="background:#f0fdf4; color:#166534; font-weight:700; border:1px solid #bbf7d0;">🏛️ All 37 Districts</span>`;
    } else {
      const badges = userDistricts.map(dId => {
        const found = OFFICIAL_37_DISTRICTS_LIST.find(d => d.id === dId || d.id === dId.toLowerCase().replace(/[^a-z0-9]/g, '_'));
        const dName = found ? found.name : (dId.charAt(0).toUpperCase() + dId.slice(1));
        return `<span class="badge" style="background:#eff6ff; color:#1e40af; font-weight:600; padding:3px 7px; margin:2px; font-size:11px;">${dName}</span>`;
      });
      districtsDisplay = `<div style="display:flex; flex-wrap:wrap; gap:2px; max-width:260px;">${badges.join('')}</div>`;
    }

    // 4. Permissions visual display
    const perms = Array.isArray(u.permissions) ? u.permissions : ['view'];
    const permBadges = PERMISSION_DEFINITIONS.filter(p => perms.includes(p.key)).map(p => 
      `<span style="display:inline-flex; align-items:center; gap:2px; font-size:10px; font-weight:700; background:#f1f5f9; color:${p.color}; border:1px solid #e2e8f0; padding:2px 6px; border-radius:4px; margin:1px;" title="${p.label} Permission">
        ${p.icon} ${p.label}
      </span>`
    ).join('');

    const permissionsCol = `
      <div style="display:flex; flex-wrap:wrap; gap:2px; max-width:240px;">
        ${permBadges || '<span style="color:#94a3b8; font-size:11px;">None</span>'}
      </div>
      <div style="font-size:10px; color:#64748b; margin-top:3px;">${perms.length} of 10 permitted</div>
    `;

    // 5. Status
    const isActive = u.active !== false;
    const statusBadge = isActive 
      ? `<span class="status ok" style="font-weight:700;">ACTIVE</span>` 
      : `<span class="status danger" style="font-weight:700;">INACTIVE</span>`;

    // 6. Action buttons
    const statusActionBtn = isPrimaryAdmin
      ? ''
      : (isActive
        ? `<button class="btn btn-sm" onclick="toggleUserStatusConfirm('${u.id}', false)" style="background:#fff7ed; color:#c2410c; border:1px solid #fed7aa; padding:4px 8px; font-size:11px; font-weight:600;" title="Suspend / Deactivate Access">⏸ Deactivate</button>`
        : `<button class="btn btn-sm" onclick="toggleUserStatusConfirm('${u.id}', true)" style="background:#f0fdf4; color:#15803d; border:1px solid #bbf7d0; padding:4px 8px; font-size:11px; font-weight:600;" title="Enable / Activate Access">▶ Activate</button>`);

    const deleteBtn = isPrimaryAdmin
      ? `<button class="btn btn-sm" disabled style="opacity:0.35; cursor:not-allowed;" title="Command Administrator cannot be deleted">🔒</button>`
      : `<button class="btn btn-sm btn-danger" onclick="deleteUserConfirm('${u.id}')" style="padding:4px 8px; font-size:11px;" title="Remove User Account">🗑️</button>`;

    return `
      <tr style="${!isActive ? 'background:#fcfcfc; opacity:0.85;' : ''}">
        <td>
          <div style="display:flex; align-items:center; gap:8px;">
            <div style="width:34px; height:34px; border-radius:50%; background:${isActive ? '#1d4ed8' : '#94a3b8'}; color:#fff; display:flex; align-items:center; justify-content:center; font-weight:700; font-size:11px; flex-shrink:0;">
              ${(u.name || u.username).substring(0, 2).toUpperCase()}
            </div>
            <div>
              <strong style="color:#0f172a; font-size:13px;">${u.name || u.username}</strong>
              <div style="font-size:11px; color:#64748b;">${u.designation || 'Portal User'} ${u.employeeId ? `• <span style="font-family:monospace;">${u.employeeId}</span>` : ''}</div>
              <div style="font-size:11px; color:#475569; margin-top:1px;">
                <code>${u.username}</code> ${u.email ? `• <a href="mailto:${u.email}" style="color:#2563eb; text-decoration:none;">${u.email}</a>` : ''}
              </div>
            </div>
          </div>
        </td>
        <td>${roleBadge}</td>
        <td>
          <div style="font-weight:600; font-size:12px; color:#1e293b;">${accessLevelDisplay}</div>
        </td>
        <td>${districtsDisplay}</td>
        <td>${permissionsCol}</td>
        <td>${statusBadge}</td>
        <td style="text-align:right;">
          <div style="display:inline-flex; gap:4px; align-items:center; justify-content:flex-end;">
            <button class="btn btn-sm btn-primary" onclick="openEditUserModal('${u.id}')" style="padding:4px 9px; font-size:11px; font-weight:600;" title="Edit User, Role & Permissions">
              ✏️ Edit
            </button>
            <button class="btn btn-sm" onclick="openResetPasswordModal('${u.id}')" style="padding:4px 8px; font-size:11px; background:#f8fafc; border:1px solid #cbd5e1;" title="Reset Sign-in Password">
              🔑
            </button>
            ${statusActionBtn}
            ${deleteBtn}
          </div>
        </td>
      </tr>
    `;
  }).join('');
}

// Populate District Checkboxes in Modal
function populateDistrictCheckboxesModal(selectedDistricts = []) {
  const container = document.getElementById('userModalDistrictContainer');
  if (!container) return;

  container.innerHTML = OFFICIAL_37_DISTRICTS_LIST.map(d => {
    const isChecked = selectedDistricts.includes(d.id) || selectedDistricts.includes(d.id.toLowerCase().replace(/[^a-z0-9]/g, '_')) || selectedDistricts.includes('all');
    return `
      <label class="district-modal-checkbox-item" data-district-name="${d.name.toLowerCase()}" style="display:flex; align-items:center; gap:6px; font-size:12px; cursor:pointer; padding:3px 6px; border-radius:4px; background:${isChecked ? '#eff6ff' : '#f8fafc'};">
        <input type="checkbox" class="user-modal-dist-chk" value="${d.id}" ${isChecked ? 'checked' : ''} onchange="updateSelectedDistrictsCount()">
        <span>${d.name}</span>
      </label>
    `;
  }).join('');

  updateSelectedDistrictsCount();
}

function selectAllDistrictsModal(selectAll) {
  const checkboxes = document.querySelectorAll('.user-modal-dist-chk');
  checkboxes.forEach(c => {
    c.checked = !!selectAll;
    if (c.parentElement) {
      c.parentElement.style.background = selectAll ? '#eff6ff' : '#f8fafc';
    }
  });
  updateSelectedDistrictsCount();
}

function filterDistrictModalList() {
  const query = (document.getElementById('userModalDistrictFilter')?.value || '').toLowerCase().trim();
  const items = document.querySelectorAll('.district-modal-checkbox-item');
  items.forEach(it => {
    const dName = it.getAttribute('data-district-name') || '';
    if (!query || dName.includes(query)) {
      it.style.display = 'flex';
    } else {
      it.style.display = 'none';
    }
  });
}

function updateSelectedDistrictsCount() {
  const checked = document.querySelectorAll('.user-modal-dist-chk:checked');
  const countLabel = document.getElementById('userModalDistrictSelectedCount');
  if (countLabel) {
    countLabel.textContent = `${checked.length} of 37 districts assigned`;
  }
}

function getSelectedDistrictsFromModal() {
  const checked = document.querySelectorAll('.user-modal-dist-chk:checked');
  return Array.from(checked).map(c => c.value);
}

function getSelectedPermissionsFromModal() {
  const perms = [];
  PERMISSION_DEFINITIONS.forEach(p => {
    const chk = document.getElementById(`perm_${p.key}`);
    if (chk && chk.checked) perms.push(p.key);
  });
  return perms;
}

function setModalPermissions(perms = []) {
  PERMISSION_DEFINITIONS.forEach(p => {
    const chk = document.getElementById(`perm_${p.key}`);
    if (chk) chk.checked = perms.includes(p.key);
  });
}

function applyPermissionPreset(preset) {
  const role = document.getElementById('userModalRole')?.value || 'DISTRICT_USER';
  if (preset === 'all') {
    if (role === 'READ_ONLY_ADMIN') {
      showToast('Read-Only users cannot be assigned full permissions.', 'warning');
      return;
    }
    setModalPermissions(['view', 'create', 'edit', 'update', 'delete', 'approve', 'close', 'acknowledge', 'export', 'import']);
  } else if (preset === 'readonly' || role === 'READ_ONLY_ADMIN') {
    setModalPermissions(['view', 'export']);
  } else {
    // Defaults based on role
    if (['ADMIN', 'SUPER_ADMIN'].includes(role)) {
      setModalPermissions(['view', 'create', 'edit', 'update', 'delete', 'approve', 'close', 'acknowledge', 'export', 'import']);
    } else if (role === 'FINANCE_ADMIN') {
      setModalPermissions(['view', 'create', 'edit', 'update', 'approve', 'export']);
    } else if (role === 'PTCL_ADMIN') {
      setModalPermissions(['view', 'update', 'export']);
    } else if (role === 'USER') {
      setModalPermissions(['view', 'create', 'edit', 'update', 'export']);
    } else {
      setModalPermissions(['view', 'create', 'edit', 'update', 'close', 'acknowledge', 'export']);
    }
  }
}

function updateUserModalRoleUI() {
  const roleSelect = document.getElementById('userModalRole');
  const distSection = document.getElementById('userModalDistrictSection');
  const provBanner = document.getElementById('userModalProvincialBanner');
  const roleDesc = document.getElementById('userModalRoleDescription');
  const readOnlyNotice = document.getElementById('readOnlyPermNotice');

  if (!roleSelect) return;
  const role = roleSelect.value;
  const isProvincial = ['ADMIN', 'SUPER_ADMIN', 'FINANCE_ADMIN', 'PTCL_ADMIN'].includes(role);
  const isReadOnly = role === 'READ_ONLY_ADMIN';

  // 1. District Assignment Section UI
  if (isProvincial) {
    if (distSection) distSection.style.display = 'none';
    if (provBanner) provBanner.style.display = 'block';
  } else {
    if (distSection) distSection.style.display = 'block';
    if (provBanner) provBanner.style.display = 'none';
  }

  // 2. Role Description Box
  if (roleDesc) {
    const descriptions = {
      'ADMIN': '🌐 <strong>All Punjab Admin:</strong> Direct operational and analytical command across all 37 Punjab districts. Can view, create, edit, approve, and export all provincial data.',
      'SUPER_ADMIN': '👑 <strong>Super Admin / Full Admin:</strong> Unrestricted system command. Full administrative authority including user management, security roles, system configuration, and audit.',
      'DISTRICT_USER': '🏛️ <strong>District Admin:</strong> Operational authority restricted strictly to assigned district(s). Can submit reports, manage district workforce, and update local tickets.',
      'USER': '👤 <strong>Standard User:</strong> Basic operational access restricted to assigned district(s). Suitable for field technicians and data contributors.',
      'FINANCE_ADMIN': '₨ <strong>Finance Admin:</strong> Dedicated access to provincial and district expenditure ledgers, disbursements, fiscal audits, and financial queries.',
      'PTCL_ADMIN': '🎫 <strong>PTCL Admin:</strong> Dedicated access to PTCL NOC link tickets, telecom connectivity status, resolution updates, and carrier SLAs.',
      'READ_ONLY_ADMIN': '👁️ <strong>Read Only Observer:</strong> Global view access across all 37 districts, sites, and analytics. All modification (create, edit, update, delete, approve, import) permissions are permanently locked.'
    };
    roleDesc.innerHTML = descriptions[role] || descriptions['DISTRICT_USER'];
  }

  // 3. Permission checkboxes handling (Strict Read Only enforcement)
  const mutationPerms = ['create', 'edit', 'update', 'delete', 'approve', 'close', 'acknowledge', 'import'];
  if (isReadOnly) {
    mutationPerms.forEach(p => {
      const chk = document.getElementById(`perm_${p}`);
      if (chk) {
        chk.checked = false;
        chk.disabled = true;
        if (chk.parentElement) chk.parentElement.style.opacity = '0.4';
      }
    });
    const viewChk = document.getElementById('perm_view');
    const expChk = document.getElementById('perm_export');
    if (viewChk) { viewChk.checked = true; viewChk.disabled = false; }
    if (expChk) { expChk.disabled = false; }
    if (readOnlyNotice) readOnlyNotice.style.display = 'block';
  } else {
    mutationPerms.forEach(p => {
      const chk = document.getElementById(`perm_${p}`);
      if (chk) {
        chk.disabled = false;
        if (chk.parentElement) chk.parentElement.style.opacity = '1';
      }
    });
    if (readOnlyNotice) readOnlyNotice.style.display = 'none';
  }
}

function openAddUserModal() {
  const modal = document.getElementById('userModal');
  const title = document.getElementById('userModalTitle');
  const subtitle = document.getElementById('userModalSubtitle');
  const editId = document.getElementById('userModalEditId');
  const formName = document.getElementById('userModalName');
  const formEmpId = document.getElementById('userModalEmpId');
  const formUser = document.getElementById('userModalUsername');
  const formEmail = document.getElementById('userModalEmail');
  const formPass = document.getElementById('userModalPassword');
  const formStatus = document.getElementById('userModalStatus');
  const formRole = document.getElementById('userModalRole');
  const passStar = document.getElementById('userModalPasswordStar');
  const passHint = document.getElementById('userModalPasswordHint');

  if (title) title.textContent = 'Add New Portal User & Configure Access';
  if (subtitle) subtitle.textContent = 'Select access level, assign permitted district(s), and specify granular module permissions';
  if (editId) editId.value = '';
  if (formName) formName.value = '';
  if (formEmpId) formEmpId.value = `NRTC-ENG-${Math.floor(1000 + Math.random() * 9000)}`;
  if (formUser) formUser.value = '';
  if (formEmail) formEmail.value = '';
  if (formRole) formRole.value = 'DISTRICT_USER';
  if (formStatus) formStatus.value = 'active';

  if (passStar) passStar.style.display = 'inline';
  if (passHint) passHint.textContent = 'Required default password for first sign-in.';
  if (formPass) {
    formPass.value = 'password123';
    formPass.placeholder = 'Default password (e.g. password123)';
    formPass.required = true;
  }

  // Pre-select Chakwal as default district for district user
  populateDistrictCheckboxesModal(['chakwal']);
  applyPermissionPreset('defaults');
  updateUserModalRoleUI();

  if (modal) {
    modal.classList.add('open');
    modal.style.display = 'flex';
  }
}

function openEditUserModal(userId) {
  const user = window.store.getUserById(userId);
  if (!user) {
    showToast('User account not found', 'error');
    return;
  }

  const modal = document.getElementById('userModal');
  const title = document.getElementById('userModalTitle');
  const subtitle = document.getElementById('userModalSubtitle');
  const editId = document.getElementById('userModalEditId');
  const formName = document.getElementById('userModalName');
  const formEmpId = document.getElementById('userModalEmpId');
  const formUser = document.getElementById('userModalUsername');
  const formEmail = document.getElementById('userModalEmail');
  const formPass = document.getElementById('userModalPassword');
  const formStatus = document.getElementById('userModalStatus');
  const formRole = document.getElementById('userModalRole');
  const passStar = document.getElementById('userModalPasswordStar');
  const passHint = document.getElementById('userModalPasswordHint');

  if (title) title.textContent = `Edit User & Permissions: ${user.name || user.username}`;
  if (subtitle) subtitle.textContent = `Modify role, assigned district(s), granular permissions, and credentials for ${user.username}`;
  if (editId) editId.value = user.id;
  if (formName) formName.value = user.name || '';
  if (formEmpId) formEmpId.value = user.employeeId || '';
  if (formUser) formUser.value = user.username || '';
  if (formEmail) formEmail.value = user.email || '';
  if (formRole) formRole.value = user.role || 'DISTRICT_USER';
  if (formStatus) formStatus.value = user.active !== false ? 'active' : 'inactive';

  if (passStar) passStar.style.display = 'none';
  if (passHint) passHint.textContent = 'Leave blank to preserve current credentials unchanged.';
  if (formPass) {
    formPass.value = '';
    formPass.placeholder = 'Leave blank to keep existing password';
    formPass.required = false;
  }

  // User districts
  const userDistricts = (user.districts && Array.isArray(user.districts) && user.districts.length > 0)
    ? user.districts
    : [user.districtId || 'chakwal'];
  populateDistrictCheckboxesModal(userDistricts);

  // User permissions
  const userPerms = Array.isArray(user.permissions) && user.permissions.length > 0
    ? user.permissions
    : (user.role === 'READ_ONLY_ADMIN' ? ['view', 'export'] : ['view', 'create', 'edit', 'update', 'export']);
  setModalPermissions(userPerms);

  updateUserModalRoleUI();

  if (modal) {
    modal.classList.add('open');
    modal.style.display = 'flex';
  }
}

function closeUserModal() {
  const modal = document.getElementById('userModal');
  if (modal) {
    modal.classList.remove('open');
    modal.style.display = 'none';
  }
}

function handleSaveUserForm(e) {
  if (e) e.preventDefault();

  const editId = document.getElementById('userModalEditId').value;
  const name = document.getElementById('userModalName').value.trim();
  const empId = document.getElementById('userModalEmpId').value.trim();
  const username = document.getElementById('userModalUsername').value.trim().toLowerCase();
  const email = document.getElementById('userModalEmail').value.trim().toLowerCase();
  const password = document.getElementById('userModalPassword').value.trim();
  const statusField = document.getElementById('userModalStatus');
  const isActive = statusField ? statusField.value === 'active' : true;
  const role = document.getElementById('userModalRole').value;

  if (!name || !username || !email) {
    showToast('Name, username, and email are required fields.', 'error');
    return;
  }

  // Determine Access Level string
  const roleSelect = document.getElementById('userModalRole');
  let accessLevel = 'District Admin';
  if (role === 'SUPER_ADMIN') accessLevel = 'Super Admin / Full Admin';
  else if (role === 'ADMIN') accessLevel = 'All Punjab Admin';
  else if (role === 'READ_ONLY_ADMIN') accessLevel = 'Read Only';
  else if (role === 'FINANCE_ADMIN') accessLevel = 'Finance Admin';
  else if (role === 'PTCL_ADMIN') accessLevel = 'PTCL Admin';
  else if (role === 'USER') accessLevel = 'User';
  else accessLevel = 'District Admin';

  // District Assignment
  let districts = [];
  let districtId = 'all';
  let districtName = 'All 37 Districts (Provincial Access)';

  if (['ADMIN', 'SUPER_ADMIN', 'FINANCE_ADMIN', 'PTCL_ADMIN'].includes(role)) {
    districts = ['all'];
    districtId = 'all';
    districtName = 'All 37 Districts (Provincial Access)';
  } else {
    districts = getSelectedDistrictsFromModal();
    if (districts.length === 0) {
      showToast('Please select at least one assigned district for this user.', 'warning');
      return;
    }
    districtId = districts[0];
    const firstDistrictObj = OFFICIAL_37_DISTRICTS_LIST.find(d => d.id === districtId);
    districtName = districts.length === 1 
      ? (firstDistrictObj ? firstDistrictObj.name : districtId) 
      : `${districts.length} Districts Assigned (${firstDistrictObj ? firstDistrictObj.name : districtId} + ${districts.length - 1} more)`;
  }

  // Permissions Assignment
  let permissions = getSelectedPermissionsFromModal();
  if (role === 'READ_ONLY_ADMIN') {
    permissions = ['view', 'export'];
  }
  if (!permissions.includes('view')) {
    permissions.unshift('view'); // view is mandatory
  }

  const payload = {
    name,
    employeeId: empId,
    username,
    email,
    role,
    accessLevel,
    districtId,
    districtName,
    districts,
    permissions,
    active: isActive,
    designation: role === 'ADMIN' ? 'Command Lead' : (role === 'FINANCE_ADMIN' ? 'Accounts Lead' : (role === 'PTCL_ADMIN' ? 'PTCL NOC Operations Lead' : `${accessLevel} (${districtName})`))
  };

  if (password) {
    payload.password = password;
  }

  if (editId) {
    const res = window.store.updateUser(editId, payload);
    if (res.success) {
      showToast(`User ${name} updated successfully. Changes take effect immediately.`, 'success');
      closeUserModal();
      renderUsersTable();
      if (appState.activePage === 'profile') {
        renderProfileView();
      }
    } else {
      showToast(res.error || 'Failed to update user.', 'error');
    }
  } else {
    payload.password = password || 'password123';
    const res = window.store.createUser(payload);
    if (res.success) {
      showToast(`User account created successfully for ${name}.`, 'success');
      closeUserModal();
      renderUsersTable();
    } else {
      showToast(res.error || 'Failed to create user.', 'error');
    }
  }
}

// 1-Click Status Toggle (Activate / Deactivate)
function toggleUserStatusConfirm(userId, targetActive) {
  const user = window.store.getUserById(userId);
  if (!user) return;

  if ((user.role === 'ADMIN' && user.username === 'admin') || user.id === 'usr_admin') {
    showToast('Cannot deactivate the primary PMU Administrator account.', 'error');
    return;
  }

  const actionText = targetActive ? 'activate' : 'deactivate';
  const confirmMsg = targetActive
    ? `Enable account access for "${user.name}" (${user.username})?`
    : `Suspend / deactivate account access for "${user.name}" (${user.username})? This user will not be able to sign in until re-enabled.`;

  if (confirm(confirmMsg)) {
    const res = window.store.toggleUserStatus(userId, targetActive);
    if (res.success) {
      showToast(`User "${user.name}" is now ${targetActive ? 'Active' : 'Inactive'}.`, 'success');
      renderUsersTable();
    } else {
      showToast(res.error || `Failed to ${actionText} user.`, 'error');
    }
  }
}

// Quick Reset Password Modal
function openResetPasswordModal(userId) {
  const user = window.store.getUserById(userId);
  if (!user) {
    showToast('User not found', 'error');
    return;
  }

  const modal = document.getElementById('resetPasswordModal');
  const targetId = document.getElementById('resetPasswordUserId');
  const targetName = document.getElementById('resetPasswordTargetName');
  const targetUser = document.getElementById('resetPasswordTargetUser');
  const passInput = document.getElementById('resetPasswordNewVal');

  if (targetId) targetId.value = user.id;
  if (targetName) targetName.textContent = user.name || user.username;
  if (targetUser) targetUser.textContent = user.username;
  if (passInput) passInput.value = '';

  if (modal) {
    modal.classList.add('open');
    modal.style.display = 'flex';
  }
}

function closeResetPasswordModal() {
  const modal = document.getElementById('resetPasswordModal');
  if (modal) {
    modal.classList.remove('open');
    modal.style.display = 'none';
  }
}

function generateRandomPass() {
  const chars = 'ABCDEFGHJKLMNPQRSTUVWXYZabcdefghijkmnpqrstuvwxyz23456789!@#$';
  let pass = '';
  for (let i = 0; i < 10; i++) {
    pass += chars.charAt(Math.floor(Math.random() * chars.length));
  }
  const input = document.getElementById('resetPasswordNewVal');
  if (input) input.value = pass;
}

function handleResetPasswordSubmit(e) {
  if (e) e.preventDefault();
  const userId = document.getElementById('resetPasswordUserId').value;
  const newPass = document.getElementById('resetPasswordNewVal').value.trim();

  if (!newPass) {
    showToast('Please enter a new password.', 'warning');
    return;
  }

  const res = window.store.resetPassword(userId, newPass);
  if (res.success) {
    showToast('Password credentials updated successfully. The user must sign in using the new password.', 'success');
    closeResetPasswordModal();
  } else {
    showToast(res.error || 'Failed to reset password.', 'error');
  }
}

function deleteUserConfirm(userId) {
  const user = window.store.getUserById(userId);
  if (!user) return;
  if ((user.role === 'ADMIN' && user.username === 'admin') || user.id === 'usr_admin') {
    showToast('Cannot delete the primary PMU Administrator account.', 'error');
    return;
  }
  if (confirm(`Are you sure you want to permanently remove user "${user.name}" (${user.districtName || user.username})? All sign-in credentials and access permissions will be revoked.`)) {
    const res = window.store.deleteUser(userId);
    if (res.success) {
      showToast(`User account removed successfully.`, 'success');
      renderUsersTable();
    } else {
      showToast(res.error || 'Failed to delete user.', 'error');
    }
  }
}

// ==========================================
// Historical Data Import Controller
// ==========================================

let pendingImportReports = [];

function initImportView() {
  pendingImportReports = [];
  const fileInput = document.getElementById('csvFileInput');
  if (fileInput) fileInput.value = '';

  const previewSec = document.getElementById('importPreviewSection');
  if (previewSec) previewSec.style.display = 'none';

  const errorsBox = document.getElementById('importErrorsBox');
  if (errorsBox) errorsBox.style.display = 'none';
}

function setupImportDropzone() {
  const dropzone = document.getElementById('importDropzone');
  if (!dropzone) return;

  ['dragenter', 'dragover'].forEach(eventName => {
    dropzone.addEventListener(eventName, (e) => {
      e.preventDefault();
      e.stopPropagation();
      dropzone.classList.add('dragover');
    }, false);
  });

  ['dragleave', 'drop'].forEach(eventName => {
    dropzone.addEventListener(eventName, (e) => {
      e.preventDefault();
      e.stopPropagation();
      dropzone.classList.remove('dragover');
    }, false);
  });

  dropzone.addEventListener('drop', (e) => {
    const dt = e.dataTransfer;
    const files = dt.files;
    if (files && files.length > 0) {
      processImportFile(files[0]);
    }
  }, false);
}

function handleCSVFileSelected(e) {
  const file = e.target.files ? e.target.files[0] : null;
  if (file) {
    processImportFile(file);
  }
}

function processImportFile(file) {
  if (!file.name.toLowerCase().endsWith('.csv')) {
    showToast('Please upload a valid .csv file.', 'error');
    return;
  }

  const reader = new FileReader();
  reader.onload = function(e) {
    const text = e.target.result;
    if (!text || !text.trim()) {
      showToast('Uploaded file is empty.', 'error');
      return;
    }

    try {
      const rawRecords = window.SafeCityImport.parseCSV(text);
      if (rawRecords.length === 0) {
        showToast('No tabular rows found in CSV. Please ensure you use the official template.', 'error');
        return;
      }

      const { validReports, errors } = window.SafeCityImport.mapRecordsToReports(rawRecords);
      pendingImportReports = validReports;

      const previewSec = document.getElementById('importPreviewSection');
      const summaryText = document.getElementById('importSummaryText');
      const validCount = document.getElementById('importValidCount');
      const errorsBox = document.getElementById('importErrorsBox');
      const tableBody = document.getElementById('importPreviewTableBody');

      if (summaryText) summaryText.textContent = `Parsed: ${rawRecords.length} Rows • Ready to Import: ${validReports.length} Records`;
      if (validCount) validCount.textContent = `${validReports.length} Valid`;

      if (errors && errors.length > 0) {
        if (errorsBox) {
          errorsBox.innerHTML = `<strong>Data Warnings (${errors.length}):</strong><br>` + errors.slice(0, 5).join('<br>') + (errors.length > 5 ? `<br>...and ${errors.length - 5} more issues.` : '');
          errorsBox.style.display = 'block';
        }
      } else if (errorsBox) {
        errorsBox.style.display = 'none';
      }

      if (tableBody) {
        if (validReports.length === 0) {
          tableBody.innerHTML = `<tr><td colspan="7" style="text-align:center; padding:20px; color:#dc2626;">No valid records could be extracted. Please check the district names and date formats.</td></tr>`;
        } else {
          tableBody.innerHTML = validReports.slice(0, 15).map(r => `
            <tr>
              <td><code>${r.report_date}</code></td>
              <td><strong>${r.district_name}</strong></td>
              <td>${r.user_name}</td>
              <td>${r.ipnv_online} / ${r.ipnv_installed}</td>
              <td>${r.cee_online} / ${r.cee_installed}</td>
              <td>${r.ofc_cut === 'Yes' ? '<span class="badge danger">Cut</span>' : '<span class="badge ok">OK</span>'}</td>
              <td>${r.generator_runtime}h</td>
            </tr>
          `).join('');

          if (validReports.length > 15) {
            tableBody.innerHTML += `<tr><td colspan="7" style="text-align:center; color:#64748b; font-style:italic;">...and ${validReports.length - 15} more records will be imported.</td></tr>`;
          }
        }
      }

      const commitBtn = document.getElementById('btnCommitImport');
      if (commitBtn) commitBtn.disabled = validReports.length === 0;

      if (previewSec) previewSec.style.display = 'block';
      showToast(`Parsed ${validReports.length} valid historical reports.`, 'info');
    } catch (err) {
      console.error(err);
      showToast('Error parsing CSV file: ' + err.message, 'error');
    }
  };

  reader.readAsText(file);
}

function cancelImport() {
  initImportView();
  showToast('Import cancelled.', 'info');
}

function commitImportedData() {
  if (!pendingImportReports || pendingImportReports.length === 0) {
    showToast('No valid reports to import.', 'error');
    return;
  }

  const result = window.store.importHistoricalReports(pendingImportReports);
  showToast(`Successfully imported ${result.total} reports (${result.addedCount} new, ${result.updatedCount} updated).`, 'success');

  initImportView();

  // Refresh data views
  if (appState.currentUser.role === 'ADMIN') {
    renderAdminDashboard();
    renderAdminReportsTable();
    showPage('admin-reports');
  } else {
    renderDistrictDashboard();
    renderMyReportsTable();
    showPage('reports');
  }
}

// ==========================================
// Toast Alerts & Helpers
// ==========================================

function showToast(message, type = 'info') {
  const container = document.getElementById('toastContainer');
  if (!container) return;

  const toast = document.createElement('div');
  toast.className = `toast ${type}`;
  toast.innerHTML = `<span>${message}</span>`;

  container.appendChild(toast);
  setTimeout(() => {
    toast.style.opacity = '0';
    toast.style.transform = 'translateX(100%)';
    toast.style.transition = 'all 0.3s ease';
    setTimeout(() => toast.remove(), 300);
  }, 3500);
}

function formatDateDisplay(dateStr) {
  if (!dateStr) return 'N/A';
  try {
    const d = new Date(dateStr);
    return d.toLocaleDateString('en-GB', { day: 'numeric', month: 'short', year: 'numeric' });
  } catch (e) {
    return dateStr;
  }
}

function resetDemoData() {
  if (confirm('Reset all daily reports to initial demo state?')) {
    window.store.resetToDemoData();
    appState.currentUser = window.store.getCurrentUser();
    setupRoleSwitcher();
    renderAppByRole();
    showToast('Demo data restored successfully.', 'success');
  }
}

// ==========================================
// Mobile Navigation & Responsive Handlers
// ==========================================

function toggleMobileSidebar(forceState) {
  const sidebar = document.getElementById('sidebar');
  if (!sidebar) return;

  let overlay = document.getElementById('sidebarOverlay');
  if (!overlay) {
    overlay = document.createElement('div');
    overlay.id = 'sidebarOverlay';
    overlay.className = 'sidebar-overlay';
    overlay.onclick = () => toggleMobileSidebar(false);
    document.body.appendChild(overlay);
  }

  const isCurrentlyOpen = sidebar.classList.contains('open');
  const willOpen = forceState !== undefined ? Boolean(forceState) : !isCurrentlyOpen;

  if (willOpen) {
    sidebar.classList.add('open');
    overlay.classList.add('active');
    document.body.style.overflow = 'hidden';
  } else {
    sidebar.classList.remove('open');
    overlay.classList.remove('active');
    document.body.style.overflow = '';
  }
}

function setupMobileResponsiveness() {
  if (typeof document === 'undefined' || !document.body) return;

  // Ensure overlay backdrop exists in DOM
  let overlay = document.getElementById('sidebarOverlay');
  if (!overlay) {
    overlay = document.createElement('div');
    overlay.id = 'sidebarOverlay';
    overlay.className = 'sidebar-overlay';
    overlay.onclick = () => toggleMobileSidebar(false);
    document.body.appendChild(overlay);
  }

  // Inject close button into sidebar header if not present
  const brand = document.querySelector('.sidebar .brand');
  if (brand && !brand.querySelector('.sidebar-close-btn')) {
    const closeBtn = document.createElement('button');
    closeBtn.className = 'sidebar-close-btn';
    closeBtn.type = 'button';
    closeBtn.innerHTML = '✕';
    closeBtn.title = 'Close Navigation Menu';
    closeBtn.setAttribute('aria-label', 'Close menu');
    closeBtn.onclick = (e) => {
      e.stopPropagation();
      toggleMobileSidebar(false);
    };
    brand.appendChild(closeBtn);
  }

  // Auto-close sidebar on mobile when clicking any navigation link
  document.querySelectorAll('.sidebar a').forEach(a => {
    a.addEventListener('click', () => {
      if (typeof window !== 'undefined' && window.innerWidth <= 1024) {
        toggleMobileSidebar(false);
      }
    });
  });

  // Initialize top profile popup
  setupTopProfilePopup();
}

function setupTopProfilePopup() {
  if (typeof document === 'undefined') return;
  const profileEl = document.querySelector('.topbar .profile') || document.querySelector('.profile');
  if (!profileEl) return;

  // Make profile element clickable
  profileEl.onclick = (e) => {
    // If click originated from within the popup actions, don't re-toggle
    if (e.target.closest('#topbarProfilePopup a, #topbarProfilePopup button')) return;
    e.stopPropagation();
    toggleTopProfilePopup();
  };

  // Construct dropdown popup if not already present
  let popup = document.getElementById('topbarProfilePopup');
  if (!popup) {
    popup = document.createElement('div');
    popup.id = 'topbarProfilePopup';
    popup.className = 'topbar-profile-popup';
    popup.onclick = (e) => e.stopPropagation();

    const user = appState.currentUser || (window.store ? window.store.getCurrentUser() : null);
    const isDistrict = user && user.role === 'DISTRICT_USER';
    const userName = user ? user.name : 'NRTC Engineer';
    const userDistrict = isDistrict ? `NRTC ${user.districtName} Field Site` : 'NRTC Safe City PMU Command';
    const badgeText = isDistrict ? `${user.districtName} Site Engineer` : '🛡️ NRTC PMU Admin';
    const avatarInitials = isDistrict ? 'NRTC' : 'PMU';
    const avatarClass = isDistrict ? 'avatar' : 'avatar admin-avatar';

    popup.innerHTML = `
      <div class="profile-popup-header">
        <div class="${avatarClass}" id="popupAvatar" style="background:${isDistrict ? '#0f3460' : '#1d4ed8'}; color:#fff; font-size:10px;">${avatarInitials}</div>
        <div class="profile-popup-info">
          <b id="popupUserName">${userName}</b>
          <span class="popup-sub" id="popupUserDistrict">${userDistrict}</span>
          <span class="badge" id="popupRoleBadge" style="background:${isDistrict ? '#f1f5f9' : '#eff6ff'}; color:${isDistrict ? '#334155' : '#1d4ed8'}; font-weight:700;">${badgeText}</span>
        </div>
      </div>
      <div class="profile-popup-menu">
        <a href="profile.html" class="profile-popup-item">
          <span class="item-icon">⚙</span>
          <span>NRTC Profile & Account</span>
        </a>
        <a href="attendance.html" class="profile-popup-item">
          <span class="item-icon">📍</span>
          <span>Live Field Attendance</span>
        </a>
        <a href="finance.html" class="profile-popup-item">
          <span class="item-icon">₨</span>
          <span>District Financial Records</span>
        </a>
      </div>
      <div class="profile-popup-footer">
        <button class="btn btn-sm btn-danger-soft" onclick="handleLogout()">
          ↪ Sign Out from Portal
        </button>
      </div>
    `;
    profileEl.appendChild(popup);
  }

  // Attach global click & Escape listeners once
  if (!window._topbarPopupListenersAttached) {
    window._topbarPopupListenersAttached = true;
    document.addEventListener('click', (e) => {
      const p = document.getElementById('topbarProfilePopup');
      if (p && p.classList.contains('show')) {
        p.classList.remove('show');
      }
    });
    document.addEventListener('keydown', (e) => {
      if (e.key === 'Escape') {
        const p = document.getElementById('topbarProfilePopup');
        if (p && p.classList.contains('show')) {
          p.classList.remove('show');
        }
      }
    });
  }
}

function toggleTopProfilePopup(forceState) {
  const popup = document.getElementById('topbarProfilePopup');
  if (!popup) return;
  const isCurrentlyShown = popup.classList.contains('show');
  const willShow = forceState !== undefined ? Boolean(forceState) : !isCurrentlyShown;

  if (willShow) {
    // Refresh content with latest current user data
    const user = appState.currentUser || (window.store ? window.store.getCurrentUser() : null);
    if (user) {
      const isDistrict = user.role === 'DISTRICT_USER';
      const pName = document.getElementById('popupUserName');
      const pDist = document.getElementById('popupUserDistrict');
      const pAv = document.getElementById('popupAvatar');
      const pBadge = document.getElementById('popupRoleBadge');

      if (pName) pName.textContent = user.name;
      if (pDist) pDist.textContent = isDistrict ? `NRTC ${user.districtName} Field Site` : 'NRTC Safe City PMU Command';
      if (pAv) {
        pAv.textContent = isDistrict ? 'NRTC' : 'PMU';
        pAv.className = isDistrict ? 'avatar' : 'avatar admin-avatar';
        pAv.style.background = isDistrict ? '#0f3460' : '#1d4ed8';
      }
      if (pBadge) {
        pBadge.textContent = isDistrict ? `${user.districtName} Site Engineer` : '🛡️ NRTC PMU Admin';
        pBadge.style.background = isDistrict ? '#f1f5f9' : '#eff6ff';
        pBadge.style.color = isDistrict ? '#334155' : '#1d4ed8';
      }
    }
    popup.classList.add('show');
  } else {
    popup.classList.remove('show');
  }
}

function closeTopProfilePopup() {
  toggleTopProfilePopup(false);
}

// Window resize listener with debounce for high-DPI canvas charts and layout corrections
let windowResizeTimer = null;
if (typeof window !== 'undefined' && window.addEventListener) {
  window.addEventListener('resize', () => {
    clearTimeout(windowResizeTimer);
    windowResizeTimer = setTimeout(() => {
      if (window.innerWidth > 1024) {
        toggleMobileSidebar(false);
      }
      // Re-render SLA charts on resize/orientation change if chart canvas is present
      if (document.getElementById('chartEquipmentSLA') && typeof renderSLAAnalytics === 'function') {
        renderSLAAnalytics();
      }
    }, 120);
  });
}

// Expose globals for HTML inline onclick handlers
window.showPage = showPage;
window.toggleMobileSidebar = toggleMobileSidebar;
window.setupTopProfilePopup = setupTopProfilePopup;
window.toggleTopProfilePopup = toggleTopProfilePopup;
window.closeTopProfilePopup = closeTopProfilePopup;
window.switchRoleMode = switchRoleMode;
window.onRoleDistrictChange = onRoleDistrictChange;
window.wizardNext = wizardNext;
window.wizardPrev = wizardPrev;
window.goToWizardStep = goToWizardStep;
window.toggleOfcFields = toggleOfcFields;
window.resetFormToDistrictDefaults = resetFormToDistrictDefaults;
window.populateStep6Review = populateStep6Review;
window.handleReportFormSubmit = handleReportFormSubmit;
window.editReport = editReport;
window.openReportDetailModal = openReportDetailModal;
window.closeReportDetailModal = closeReportDetailModal;
window.submitAdminReview = submitAdminReview;
window.printReportById = printReportById;
window.exportCurrentReports = exportCurrentReports;
window.resetDemoData = resetDemoData;
window.renderAdminReportsTable = renderAdminReportsTable;
window.applyAdminReportFilters = applyAdminReportFilters;
window.debounceAdminFilter = debounceAdminFilter;
window.resetAdminReportFilters = resetAdminReportFilters;
window.onAdminDistrictChange = onAdminDistrictChange;
window.changeAdminReportsPage = changeAdminReportsPage;
window.exportAdminReports = exportAdminReports;
window.updateAdminSitesDatalist = updateAdminSitesDatalist;
window.updateAdminSitesDropdown = updateAdminSitesDropdown;
window.renderMyReportsTable = renderMyReportsTable;

// Auth, Users, & Import handlers
window.handleLoginFormSubmit = handleLoginFormSubmit;
window.quickLogin = quickLogin;
window.handleLogout = handleLogout;
window.renderUsersTable = renderUsersTable;
window.openAddUserModal = openAddUserModal;
window.openEditUserModal = openEditUserModal;
window.openProfileEditModal = openProfileEditModal;
window.closeUserModal = closeUserModal;
window.handleSaveUserForm = handleSaveUserForm;
window.deleteUserConfirm = deleteUserConfirm;
window.toggleUserStatusConfirm = toggleUserStatusConfirm;
window.openResetPasswordModal = openResetPasswordModal;
window.closeResetPasswordModal = closeResetPasswordModal;
window.handleResetPasswordSubmit = handleResetPasswordSubmit;
window.generateRandomPass = generateRandomPass;
window.selectAllDistrictsModal = selectAllDistrictsModal;
window.filterDistrictModalList = filterDistrictModalList;
window.applyPermissionPreset = applyPermissionPreset;
window.updateSelectedDistrictsCount = updateSelectedDistrictsCount;
window.handleCSVFileSelected = handleCSVFileSelected;
window.cancelImport = cancelImport;
window.commitImportedData = commitImportedData;
window.updateUserModalRoleUI = updateUserModalRoleUI;

// Export & Matrix & Analytics globals
window.openExportModal = openExportModal;
window.closeExportModal = closeExportModal;
window.setExportMode = setExportMode;
window.updateExportPreview = updateExportPreview;
window.executeModalExport = executeModalExport;
window.initDistrictsMatrixPage = initDistrictsMatrixPage;
window.filterDistrictsMatrix = filterDistrictsMatrix;
window.renderDistrictsMatrix = renderDistrictsMatrix;
window.exportMatrixSites = exportMatrixSites;
window.initSlaFilters = initSlaFilters;
window.updateSlaSitesDropdown = updateSlaSitesDropdown;
window.onSlaDistrictChange = onSlaDistrictChange;
window.applySlaFilters = applySlaFilters;
window.resetSlaFilters = resetSlaFilters;
window.exportFilteredSlaReport = exportFilteredSlaReport;
window.onAnalyticsFilterChange = onAnalyticsFilterChange;
window.renderAnalyticsView = renderAnalyticsView;
window.setAnalyticsTableTab = setAnalyticsTableTab;
window.filterByDistrictFromTable = filterByDistrictFromTable;

// ==========================================
// Live Attendance & Geolocation Controller
// ==========================================

let currentGeoCoordinates = null;

async function renderAttendancePage() {
  const user = appState.currentUser || window.store.getCurrentUser();
  const isDistrict = user.role === 'DISTRICT_USER';

  // Asynchronously prefetch real employees so store is fully synced
  if (window.api && typeof window.api.getEmployees === 'function') {
    try {
      const emps = await window.api.getEmployees();
      if (emps && emps.length > 0 && window.store.syncEmployees) {
        window.store.syncEmployees(emps);
      }
    } catch (e) {
      console.warn('Attendance prefetch note:', e);
    }
  }

  const distView = document.getElementById('districtAttendanceView');
  const adminView = document.getElementById('adminAttendanceView');

  if (distView) distView.style.display = isDistrict ? 'block' : 'none';
  if (adminView) adminView.style.display = !isDistrict ? 'block' : 'none';

  const titleText = document.getElementById('pageTitleText') || document.getElementById('attendancePageTitle');
  const subtitleText = document.getElementById('pageSubtitleText') || document.getElementById('attendancePageSubtitle');

  if (isDistrict) {
    if (titleText) titleText.textContent = `Live Field Attendance — ${user.districtName || 'District'} Site`;
    if (subtitleText) subtitleText.textContent = `GPS Location Verification for Field O&M Personnel (${user.districtName})`;
    renderDistrictAttendance();
    renderDistrictAttendanceLog();
  } else {
    if (titleText) titleText.textContent = 'Provincial Field Attendance & GPS Telemetry';
    if (subtitleText) subtitleText.textContent = 'Real-time GPS Tracking of Field Staff across all 37 Districts';
    renderAdminAttendance();
  }
}

function renderDistrictAttendance() {
  const user = appState.currentUser || window.store.getCurrentUser();
  const districtId = user.districtId || 'chakwal';
  const dist = window.getDistrictById ? window.getDistrictById(districtId) : null;

  const distHeader = document.getElementById('distRosterHeader');
  const distSub = document.getElementById('distRosterSub');
  if (distHeader) distHeader.textContent = `${user.districtName || 'District'} Field Operations Team`;
  if (distSub && dist) {
    distSub.textContent = `All 3 field staff must check in within ${dist.radiusKm} km of ${dist.centerName || dist.name + ' Center'}.`;
  }

  const summary = window.store.getDistrictAttendanceSummary(districtId);
  const elTotal = document.getElementById('distStatTotalStaff');
  const elPresent = document.getElementById('distStatPresent');
  const elPresentPct = document.getElementById('distStatPresentPct');
  const elAbsent = document.getElementById('distStatAbsent');
  const elGeofence = document.getElementById('distStatGeofence');
  const elCenterName = document.getElementById('distStatCenterName');

  if (elTotal) elTotal.textContent = summary.totalEmployees;
  if (elPresent) elPresent.textContent = summary.present;
  if (elPresentPct) elPresentPct.textContent = `${summary.attendanceRate}% Present Today`;
  if (elAbsent) elAbsent.textContent = summary.absent + summary.outOfBounds;
  if (elGeofence && dist) elGeofence.textContent = `${dist.radiusKm} km`;
  if (elCenterName && dist) elCenterName.textContent = dist.centerName || `${dist.name} Hub`;

  const container = document.getElementById('districtRosterCardsContainer');
  if (!container) return;

  const employees = window.store.getEmployeesByDistrict(districtId);
  const attendanceToday = window.store.getAttendanceToday(districtId);

  container.innerHTML = employees.map(emp => {
    const eid = emp.empId || emp.employeeId || emp.id;
    const att = attendanceToday.find(a => a.employeeId === eid || a.employeeId === emp.id || a.employeeId === emp.empId);
    const isPresent = att && att.status === 'PRESENT';
    const isLate = att && att.status === 'LATE';
    const isOutOfBounds = att && att.status === 'OUT_OF_BOUNDS';

    let cardClass = 'emp-card';
    let badgeHtml = '<span class="badge" style="background:#fee2e2; color:#991b1b;">ABSENT / NOT CHECKED IN</span>';

    if (isPresent) {
      cardClass += ' present';
      badgeHtml = '<span class="badge" style="background:#ecfdf5; color:#065f46;">✓ PRESENT (ON-SITE)</span>';
    } else if (isLate) {
      cardClass += ' late';
      badgeHtml = '<span class="badge" style="background:#fef3c7; color:#92400e;">⏱ LATE CHECK-IN</span>';
    } else if (isOutOfBounds) {
      cardClass += ' out_of_bounds';
      badgeHtml = '<span class="badge" style="background:#fee2e2; color:#991b1b;">⚠ OUT OF BOUNDS</span>';
    }

    const checkInTime = att ? att.checkInTime : '—';
    const coordsStr = att && att.latitude ? `${att.latitude.toFixed(4)}°, ${att.longitude.toFixed(4)}°` : 'No GPS Ping';
    const distStr = att && att.distanceFromCenterKm !== undefined && att.distanceFromCenterKm !== null ? `${att.distanceFromCenterKm} km from hub` : '—';
    const mapUrl = att && att.latitude ? `https://www.google.com/maps?q=${att.latitude},${att.longitude}` : '#';

    const empPhoto = emp.photo || emp.referenceAvatar || 'assets/images/nrtc-logo.png';

    return `
      <div class="${cardClass}">
        <div>
          <div style="display:flex; justify-content:space-between; align-items:start; margin-bottom:8px;">
            <div style="display:flex; align-items:center; gap:10px;">
              <img src="${empPhoto}" alt="${emp.name}" style="width:44px; height:44px; border-radius:50%; object-fit:cover; border:2px solid #cbd5e1; background:#e2e8f0; flex-shrink:0;" onerror="this.src='assets/images/nrtc-logo.png'">
              <div>
                <h4 style="margin:0; font-size:15px; font-weight:700;">${emp.name}</h4>
                <small style="color:var(--muted); font-family:monospace;">${eid} • ${emp.phone || ''}</small>
              </div>
            </div>
            ${badgeHtml}
          </div>
          <p style="font-size:13px; color:#334155; font-weight:600; margin-bottom:12px;">${emp.designation}</p>

          <div style="background:#f8fafc; border-radius:6px; padding:10px; font-size:12px; margin-bottom:14px; border:1px solid #e2e8f0;">
            <div style="display:flex; justify-content:space-between; margin-bottom:4px;">
              <span style="color:var(--muted);">Check-In:</span>
              <strong>${checkInTime}</strong>
            </div>
            <div style="display:flex; justify-content:space-between; margin-bottom:4px;">
              <span style="color:var(--muted);">Live GPS:</span>
              <span class="gps-coords-badge">${coordsStr}</span>
            </div>
            <div style="display:flex; justify-content:space-between;">
              <span style="color:var(--muted);">Distance:</span>
              <span style="font-weight:600; color:${isOutOfBounds ? '#dc2626' : '#166534'}">${distStr}</span>
            </div>
          </div>
        </div>

        <div style="display:flex; justify-content:space-between; align-items:center; border-top:1px solid var(--border); padding-top:12px;">
          ${att && att.latitude ? `<a href="${mapUrl}" target="_blank" class="map-link-btn">📍 Open Map Pin</a>` : `<span style="font-size:11px; color:var(--muted);">Pending check-in</span>`}
          <button class="btn btn-sm btn-primary" onclick="openQuickCheckInModal('${eid}')">
            ${att ? '📍 Re-Verify GPS' : '📍 Check In Now'}
          </button>
        </div>
      </div>
    `;
  }).join('');
}

function renderDistrictAttendanceLog() {
  const user = appState.currentUser || window.store.getCurrentUser();
  const districtId = user.districtId || 'chakwal';
  const dateInput = document.getElementById('distAttFilterDate');
  const dateVal = dateInput ? dateInput.value : '';

  const records = window.store.getAttendanceByDistrict(districtId, dateVal);
  const tbody = document.getElementById('districtAttendanceTableBody');
  if (!tbody) return;

  if (records.length === 0) {
    tbody.innerHTML = `<tr><td colspan="10" style="text-align:center; padding:24px; color:var(--muted);">No attendance logs recorded for selected date.</td></tr>`;
    return;
  }

  tbody.innerHTML = records.map(r => {
    const isOk = r.status === 'PRESENT';
    const isLate = r.status === 'LATE';
    const isWarn = r.status === 'OUT_OF_BOUNDS';
    let badge = `<span class="badge" style="background:#fee2e2; color:#991b1b;">${r.status}</span>`;
    if (isOk) badge = `<span class="badge" style="background:#ecfdf5; color:#065f46;">PRESENT</span>`;
    else if (isLate) badge = `<span class="badge" style="background:#fef3c7; color:#92400e;">LATE</span>`;
    else if (isWarn) badge = `<span class="badge" style="background:#fee2e2; color:#991b1b;">OUT OF BOUNDS</span>`;

    const mapLink = r.latitude ? `<a href="https://www.google.com/maps?q=${r.latitude},${r.longitude}" target="_blank" class="map-link-btn">📍 Map</a>` : '—';

    // Face Biometric Thumbnail & Score badge
    const emp = window.store.getEmployeeById(r.employeeId);
    const faceImg = r.faceSnapshot || (emp ? emp.referenceAvatar : null) || (window.store.generateFaceAvatarSvg ? window.store.generateFaceAvatarSvg(r.employeeName, 'resident') : '');
    const isFaceOk = !!r.faceVerified;
    const scoreBadge = isFaceOk 
      ? `<span class="face-match-badge face-match-pass" title="Biometric Confidence Score">✓ ${r.faceMatchScore || '98.8%'}</span>` 
      : `<span class="face-match-badge face-match-fail" title="Unverified">✕ Unverified</span>`;
    
    const faceCell = `
      <div class="face-thumb-cell" onclick="openFaceInspectionModal('${r.id}')" title="Click to view biometric audit comparison" style="cursor:pointer;">
        <img src="${faceImg}" class="face-thumb-img" alt="Face Profile">
        ${scoreBadge}
      </div>
    `;

    return `
      <tr>
        <td style="font-weight:600;">${r.date}</td>
        <td>${faceCell}</td>
        <td><strong>${r.employeeName}</strong><br><small style="color:var(--muted); font-family:monospace;">${r.employeeId}</small></td>
        <td>${r.designation}</td>
        <td>${r.checkInTime || '—'}</td>
        <td><span class="gps-coords-badge">${r.latitude ? `${r.latitude.toFixed(4)}, ${r.longitude.toFixed(4)}` : '—'}</span></td>
        <td><strong>${r.distanceFromCenterKm !== null && r.distanceFromCenterKm !== undefined ? `${r.distanceFromCenterKm} km` : '—'}</strong></td>
        <td>${badge}</td>
        <td>${mapLink}</td>
        <td><small style="color:#475467;">${r.remarks || '—'}</small></td>
      </tr>
    `;
  }).join('');
}

// Face Biometric Verification State
let currentFaceVerification = {
  verified: false,
  matchScore: null,
  faceSnapshot: null,
  employeeId: null,
  cameraStream: null,
  customUploadSnapshot: null
};

function resetFaceBiometricState(keepCamera) {
  currentFaceVerification.verified = false;
  currentFaceVerification.matchScore = null;
  currentFaceVerification.faceSnapshot = null;
  currentFaceVerification.employeeId = null;
  currentFaceVerification.customUploadSnapshot = null;

  const testFileInput = document.getElementById('bioTestFileInput');
  if (testFileInput) testFileInput.value = '';

  if (!keepCamera) {
    stopFaceCamera();
  }

  // Visual reticle and laser reset
  const reticle = document.getElementById('faceOvalReticle');
  if (reticle) reticle.className = 'face-oval-reticle';
  const laser = document.getElementById('faceScanLaser');
  if (laser) laser.className = 'face-scan-laser';
  const prompt = document.getElementById('facePromptPill');
  if (prompt) prompt.innerHTML = '<span>👤 Position face within the oval reticle</span>';
  const statusText = document.getElementById('faceScanStatusText');
  if (statusText) {
    statusText.textContent = 'Awaiting facial scan...';
    statusText.style.color = 'var(--muted)';
  }

  // Toggle buttons
  const btnRestart = document.getElementById('btnRestartCamera');
  if (btnRestart) btnRestart.style.display = 'none';
  const btnCapture = document.getElementById('btnCaptureFace');
  if (btnCapture) btnCapture.disabled = false;

  // Re-lock Stage 2 GPS
  lockGpsSection();
}

function lockGpsSection() {
  const gpsWrap = document.getElementById('gpsSectionWrap');
  if (gpsWrap) gpsWrap.classList.add('locked-section');

  const lockNotice = document.getElementById('gpsLockNotice');
  if (lockNotice) {
    lockNotice.className = 'locked-notice-banner is-locked';
  }
  const lockIcon = document.getElementById('gpsLockIcon');
  if (lockIcon) lockIcon.textContent = '🔒';
  const lockText = document.getElementById('gpsLockText');
  if (lockText) lockText.textContent = 'LOCKED: Pass Stage 1 Face Biometric Verification to unlock GPS hardware detection.';

  const stage2Badge = document.getElementById('stage2Badge');
  if (stage2Badge) {
    stage2Badge.style.background = '#f1f5f9';
    stage2Badge.style.color = '#475467';
  }

  const submitBtn = document.getElementById('btnSubmitCheckIn');
  if (submitBtn) submitBtn.disabled = true;
}

function unlockGpsSection(matchScore) {
  const gpsWrap = document.getElementById('gpsSectionWrap');
  if (gpsWrap) gpsWrap.classList.remove('locked-section');

  const lockNotice = document.getElementById('gpsLockNotice');
  if (lockNotice) {
    lockNotice.className = 'locked-notice-banner is-unlocked';
  }
  const lockIcon = document.getElementById('gpsLockIcon');
  if (lockIcon) lockIcon.textContent = '🔓';
  const lockText = document.getElementById('gpsLockText');
  if (lockText) lockText.innerHTML = `<strong>UNLOCKED:</strong> Biometric Identity Confirmed (${matchScore}). GPS location detection is now active.`;

  const stage2Badge = document.getElementById('stage2Badge');
  if (stage2Badge) {
    stage2Badge.style.background = '#ecfdf5';
    stage2Badge.style.color = '#065f46';
  }

  const submitBtn = document.getElementById('btnSubmitCheckIn');
  if (submitBtn) submitBtn.disabled = false;

  // Auto initialize GPS coordinates once unlocked
  if (!currentGeoCoordinates) {
    simulateDistrictCenterGPS();
  }
}

function startFaceCamera() {
  currentFaceVerification.customUploadSnapshot = null;
  const video = document.getElementById('faceCameraVideo');
  const canvas = document.getElementById('faceSnapshotCanvas');
  const prompt = document.getElementById('facePromptPill');
  const btnRestart = document.getElementById('btnRestartCamera');
  const reticle = document.getElementById('faceOvalReticle');
  const laser = document.getElementById('faceScanLaser');

  if (canvas) canvas.style.display = 'none';
  if (video) video.style.display = 'block';
  if (btnRestart) btnRestart.style.display = 'none';
  if (reticle) reticle.className = 'face-oval-reticle';
  if (laser) laser.className = 'face-scan-laser';

  if (!navigator.mediaDevices || !navigator.mediaDevices.getUserMedia) {
    if (prompt) prompt.innerHTML = '<span>📷 Webcam not detected. Use test tools or upload a photo</span>';
    return;
  }

  navigator.mediaDevices.getUserMedia({ video: { facingMode: 'user', width: { ideal: 640 }, height: { ideal: 480 } } })
    .then(stream => {
      currentFaceVerification.cameraStream = stream;
      if (video) {
        video.srcObject = stream;
        video.play().catch(e => console.warn('Video play prevented:', e));
      }
      if (prompt) prompt.innerHTML = '<span>👤 Position face within the oval reticle</span>';
    })
    .catch(err => {
      console.warn('Camera access note:', err);
      if (prompt) prompt.innerHTML = '<span>📷 Camera unavailable. Use test buttons or upload photo</span>';
    });
}

function stopFaceCamera() {
  if (currentFaceVerification.cameraStream) {
    currentFaceVerification.cameraStream.getTracks().forEach(track => {
      try { track.stop(); } catch (e) {}
    });
    currentFaceVerification.cameraStream = null;
  }
  const video = document.getElementById('faceCameraVideo');
  if (video) video.srcObject = null;
}

function handleBiometricFileUpload(input) {
  if (!input || !input.files || !input.files[0]) return;
  const file = input.files[0];
  const reader = new FileReader();

  reader.onload = function(e) {
    const dataUrl = e.target.result;
    currentFaceVerification.customUploadSnapshot = dataUrl;

    const video = document.getElementById('faceCameraVideo');
    const canvas = document.getElementById('faceSnapshotCanvas');
    const prompt = document.getElementById('facePromptPill');
    const statusText = document.getElementById('faceScanStatusText');
    const btnRestart = document.getElementById('btnRestartCamera');

    if (video) video.style.display = 'none';
    if (canvas) {
      canvas.style.display = 'block';
      const img = new Image();
      img.onload = function() {
        canvas.width = img.naturalWidth || 320;
        canvas.height = img.naturalHeight || 240;
        const ctx = canvas.getContext('2d');
        ctx.clearRect(0, 0, canvas.width, canvas.height);
        ctx.drawImage(img, 0, 0, canvas.width, canvas.height);
      };
      img.src = dataUrl;
    }

    if (btnRestart) btnRestart.style.display = 'inline-block';
    if (prompt) prompt.innerHTML = '<span>📁 Test photo loaded. Click "Scan & Verify Face" to compare with enrolled database record.</span>';
    if (statusText) {
      statusText.innerHTML = '<span style="color:#0284c7;">Photo staged for verification</span>';
    }
  };

  reader.readAsDataURL(file);
}

async function captureAndVerifyFace() {
  const empSelect = document.getElementById('checkInEmployeeSelect');
  if (!empSelect) return;
  const empId = empSelect.value;
  const emp = window.store.getEmployeeById(empId);
  if (!emp) {
    showToast('Please select an employee first.', 'warning');
    return;
  }

  const laser = document.getElementById('faceScanLaser');
  const reticle = document.getElementById('faceOvalReticle');
  const prompt = document.getElementById('facePromptPill');
  const statusText = document.getElementById('faceScanStatusText');
  const video = document.getElementById('faceCameraVideo');
  const canvas = document.getElementById('faceSnapshotCanvas');
  const btnRestart = document.getElementById('btnRestartCamera');
  const btnCapture = document.getElementById('btnCaptureFace');

  if (btnCapture) btnCapture.disabled = true;

  // Trigger laser scan animation & active reticle
  if (laser) laser.className = 'face-scan-laser active';
  if (reticle) reticle.className = 'face-oval-reticle scanning';
  if (prompt) prompt.innerHTML = `<span>🔍 Biometric comparison against enrolled record for ${emp.name}...</span>`;
  if (statusText) {
    statusText.innerHTML = '<span style="color:#0284c7;">Analyzing facial features & skin tone...</span>';
  }

  let capturedSource = null;
  if (currentFaceVerification.customUploadSnapshot) {
    capturedSource = currentFaceVerification.customUploadSnapshot;
  } else if (video && video.videoWidth > 0 && canvas) {
    canvas.width = video.videoWidth;
    canvas.height = video.videoHeight;
    const ctx = canvas.getContext('2d');
    ctx.translate(canvas.width, 0);
    ctx.scale(-1, 1);
    ctx.drawImage(video, 0, 0, canvas.width, canvas.height);
    capturedSource = canvas.toDataURL('image/jpeg', 0.85);
  } else {
    // If no camera stream and no uploaded file staged, alert user
    if (!video || !video.srcObject) {
      if (laser) laser.className = 'face-scan-laser';
      if (reticle) reticle.className = 'face-oval-reticle';
      if (btnCapture) btnCapture.disabled = false;
      showToast('No active camera detected. Please enable camera or click "Upload Test Photo" to test.', 'warning');
      return;
    }
    capturedSource = emp.photo || emp.referenceAvatar;
  }

  await new Promise(r => setTimeout(r, 650));

  try {
    const result = await window.store.verifyFaceBiometric(empId, capturedSource, false);
    if (laser) laser.className = 'face-scan-laser';
    if (btnCapture) btnCapture.disabled = false;

    if (result.verified) {
      if (reticle) reticle.className = 'face-oval-reticle verified';
      if (prompt) prompt.innerHTML = `<span style="color:#10b981;">✓ Face Match Confirmed: ${emp.name} (${result.matchScore})</span>`;
      if (statusText) statusText.innerHTML = `<span style="color:var(--success);">✓ VERIFIED (${result.matchScore})</span>`;
      if (btnRestart) btnRestart.style.display = 'inline-block';

      currentFaceVerification.verified = true;
      currentFaceVerification.matchScore = result.matchScore;
      currentFaceVerification.faceSnapshot = result.snapshotBase64 || result.capturedSnapshot;
      currentFaceVerification.employeeId = empId;

      unlockGpsSection(result.matchScore);
      showToast(`✓ Face Biometric Verified for ${emp.name} (${result.matchScore})`, 'success');
    } else {
      if (reticle) reticle.className = 'face-oval-reticle rejected';
      if (prompt) prompt.innerHTML = `<span style="color:#ef4444;">✕ Face Mismatch (${result.matchScore}) - Identity Rejected</span>`;
      if (statusText) statusText.innerHTML = `<span style="color:var(--danger);">✕ REJECTED: Face Mismatch</span>`;
      if (btnRestart) btnRestart.style.display = 'inline-block';

      currentFaceVerification.verified = false;
      currentFaceVerification.matchScore = result.matchScore;
      currentFaceVerification.faceSnapshot = result.snapshotBase64 || result.capturedSnapshot;
      currentFaceVerification.employeeId = empId;

      lockGpsSection();
      showToast(`🚫 ANTI-PROXY REJECTION: ${result.reason}`, 'danger');
    }
  } catch (err) {
    if (laser) laser.className = 'face-scan-laser';
    if (btnCapture) btnCapture.disabled = false;
    console.error('Biometric verification error:', err);
    showToast('Biometric engine error during facial verification.', 'danger');
  }
}

async function simulateFaceMatch() {
  const empSelect = document.getElementById('checkInEmployeeSelect');
  if (!empSelect) return;
  const empId = empSelect.value;
  const emp = window.store.getEmployeeById(empId);
  if (!emp) return;

  const laser = document.getElementById('faceScanLaser');
  const reticle = document.getElementById('faceOvalReticle');
  const prompt = document.getElementById('facePromptPill');
  const statusText = document.getElementById('faceScanStatusText');
  const btnRestart = document.getElementById('btnRestartCamera');
  const video = document.getElementById('faceCameraVideo');
  const canvas = document.getElementById('faceSnapshotCanvas');

  // Preview the employee's genuine face on canvas
  if (video) video.style.display = 'none';
  if (canvas) {
    canvas.style.display = 'block';
    const ctx = canvas.getContext('2d');
    const img = new Image();
    img.crossOrigin = 'anonymous';
    img.onload = () => {
      canvas.width = img.naturalWidth || 320;
      canvas.height = img.naturalHeight || 240;
      ctx.drawImage(img, 0, 0, canvas.width, canvas.height);
    };
    img.src = emp.photo || emp.referenceAvatar;
  }

  if (laser) laser.className = 'face-scan-laser active';
  if (reticle) reticle.className = 'face-oval-reticle scanning';
  if (prompt) prompt.innerHTML = `<span>🔍 Verifying genuine biometric record for ${emp.name}...</span>`;
  if (statusText) statusText.innerHTML = '<span style="color:#0284c7;">Matching against database record...</span>';

  await new Promise(r => setTimeout(r, 500));

  const result = await window.store.verifyFaceBiometric(empId, emp.photo || emp.referenceAvatar, false);
  if (laser) laser.className = 'face-scan-laser';
  if (reticle) reticle.className = 'face-oval-reticle verified';
  if (prompt) prompt.innerHTML = `<span style="color:#10b981;">✓ Face Match Confirmed: ${emp.name} (${result.matchScore})</span>`;
  if (statusText) statusText.innerHTML = `<span style="color:var(--success);">✓ VERIFIED (${result.matchScore})</span>`;
  if (btnRestart) btnRestart.style.display = 'inline-block';

  currentFaceVerification.verified = true;
  currentFaceVerification.matchScore = result.matchScore;
  currentFaceVerification.faceSnapshot = result.snapshotBase64 || result.capturedSnapshot;
  currentFaceVerification.employeeId = empId;

  unlockGpsSection(result.matchScore);
  showToast(`✓ Genuine Face Verified: ${emp.name} (${result.matchScore})`, 'success');
}

async function simulateFaceMismatch() {
  const empSelect = document.getElementById('checkInEmployeeSelect');
  if (!empSelect) return;
  const empId = empSelect.value;
  const emp = window.store.getEmployeeById(empId);
  if (!emp) return;

  const laser = document.getElementById('faceScanLaser');
  const reticle = document.getElementById('faceOvalReticle');
  const prompt = document.getElementById('facePromptPill');
  const statusText = document.getElementById('faceScanStatusText');
  const btnRestart = document.getElementById('btnRestartCamera');
  const video = document.getElementById('faceCameraVideo');
  const canvas = document.getElementById('faceSnapshotCanvas');

  // Find a DIFFERENT employee from the store to act as unauthorized proxy
  const allEmps = window.store.getAllEmployees() || [];
  const otherEmp = allEmps.find(e => (e.id !== emp.id && e.empId !== emp.empId && (e.photo || e.referenceAvatar))) || {
    name: 'Unauthorized Proxy Person',
    photo: 'assets/employees/image90.jpeg'
  };

  // Preview the intruder/proxy's face on canvas to show that a different person is at the camera
  if (video) video.style.display = 'none';
  if (canvas) {
    canvas.style.display = 'block';
    const ctx = canvas.getContext('2d');
    const img = new Image();
    img.crossOrigin = 'anonymous';
    img.onload = () => {
      canvas.width = img.naturalWidth || 320;
      canvas.height = img.naturalHeight || 240;
      ctx.drawImage(img, 0, 0, canvas.width, canvas.height);
    };
    img.src = otherEmp.photo || otherEmp.referenceAvatar;
  }

  if (laser) laser.className = 'face-scan-laser active';
  if (reticle) reticle.className = 'face-oval-reticle scanning';
  if (prompt) prompt.innerHTML = `<span>⚠️ Scanning different face (${otherEmp.name}) against ${emp.name}...</span>`;
  if (statusText) statusText.innerHTML = '<span style="color:#ef4444;">Comparing unauthorized biometric...</span>';

  await new Promise(r => setTimeout(r, 500));

  // Perform actual biometric comparison between otherEmp.photo and emp.photo!
  const result = await window.store.verifyFaceBiometric(empId, otherEmp.photo || otherEmp.referenceAvatar, true);
  if (laser) laser.className = 'face-scan-laser';
  if (reticle) reticle.className = 'face-oval-reticle rejected';
  if (prompt) prompt.innerHTML = `<span style="color:#ef4444;">✕ Face Mismatch (${result.matchScore}) — Rejected</span>`;
  if (statusText) statusText.innerHTML = `<span style="color:var(--danger);">✕ REJECTED: Anti-Proxy Block (${result.matchScore})</span>`;
  if (btnRestart) btnRestart.style.display = 'inline-block';

  currentFaceVerification.verified = false;
  currentFaceVerification.matchScore = result.matchScore;
  currentFaceVerification.faceSnapshot = otherEmp.photo || otherEmp.referenceAvatar;
  currentFaceVerification.employeeId = empId;

  lockGpsSection();
  showToast(`🚫 ANTI-PROXY REJECTION: Detected face does not match ${emp.name}! (Score: ${result.matchScore})`, 'danger');
}

async function openQuickCheckInModal(preselectedEmpId) {
  const user = appState.currentUser || window.store.getCurrentUser();
  const districtId = user.districtId || 'chakwal';
  
  let employees = [];
  if (window.api && typeof window.api.getEmployees === 'function') {
    try {
      employees = await window.api.getEmployees({ district: districtId });
    } catch (e) {
      console.warn('API getEmployees error in quick check-in:', e);
    }
  }

  if (!employees || employees.length === 0) {
    employees = window.store.getEmployeesByDistrict(districtId);
  } else if (window.store && typeof window.store.syncEmployees === 'function') {
    window.store.syncEmployees(employees);
  }

  // Fallback: If still empty, get all employees matching district name or location
  if (!employees || employees.length === 0) {
    const all = window.store.getAllEmployees();
    employees = all.filter(e => {
      const d = (e.district_id || e.districtId || '').toLowerCase();
      const loc = (e.location || '').toLowerCase();
      return d.includes(districtId.toLowerCase()) || loc.includes(districtId.toLowerCase());
    });
  }

  const empSelect = document.getElementById('checkInEmployeeSelect');
  if (empSelect) {
    if (employees.length === 0) {
      empSelect.innerHTML = `<option value="${user.empId || 'user_site'}" selected>${user.name || 'Site Engineer'} (${user.districtName || 'Site'})</option>`;
    } else {
      empSelect.innerHTML = employees.map(e => {
        const eid = e.empId || e.employeeId || e.id;
        const isSelected = (preselectedEmpId && (preselectedEmpId === eid || preselectedEmpId === e.id)) ||
                           (!preselectedEmpId && user.name && e.name.toLowerCase().includes(user.name.toLowerCase()));
        return `
          <option value="${eid}" ${isSelected ? 'selected' : ''}>
            ${e.name} (${eid}) — ${e.designation || 'Field Staff'}
          </option>
        `;
      }).join('');
    }
    onCheckInEmployeeChange();
  }

  const badge = document.getElementById('checkInDistrictBadge');
  if (badge) badge.textContent = `${user.districtName || 'District'} Operational Site`;

  document.getElementById('checkInLat').value = '';
  document.getElementById('checkInLng').value = '';
  document.getElementById('gpsStatusMessage').textContent = 'Location detection will unlock after Stage 1 Face Verification.';
  document.getElementById('geofenceResultBox').style.display = 'none';
  currentGeoCoordinates = null;

  // Reset face biometric verification and strictly lock GPS section
  resetFaceBiometricState(false);
  startFaceCamera();

  const modal = document.getElementById('checkInModal');
  if (modal) {
    modal.classList.add('open');
    modal.style.display = 'flex';
  }
}

function closeCheckInModal() {
  stopFaceCamera();
  const modal = document.getElementById('checkInModal');
  if (modal) {
    modal.classList.remove('open');
    modal.style.display = 'none';
  }
}

function onCheckInEmployeeChange() {
  // Always reset biometric verification when selected employee changes to prevent proxy bypass!
  resetFaceBiometricState(true);
  const empSelect = document.getElementById('checkInEmployeeSelect');
  if (!empSelect) return;
  const empId = empSelect.value;
  const emp = window.store.getEmployeeById(empId);

  // Update Enrolled Biometric Card
  const photoEl = document.getElementById('enrolledPhotoPreview');
  const nameEl = document.getElementById('enrolledNamePreview');
  const badgeEl = document.getElementById('enrolledIdBadge');
  const desigEl = document.getElementById('enrolledDesigPreview');

  if (emp) {
    const photoSrc = emp.photo || emp.referenceAvatar || 'assets/images/nrtc-logo.png';
    if (photoEl) {
      photoEl.src = photoSrc;
      photoEl.onerror = () => { photoEl.src = 'assets/images/nrtc-logo.png'; };
    }
    if (nameEl) nameEl.textContent = emp.name;
    if (badgeEl) badgeEl.textContent = emp.empId || emp.employeeId || emp.id;
    if (desigEl) desigEl.textContent = `${emp.designation || 'Field Staff'} • ${emp.location || emp.districtName || 'Site Hub'}`;
  }

  const statusText = document.getElementById('faceScanStatusText');
  if (statusText) {
    statusText.textContent = emp ? `Awaiting scan for ${emp.name}...` : 'Awaiting facial scan...';
    statusText.style.color = 'var(--muted)';
  }
}

function fetchLiveGPS() {
  const statusMsg = document.getElementById('gpsStatusMessage');
  if (statusMsg) statusMsg.textContent = '🛰️ Requesting device GPS coordinates from browser...';

  if (!navigator.geolocation) {
    if (statusMsg) statusMsg.textContent = '⚠️ Geolocation is not supported by your browser. Using district center preset.';
    simulateDistrictCenterGPS();
    return;
  }

  navigator.geolocation.getCurrentPosition(
    position => {
      const lat = position.coords.latitude;
      const lng = position.coords.longitude;
      const accuracy = position.coords.accuracy || 10;
      applyCoordinates(lat, lng, accuracy, 'LIVE_GPS');
    },
    error => {
      console.warn('Geolocation error:', error);
      if (statusMsg) {
        statusMsg.textContent = `⚠️ Device GPS unavailable (${error.message || 'Permission denied'}). Falling back to District Site Hub preset.`;
      }
      simulateDistrictCenterGPS();
    },
    { enableHighAccuracy: true, timeout: 8000, maximumAge: 0 }
  );
}

function simulateDistrictCenterGPS() {
  const user = appState.currentUser || window.store.getCurrentUser();
  const districtId = user.districtId || 'chakwal';
  const dist = window.getDistrictById ? window.getDistrictById(districtId) : null;
  if (!dist) return;

  const jitterLat = (Math.random() - 0.5) * 0.015;
  const jitterLng = (Math.random() - 0.5) * 0.015;
  const lat = Math.round((dist.lat + jitterLat) * 10000) / 10000;
  const lng = Math.round((dist.lng + jitterLng) * 10000) / 10000;

  applyCoordinates(lat, lng, 12, 'DISTRICT_HUB_PRESET');
}

function simulateOutOfBoundsGPS() {
  const user = appState.currentUser || window.store.getCurrentUser();
  const districtId = user.districtId || 'chakwal';
  const dist = window.getDistrictById ? window.getDistrictById(districtId) : null;
  if (!dist) return;

  const lat = Math.round((dist.lat + 0.85) * 10000) / 10000;
  const lng = Math.round((dist.lng + 0.85) * 10000) / 10000;
  applyCoordinates(lat, lng, 25, 'OUT_OF_BOUNDS_SIM');
}

function applyCoordinates(lat, lng, accuracy, source) {
  const latInput = document.getElementById('checkInLat');
  const lngInput = document.getElementById('checkInLng');
  if (latInput) latInput.value = lat;
  if (lngInput) lngInput.value = lng;

  const user = appState.currentUser || window.store.getCurrentUser();
  const districtId = user.districtId || 'chakwal';
  const verification = window.verifyDistrictLocation ? window.verifyDistrictLocation(districtId, lat, lng) : { isInside: true, distanceKm: 1.5, radiusKm: 35 };

  currentGeoCoordinates = {
    latitude: lat,
    longitude: lng,
    accuracy: accuracy,
    distanceKm: verification.distanceKm,
    isInside: verification.isInside,
    source: source
  };

  const statusMsg = document.getElementById('gpsStatusMessage');
  if (statusMsg) {
    statusMsg.innerHTML = `✓ Coordinates acquired (${source.replace(/_/g, ' ')}). Accuracy: ±${Math.round(accuracy)}m.`;
  }

  const resultBox = document.getElementById('geofenceResultBox');
  if (resultBox) {
    resultBox.style.display = 'block';
    if (verification.isInside) {
      resultBox.className = 'geo-status-ok';
      resultBox.innerHTML = `✓ <strong>Within Permitted Geofence:</strong> Distance to ${user.districtName} hub is <strong>${verification.distanceKm} km</strong> (Limit: ${verification.radiusKm} km). Status: <strong>PRESENT</strong>.`;
    } else {
      resultBox.className = 'geo-status-warn';
      resultBox.innerHTML = `⚠️ <strong>Outside District Boundary:</strong> Distance is <strong>${verification.distanceKm} km</strong> (Limit: ${verification.radiusKm} km). Status: <strong>OUT OF BOUNDS</strong>.`;
    }
  }
}

function handleAttendanceSubmit(event) {
  event.preventDefault();
  const user = appState.currentUser || window.store.getCurrentUser();
  const districtId = user.districtId || 'chakwal';
  const empSelect = document.getElementById('checkInEmployeeSelect');
  if (!empSelect) return;
  const empId = empSelect.value;
  const emp = window.store.getEmployeeById(empId);
  const shift = document.getElementById('checkInShiftSelect').value;
  const remarks = document.getElementById('checkInRemarks').value;

  // Strict anti-proxy enforcement check: Face verification is mandatory
  if (!currentFaceVerification.verified || currentFaceVerification.employeeId !== empId) {
    showToast('Face biometric verification is mandatory before attendance can be submitted.', 'danger');
    return;
  }

  if (!currentGeoCoordinates) {
    simulateDistrictCenterGPS();
  }

  const now = new Date();
  const todayStr = now.toISOString().split('T')[0];
  const timeStr = now.toTimeString().split(' ')[0];

  let status = 'PRESENT';
  if (!currentGeoCoordinates.isInside) {
    status = 'OUT_OF_BOUNDS';
  } else if (now.getHours() > 9 || (now.getHours() === 9 && now.getMinutes() > 30)) {
    status = 'LATE';
  }

  const attRecord = {
    id: `att_${empId}_${todayStr}`,
    employeeId: empId,
    employeeName: emp ? emp.name : 'Field Engineer',
    designation: emp ? emp.designation : 'Field Personnel',
    districtId: districtId,
    districtName: user.districtName || 'District',
    date: todayStr,
    checkInTime: timeStr,
    checkOutTime: null,
    shift: shift,
    latitude: currentGeoCoordinates.latitude,
    longitude: currentGeoCoordinates.longitude,
    accuracyMeters: currentGeoCoordinates.accuracy || 15,
    distanceFromCenterKm: currentGeoCoordinates.distanceKm,
    isWithinGeofence: currentGeoCoordinates.isInside,
    status: status,
    remarks: remarks || (currentGeoCoordinates.isInside ? 'Checked in on-site' : 'Off-site check-in flagged'),
    verifiedBy: 'FACE_BIOMETRIC_AND_GPS',
    faceVerified: true,
    faceMatchScore: currentFaceVerification.matchScore || '98.8%',
    faceSnapshot: currentFaceVerification.faceSnapshot || (emp ? emp.referenceAvatar : null),
    livenessVerified: true,
    timestamp: `${todayStr} ${timeStr}`
  };

  window.store.recordAttendance(attRecord);
  showToast(`Attendance checked in with Biometric Verification for ${attRecord.employeeName}: ${status}`, status === 'PRESENT' ? 'success' : 'warning');
  closeCheckInModal();
  renderDistrictAttendance();
  renderDistrictAttendanceLog();
}

function renderAdminAttendance() {
  const filterDist = document.getElementById('adminAttFilterDistrict');
  const filterStatus = document.getElementById('adminAttFilterStatus');
  const filterDate = document.getElementById('adminAttFilterDate');

  const selectedDist = filterDist ? filterDist.value : 'all';
  const selectedStatus = filterStatus ? filterStatus.value : 'all';
  const selectedDate = filterDate && filterDate.value ? filterDate.value : new Date().toISOString().split('T')[0];

  if (filterDist && filterDist.options.length <= 1 && window.PUNJAB_DISTRICTS) {
    window.PUNJAB_DISTRICTS.forEach(d => {
      const opt = document.createElement('option');
      opt.value = d.id;
      opt.textContent = d.name;
      filterDist.appendChild(opt);
    });
  }

  const summary = window.store.getProvincialAttendanceSummary(selectedDate);
  const elForce = document.getElementById('adminStatTotalForce') || document.getElementById('adminStatTotalStaff');
  const elPresent = document.getElementById('adminStatPresent');
  const elRate = document.getElementById('adminStatPresentRate') || document.getElementById('adminStatComplianceRate');
  const elAbsent = document.getElementById('adminStatAbsent');
  const elWarn = document.getElementById('adminStatOutOfBounds');

  if (elForce) elForce.textContent = summary.totalEmployees;
  if (elPresent) elPresent.textContent = summary.present;
  if (elRate) elRate.textContent = `${summary.attendanceRate}% Compliance`;
  if (elAbsent) elAbsent.textContent = summary.absent;
  if (elWarn) elWarn.textContent = summary.outOfBounds;

  const allEmployees = window.store.getAllEmployees();
  const allAttendance = window.store.getAllAttendance({ date: selectedDate });

  let displayList = allEmployees.map(emp => {
    const att = allAttendance.find(a => a.employeeId === emp.employeeId);
    return {
      emp,
      att: att || null,
      status: att ? att.status : 'ABSENT',
      districtId: emp.districtId,
      districtName: emp.districtName
    };
  });

  if (selectedDist !== 'all') {
    displayList = displayList.filter(item => item.districtId.toLowerCase() === selectedDist.toLowerCase());
  }
  if (selectedStatus !== 'all') {
    displayList = displayList.filter(item => item.status.toUpperCase() === selectedStatus.toUpperCase());
  }

  const badgeCount = document.getElementById('adminRecordCountBadge') || document.getElementById('adminAttRecordCountBadge');
  if (badgeCount) badgeCount.textContent = `Showing ${displayList.length} Personnel`;

  const tbody = document.getElementById('adminAttendanceTableBody');
  if (!tbody) return;

  if (displayList.length === 0) {
    tbody.innerHTML = `<tr><td colspan="10" style="text-align:center; padding:24px; color:var(--muted);">No field staff matched the selected filters.</td></tr>`;
    return;
  }

  tbody.innerHTML = displayList.map(item => {
    const { emp, att, status } = item;
    let badge = `<span class="badge" style="background:#fee2e2; color:#991b1b;">ABSENT</span>`;
    if (status === 'PRESENT') {
      badge = `<span class="badge" style="background:#ecfdf5; color:#065f46;">✓ PRESENT (ON-SITE)</span>`;
    } else if (status === 'LATE') {
      badge = `<span class="badge" style="background:#fef3c7; color:#92400e;">⏱ LATE</span>`;
    } else if (status === 'OUT_OF_BOUNDS') {
      badge = `<span class="badge" style="background:#fee2e2; color:#991b1b;">⚠ OUT OF BOUNDS</span>`;
    }

    const checkInTime = att ? att.checkInTime : '—';
    const coordsStr = att && att.latitude ? `${att.latitude.toFixed(4)}, ${att.longitude.toFixed(4)}` : 'No Ping';
    const distStr = att && att.distanceFromCenterKm !== null && att.distanceFromCenterKm !== undefined ? `${att.distanceFromCenterKm} km` : '—';
    const mapBtn = att && att.latitude ? `<a href="https://www.google.com/maps?q=${att.latitude},${att.longitude}" target="_blank" class="map-link-btn">📍 Map Pin</a>` : '—';
    const attId = att ? att.id : `att_${emp.employeeId}_${selectedDate}`;

    // Face Biometric Cell with click-to-inspect audit
    const faceImg = (att && att.faceSnapshot) ? att.faceSnapshot : emp.referenceAvatar;
    const isFaceOk = att && att.faceVerified;
    const scoreBadge = isFaceOk 
      ? `<span class="face-match-badge face-match-pass" title="Biometric Confidence Score">✓ ${att.faceMatchScore || '98.8%'}</span>` 
      : `<span class="face-match-badge face-match-fail" title="Unverified">✕ Pending</span>`;
    
    const faceCell = `
      <div class="face-thumb-cell" onclick="openFaceInspectionModal('${attId}')" title="Click to view biometric audit comparison" style="cursor:pointer;">
        <img src="${faceImg}" class="face-thumb-img" alt="Face Biometric">
        ${scoreBadge}
      </div>
    `;

    return `
      <tr>
        <td><strong>${emp.districtName}</strong></td>
        <td>${faceCell}</td>
        <td><strong>${emp.name}</strong><br><small style="color:var(--muted); font-family:monospace;">${emp.employeeId}</small></td>
        <td><small>${emp.designation}</small></td>
        <td>${checkInTime}</td>
        <td><span class="gps-coords-badge">${coordsStr}</span></td>
        <td><strong>${distStr}</strong></td>
        <td>${badge}</td>
        <td>${mapBtn}</td>
        <td>
          <button class="btn btn-sm" onclick="openAdminAttModal('${attId}', '${emp.name.replace(/'/g, "\\'")}', '${status}')">
            ⚙ Regularize
          </button>
        </td>
      </tr>
    `;
  }).join('');
}

function openAdminAttModal(recordId, empName, currentStatus) {
  document.getElementById('adminAttRecordId').value = recordId;
  const targetLabel = document.getElementById('adminAttTargetName');
  if (targetLabel) targetLabel.textContent = empName;
  const statusSelect = document.getElementById('adminAttStatusSelect');
  if (statusSelect) statusSelect.value = currentStatus === 'ABSENT' ? 'PRESENT' : currentStatus;
  document.getElementById('adminAttRemarks').value = '';

  const modal = document.getElementById('adminAttModal');
  if (modal) {
    modal.classList.add('open');
    modal.style.display = 'flex';
  }
}

function closeAdminAttModal() {
  const modal = document.getElementById('adminAttModal');
  if (modal) {
    modal.classList.remove('open');
    modal.style.display = 'none';
  }
}

function handleAdminAttSubmit(event) {
  event.preventDefault();
  const recordId = document.getElementById('adminAttRecordId').value;
  const newStatus = document.getElementById('adminAttStatusSelect').value;
  const remarks = document.getElementById('adminAttRemarks').value;

  window.store.updateAttendanceStatus(recordId, newStatus, remarks, 'NRTC PMU Admin');
  showToast(`Attendance regularized to ${newStatus}`, 'success');
  closeAdminAttModal();
  renderAdminAttendance();
}

// Side-by-Side Face Biometric Inspection Modal
function openFaceInspectionModal(attendanceId) {
  const allAtt = window.store.getAllAttendance();
  let att = allAtt.find(a => a.id === attendanceId);
  let emp = null;

  if (att) {
    emp = window.store.getEmployeeById(att.employeeId);
  } else if (attendanceId && attendanceId.startsWith('att_')) {
    const parts = attendanceId.split('_');
    const empId = parts[1];
    emp = window.store.getEmployeeById(empId);
  }

  if (!emp && !att) {
    showToast('Biometric record details not available.', 'warning');
    return;
  }

  const empName = emp ? emp.name : (att ? att.employeeName : 'Field Staff');
  const empDesig = emp ? emp.designation : (att ? att.designation : 'Technical Staff');
  const profileId = emp ? (emp.faceProfileId || 'BIO-' + emp.employeeId) : 'BIO-UNSET';
  const refImg = emp ? emp.referenceAvatar : (window.store.generateFaceAvatarSvg ? window.store.generateFaceAvatarSvg(empName, 'resident') : '');
  const liveImg = (att && att.faceSnapshot) ? att.faceSnapshot : refImg;
  const isVerified = att ? !!att.faceVerified : false;
  const matchScore = att && att.faceMatchScore ? att.faceMatchScore : (isVerified ? '98.8%' : 'Pending');
  const timestamp = att ? (att.timestamp || `${att.date} ${att.checkInTime || ''}`) : 'Awaiting Live Scan';
  const geofence = att ? (att.isWithinGeofence ? `✓ Inside Geofence (${att.distanceFromCenterKm} km)` : `⚠ Out of Bounds (${att.distanceFromCenterKm} km)`) : '—';

  const elSub = document.getElementById('bioInspectSubTitle');
  if (elSub) elSub.textContent = `${empName} (${emp ? emp.employeeId : ''}) • Punjab Safe City Biometric Database`;

  const elRefImg = document.getElementById('bioInspectRefImg');
  if (elRefImg) elRefImg.src = refImg;

  const elProfileId = document.getElementById('bioInspectProfileId');
  if (elProfileId) elProfileId.textContent = profileId;

  const elEmpName = document.getElementById('bioInspectEmpName');
  if (elEmpName) elEmpName.textContent = empName;

  const elDesig = document.getElementById('bioInspectDesignation');
  if (elDesig) elDesig.textContent = empDesig;

  const elLiveImg = document.getElementById('bioInspectLiveImg');
  if (elLiveImg) {
    elLiveImg.src = liveImg;
    elLiveImg.className = isVerified ? 'bio-portrait live' : 'bio-portrait';
  }

  const elTimestamp = document.getElementById('bioInspectTimestamp');
  if (elTimestamp) elTimestamp.textContent = timestamp;

  const elScore = document.getElementById('bioInspectMatchScore');
  if (elScore) elScore.textContent = matchScore;

  const elLiveness = document.getElementById('bioInspectLiveness');
  if (elLiveness) {
    elLiveness.innerHTML = isVerified ? '<span style="color:var(--success);">✓ Active Reticle Pass</span>' : '<span style="color:var(--muted);">Pending Check-In</span>';
  }

  const elGeo = document.getElementById('bioInspectGeofence');
  if (elGeo) elGeo.textContent = geofence;

  const elBanner = document.getElementById('bioInspectDecisionBanner');
  if (elBanner) {
    if (isVerified) {
      elBanner.className = 'bio-decision-banner bio-decision-pass';
      elBanner.innerHTML = `✓ BIOMETRIC MATCH VERIFIED (${matchScore}) — Anti-Proxy Validation Passed`;
    } else {
      elBanner.className = 'bio-decision-banner bio-decision-fail';
      elBanner.innerHTML = `⚠️ PENDING / UNVERIFIED BIOMETRIC RECORD — Awaiting Live Facial Scan`;
    }
  }

  const modal = document.getElementById('faceInspectionModal');
  if (modal) {
    modal.classList.add('open');
    modal.style.display = 'flex';
  }
}

function closeFaceInspectionModal() {
  const modal = document.getElementById('faceInspectionModal');
  if (modal) {
    modal.classList.remove('open');
    modal.style.display = 'none';
  }
}

function exportDistrictAttendanceCSV() {
  const user = appState.currentUser || window.store.getCurrentUser();
  const districtId = user.districtId || 'chakwal';
  const records = window.store.getAttendanceByDistrict(districtId);
  if (!records.length) { showToast('No attendance records to export.', 'info'); return; }

  const headers = ['Date', 'District', 'Employee ID', 'Employee Name', 'Designation', 'Face Verified', 'Match Score', 'Check-In Time', 'Latitude', 'Longitude', 'Distance (km)', 'Geofence Verified', 'Status', 'Remarks'];
  const rows = records.map(r => [
    r.date, r.districtName, r.employeeId, `"${r.employeeName}"`, `"${r.designation}"`, r.faceVerified ? 'YES' : 'NO', r.faceMatchScore || '', r.checkInTime || '', r.latitude || '', r.longitude || '', r.distanceFromCenterKm || '', r.isWithinGeofence ? 'YES' : 'NO', r.status, `"${(r.remarks || '').replace(/"/g, '""')}"`
  ]);

  downloadCSV(`SafeCity_Attendance_${districtId}_${new Date().toISOString().split('T')[0]}.csv`, headers, rows);
}

function exportAdminAttendanceCSV() {
  const dateVal = document.getElementById('adminAttFilterDate') ? document.getElementById('adminAttFilterDate').value : new Date().toISOString().split('T')[0];
  const allEmployees = window.store.getAllEmployees();
  const allAttendance = window.store.getAllAttendance({ date: dateVal });

  const headers = ['Date', 'District', 'Employee ID', 'Employee Name', 'Designation', 'Face Verified', 'Match Score', 'Check-In Time', 'Latitude', 'Longitude', 'Distance (km)', 'Geofence Verified', 'Status', 'Remarks'];
  const rows = allEmployees.map(emp => {
    const att = allAttendance.find(a => a.employeeId === emp.employeeId);
    return [
      dateVal,
      emp.districtName,
      emp.employeeId,
      `"${emp.name}"`,
      `"${emp.designation}"`,
      att && att.faceVerified ? 'YES' : 'NO',
      att ? att.faceMatchScore || '' : '',
      att ? att.checkInTime || '' : '',
      att ? att.latitude || '' : '',
      att ? att.longitude || '' : '',
      att && att.distanceFromCenterKm !== undefined ? att.distanceFromCenterKm : '',
      att && att.isWithinGeofence ? 'YES' : 'NO',
      att ? att.status : 'ABSENT',
      att ? `"${(att.remarks || '').replace(/"/g, '""')}"` : '"Not checked in"'
    ];
  });

  downloadCSV(`SafeCity_Punjab_Field_Attendance_${dateVal}.csv`, headers, rows);
}

// ==========================================
// District Operational Finances Controller
// ==========================================

let uploadedReceiptBase64 = '';
let activeFinanceTab = 'expenses';
let activeDashFinanceTab = 'expenses';
let financeSearchTimer = null;

function renderFinancePage() {
  const user = appState.currentUser || window.store.getCurrentUser();
  if (!user) return;

  const isFinanceAdmin = user.role === 'FINANCE_ADMIN';
  const isAdmin = user.role === 'ADMIN' || user.role === 'SUPER_ADMIN';
  const isDistrict = !isFinanceAdmin && !isAdmin;

  // Header Titles
  const pageTitle = document.getElementById('pageTitleText');
  const pageSub = document.getElementById('pageSubtitleText');
  const viewHeader = document.getElementById('financeViewHeader');
  const viewSub = document.getElementById('financeViewSub');

  if (isFinanceAdmin) {
    if (pageTitle) pageTitle.textContent = 'Finance Admin Portal & Ledger';
    if (pageSub) pageSub.textContent = 'Operational expenditures, disbursement tracking, payments & queries';
    if (viewHeader) viewHeader.textContent = 'Operational Expenditure & Disbursement Ledger 💰';
    if (viewSub) viewSub.textContent = 'Review field claims, authorize disbursements, record payments, and resolve financial queries.';
  } else if (isDistrict) {
    if (pageTitle) pageTitle.textContent = `District Finances — ${user.districtName || 'District'} Site`;
    if (pageSub) pageSub.textContent = `Log on-site expenditures, generator diesel bills, and track reimbursement status (${user.districtName || ''})`;
    if (viewHeader) viewHeader.textContent = 'District Site Operational Expenses & Balances ₨';
    if (viewSub) viewSub.textContent = 'Maintain on-site O&M expenses, view paid amounts, remaining balances, and submit queries.';
  } else {
    if (pageTitle) pageTitle.textContent = 'Provincial District Finances & Oversight';
    if (pageSub) pageSub.textContent = 'Provincial PMU financial oversight and claim approval across all 37 districts';
    if (viewHeader) viewHeader.textContent = 'Provincial District Finances & Expenditure Audit 💰';
    if (viewSub) viewSub.textContent = 'Provincial financial ledger, audited vouchers, and district claim tracking.';
  }

  // Header Quick Actions
  const actionsContainer = document.getElementById('financeHeaderActions');
  if (actionsContainer) {
    if (isDistrict) {
      actionsContainer.innerHTML = `
        <button class="btn btn-primary" onclick="openNewExpenseModal()">➕ Log Monthly Expense</button>
        <button class="btn" onclick="openSubmitQueryModal()" style="background:#0f3460; color:#fff;">💬 Submit Query</button>
        <button class="btn" onclick="renderFinancePage()">↺ Refresh</button>
      `;
    } else if (isFinanceAdmin) {
      actionsContainer.innerHTML = `
        <button class="btn btn-primary" onclick="openNewExpenseModal()">➕ Log Expense Claim</button>
        <button class="btn" onclick="openSubmitQueryModal()" style="background:#0f3460; color:#fff;">💬 Submit Query</button>
        <button class="btn" onclick="renderFinancePage()">↺ Refresh Data</button>
      `;
    } else {
      actionsContainer.innerHTML = `
        <button class="btn btn-primary" onclick="exportFinanceCSV()">⤓ Export Ledger (CSV)</button>
        <button class="btn" onclick="renderFinancePage()">↺ Refresh Data</button>
      `;
    }
  }

  // Calculate & Render 5 Mandatory KPIs
  const summaryFilter = isDistrict ? { userId: user.id, district: user.districtId } : {};
  const summary = window.store.getFinanceSummary(summaryFilter);

  const elTotalExpense = document.getElementById('kpiTotalExpense');
  const elTotalPaid = document.getElementById('kpiTotalPaid');
  const elTotalOutstanding = document.getElementById('kpiTotalOutstanding');
  const elPendingQueries = document.getElementById('kpiPendingQueries');
  const elTotalRecords = document.getElementById('kpiTotalRecords');
  const elQueriesTabBadge = document.getElementById('queriesTabBadge');

  if (elTotalExpense) elTotalExpense.textContent = `PKR ${(summary.totalExpense || 0).toLocaleString()}`;
  if (elTotalPaid) elTotalPaid.textContent = `PKR ${(summary.totalPaid || 0).toLocaleString()}`;
  if (elTotalOutstanding) elTotalOutstanding.textContent = `PKR ${(summary.totalOutstanding || 0).toLocaleString()}`;
  if (elPendingQueries) elPendingQueries.textContent = `${summary.pendingQueries || 0}`;
  if (elTotalRecords) elTotalRecords.textContent = `${summary.claimCount || 0}`;
  if (elQueriesTabBadge) elQueriesTabBadge.textContent = `${summary.pendingQueries || 0}`;

  // Read tab parameter from URL if provided (e.g. finance.html?tab=expenses or finance.html?tab=queries)
  const urlParams = new URLSearchParams(window.location.search);
  const requestedTab = urlParams.get('tab');
  if (requestedTab === 'expenses' || requestedTab === 'queries') {
    activeFinanceTab = requestedTab;
  }

  // Populate filter dropdowns
  populateFinanceFilterDropdowns(user, isDistrict);

  // Render active tab & tables
  switchFinanceTab(activeFinanceTab);
  renderFinanceRecordsTable();
  renderFinanceQueriesTable();
}

function switchFinanceTab(tab) {
  const targetTab = tab || 'expenses';
  const contentExpenses = document.getElementById('tabContentExpenses');
  const contentQueries = document.getElementById('tabContentQueries');

  // If tab elements are missing from DOM, we are on another page; redirect to finance.html with tab parameter
  if (!contentExpenses || !contentQueries) {
    window.location.href = 'finance.html?tab=' + encodeURIComponent(targetTab);
    return;
  }

  activeFinanceTab = targetTab;
  try {
    const url = new URL(window.location);
    if (url.searchParams.get('tab') !== targetTab) {
      url.searchParams.set('tab', targetTab);
      window.history.replaceState({}, '', url);
    }
  } catch (e) {}

  const btnExpenses = document.getElementById('tabBtnExpenses');
  const btnQueries = document.getElementById('tabBtnQueries');

  if (targetTab === 'expenses') {
    contentExpenses.style.display = 'block';
    contentQueries.style.display = 'none';
    if (btnExpenses) btnExpenses.className = 'btn btn-primary';
    if (btnQueries) btnQueries.className = 'btn';

    // Highlight Expense Records in sidebar
    const navExp = document.getElementById('nav-fin-tab-expenses');
    const navQ = document.getElementById('nav-fin-tab-queries');
    const navMain = document.getElementById('nav-finance-main');
    const navFinAdmin = document.getElementById('nav-finance-admin');
    if (navExp) navExp.classList.add('active');
    if (navQ) navQ.classList.remove('active');
    if (navMain) navMain.classList.remove('active');
    if (navFinAdmin) navFinAdmin.classList.add('active');
  } else {
    contentExpenses.style.display = 'none';
    contentQueries.style.display = 'block';
    if (btnExpenses) btnExpenses.className = 'btn';
    if (btnQueries) btnQueries.className = 'btn btn-primary';

    // Highlight Finance Queries in sidebar
    const navExp = document.getElementById('nav-fin-tab-expenses');
    const navQ = document.getElementById('nav-fin-tab-queries');
    const navMain = document.getElementById('nav-finance-main');
    const navFinAdmin = document.getElementById('nav-finance-admin');
    if (navQ) navQ.classList.add('active');
    if (navExp) navExp.classList.remove('active');
    if (navMain) navMain.classList.remove('active');
    if (navFinAdmin) navFinAdmin.classList.add('active');
  }
}

function populateFinanceFilterDropdowns(user, isDistrict) {
  const isFinanceAdmin = user.role === 'FINANCE_ADMIN';

  // District dropdown
  const distSelect = document.getElementById('finFilterDistrict');
  if (distSelect && distSelect.options.length <= 1) {
    distSelect.innerHTML = isDistrict ? '' : '<option value="all">All Districts</option>';
    if (isDistrict) {
      const opt = document.createElement('option');
      opt.value = (user.districtId || 'chakwal').toLowerCase();
      opt.textContent = user.districtName || 'District';
      opt.selected = true;
      distSelect.appendChild(opt);
      distSelect.disabled = true;
    } else if (window.PUNJAB_DISTRICTS) {
      window.PUNJAB_DISTRICTS.forEach(d => {
        const opt = document.createElement('option');
        opt.value = d.id;
        opt.textContent = d.name;
        distSelect.appendChild(opt);
      });
    }
  }

  // Users dropdown (Strict requirement: Remove "All Users" dropdown for Finance Admin!)
  const userSelect = document.getElementById('finFilterUser');
  if (userSelect) {
    if (isFinanceAdmin || isDistrict) {
      userSelect.style.display = 'none';
      if (userSelect.parentElement && userSelect.parentElement.classList.contains('form-group')) {
        userSelect.parentElement.style.display = 'none';
      }
    } else if (userSelect.options.length <= 1) {
      userSelect.style.display = '';
      userSelect.innerHTML = '<option value="all">All Users</option>';
      const allUsers = window.store.getAllUsers();
      allUsers.forEach(u => {
        const opt = document.createElement('option');
        opt.value = u.id;
        opt.textContent = `${u.name} (${u.districtName || u.role})`;
        userSelect.appendChild(opt);
      });
    }
  }

  // Category filter dropdown (including Monthly Expense)
  const catSelect = document.getElementById('finFilterCategory');
  if (catSelect && catSelect.options.length <= 1) {
    catSelect.innerHTML = `
      <option value="all">All Categories</option>
      <option value="MONTHLY_EXPENSE">📅 Monthly Expense</option>
      <option value="FUEL">⛽ Generator Fuel / Diesel</option>
      <option value="FIBER_REPAIR">🪢 Optical Fiber Repair</option>
      <option value="HARDWARE_SPARES">📹 CCTV Spares &amp; Mounts</option>
      <option value="TRAVEL_TADA">🚗 Field Travel TA / DA</option>
      <option value="POWER_UPS">🔋 Power, UPS &amp; Batteries</option>
      <option value="FACILITY_AC">❄️ Server Rack &amp; AC Maintenance</option>
      <option value="PETTY_CASH">🧾 Office Petty Cash</option>
      <option value="EMERGENCY">🚨 Emergency Response</option>
    `;
  }
}

function onFinanceSearchChange() {
  if (financeSearchTimer) clearTimeout(financeSearchTimer);
  financeSearchTimer = setTimeout(() => {
    renderFinanceRecordsTable();
  }, 250);
}

function resetFinanceFilters() {
  const searchInput = document.getElementById('finFilterSearch');
  const userSelect = document.getElementById('finFilterUser');
  const distSelect = document.getElementById('finFilterDistrict');
  const catSelect = document.getElementById('finFilterCategory');
  const monthSelect = document.getElementById('finFilterMonth');
  const yearSelect = document.getElementById('finFilterYear');
  const statusSelect = document.getElementById('finFilterStatus');

  if (searchInput) searchInput.value = '';
  if (userSelect && !userSelect.disabled && userSelect.style.display !== 'none') userSelect.value = 'all';
  if (distSelect && !distSelect.disabled) distSelect.value = 'all';
  if (catSelect) catSelect.value = 'all';
  if (monthSelect) monthSelect.value = 'all';
  if (yearSelect) yearSelect.value = 'all';
  if (statusSelect) statusSelect.value = 'all';

  renderFinanceRecordsTable();
}

function renderFinanceRecordsTable() {
  const user = appState.currentUser || window.store.getCurrentUser();
  if (!user) return;

  const isFinanceAdmin = user.role === 'FINANCE_ADMIN';
  const isAdmin = user.role === 'ADMIN' || user.role === 'SUPER_ADMIN';
  const isDistrict = !isFinanceAdmin && !isAdmin;

  const search = (document.getElementById('finFilterSearch') ? document.getElementById('finFilterSearch').value : '').trim();
  const userId = (!isFinanceAdmin && document.getElementById('finFilterUser')) ? document.getElementById('finFilterUser').value : 'all';
  const district = document.getElementById('finFilterDistrict') ? document.getElementById('finFilterDistrict').value : 'all';
  const category = document.getElementById('finFilterCategory') ? document.getElementById('finFilterCategory').value : 'all';
  const month = document.getElementById('finFilterMonth') ? document.getElementById('finFilterMonth').value : 'all';
  const year = document.getElementById('finFilterYear') ? document.getElementById('finFilterYear').value : 'all';
  const status = document.getElementById('finFilterStatus') ? document.getElementById('finFilterStatus').value : 'all';

  const filters = {
    search,
    category: category !== 'all' ? category : '',
    status: status !== 'all' ? status : '',
    month: month !== 'all' ? month : '',
    year: year !== 'all' ? year : ''
  };

  if (isDistrict) {
    filters.userId = user.id;
    filters.district = user.districtId;
  } else if (!isFinanceAdmin) {
    if (userId !== 'all') filters.userId = userId;
    if (district !== 'all') filters.district = district;
  } else {
    // Finance Admin sees all users across districts
    if (district !== 'all') filters.district = district;
  }

  const expenses = window.store.getAllExpenses(filters);
  const tbody = document.getElementById('financeRecordsTableBody');
  if (!tbody) return;

  if (expenses.length === 0) {
    tbody.innerHTML = `<tr><td colspan="8" style="text-align:center; padding:28px; color:var(--muted);">No expense records match the active filter criteria.</td></tr>`;
    return;
  }

  tbody.innerHTML = expenses.map(e => {
    // Payment Status badge
    let payBadge = `<span class="pay-status-badge pay-status-not_paid">Not Paid</span>`;
    if (e.paymentStatus === 'PARTIALLY_PAID') {
      payBadge = `<span class="pay-status-badge pay-status-partially_paid">Partially Paid</span>`;
    } else if (e.paymentStatus === 'FULLY_PAID') {
      payBadge = `<span class="pay-status-badge pay-status-fully_paid">Fully Paid</span>`;
    }

    // Amount colors
    const balanceColor = e.remainingBalance > 0 ? 'var(--danger)' : 'var(--success)';
    const balanceWeight = e.remainingBalance > 0 ? '700' : '600';
    const monthStr = e.month || (e.expenseDate ? e.expenseDate.substring(0, 7) : '2026-10');

    // Actions per role
    let actionButtons = `<button class="btn btn-sm" onclick="openViewVoucherModal('${e.id}')">👁 View</button>`;
    if (isFinanceAdmin) {
      if (e.remainingBalance > 0) {
        actionButtons += ` <button class="btn btn-sm btn-primary" onclick="openRecordPaymentModal('${e.id}')" style="background:#1d4ed8; color:#fff; font-weight:600;">💳 Add Payment</button>`;
      } else {
        actionButtons += ` <span class="badge" style="background:#ecfdf5; color:#065f46; font-size:11px;">✓ Cleared</span>`;
      }
    }

    return `
      <tr>
        <td>
          <strong>${e.userName || 'Site Engineer'}</strong><br>
          <small style="color:var(--muted);">${e.userId || ''}</small>
        </td>
        <td><strong>${e.districtName || 'District'}</strong></td>
        <td><strong style="font-family:monospace;">${monthStr}</strong></td>
        <td class="amount-display">PKR ${Number(e.amount || 0).toLocaleString()}</td>
        <td class="amount-display" style="color:var(--success); font-weight:700;">PKR ${Number(e.paidAmount || 0).toLocaleString()}</td>
        <td class="amount-display" style="color:${balanceColor}; font-weight:${balanceWeight};">PKR ${Number(e.remainingBalance || 0).toLocaleString()}</td>
        <td>${payBadge}</td>
        <td>
          <div style="display:flex; gap:6px; align-items:center;">
            ${actionButtons}
          </div>
        </td>
      </tr>
    `;
  }).join('');
}

function renderFinanceQueriesTable() {
  const user = appState.currentUser || window.store.getCurrentUser();
  if (!user) return;

  const isFinanceAdmin = user.role === 'FINANCE_ADMIN';
  const isAdmin = user.role === 'ADMIN' || user.role === 'SUPER_ADMIN';
  const isDistrict = !isFinanceAdmin && !isAdmin;

  const search = (document.getElementById('queryFilterSearch') ? document.getElementById('queryFilterSearch').value : '').trim().toLowerCase();
  const status = document.getElementById('queryFilterStatus') ? document.getElementById('queryFilterStatus').value : 'all';

  let queries = window.store.getAllFinanceQueries();

  if (isDistrict) {
    queries = queries.filter(q => (q.userId && String(q.userId).toLowerCase() === String(user.id).toLowerCase()) || (q.districtId && String(q.districtId).toLowerCase() === String(user.districtId).toLowerCase()));
  }

  if (status !== 'all') {
    queries = queries.filter(q => q.status === status);
  }

  if (search) {
    queries = queries.filter(q => 
      (q.subject && q.subject.toLowerCase().includes(search)) ||
      (q.message && q.message.toLowerCase().includes(search)) ||
      (q.userName && q.userName.toLowerCase().includes(search)) ||
      (q.districtName && q.districtName.toLowerCase().includes(search))
    );
  }

  const tbody = document.getElementById('financeQueriesTableBody');
  if (!tbody) return;

  if (queries.length === 0) {
    tbody.innerHTML = `<tr><td colspan="9" style="text-align:center; padding:28px; color:var(--muted);">No finance queries found. Click "💬 Submit New Query" to lodge an inquiry.</td></tr>`;
    return;
  }

  tbody.innerHTML = queries.map(q => {
    let statusClass = 'query-status-pending';
    let statusIcon = '⏳';
    if (q.status === 'Under Review') {
      statusClass = 'query-status-under_review';
      statusIcon = '🔍';
    } else if (q.status === 'Responded') {
      statusClass = 'query-status-responded';
      statusIcon = '💬';
    } else if (q.status === 'Resolved') {
      statusClass = 'query-status-resolved';
      statusIcon = '✓';
    } else if (q.status === 'Rejected') {
      statusClass = 'query-status-rejected';
      statusIcon = '✕';
    }

    const statusBadge = `<span class="query-status-badge ${statusClass}">${statusIcon} ${q.status}</span>`;
    const catBadge = `<span class="badge" style="background:#f1f5f9; color:#475569; font-size:11px;">${(q.category || '').replace(/_/g, ' ')}</span>`;
    const dateStr = q.createdAt ? q.createdAt.substring(0, 10) : '—';
    const monthStr = q.month || '—';

    let actionButton = '—';
    if (isFinanceAdmin) {
      actionButton = `<button class="btn btn-sm btn-primary" onclick="openRespondQueryModal('${q.id}')">✍ Update / Respond</button>`;
    }

    const responseBlock = q.response ? `
      <div>
        <strong style="font-size:12px; color:#1e3a8a;">"${q.response}"</strong><br>
        <small style="color:var(--muted);">By ${q.respondedBy || 'Finance'} • ${q.updatedAt ? q.updatedAt.substring(0, 10) : ''}</small>
      </div>
    ` : `<em style="color:var(--muted); font-size:12px;">Awaiting finance review</em>`;

    return `
      <tr>
        <td><small style="font-weight:600;">${dateStr}</small></td>
        <td><strong>${q.userName}</strong></td>
        <td><strong>${q.districtName}</strong></td>
        <td><span style="font-family:monospace; font-size:12px;">${monthStr}</span></td>
        <td>${catBadge}</td>
        <td>
          <strong style="color:#0f172a;">${q.subject}</strong><br>
          <small style="color:#475467;">${q.message}</small>
          ${q.attachmentUrl ? `<div style="margin-top:4px;"><a href="${q.attachmentUrl}" target="_blank" style="font-size:11px; color:#2563eb; text-decoration:underline;">📎 View Attachment</a></div>` : ''}
        </td>
        <td>${statusBadge}</td>
        <td>${responseBlock}</td>
        <td>${actionButton}</td>
      </tr>
    `;
  }).join('');
}

// ==========================================
// Payment Modal & Disbursement Handlers
// ==========================================

function openRecordPaymentModal(expenseId) {
  const user = appState.currentUser || window.store.getCurrentUser();
  if (user.role !== 'FINANCE_ADMIN' && user.role !== 'SUPER_ADMIN' && user.role !== 'ADMIN') {
    showToast('Permission denied: Only Finance Admin can record payments.', 'danger');
    return;
  }

  const exp = window.store.getExpenseById(expenseId);
  if (!exp) {
    showToast('Expense record not found.', 'danger');
    return;
  }

  const form = document.getElementById('recordPaymentForm');
  if (form) form.reset();

  document.getElementById('payExpenseId').value = exp.id;
  document.getElementById('payExpenseTitle').textContent = exp.title || 'Operational Expense';
  document.getElementById('payExpenseUserDistrict').textContent = `${exp.userName || 'Site Engineer'} • ${exp.districtName || 'District'} • Month: ${exp.month || '2026-10'}`;
  document.getElementById('payExpenseTotalAmount').textContent = `PKR ${Number(exp.amount).toLocaleString()}`;
  document.getElementById('payExpenseAlreadyPaid').textContent = `PKR ${Number(exp.paidAmount || 0).toLocaleString()}`;
  document.getElementById('payExpenseRemainingBalance').textContent = `PKR ${Number(exp.remainingBalance || 0).toLocaleString()}`;

  const amountInput = document.getElementById('payAmountInput');
  if (amountInput) {
    amountInput.value = exp.remainingBalance;
    amountInput.max = exp.remainingBalance;
  }

  const dateInput = document.getElementById('payDateInput');
  if (dateInput) {
    dateInput.value = new Date().toISOString().split('T')[0];
  }

  const modal = document.getElementById('recordPaymentModal');
  if (modal) {
    modal.classList.add('open');
    modal.style.display = 'flex';
  }
}

function closeRecordPaymentModal() {
  const modal = document.getElementById('recordPaymentModal');
  if (modal) {
    modal.classList.remove('open');
    modal.style.display = 'none';
  }
}

async function handleRecordPaymentSubmit(event) {
  event.preventDefault();
  const expenseId = document.getElementById('payExpenseId').value;
  const amount = parseFloat(document.getElementById('payAmountInput').value) || 0;
  const paymentDate = document.getElementById('payDateInput').value;
  const reference = document.getElementById('payReferenceInput').value;
  const remarks = document.getElementById('payRemarksInput').value;
  const fileInput = document.getElementById('payProofFileInput');

  if (amount <= 0) {
    showToast('Payment amount must be greater than zero.', 'danger');
    return;
  }

  let proofUrl = '';
  if (fileInput && fileInput.files && fileInput.files[0] && window.api && typeof window.api.uploadFile === 'function') {
    try {
      showToast('Uploading payment proof...', 'info');
      const up = await window.api.uploadFile('payments', fileInput.files[0]);
      if (up && up.url) proofUrl = up.url;
    } catch (e) {
      console.warn('File upload warning:', e);
    }
  }

  const paymentData = {
    amount,
    paymentDate,
    reference,
    remarks,
    proofUrl
  };

  const res = window.store.addPayment(expenseId, paymentData);
  if (!res.success) {
    showToast(res.error || 'Failed to record payment.', 'danger');
    return;
  }

  const updatedExp = res.expense;
  showToast(`Payment of PKR ${amount.toLocaleString()} recorded. Remaining balance: PKR ${updatedExp.remainingBalance.toLocaleString()}`, 'success');
  closeRecordPaymentModal();

  renderFinancePage();
}

// ==========================================
// Finance Query Handlers
// ==========================================

function openSubmitQueryModal() {
  const form = document.getElementById('submitQueryForm');
  if (form) form.reset();

  const monthInput = document.getElementById('queryMonthYear');
  if (monthInput) {
    monthInput.value = new Date().toISOString().substring(0, 7);
  }

  const modal = document.getElementById('submitQueryModal');
  if (modal) {
    modal.classList.add('open');
    modal.style.display = 'flex';
  }
}

function closeSubmitQueryModal() {
  const modal = document.getElementById('submitQueryModal');
  if (modal) {
    modal.classList.remove('open');
    modal.style.display = 'none';
  }
}

async function handleQuerySubmit(event) {
  event.preventDefault();
  const user = appState.currentUser || window.store.getCurrentUser();
  const monthYear = document.getElementById('queryMonthYear').value;
  const category = document.getElementById('queryCategory').value;
  const subject = document.getElementById('querySubject').value;
  const message = document.getElementById('queryMessage').value;
  const fileInput = document.getElementById('queryAttachmentFile');

  let attachmentUrl = '';
  if (fileInput && fileInput.files && fileInput.files[0] && window.api && typeof window.api.uploadFile === 'function') {
    try {
      showToast('Uploading attachment...', 'info');
      const up = await window.api.uploadFile('queries', fileInput.files[0]);
      if (up && up.url) attachmentUrl = up.url;
    } catch (e) {
      console.warn('File upload warning:', e);
    }
  }

  const queryData = {
    userId: user.id || 'usr_site',
    userName: user.name || (user.districtName ? `${user.districtName} Engineer` : 'Site Engineer'),
    districtId: (user.districtId || 'chakwal').toLowerCase(),
    districtName: user.districtName || 'District',
    month: monthYear,
    year: monthYear ? monthYear.split('-')[0] : '2026',
    category,
    subject,
    message,
    attachmentUrl
  };

  window.store.saveFinanceQuery(queryData);
  showToast('Finance query submitted successfully. Awaiting PMU review.', 'success');
  closeSubmitQueryModal();

  if (document.getElementById('view-finance')) {
    renderFinancePage();
  }
  if (document.getElementById('view-dashboard')) {
    renderDashboardFinances();
  }
}

function openRespondQueryModal(queryId) {
  const queries = window.store.getAllFinanceQueries();
  const q = queries.find(item => item.id === queryId);
  if (!q) {
    showToast('Query not found.', 'danger');
    return;
  }

  document.getElementById('respondQueryId').value = q.id;
  document.getElementById('respondQuerySubject').textContent = q.subject;
  document.getElementById('respondQueryMeta').textContent = `${q.userName} (${q.districtName}) • Month: ${q.month || '—'} • ${q.category}`;
  document.getElementById('respondQueryMessage').textContent = q.message;
  document.getElementById('respondQueryStatus').value = q.status || 'Under Review';
  document.getElementById('respondQueryRemarks').value = q.response || '';

  const modal = document.getElementById('respondQueryModal');
  if (modal) {
    modal.classList.add('open');
    modal.style.display = 'flex';
  }
}

function closeRespondQueryModal() {
  const modal = document.getElementById('respondQueryModal');
  if (modal) {
    modal.classList.remove('open');
    modal.style.display = 'none';
  }
}

function handleRespondQuerySubmit(event) {
  event.preventDefault();
  const user = appState.currentUser || window.store.getCurrentUser();
  const queryId = document.getElementById('respondQueryId').value;
  const status = document.getElementById('respondQueryStatus').value;
  const remarks = document.getElementById('respondQueryRemarks').value;

  window.store.updateFinanceQuery(queryId, status, remarks, user.name || 'Finance Admin');
  showToast(`Finance query status updated to "${status}".`, 'success');
  closeRespondQueryModal();

  renderFinancePage();
}

// ==========================================
// Log Monthly Expense Modal Handlers
// ==========================================

function openNewExpenseModal() {
  const user = appState.currentUser || window.store.getCurrentUser();
  const form = document.getElementById('expenseForm');
  if (form) form.reset();

  const monthYearInput = document.getElementById('expMonthYear');
  if (monthYearInput) monthYearInput.value = new Date().toISOString().substring(0, 7);

  const dateInput = document.getElementById('expDate');
  if (dateInput) dateInput.value = new Date().toISOString().split('T')[0];

  const label = document.getElementById('expenseModalDistrictLabel');
  if (label) label.textContent = `${user.districtName || 'District'} Operational Site`;

  uploadedReceiptBase64 = '';
  const img = document.getElementById('receiptPreviewImg');
  const txt = document.getElementById('receiptPlaceholderText');
  if (img) { img.style.display = 'none'; img.src = ''; }
  if (txt) txt.style.display = 'block';

  const modal = document.getElementById('expenseModal');
  if (modal) {
    modal.classList.add('open');
    modal.style.display = 'flex';
  }
}

function closeExpenseModal() {
  const modal = document.getElementById('expenseModal');
  if (modal) {
    modal.classList.remove('open');
    modal.style.display = 'none';
  }
}

function previewReceiptFile(event) {
  const file = event.target.files[0];
  if (!file) return;

  const reader = new FileReader();
  reader.onload = e => {
    uploadedReceiptBase64 = e.target.result;
    const img = document.getElementById('receiptPreviewImg');
    const txt = document.getElementById('receiptPlaceholderText');
    if (img) {
      img.src = uploadedReceiptBase64;
      img.style.display = 'block';
    }
    if (txt) txt.style.display = 'none';
  };
  reader.readAsDataURL(file);
}

async function handleExpenseSubmit(event) {
  event.preventDefault();
  const user = appState.currentUser || window.store.getCurrentUser();
  const districtId = (user.districtId && user.districtId !== 'all') ? user.districtId : 'chakwal';
  const monthYear = document.getElementById('expMonthYear') ? document.getElementById('expMonthYear').value : new Date().toISOString().substring(0, 7);
  const amount = parseFloat(document.getElementById('expAmount').value) || 0;
  const fileInput = document.getElementById('expReceiptFile');

  if (amount <= 0) {
    showToast('Expense amount must be greater than zero.', 'danger');
    return;
  }

  let billUrl = '';
  if (fileInput && fileInput.files && fileInput.files[0] && window.api && typeof window.api.uploadFile === 'function') {
    try {
      showToast('Uploading bill / receipt...', 'info');
      const up = await window.api.uploadFile('bills', fileInput.files[0]);
      if (up && up.url) billUrl = up.url;
    } catch (e) {
      console.warn('Upload error:', e);
    }
  }

  const expenseData = {
    districtId: districtId,
    districtName: user.districtName || 'District',
    userId: user.id || `usr_${districtId}`,
    userName: user.name || (user.districtName ? `${user.districtName} Lead` : 'Site Engineer'),
    month: monthYear,
    year: monthYear ? monthYear.split('-')[0] : '2026',
    expenseDate: document.getElementById('expDate').value,
    category: document.getElementById('expCategory').value,
    title: document.getElementById('expTitle').value,
    amount: amount,
    vendorName: document.getElementById('expVendorName') ? document.getElementById('expVendorName').value : '',
    invoiceNumber: document.getElementById('expInvoiceNumber') ? document.getElementById('expInvoiceNumber').value : '',
    description: document.getElementById('expDescription').value,
    receiptAttachment: billUrl || uploadedReceiptBase64 || '',
    receiptAttachmentUrl: billUrl || '',
    status: 'PENDING_APPROVAL'
  };

  window.store.saveExpense(expenseData);
  showToast(`Monthly expense claim for PKR ${amount.toLocaleString()} logged. Status: Not Paid`, 'success');
  closeExpenseModal();

  if (document.getElementById('view-finance')) {
    renderFinancePage();
  }
  if (document.getElementById('view-dashboard')) {
    renderDashboardFinances();
  }
}

function openViewVoucherModal(id) {
  const exp = window.store.getExpenseById(id);
  if (!exp) {
    showToast('Voucher not found.', 'danger');
    return;
  }

  const title = document.getElementById('voucherModalTitle');
  const dist = document.getElementById('voucherModalDistrict');
  const body = document.getElementById('voucherModalBody');

  if (title) title.textContent = `Voucher #${exp.invoiceNumber || exp.id}`;
  if (dist) dist.textContent = `${exp.districtName} • ${exp.userName} (${exp.month || '2026-10'})`;

  if (body) {
    let paymentsHtml = '<p style="color:var(--muted); font-size:12px; margin:0;">No payment disbursements recorded yet.</p>';
    if (Array.isArray(exp.payments) && exp.payments.length > 0) {
      paymentsHtml = `
        <div style="border:1px solid #e2e8f0; border-radius:6px; overflow:hidden;">
          <table style="width:100%; font-size:12px;">
            <thead style="background:#f1f5f9;">
              <tr>
                <th style="padding:6px 8px; text-align:left;">Date</th>
                <th style="padding:6px 8px; text-align:left;">Reference</th>
                <th style="padding:6px 8px; text-align:right;">Amount (PKR)</th>
                <th style="padding:6px 8px; text-align:left;">Remarks</th>
              </tr>
            </thead>
            <tbody>
              ${exp.payments.map(p => `
                <tr style="border-top:1px solid #e2e8f0;">
                  <td style="padding:6px 8px;">${p.paymentDate}</td>
                  <td style="padding:6px 8px;"><strong style="font-family:monospace;">${p.reference}</strong></td>
                  <td style="padding:6px 8px; text-align:right; color:var(--success); font-weight:700;">PKR ${Number(p.amount).toLocaleString()}</td>
                  <td style="padding:6px 8px; color:var(--muted);">${p.remarks || '—'}</td>
                </tr>
              `).join('')}
            </tbody>
          </table>
        </div>
      `;
    }

    const receiptHtml = (exp.receiptAttachmentUrl || exp.receiptAttachment) ? `
      <div style="border:1px solid #e2e8f0; border-radius:8px; padding:10px; text-align:center; background:#f8fafc; margin-top:6px;">
        <img src="${exp.receiptAttachmentUrl || exp.receiptAttachment}" style="max-width:100%; max-height:240px; object-fit:contain; border-radius:6px;" alt="Receipt">
        ${exp.receiptAttachmentUrl ? `<div style="margin-top:6px;"><a href="${exp.receiptAttachmentUrl}" target="_blank" style="font-size:12px; color:#2563eb; text-decoration:underline;">Open Full Image</a></div>` : ''}
      </div>
    ` : `<div style="border:1px dashed #cbd5e1; border-radius:6px; padding:12px; text-align:center; color:var(--muted); font-size:12px;">No bill or receipt photo attached.</div>`;

    body.innerHTML = `
      <div style="background:#f8fafc; border:1px solid #e2e8f0; border-radius:8px; padding:14px; margin-bottom:14px;">
        <div style="display:flex; justify-content:space-between; margin-bottom:8px;">
          <span style="color:var(--muted); font-size:12px;">Claim Title:</span>
          <strong>${exp.title}</strong>
        </div>
        <div style="display:flex; justify-content:space-between; margin-bottom:8px;">
          <span style="color:var(--muted); font-size:12px;">Category:</span>
          <span class="badge" style="background:#f1f5f9; color:#475569;">${(exp.category || '').replace(/_/g, ' ')}</span>
        </div>
        <div style="display:flex; justify-content:space-between; margin-bottom:8px;">
          <span style="color:var(--muted); font-size:12px;">Total Expense:</span>
          <strong style="font-size:15px; color:#0f172a;">PKR ${Number(exp.amount).toLocaleString()}</strong>
        </div>
        <div style="display:flex; justify-content:space-between; margin-bottom:8px;">
          <span style="color:var(--muted); font-size:12px;">Total Paid:</span>
          <strong style="font-size:15px; color:var(--success);">PKR ${Number(exp.paidAmount || 0).toLocaleString()}</strong>
        </div>
        <div style="display:flex; justify-content:space-between; margin-bottom:8px;">
          <span style="color:var(--muted); font-size:12px;">Remaining Balance:</span>
          <strong style="font-size:15px; color:${exp.remainingBalance > 0 ? 'var(--danger)' : 'var(--success)'};">PKR ${Number(exp.remainingBalance || 0).toLocaleString()}</strong>
        </div>
        <div style="display:flex; justify-content:space-between;">
          <span style="color:var(--muted); font-size:12px;">Payment Status:</span>
          <strong>${(exp.paymentStatus || 'NOT_PAID').replace(/_/g, ' ')}</strong>
        </div>
      </div>

      <div style="margin-bottom:14px;">
        <h5 style="font-size:12px; text-transform:uppercase; color:var(--muted); margin-bottom:4px;">Description / Operational Justification</h5>
        <p style="font-size:13px; background:#fff; border:1px solid #e2e8f0; border-radius:6px; padding:10px; margin:0;">
          ${exp.description || 'No detailed remarks provided.'}
        </p>
      </div>

      <div style="margin-bottom:14px;">
        <h5 style="font-size:12px; text-transform:uppercase; color:var(--muted); margin-bottom:6px;">Payment Disbursements History</h5>
        ${paymentsHtml}
      </div>

      <div>
        <h5 style="font-size:12px; text-transform:uppercase; color:var(--muted); margin-bottom:4px;">Attached Bill / Receipt Photo</h5>
        ${receiptHtml}
      </div>
    `;
  }

  const modal = document.getElementById('viewVoucherModal');
  if (modal) {
    modal.classList.add('open');
    modal.style.display = 'flex';
  }
}

function closeViewVoucherModal() {
  const modal = document.getElementById('viewVoucherModal');
  if (modal) {
    modal.classList.remove('open');
    modal.style.display = 'none';
  }
}

function exportFinanceCSV() {
  const expenses = window.store.getAllExpenses();
  if (!expenses.length) {
    showToast('No financial records to export.', 'info');
    return;
  }

  const headers = ['User', 'District', 'Month', 'Expense (PKR)', 'Paid (PKR)', 'Remaining Balance (PKR)', 'Payment Status', 'Category', 'Title', 'Invoice #', 'Vendor', 'Created Date'];
  const rows = expenses.map(e => [
    `"${(e.userName || '').replace(/"/g, '""')}"`,
    `"${(e.districtName || '').replace(/"/g, '""')}"`,
    e.month || '',
    e.amount || 0,
    e.paidAmount || 0,
    e.remainingBalance || 0,
    e.paymentStatus || '',
    e.category || '',
    `"${(e.title || '').replace(/"/g, '""')}"`,
    `"${(e.invoiceNumber || '').replace(/"/g, '""')}"`,
    `"${(e.vendorName || '').replace(/"/g, '""')}"`,
    e.expenseDate || ''
  ]);

  downloadCSV(`SafeCity_Punjab_Operational_Finances_${new Date().toISOString().split('T')[0]}.csv`, headers, rows);
}

// ==========================================
// User Dashboard Finance Section Handlers
// ==========================================

function switchDashFinanceTab(tab) {
  activeDashFinanceTab = tab;
  const contentExpenses = document.getElementById('dashTabContentExpenses');
  const contentQueries = document.getElementById('dashTabContentQueries');
  const btnExpenses = document.getElementById('btnDashTabExp');
  const btnQueries = document.getElementById('btnDashTabQry');

  if (tab === 'expenses') {
    if (contentExpenses) contentExpenses.style.display = 'block';
    if (contentQueries) contentQueries.style.display = 'none';
    if (btnExpenses) btnExpenses.className = 'btn btn-sm btn-primary';
    if (btnQueries) btnQueries.className = 'btn btn-sm';
  } else {
    if (contentExpenses) contentExpenses.style.display = 'none';
    if (contentQueries) contentQueries.style.display = 'block';
    if (btnExpenses) btnExpenses.className = 'btn btn-sm';
    if (btnQueries) btnQueries.className = 'btn btn-sm btn-primary';
  }
}

function renderDashboardFinances() {
  const user = appState.currentUser || window.store.getCurrentUser();
  if (!user) return;

  const districtId = user.districtId || 'chakwal';
  const filter = { userId: user.id, district: districtId };
  const summary = window.store.getFinanceSummary(filter);

  // Update Mini KPIs
  const elExpense = document.getElementById('userDashTotalExpense');
  const elPaid = document.getElementById('userDashTotalPaid');
  const elBalance = document.getElementById('userDashRemainingBalance');
  const elQueries = document.getElementById('userDashPendingQueries');
  const elClaimCount = document.getElementById('userDashClaimCount');
  const elQueryBadge = document.getElementById('userDashQueryBadge');

  if (elExpense) elExpense.textContent = `PKR ${(summary.totalExpense || 0).toLocaleString()}`;
  if (elPaid) elPaid.textContent = `PKR ${(summary.totalPaid || 0).toLocaleString()}`;
  if (elBalance) elBalance.textContent = `PKR ${(summary.totalOutstanding || 0).toLocaleString()}`;
  if (elQueries) elQueries.textContent = `${summary.pendingQueries || 0}`;
  if (elClaimCount) elClaimCount.textContent = `${summary.claimCount || 0} claims logged`;
  if (elQueryBadge) elQueryBadge.textContent = `${summary.pendingQueries || 0}`;

  // Populate User Expenses Table
  const tbodyExpenses = document.getElementById('userDashExpensesBody');
  if (tbodyExpenses) {
    const expenses = window.store.getAllExpenses(filter);
    if (expenses.length === 0) {
      tbodyExpenses.innerHTML = `<tr><td colspan="8" style="text-align:center; padding:20px; color:var(--muted);">No monthly expense claims submitted yet. Click "➕ Log Monthly Expense" to add your first claim.</td></tr>`;
    } else {
      tbodyExpenses.innerHTML = expenses.map(e => {
        let payBadge = `<span class="pay-status-badge pay-status-not_paid">Not Paid</span>`;
        if (e.paymentStatus === 'PARTIALLY_PAID') payBadge = `<span class="pay-status-badge pay-status-partially_paid">Partially Paid</span>`;
        else if (e.paymentStatus === 'FULLY_PAID') payBadge = `<span class="pay-status-badge pay-status-fully_paid">Fully Paid</span>`;

        return `
          <tr>
            <td><strong>${e.userName || user.name}</strong></td>
            <td><strong>${e.districtName || user.districtName}</strong></td>
            <td><strong style="font-family:monospace;">${e.month || (e.expenseDate ? e.expenseDate.substring(0, 7) : '2026-10')}</strong></td>
            <td class="amount-display">PKR ${Number(e.amount || 0).toLocaleString()}</td>
            <td class="amount-display" style="color:var(--success); font-weight:700;">PKR ${Number(e.paidAmount || 0).toLocaleString()}</td>
            <td class="amount-display" style="color:${e.remainingBalance > 0 ? 'var(--danger)' : 'var(--success)'}; font-weight:700;">PKR ${Number(e.remainingBalance || 0).toLocaleString()}</td>
            <td>${payBadge}</td>
            <td><button class="btn btn-sm" onclick="openViewVoucherModal('${e.id}')">👁 View</button></td>
          </tr>
        `;
      }).join('');
    }
  }

  // Populate User Queries Table
  const tbodyQueries = document.getElementById('userDashQueriesBody');
  if (tbodyQueries) {
    let queries = window.store.getAllFinanceQueries();
    queries = queries.filter(q => (q.userId && String(q.userId).toLowerCase() === String(user.id).toLowerCase()) || (q.districtId && String(q.districtId).toLowerCase() === String(user.districtId).toLowerCase()));

    if (queries.length === 0) {
      tbodyQueries.innerHTML = `<tr><td colspan="6" style="text-align:center; padding:20px; color:var(--muted);">No finance queries submitted. Click "💬 Submit Finance Query" if you have any inquiry.</td></tr>`;
    } else {
      tbodyQueries.innerHTML = queries.map(q => {
        let statusClass = 'query-status-pending';
        let statusIcon = '⏳';
        if (q.status === 'Under Review') { statusClass = 'query-status-under_review'; statusIcon = '🔍'; }
        else if (q.status === 'Responded') { statusClass = 'query-status-responded'; statusIcon = '💬'; }
        else if (q.status === 'Resolved') { statusClass = 'query-status-resolved'; statusIcon = '✓'; }
        else if (q.status === 'Rejected') { statusClass = 'query-status-rejected'; statusIcon = '✕'; }

        return `
          <tr>
            <td><small style="font-weight:600;">${q.createdAt ? q.createdAt.substring(0, 10) : '—'}</small></td>
            <td><span style="font-family:monospace; font-size:12px;">${q.month || '—'}</span></td>
            <td><span class="badge" style="background:#f1f5f9; color:#475569; font-size:11px;">${(q.category || '').replace(/_/g, ' ')}</span></td>
            <td><strong>${q.subject}</strong><br><small style="color:var(--muted);">${q.message}</small></td>
            <td><span class="query-status-badge ${statusClass}">${statusIcon} ${q.status}</span></td>
            <td>${q.response ? `<strong>${q.response}</strong><br><small style="color:var(--muted);">By: ${q.respondedBy || 'Finance'}</small>` : '<em style="color:var(--muted); font-size:12px;">Awaiting response</em>'}</td>
          </tr>
        `;
      }).join('');
    }
  }
}

// ==========================================
// Admin Overview Finance Queries Handlers
// ==========================================

function renderAdminOverviewFinances() {
  const tbody = document.getElementById('adminOverviewQueriesBody');
  if (!tbody) return;

  const queries = window.store.getAllFinanceQueries();
  if (queries.length === 0) {
    tbody.innerHTML = `<tr><td colspan="8" style="text-align:center; padding:20px; color:var(--muted);">No district finance queries pending review.</td></tr>`;
    return;
  }

  tbody.innerHTML = queries.map(q => {
    let statusClass = 'query-status-pending';
    let statusIcon = '⏳';
    if (q.status === 'Under Review') { statusClass = 'query-status-under_review'; statusIcon = '🔍'; }
    else if (q.status === 'Responded') { statusClass = 'query-status-responded'; statusIcon = '💬'; }
    else if (q.status === 'Resolved') { statusClass = 'query-status-resolved'; statusIcon = '✓'; }
    else if (q.status === 'Rejected') { statusClass = 'query-status-rejected'; statusIcon = '✕'; }

    return `
      <tr>
        <td><small style="font-weight:600;">${q.createdAt ? q.createdAt.substring(0, 10) : '—'}</small></td>
        <td><strong>${q.districtName || 'District'}</strong></td>
        <td><strong>${q.userName || 'Site Engineer'}</strong></td>
        <td><span style="font-family:monospace; font-size:12px;">${q.month || '—'}</span></td>
        <td><span class="badge" style="background:#f1f5f9; color:#475569; font-size:11px;">${(q.category || '').replace(/_/g, ' ')}</span></td>
        <td><strong>${q.subject}</strong><br><small style="color:var(--muted);">${q.message}</small></td>
        <td><span class="query-status-badge ${statusClass}">${statusIcon} ${q.status}</span></td>
        <td>${q.response ? `<strong>${q.response}</strong><br><small style="color:var(--muted);">By: ${q.respondedBy || 'Finance'}</small>` : '<em style="color:var(--muted); font-size:12px;">Awaiting response</em>'}</td>
      </tr>
    `;
  }).join('');
}

function downloadCSV(filename, headers, rows) {
  const csvContent = 'data:text/csv;charset=utf-8,' + [headers.join(','), ...rows.map(e => e.join(','))].join('\n');
  const encodedUri = encodeURI(csvContent);
  const link = document.createElement('a');
  link.setAttribute('href', encodedUri);
  link.setAttribute('download', filename);
  document.body.appendChild(link);
  link.click();
  document.body.removeChild(link);
  showToast(`Exported ${filename}`, 'success');
}

// Global window functions export
window.renderAttendancePage = renderAttendancePage;
window.renderDistrictAttendance = renderDistrictAttendance;
window.renderDistrictAttendanceLog = renderDistrictAttendanceLog;
window.openQuickCheckInModal = openQuickCheckInModal;
window.closeCheckInModal = closeCheckInModal;
window.onCheckInEmployeeChange = onCheckInEmployeeChange;
window.fetchLiveGPS = fetchLiveGPS;
window.simulateDistrictCenterGPS = simulateDistrictCenterGPS;
window.simulateOutOfBoundsGPS = simulateOutOfBoundsGPS;
window.handleAttendanceSubmit = handleAttendanceSubmit;
window.renderAdminAttendance = renderAdminAttendance;
window.openAdminAttModal = openAdminAttModal;
window.closeAdminAttModal = closeAdminAttModal;
window.handleAdminAttSubmit = handleAdminAttSubmit;
window.exportDistrictAttendanceCSV = exportDistrictAttendanceCSV;
window.exportAdminAttendanceCSV = exportAdminAttendanceCSV;
window.exportProvincialAttendanceCSV = exportAdminAttendanceCSV;
window.startFaceCamera = startFaceCamera;
window.stopFaceCamera = stopFaceCamera;
window.captureAndVerifyFace = captureAndVerifyFace;
window.simulateFaceMatch = simulateFaceMatch;
window.simulateFaceMismatch = simulateFaceMismatch;
window.openFaceInspectionModal = openFaceInspectionModal;
window.closeFaceInspectionModal = closeFaceInspectionModal;
window.handleBiometricFileUpload = handleBiometricFileUpload;

// Finance Globals
window.renderFinancePage = renderFinancePage;
window.renderFinanceRecordsTable = renderFinanceRecordsTable;
window.renderFinanceQueriesTable = renderFinanceQueriesTable;
window.switchFinanceTab = switchFinanceTab;
window.switchDashFinanceTab = switchDashFinanceTab;
window.onFinanceSearchChange = onFinanceSearchChange;
window.resetFinanceFilters = resetFinanceFilters;
window.openRecordPaymentModal = openRecordPaymentModal;
window.closeRecordPaymentModal = closeRecordPaymentModal;
window.handleRecordPaymentSubmit = handleRecordPaymentSubmit;
window.openRespondQueryModal = openRespondQueryModal;
window.closeRespondQueryModal = closeRespondQueryModal;
window.handleRespondQuerySubmit = handleRespondQuerySubmit;
window.openSubmitQueryModal = openSubmitQueryModal;
window.closeSubmitQueryModal = closeSubmitQueryModal;
window.handleQuerySubmit = handleQuerySubmit;
window.openNewExpenseModal = openNewExpenseModal;
window.closeExpenseModal = closeExpenseModal;
window.previewReceiptFile = previewReceiptFile;
window.handleExpenseSubmit = handleExpenseSubmit;
window.openViewVoucherModal = openViewVoucherModal;
window.closeViewVoucherModal = closeViewVoucherModal;
window.exportFinanceCSV = exportFinanceCSV;
window.renderDashboardFinances = renderDashboardFinances;
window.renderAdminOverviewFinances = renderAdminOverviewFinances;



