/**
 * NRTC Safe City Daily Reporting Portal - Historical Data Import Module
 * Handles CSV parsing, template downloading, validation, and database commit.
 */

const SafeCityImport = {
  /**
   * Generates and downloads a clean, pre-structured CSV template for importing old data.
   */
  downloadTemplate() {
    const headers = [
      'Report Date (YYYY-MM-DD)',
      'District Name',
      'NRTC Site Engineer Name',
      'NRTC Employee ID',
      'IPNV Installed',
      'IPNV Online',
      'CEE Installed',
      'CEE Online',
      'DEE Installed',
      'DEE Online',
      'PS Installed',
      'PS Online',
      'DC Installed',
      'DC Online',
      'FRNV Installed',
      'FRNV Online',
      'MCR DR Installed',
      'MCR DR Online',
      'WiFi AP Installed',
      'WiFi AP Online',
      'Panic Installed',
      'Panic Online',
      'Environmental Online',
      'Biometric Online',
      'OFC Cut (Yes/No)',
      'OFC Cut Location',
      'OFC Cut Type',
      'OFC Details',
      'Generator Runtime Hours',
      'Major Daily Activities',
      'IPNV Offline Reason',
      'CEE Offline Reason',
      'RMA Details',
      'Other Issues',
      'Status (SUBMITTED/APPROVED)'
    ];

    const sampleRows = [
      [
        '2026-08-10',
        'Chakwal',
        'Mubasher Hassan',
        'NRTC-ENG-4182',
        '90',
        '88',
        '20',
        '20',
        '10',
        '10',
        '12',
        '12',
        '8',
        '8',
        '12',
        '11',
        '4',
        '4',
        '15',
        '15',
        '6',
        '6',
        '4',
        '5',
        'No',
        '',
        '',
        '',
        '4.5',
        'Routine district monitoring along VIP and market corridors.',
        '2 cameras undergoing wiper replacement',
        '',
        '',
        '',
        'APPROVED'
      ],
      [
        '2026-08-11',
        'Wazirabad',
        'Hamza Kausar',
        'NRTC-ENG-1254',
        '127',
        '124',
        '51',
        '50',
        '450',
        '440',
        '180',
        '175',
        '95',
        '92',
        '250',
        '240',
        '40',
        '40',
        '650',
        '630',
        '120',
        '115',
        '78',
        '88',
        'Yes',
        'Ferozepur Road pole #142',
        'Underground (Excavation)',
        '12-core feeder cable repaired in 2.5 hours',
        '6.0',
        'Metropolitan surveillance during cricket match traffic movement.',
        '190 cameras affected by road expansion',
        '20 units under PTZ motor repair',
        'RMA-LHR-984 sent to lab',
        '',
        'APPROVED'
      ]
    ];

    const csvContent = '\uFEFF' + headers.join(',') + '\n' + sampleRows.map(r => r.map(c => `"${c.replace(/"/g, '""')}"`).join(',')).join('\n');
    const blob = new Blob([csvContent], { type: 'text/csv;charset=utf-8;' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = 'NRTC_PSCA_Historical_Data_Template.csv';
    document.body.appendChild(a);
    a.click();
    document.body.removeChild(a);
    if (typeof showToast === 'function') {
      showToast('Official CSV template downloaded successfully.', 'success');
    }
  },

  /**
   * Parse CSV string into an array of objects
   */
  parseCSV(text) {
    const lines = [];
    let currentLine = [];
    let currentCell = '';
    let inQuotes = false;

    for (let i = 0; i < text.length; i++) {
      const char = text[i];
      const nextChar = text[i + 1];

      if (char === '"') {
        if (inQuotes && nextChar === '"') {
          currentCell += '"';
          i++; // Skip escaped quote
        } else {
          inQuotes = !inQuotes;
        }
      } else if (char === ',' && !inQuotes) {
        currentLine.push(currentCell.trim());
        currentCell = '';
      } else if ((char === '\r' || char === '\n') && !inQuotes) {
        if (char === '\r' && nextChar === '\n') {
          i++; // Skip \n
        }
        currentLine.push(currentCell.trim());
        if (currentLine.some(c => c !== '')) {
          lines.push(currentLine);
        }
        currentLine = [];
        currentCell = '';
      } else {
        currentCell += char;
      }
    }

    if (currentCell || currentLine.length > 0) {
      currentLine.push(currentCell.trim());
      if (currentLine.some(c => c !== '')) {
        lines.push(currentLine);
      }
    }

    if (lines.length < 2) return [];

    const headers = lines[0].map(h => h.toLowerCase().replace(/[^a-z0-9]/g, ''));
    const records = [];

    for (let i = 1; i < lines.length; i++) {
      const row = lines[i];
      const record = {};
      for (let j = 0; j < headers.length; j++) {
        const key = headers[j];
        record[key] = row[j] !== undefined ? row[j] : '';
      }
      records.push(record);
    }

    return records;
  },

  /**
   * Converts parsed rows into standard daily report models with district resolution
   */
  mapRecordsToReports(rawRecords) {
    const validReports = [];
    const errors = [];

    rawRecords.forEach((r, idx) => {
      const rowNum = idx + 2;

      // Extract date
      let dateVal = r.reportdateyyyy || r.reportdate || r.date || '';
      if (!dateVal && r.reportdateyyyymmdd) dateVal = r.reportdateyyyymmdd;

      // Clean date string if needed
      dateVal = dateVal.replace(/\//g, '-');
      if (!/^\d{4}-\d{2}-\d{2}$/.test(dateVal)) {
        // Try parsing DD-MM-YYYY
        const parts = dateVal.split('-');
        if (parts.length === 3 && parts[2].length === 4) {
          dateVal = `${parts[2]}-${parts[1].padStart(2, '0')}-${parts[0].padStart(2, '0')}`;
        }
      }

      if (!dateVal || !/^\d{4}-\d{2}-\d{2}$/.test(dateVal)) {
        errors.push(`Row ${rowNum}: Invalid date format "${dateVal}". Expected YYYY-MM-DD.`);
        return;
      }

      // Extract District
      const distName = r.districtname || r.district || '';
      let district = window.getDistrictByName ? window.getDistrictByName(distName) : null;
      if (!district && window.getDistrictById) {
        district = window.getDistrictById(distName);
      }

      if (!district) {
        errors.push(`Row ${rowNum}: Unknown Punjab district "${distName}". Please use valid district name.`);
        return;
      }

      const ipnvInstalled = parseInt(r.ipnvinstalled) || district.baseIpnw || 90;
      const ipnvOnline = parseInt(r.ipnvonline) || Math.floor(ipnvInstalled * 0.95);

      const ceeInstalled = parseInt(r.ceeinstalled) || district.baseCee || 20;
      const ceeOnline = parseInt(r.ceeonline) || Math.floor(ceeInstalled * 0.95);

      const deeInstalled = parseInt(r.deeinstalled) || district.baseDee || 10;
      const deeOnline = parseInt(r.deeonline) || deeInstalled;

      const report = {
        id: 'rep_hist_' + district.id + '_' + dateVal.replace(/-/g, ''),
        user_id: 'usr_import',
        user_name: r.nrtcsiteengineername || r.siteengineername || r.engineername || 'NRTC Site Lead',
        employee_id: r.nrtcemployeeid || r.employeeid || 'NRTC-ENG-IMPORT',
        contractor: 'NRTC',
        client_authority: 'Punjab Safe Cities Authority (PSCA)',
        district_id: district.id,
        district_name: district.name,
        report_date: dateVal,
        status: (r.status || 'APPROVED').toUpperCase(),
        submitted_at: `${dateVal} 18:00:00`,

        ipnv_installed: ipnvInstalled,
        ipnv_online: Math.min(ipnvOnline, ipnvInstalled),
        cee_installed: ceeInstalled,
        cee_online: Math.min(ceeOnline, ceeInstalled),
        dee_installed: deeInstalled,
        dee_online: Math.min(deeOnline, deeInstalled),
        ps_installed: parseInt(r.psinstalled) || 12,
        ps_online: parseInt(r.psonline) || 12,
        dc_installed: parseInt(r.dcinstalled) || 8,
        dc_online: parseInt(r.dconline) || 8,
        frnv_installed: parseInt(r.frnvinstalled) || 12,
        frnv_online: parseInt(r.frnvonline) || 11,
        mcr_dr_installed: parseInt(r.mcrdrinstalled) || 4,
        mcr_dr_online: parseInt(r.mcrdronline) || 4,

        wifi_installed: parseInt(r.wifiapinstalled) || district.baseWifi || 15,
        wifi_online: parseInt(r.wifiaponline) || Math.max(0, (district.baseWifi || 15) - 1),
        panic_installed: parseInt(r.panicinstalled) || 6,
        panic_online: parseInt(r.paniconline) || 6,
        environmental_installed: 4,
        environmental_online: parseInt(r.environmentalonline) || 4,
        biometric_installed: 5,
        biometric_online: parseInt(r.biometriconline) || 5,

        ofc_cut: (r.ofccutyesno || r.ofccut || 'No').toLowerCase().includes('yes') ? 'Yes' : 'No',
        ofc_location: r.ofccutlocation || '',
        ofc_type: r.ofccuttype || 'None',
        ofc_details: r.ofcdetails || '',

        generator_runtime: parseFloat(r.generatorruntimehours || r.generatorruntime) || 4.5,
        major_daily_activity: r.majordailyactivities || 'Historical daily log imported.',
        ipnv_offline_reason: r.ipnvofflinereason || '',
        cee_offline_reason: r.ceeofflinereason || '',
        rma_details: r.rmadetails || '',
        other_issues: r.otherissues || '',
        admin_remarks: 'Imported historical dataset verified by NRTC PMU.',
        reviewed_by: 'NRTC PMU Audit',
        reviewed_at: `${dateVal} 20:00:00`
      };

      validReports.push(report);
    });

    return { validReports, errors };
  }
};

window.SafeCityImport = SafeCityImport;
window.downloadTemplate = function() {
  SafeCityImport.downloadTemplate();
};
window.downloadCsvTemplate = function() {
  SafeCityImport.downloadTemplate();
};
