const path = require('path');
const XLSX = require('xlsx');

const uploadDir = 'C:\\Users\\mubas\\.gemini\\antigravity\\brain\\786d803e-4a56-4256-8e0f-49f9457a89ad\\.user_uploaded';

['media_1790755975727.xlsx', 'media_1790697626668.xlsx', 'media_1790893556088.xlsx', 'media_1790893556111.xlsx'].forEach(f => {
  const wb = XLSX.readFile(path.join(uploadDir, f));
  console.log(`\n=== ${f} ===`);
  console.log(`Sheets:`, wb.SheetNames);
  if (wb.Sheets['Form Responses 1']) {
    const rows = XLSX.utils.sheet_to_json(wb.Sheets['Form Responses 1']);
    console.log(`  Form Responses 1: ${rows.length} rows`);
  }
  if (wb.Sheets['Tickets Generated']) {
    const rows = XLSX.utils.sheet_to_json(wb.Sheets['Tickets Generated']);
    console.log(`  Tickets Generated: ${rows.length} rows`);
  }
});
