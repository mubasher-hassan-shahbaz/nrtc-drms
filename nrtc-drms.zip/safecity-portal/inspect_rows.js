const path = require('path');
const XLSX = require('xlsx');

const uploadDir = 'C:\\Users\\mubas\\.gemini\\antigravity\\brain\\786d803e-4a56-4256-8e0f-49f9457a89ad\\.user_uploaded';

const wb88 = XLSX.readFile(path.join(uploadDir, 'media_1790893556088.xlsx'));
const ws88_rep = wb88.Sheets['Form Responses 1'];
const ws88_tkt = wb88.Sheets['Tickets Generated'];

const rows88_rep = XLSX.utils.sheet_to_json(ws88_rep);
const rows88_tkt = XLSX.utils.sheet_to_json(ws88_tkt);

console.log('File media_1790893556088.xlsx:');
console.log('  Form Responses 1 count:', rows88_rep.length);
if (rows88_rep.length > 0) {
  console.log('  Form Responses 1 columns:', Object.keys(rows88_rep[0]));
  console.log('  Sample row 0:', rows88_rep[0]);
}
console.log('  Tickets Generated count:', rows88_tkt.length);
if (rows88_tkt.length > 0) {
  console.log('  Tickets Generated columns:', Object.keys(rows88_tkt[0]));
  console.log('  Sample row 0:', rows88_tkt[0]);
}

const wb11 = XLSX.readFile(path.join(uploadDir, 'media_1790893556111.xlsx'));
const rows11_rep = XLSX.utils.sheet_to_json(wb11.Sheets['Form Responses 1']);
console.log('\nFile media_1790893556111.xlsx:');
console.log('  Form Responses 1 count:', rows11_rep.length);
if (rows11_rep.length > 0) {
  console.log('  Form Responses 1 columns:', Object.keys(rows11_rep[0]));
}
