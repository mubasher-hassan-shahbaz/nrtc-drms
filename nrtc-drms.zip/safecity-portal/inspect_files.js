const fs = require('fs');
const path = require('path');
const XLSX = require('xlsx');

const uploadDir = 'C:\\Users\\mubas\\.gemini\\antigravity\\brain\\786d803e-4a56-4256-8e0f-49f9457a89ad\\.user_uploaded';
const files = fs.readdirSync(uploadDir).filter(f => f.endsWith('.xlsx'));

for (const f of files) {
  const filePath = path.join(uploadDir, f);
  const stat = fs.statSync(filePath);
  console.log(`\n========================================`);
  console.log(`FILE: ${f} (${(stat.size / 1024).toFixed(1)} KB)`);
  try {
    const wb = XLSX.readFile(filePath);
    console.log(`Sheets: ${wb.SheetNames.join(', ')}`);
    for (const name of wb.SheetNames) {
      const sheet = wb.Sheets[name];
      const data = XLSX.utils.sheet_to_json(sheet, { header: 1 });
      console.log(`  Sheet [${name}]: ${data.length} rows`);
      if (data.length > 0) {
        console.log(`    Header (first 8):`, JSON.stringify(data[0].slice(0, 8)));
        if (data.length > 1) {
          console.log(`    Row 1 (first 8):`, JSON.stringify(data[1].slice(0, 8)));
        }
      }
    }
  } catch (err) {
    console.error(`Error reading ${f}:`, err.message);
  }
}
